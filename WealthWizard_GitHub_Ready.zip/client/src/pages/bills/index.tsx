import React, { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage,
  FormDescription
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Drawer } from "vaul";
import { 
  Receipt, 
  Add, 
  ElectricBolt, 
  Home, 
  PhoneIphone, 
  Language, 
  LocalHospital,
  School,
  EventNote,
  CheckCircle,
  Schedule 
} from "@mui/icons-material";
import { formatCurrency, formatDate } from "@/lib/utils";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const billSchema = z.object({
  userId: z.number(),
  payee: z.string().min(1, { message: "Payee name is required" }),
  accountNumber: z.string().optional(),
  amount: z.string().min(1, { message: "Amount is required" })
    .refine(val => !isNaN(parseFloat(val)) && parseFloat(val) > 0, {
      message: "Amount must be a positive number"
    }),
  dueDate: z.string().min(1, { message: "Due date is required" }),
  isRecurring: z.boolean().default(false),
  frequency: z.string().optional(),
  category: z.string().optional(),
  providerId: z.string().optional(),
  planDetails: z.string().optional(),
});

export default function Bills() {
  const [activeTab, setActiveTab] = useState("upcoming");
  const [isAddBillOpen, setIsAddBillOpen] = useState(false);
  const [selectedBill, setSelectedBill] = useState<any>(null);
  const [billDetailsOpen, setBillDetailsOpen] = useState(false);
  const [localBills, setLocalBills] = useState<any[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch user data
  const { data: user } = useQuery({
    queryKey: ["/api/auth/me"],
  });
  
  // Fetch accounts
  const { data: accounts = [] } = useQuery({
    queryKey: ["/api/accounts"],
  });
  
  // Fetch bills
  const { data: apiLoadedBills = [], isLoading: isLoadingBills } = useQuery({
    queryKey: ["/api/bills"],
  });
  
  // Example bills for testing UI with detailed category information
  const demoUpcomingBills = [
    {
      id: 1001,
      userId: user?.id,
      payee: "Pacific Electric",
      accountNumber: "76549821",
      amount: 124.56,
      dueDate: "2025-05-15",
      isRecurring: true,
      frequency: "monthly",
      category: "utilities",
      status: "pending",
      details: {
        paymentMethod: "ACH Direct Debit",
        billingAddress: "123 Oak Street, Anytown, CA 90210",
        accountType: "Residential",
        customerSince: "2019-05-10",
        lastMeterReading: "58295 kWh",
        serviceDescription: "Electricity and Gas Services",
        serviceAddress: "123 Oak Street, Anytown, CA 90210",
        customerService: "1-800-555-0123",
        statementDate: "2025-04-18",
        billingPeriod: "2025-03-15 to 2025-04-15"
      }
    },
    {
      id: 1002,
      userId: user?.id,
      payee: "City Water Services",
      accountNumber: "WTR-45678",
      amount: 78.90,
      dueDate: "2025-05-10",
      isRecurring: true,
      frequency: "monthly",
      category: "utilities",
      status: "pending",
      details: {
        paymentMethod: "Autopay",
        billingAddress: "123 Oak Street, Anytown, CA 90210",
        accountType: "Residential",
        customerSince: "2019-05-15",
        lastMeterReading: "12580 gal",
        serviceDescription: "Water and Sewer Services",
        serviceAddress: "123 Oak Street, Anytown, CA 90210",
        customerService: "1-800-555-7890",
        statementDate: "2025-04-15",
        billingPeriod: "2025-03-10 to 2025-04-10"
      }
    },
    {
      id: 1003,
      userId: user?.id,
      payee: "Woodland Apartments",
      accountNumber: "APT-112233",
      amount: 1850.00,
      dueDate: "2025-05-01",
      isRecurring: true,
      frequency: "monthly",
      category: "rent",
      status: "pending",
      details: {
        paymentMethod: "Direct Deposit",
        billingAddress: "123 Oak Street, Apt 4B, Anytown, CA 90210",
        accountType: "Residential Lease",
        customerSince: "2022-08-01",
        leaseEnd: "2025-07-31",
        serviceDescription: "Monthly Rent for Apartment 4B",
        propertyManager: "Jane Smith",
        customerService: "1-800-555-4567",
        statementDate: "2025-04-20",
        billingPeriod: "2025-05-01 to 2025-05-31",
        latePaymentFee: "$50 after the 5th"
      }
    }
  ];
  
  const demoPaidBills = [
    {
      id: 1004,
      userId: user?.id,
      payee: "Pacific Electric",
      accountNumber: "76549821",
      amount: 118.42,
      dueDate: "2025-04-15",
      isRecurring: true,
      frequency: "monthly",
      category: "utilities",
      status: "paid",
      details: {
        paymentMethod: "ACH Direct Debit",
        billingAddress: "123 Oak Street, Anytown, CA 90210",
        accountType: "Residential",
        customerSince: "2019-05-10",
        lastMeterReading: "57843 kWh",
        serviceDescription: "Electricity and Gas Services",
        serviceAddress: "123 Oak Street, Anytown, CA 90210",
        customerService: "1-800-555-0123",
        statementDate: "2025-03-18",
        billingPeriod: "2025-02-15 to 2025-03-15",
        paymentConfirmation: "PE-2504150789",
        paymentDate: "2025-04-15"
      }
    },
    {
      id: 1005,
      userId: user?.id,
      payee: "Northeast Internet",
      accountNumber: "NET-98765",
      amount: 89.99,
      dueDate: "2025-04-12",
      isRecurring: true,
      frequency: "monthly",
      category: "internet",
      status: "paid",
      details: {
        paymentMethod: "Credit Card",
        billingAddress: "123 Oak Street, Anytown, CA 90210",
        accountType: "Residential Fiber",
        customerSince: "2020-01-15",
        planDetails: "Gigabit Fiber Plan",
        serviceDescription: "Internet and Streaming Services",
        serviceAddress: "123 Oak Street, Anytown, CA 90210",
        customerService: "1-800-555-8765",
        statementDate: "2025-03-28",
        billingPeriod: "2025-03-12 to 2025-04-12",
        paymentConfirmation: "NI-2504120345",
        paymentDate: "2025-04-12"
      }
    },
    {
      id: 1006,
      userId: user?.id,
      payee: "Cell Mobile",
      accountNumber: "CELL-88774455",
      amount: 110.50,
      dueDate: "2025-04-05",
      isRecurring: true,
      frequency: "monthly",
      category: "phone",
      status: "paid",
      details: {
        paymentMethod: "Bank Account",
        billingAddress: "123 Oak Street, Anytown, CA 90210",
        accountType: "Family Plan",
        customerSince: "2018-06-22",
        planDetails: "Unlimited Talk, Text & Data",
        serviceDescription: "Mobile Phone Services - 2 lines",
        devicePayment: "$25.00/month included",
        customerService: "1-800-555-2345",
        statementDate: "2025-03-20",
        billingPeriod: "2025-03-05 to 2025-04-05",
        paymentConfirmation: "CM-2504050123",
        paymentDate: "2025-04-04"
      }
    }
  ];
  
  // Combine API loaded bills with demo bills
  const bills = [...apiLoadedBills, ...(apiLoadedBills.length === 0 ? [...demoUpcomingBills, ...demoPaidBills] : [])];
  
  // Initialize local bills state from combined bills when first loaded
  useEffect(() => {
    if (bills.length > 0 && localBills.length === 0) {
      setLocalBills(bills);
    }
  }, [bills, localBills.length]);
  
  // Use local state for bills if available, otherwise use API-loaded bills
  const displayBills = localBills.length > 0 ? localBills : bills;
  
  // Filter bills based on active tab
  const upcomingBills = displayBills.filter((bill: any) => bill.status === "pending");
  const paidBills = displayBills.filter((bill: any) => bill.status === "paid");
  
  // Bill categories
  const billCategories = [
    { id: "utilities", name: "Utilities", icon: <ElectricBolt /> },
    { id: "rent", name: "Rent/Mortgage", icon: <Home /> },
    { id: "phone", name: "Phone", icon: <PhoneIphone /> },
    { id: "internet", name: "Internet", icon: <Language /> },
    { id: "medical", name: "Medical", icon: <LocalHospital /> },
    { id: "education", name: "Education", icon: <School /> },
    { id: "other", name: "Other", icon: <Receipt /> },
  ];
  
  // Category-specific providers and options
  const phoneProviders = [
    { id: "tmobile", name: "T-Mobile", plan: "Magenta MAX", price: 85.00 },
    { id: "verizon", name: "Verizon", plan: "Unlimited Plus", price: 80.00 },
    { id: "att", name: "AT&T", plan: "Unlimited Premium", price: 75.00 },
    { id: "puretalk", name: "Pure Talk", plan: "Unlimited", price: 40.00 },
    { id: "mint", name: "Mint Mobile", plan: "Unlimited", price: 30.00 },
    { id: "visible", name: "Visible", plan: "Visible+", price: 45.00 },
    { id: "cricket", name: "Cricket Wireless", plan: "Unlimited", price: 55.00 },
    { id: "boost", name: "Boost Mobile", plan: "Unlimited", price: 50.00 },
  ];
  
  const internetProviders = [
    { id: "comcast", name: "Comcast Xfinity", plan: "Gigabit", price: 89.99 },
    { id: "att_fiber", name: "AT&T Fiber", plan: "Internet 1000", price: 80.00 },
    { id: "spectrum", name: "Spectrum", plan: "Gig", price: 89.99 },
    { id: "verizon_fios", name: "Verizon Fios", plan: "Gigabit Connection", price: 89.99 },
    { id: "cox", name: "Cox", plan: "Gigablast", price: 99.99 },
    { id: "century_link", name: "CenturyLink", plan: "Fiber Gigabit", price: 65.00 },
    { id: "frontier", name: "Frontier", plan: "Fiber Gig", price: 74.99 },
    { id: "optimum", name: "Optimum", plan: "Gig", price: 79.99 },
  ];
  
  const utilityProviders = [
    { id: "pge", name: "Pacific Gas & Electric", service: "Electricity & Gas", avgBill: 150.00 },
    { id: "socal_edison", name: "Southern California Edison", service: "Electricity", avgBill: 120.00 },
    { id: "sdge", name: "San Diego Gas & Electric", service: "Electricity & Gas", avgBill: 140.00 },
    { id: "ladwp", name: "Los Angeles DWP", service: "Water & Power", avgBill: 130.00 },
    { id: "cwater", name: "City Water Services", service: "Water", avgBill: 80.00 },
    { id: "amwater", name: "American Water", service: "Water & Sewage", avgBill: 85.00 },
    { id: "waste_mgmt", name: "Waste Management", service: "Trash & Recycling", avgBill: 45.00 },
    { id: "republic", name: "Republic Services", service: "Trash & Recycling", avgBill: 40.00 },
  ];
  
  const propertyTypes = [
    { id: "apartment", name: "Apartment", avgRent: 1850.00 },
    { id: "house", name: "House", avgRent: 2500.00 },
    { id: "condo", name: "Condominium", avgRent: 2100.00 },
    { id: "townhouse", name: "Townhouse", avgRent: 2200.00 },
    { id: "duplex", name: "Duplex", avgRent: 1900.00 },
    { id: "studio", name: "Studio", avgRent: 1400.00 },
    { id: "room", name: "Room", avgRent: 900.00 },
    { id: "other_rental", name: "Other Rental", avgRent: 1800.00 },
  ];
  
  const billForm = useForm<z.infer<typeof billSchema>>({
    resolver: zodResolver(billSchema),
    defaultValues: {
      userId: user?.id,
      payee: "",
      accountNumber: "",
      amount: "",
      dueDate: "",
      isRecurring: false,
      frequency: "monthly",
      category: "utilities",
    }
  });
  
  // Bill payment mutation
  const billMutation = useMutation({
    mutationFn: (data: any) => {
      return apiRequest("POST", "/api/bills", data);
    },
    onSuccess: () => {
      // Invalidate queries
      queryClient.invalidateQueries({ queryKey: ["/api/bills"] });
      
      // Reset form and close dialog
      billForm.reset();
      setIsAddBillOpen(false);
      
      // Show success toast
      toast({
        title: "Bill added successfully",
        description: "Your bill has been added to your payment schedule.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to add bill",
        description: error.message || "There was an error adding your bill.",
        variant: "destructive",
      });
    }
  });
  
  // Pay bill mutation
  const payBillMutation = useMutation({
    mutationFn: (billId: number) => {
      // If it's a demo bill (ID > 1000), simulate a successful API call
      if (billId > 1000) {
        return new Promise<Response>((resolve) => {
          setTimeout(() => {
            resolve(new Response(JSON.stringify({ success: true })));
          }, 800);
        });
      }
      // Otherwise, make the real API call
      return apiRequest("PATCH", `/api/bills/${billId}`, { status: "paid" });
    },
    onSuccess: () => {
      // Invalidate queries
      queryClient.invalidateQueries({ queryKey: ["/api/bills"] });
    },
    onError: (error: any) => {
      toast({
        title: "Payment failed",
        description: error.message || "There was an error processing your payment.",
        variant: "destructive",
      });
    }
  });
  
  const onAddBillSubmit = (values: z.infer<typeof billSchema>) => {
    if (!user?.id) return;
    
    // For demo purposes, create a new bill directly in local state
    const newBillId = Math.max(...displayBills.map((bill: any) => bill.id || 0), 1000) + 1;
    
    const category = values.category || "utilities";
    
    // Create category-specific details
    let specificDetails: any = {};
    
    // Add category-specific details based on the bill category
    if (category === "phone") {
      // Find the provider information
      const provider = phoneProviders.find(p => p.id === values.providerId) || phoneProviders[0];
      specificDetails = {
        planDetails: values.planDetails || provider.plan,
        providerId: values.providerId,
        devicePayment: "$25.00/month included",
      };
    } else if (category === "internet") {
      // Find the provider information
      const provider = internetProviders.find(p => p.id === values.providerId) || internetProviders[0];
      specificDetails = {
        planDetails: values.planDetails || provider.plan,
        providerId: values.providerId,
        connectionType: "Fiber",
      };
    } else if (category === "utilities") {
      // Find the provider information
      const provider = utilityProviders.find(p => p.id === values.providerId) || utilityProviders[0];
      specificDetails = {
        lastMeterReading: provider.service.includes("Water") ? "1260 gal" : "5830 kWh",
        serviceType: provider.service,
        providerId: values.providerId,
      };
    } else if (category === "rent") {
      // Find the property type
      const property = propertyTypes.find(p => p.id === values.providerId) || propertyTypes[0];
      specificDetails = {
        propertyType: property.name,
        leaseEnd: new Date(new Date().setFullYear(new Date().getFullYear() + 1)).toISOString().split('T')[0],
        propertyManager: "Property Manager",
        latePaymentFee: "$50 after the 5th",
        providerId: values.providerId,
      };
    }
    
    const newBill = {
      id: newBillId,
      userId: user.id,
      payee: values.payee,
      accountNumber: values.accountNumber || "",
      amount: parseFloat(values.amount),
      dueDate: values.dueDate,
      isRecurring: values.isRecurring,
      frequency: values.frequency || "monthly",
      category: category,
      status: "pending",
      details: {
        paymentMethod: "ACH Direct Debit",
        billingAddress: "123 Oak Street, Anytown, CA 90210",
        accountType: category === "utilities" ? "Residential" : 
                    category === "rent" ? "Residential Lease" : 
                    category === "phone" ? "Mobile Service" : 
                    category === "internet" ? "Home Internet" : "Standard",
        customerSince: new Date().toISOString().split('T')[0],
        serviceDescription: `${values.payee} - ${category.charAt(0).toUpperCase() + category.slice(1)} Service`,
        statementDate: new Date().toISOString().split('T')[0],
        billingPeriod: `${values.dueDate} to ${new Date(new Date(values.dueDate).getTime() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]}`,
        customerService: "1-800-555-" + Math.floor(1000 + Math.random() * 9000),
        ...specificDetails,
      }
    };
    
    // Add the new bill to local state
    setLocalBills(prev => [...prev, newBill]);
    
    // Close dialog and show success message
    setIsAddBillOpen(false);
    
    // Show success toast
    toast({
      title: "Bill added successfully",
      description: "Your bill has been added to your payment schedule.",
    });
    
    // Reset form
    billForm.reset();
    
    // Only call API if we're in a real environment
    if (Array.isArray(apiLoadedBills) && apiLoadedBills.length > 0) {
      billMutation.mutate({
        ...values,
        userId: user.id,
        amount: parseFloat(values.amount).toString(),
      });
    }
  };
  
  const handlePayBill = (billId: number) => {
    payBillMutation.mutate(billId);
    
    // Update the local state directly for all bills
    setLocalBills(prev => 
      prev.length > 0 ? 
        prev.map((bill: any) => {
          if (bill.id === billId) {
            // Create a paid version of the bill
            const paidBill = { 
              ...bill, 
              status: "paid",
              // Add payment details if they don't exist
              details: {
                ...bill.details,
                paymentConfirmation: bill.details?.paymentConfirmation || `FC-${Date.now().toString().slice(-10)}`,
                paymentDate: new Date().toISOString().split('T')[0]
              }
            };
            return paidBill;
          }
          return bill;
        }) 
        : []
    );
    
    // Close the bill details dialog if open
    setBillDetailsOpen(false);
    
    // Show success message after a brief delay
    setTimeout(() => {
      toast({
        title: "Payment successful",
        description: "Your bill payment has been processed.",
      });
    }, 800);
  };
  
  const getBillCategoryIcon = (category: string) => {
    const foundCategory = billCategories.find(cat => cat.id === category);
    if (!foundCategory) return <Receipt />;
    return foundCategory.icon;
  };
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow bg-neutral-50 dark:bg-neutral-900">
        <div className="container mx-auto px-4 py-6">
          {/* Page Header */}
          <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-neutral-900 dark:text-white">Bill Pay</h1>
              <p className="text-neutral-600 dark:text-neutral-400 mt-1">
                Manage and pay your bills in one place
              </p>
            </div>
            <Button onClick={() => setIsAddBillOpen(true)} className="flex items-center gap-2">
              <Add className="h-4 w-4" />
              Add Bill
            </Button>
          </div>
          
          {/* Bill Categories */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-4 mb-8">
            {billCategories.map((category) => (
              <Card key={category.id} className="cursor-pointer hover:shadow-md transition-shadow h-full">
                <CardContent className="p-4 flex flex-col items-center justify-center text-center">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-2">
                    {React.cloneElement(category.icon as React.ReactElement, { className: "text-primary" })}
                  </div>
                  <span className="text-sm font-medium">{category.name}</span>
                </CardContent>
              </Card>
            ))}
          </div>
          
          {/* Bills Tabs */}
          <Card className="mb-8">
            <CardHeader className="pb-0">
              <Tabs defaultValue={activeTab} value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="upcoming">Upcoming Bills</TabsTrigger>
                  <TabsTrigger value="history">Payment History</TabsTrigger>
                </TabsList>
              
                <CardContent className="pt-6">
                  <TabsContent value="upcoming">
                    {isLoadingBills ? (
                      <div className="flex justify-center py-8">
                        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                      </div>
                    ) : upcomingBills.length === 0 ? (
                      <div className="text-center py-8 text-neutral-500 dark:text-neutral-400">
                        <div className="w-16 h-16 rounded-full bg-neutral-100 dark:bg-neutral-800 mx-auto flex items-center justify-center mb-4">
                          <Receipt className="h-8 w-8 text-neutral-500 dark:text-neutral-400" />
                        </div>
                        <p className="mb-4">No upcoming bills found</p>
                        <Button variant="outline" onClick={() => setIsAddBillOpen(true)}>
                          Add Your First Bill
                        </Button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {upcomingBills.map((bill: any) => (
                          <div 
                            key={bill.id} 
                            className="flex items-center justify-between p-4 border border-neutral-200 dark:border-neutral-700 rounded-lg hover:bg-neutral-50 dark:hover:bg-neutral-800 cursor-pointer"
                            onClick={() => {
                              setSelectedBill(bill);
                              setBillDetailsOpen(true);
                            }}
                          >
                            <div className="flex items-center">
                              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mr-4">
                                {getBillCategoryIcon(bill.category)}
                              </div>
                              <div>
                                <h3 className="font-medium">{bill.payee}</h3>
                                <div className="flex items-center gap-2 text-sm text-neutral-500 dark:text-neutral-400">
                                  <span>Due {formatDate(bill.dueDate)}</span>
                                  {bill.isRecurring && (
                                    <>
                                      <span>•</span>
                                      <span className="flex items-center">
                                        <Schedule className="h-3 w-3 mr-1" />
                                        {bill.frequency}
                                      </span>
                                    </>
                                  )}
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center gap-4">
                              <span className="font-semibold">{formatCurrency(bill.amount)}</span>
                              <Button 
                                onClick={(e) => {
                                  e.stopPropagation(); // Prevent opening details when clicking the button
                                  handlePayBill(bill.id);
                                }} 
                                disabled={payBillMutation.isPending}
                              >
                                Pay Now
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </TabsContent>
                  
                  <TabsContent value="history">
                    {isLoadingBills ? (
                      <div className="flex justify-center py-8">
                        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                      </div>
                    ) : paidBills.length === 0 ? (
                      <div className="text-center py-8 text-neutral-500 dark:text-neutral-400">
                        <div className="w-16 h-16 rounded-full bg-neutral-100 dark:bg-neutral-800 mx-auto flex items-center justify-center mb-4">
                          <Receipt className="h-8 w-8 text-neutral-500 dark:text-neutral-400" />
                        </div>
                        <p>No payment history found</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {paidBills.map((bill: any) => (
                          <div 
                            key={bill.id} 
                            className="flex items-center justify-between p-4 border border-neutral-200 dark:border-neutral-700 rounded-lg hover:bg-neutral-50 dark:hover:bg-neutral-800 cursor-pointer"
                            onClick={() => {
                              setSelectedBill(bill);
                              setBillDetailsOpen(true);
                            }}
                          >
                            <div className="flex items-center">
                              <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center mr-4">
                                <CheckCircle className="text-green-600 dark:text-green-400" />
                              </div>
                              <div>
                                <h3 className="font-medium">{bill.payee}</h3>
                                <div className="flex items-center gap-2 text-sm text-neutral-500 dark:text-neutral-400">
                                  <span>Paid on {formatDate(bill.dueDate)}</span>
                                </div>
                              </div>
                            </div>
                            <span className="font-semibold">{formatCurrency(bill.amount)}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </TabsContent>
                </CardContent>
              </Tabs>
            </CardHeader>
          </Card>
          
          {/* Payment Center */}
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <Card>
              <CardHeader>
                <CardTitle>Payment Center</CardTitle>
                <CardDescription>Pay bills to registered or new payees</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800 rounded-lg p-4 text-sm text-blue-700 dark:text-blue-300">
                    <div className="flex items-start gap-3">
                      <div className="bg-blue-200 dark:bg-blue-800 rounded-full p-1.5 mt-0.5">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                          <polyline points="22 4 12 14.01 9 11.01"></polyline>
                        </svg>
                      </div>
                      <div>
                        <span className="font-medium">Payments are processed securely through ACH</span>
                        <p className="mt-1 text-xs text-blue-600 dark:text-blue-400">Typically takes 1-3 business days to complete transfers</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h3 className="text-sm font-medium">Common Payees</h3>
                    <div className="grid grid-cols-2 gap-2">
                      {billCategories.slice(0, 4).map((category) => (
                        <Button
                          key={category.id}
                          variant="outline"
                          className="justify-start h-auto py-3 px-4"
                          onClick={() => setIsAddBillOpen(true)}
                        >
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                              {React.cloneElement(category.icon as React.ReactElement, { className: "text-primary h-4 w-4" })}
                            </div>
                            <span className="text-sm">{category.name}</span>
                          </div>
                        </Button>
                      ))}
                    </div>
                    
                    <Button
                      variant="ghost"
                      className="w-full justify-center text-sm mt-2"
                      onClick={() => setIsAddBillOpen(true)}
                    >
                      View All Payees
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Financial Insights</CardTitle>
                <CardDescription>Manage your bills with detailed tracking</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="bg-neutral-50 dark:bg-neutral-800 rounded-lg p-4 border border-neutral-200 dark:border-neutral-700">
                    <h3 className="text-sm font-medium mb-1">Total Due</h3>
                    <p className="text-2xl font-bold">{formatCurrency(upcomingBills.reduce((total: number, bill: any) => total + parseFloat(bill.amount), 0))}</p>
                    <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">Due this month</p>
                  </div>
                  
                  <div className="bg-neutral-50 dark:bg-neutral-800 rounded-lg p-4 border border-neutral-200 dark:border-neutral-700">
                    <h3 className="text-sm font-medium mb-2">Bills by Category</h3>
                    {upcomingBills.length === 0 ? (
                      <p className="text-sm text-neutral-500 dark:text-neutral-400">No bill data available</p>
                    ) : (
                      <div className="space-y-3">
                        {/* Rent/Mortgage */}
                        <div className="text-sm">
                          <div className="flex items-center justify-between text-xs mb-1">
                            <span className="flex items-center gap-1.5">
                              <Home className="h-3 w-3" />
                              {billCategories[1].name}
                            </span>
                            <span>{Math.round(1850 / 2053.46 * 100)}%</span>
                          </div>
                          <div className="h-2 w-full bg-neutral-200 dark:bg-neutral-700 rounded-full overflow-hidden">
                            <div className="h-full bg-amber-500" style={{ width: `${Math.round(1850 / 2053.46 * 100)}%` }}></div>
                          </div>
                        </div>
                        
                        {/* Utilities */}
                        <div className="text-sm">
                          <div className="flex items-center justify-between text-xs mb-1">
                            <span className="flex items-center gap-1.5">
                              <ElectricBolt className="h-3 w-3" />
                              {billCategories[0].name}
                            </span>
                            <span>{Math.round((124.56 + 78.90) / 2053.46 * 100)}%</span>
                          </div>
                          <div className="h-2 w-full bg-neutral-200 dark:bg-neutral-700 rounded-full overflow-hidden">
                            <div className="h-full bg-blue-500" style={{ width: `${Math.round((124.56 + 78.90) / 2053.46 * 100)}%` }}></div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                  
                  <div className="bg-neutral-50 dark:bg-neutral-800 rounded-lg p-4 border border-neutral-200 dark:border-neutral-700">
                    <h3 className="text-sm font-medium mb-2">Payment Methods</h3>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-primary"></div>
                        <span className="text-xs">Primary Checking (****{accounts[0]?.accountNumber || "4582"})</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-neutral-400"></div>
                        <span className="text-xs">Credit Card (****2468)</span>
                      </div>
                      <Button variant="outline" size="sm" className="text-xs w-full">
                        Manage Payment Methods
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      
      <Footer />
      
      {/* Bill Details Drawer */}
      <Drawer.Root
        open={billDetailsOpen}
        onOpenChange={setBillDetailsOpen}
        onClose={() => setBillDetailsOpen(false)}
        shouldScaleBackground
      >
        <Drawer.Portal>
          <Drawer.Overlay className="fixed inset-0 bg-black/40" />
          <Drawer.Content className="fixed bottom-0 left-0 right-0 mt-24 flex h-[90%] flex-col rounded-t-[10px] bg-white dark:bg-neutral-950">
            <div className="flex-1 overflow-y-auto rounded-t-[10px] p-4">
              <div className="mx-auto mb-8 h-1.5 w-12 flex-shrink-0 rounded-full bg-neutral-300 dark:bg-neutral-700" />
              
              {selectedBill && (
                <div className="mx-auto max-w-2xl space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        {getBillCategoryIcon(selectedBill.category)}
                      </div>
                      <div>
                        <h2 className="text-xl font-semibold">{selectedBill.payee}</h2>
                        <p className="text-sm text-neutral-500 dark:text-neutral-400">
                          {billCategories.find(cat => cat.id === selectedBill.category)?.name || "Other"}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold">{formatCurrency(selectedBill.amount)}</p>
                      <p className="text-sm text-neutral-500 dark:text-neutral-400">
                        {selectedBill.status === "paid" ? "Paid" : "Due"} {formatDate(selectedBill.dueDate)}
                      </p>
                    </div>
                  </div>
                  
                  {/* Bill Status */}
                  <div className={`${
                    selectedBill.status === "paid" 
                      ? "bg-green-50 dark:bg-green-900/20 border-green-100 dark:border-green-800 text-green-700 dark:text-green-300" 
                      : "bg-amber-50 dark:bg-amber-900/20 border-amber-100 dark:border-amber-800 text-amber-700 dark:text-amber-300"
                    } border rounded-lg p-3 flex items-center gap-3`}
                  >
                    {selectedBill.status === "paid" ? (
                      <CheckCircle className="h-5 w-5" />
                    ) : (
                      <Schedule className="h-5 w-5" />
                    )}
                    <div>
                      <p className="font-medium">
                        {selectedBill.status === "paid" 
                          ? "Payment Completed" 
                          : "Payment Scheduled"}
                      </p>
                      <p className="text-xs mt-0.5">
                        {selectedBill.status === "paid" 
                          ? `Paid on ${formatDate(selectedBill.dueDate)}` 
                          : `Due on ${formatDate(selectedBill.dueDate)}`}
                      </p>
                    </div>
                  </div>
                  
                  {/* Basic Bill Information */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {selectedBill.accountNumber && (
                      <div>
                        <h3 className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Account Number</h3>
                        <p className="font-mono text-base">{selectedBill.accountNumber}</p>
                      </div>
                    )}
                    
                    <div>
                      <h3 className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Payment Type</h3>
                      <p className="text-base">
                        {selectedBill.isRecurring ? (
                          <span className="flex items-center gap-1.5">
                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
                              <path d="M3 3v5h5" />
                              <path d="M12 7v5l4 2" />
                            </svg>
                            Recurring ({selectedBill.frequency})
                          </span>
                        ) : "One-time payment"}
                      </p>
                    </div>
                    
                    <div>
                      <h3 className="text-sm font-medium text-neutral-500 dark:text-neutral-400">From Account</h3>
                      <p className="text-base">Primary Checking (****{accounts[0]?.accountNumber || "0000"})</p>
                    </div>
                    
                    {selectedBill.details?.paymentConfirmation && (
                      <div>
                        <h3 className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Confirmation</h3>
                        <p className="font-mono text-base">{selectedBill.details.paymentConfirmation}</p>
                      </div>
                    )}
                  </div>
                  
                  {/* Category-specific details */}
                  <div className="border border-neutral-200 dark:border-neutral-700 rounded-lg overflow-hidden">
                    <div className="bg-neutral-100 dark:bg-neutral-800 px-4 py-3 border-b border-neutral-200 dark:border-neutral-700">
                      <h3 className="font-medium">Account Details</h3>
                    </div>
                    <div className="p-4 space-y-4">
                      {/* Common details for all categories */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-3 text-sm">
                        <div>
                          <span className="text-neutral-500 dark:text-neutral-400">Account Type</span>
                          <p className="font-medium mt-0.5">{selectedBill.details?.accountType}</p>
                        </div>
                        
                        <div>
                          <span className="text-neutral-500 dark:text-neutral-400">Customer Since</span>
                          <p className="font-medium mt-0.5">{formatDate(selectedBill.details?.customerSince)}</p>
                        </div>
                        
                        <div className="col-span-2">
                          <span className="text-neutral-500 dark:text-neutral-400">Billing Address</span>
                          <p className="font-medium mt-0.5">{selectedBill.details?.billingAddress}</p>
                        </div>
                        
                        <div className="col-span-2">
                          <span className="text-neutral-500 dark:text-neutral-400">Billing Period</span>
                          <p className="font-medium mt-0.5">{selectedBill.details?.billingPeriod}</p>
                        </div>
                      </div>
                      
                      {/* Phone-specific details */}
                      {selectedBill.category === "phone" && (
                        <div className="mt-4 pt-4 border-t border-neutral-200 dark:border-neutral-700">
                          <h4 className="font-medium mb-3">Service Details</h4>
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <span className="text-neutral-500 dark:text-neutral-400">Plan</span>
                              <span className="font-medium">{selectedBill.details?.planDetails}</span>
                            </div>
                            
                            <div className="flex flex-col gap-2">
                              <span className="text-neutral-500 dark:text-neutral-400">Choose Provider</span>
                              <div className="grid grid-cols-2 gap-2">
                                {phoneProviders.slice(0, 4).map(provider => (
                                  <div 
                                    key={provider.id}
                                    className={`border rounded px-3 py-2 text-xs cursor-pointer ${
                                      provider.name === selectedBill.payee 
                                        ? "border-primary bg-primary/5" 
                                        : "border-neutral-200 dark:border-neutral-700"
                                    }`}
                                  >
                                    <div className="font-medium">{provider.name}</div>
                                    <div className="text-neutral-500 dark:text-neutral-400 mt-1">{provider.plan}</div>
                                  </div>
                                ))}
                              </div>
                            </div>
                            
                            {selectedBill.details?.devicePayment && (
                              <div className="flex items-center justify-between">
                                <span className="text-neutral-500 dark:text-neutral-400">Device Payment</span>
                                <span className="font-medium">{selectedBill.details.devicePayment}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                      
                      {/* Internet-specific details */}
                      {selectedBill.category === "internet" && (
                        <div className="mt-4 pt-4 border-t border-neutral-200 dark:border-neutral-700">
                          <h4 className="font-medium mb-3">Service Details</h4>
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <span className="text-neutral-500 dark:text-neutral-400">Plan</span>
                              <span className="font-medium">{selectedBill.details?.planDetails}</span>
                            </div>
                            
                            <div className="flex flex-col gap-2">
                              <span className="text-neutral-500 dark:text-neutral-400">Choose Provider</span>
                              <div className="grid grid-cols-2 gap-2">
                                {internetProviders.slice(0, 4).map(provider => (
                                  <div 
                                    key={provider.id}
                                    className={`border rounded px-3 py-2 text-xs cursor-pointer ${
                                      provider.name === selectedBill.payee 
                                        ? "border-primary bg-primary/5" 
                                        : "border-neutral-200 dark:border-neutral-700"
                                    }`}
                                  >
                                    <div className="font-medium">{provider.name}</div>
                                    <div className="text-neutral-500 dark:text-neutral-400 mt-1">{provider.plan}</div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                      
                      {/* Utilities-specific details */}
                      {selectedBill.category === "utilities" && (
                        <div className="mt-4 pt-4 border-t border-neutral-200 dark:border-neutral-700">
                          <h4 className="font-medium mb-3">Utility Details</h4>
                          <div className="space-y-3">
                            {selectedBill.details?.lastMeterReading && (
                              <div className="flex items-center justify-between">
                                <span className="text-neutral-500 dark:text-neutral-400">Last Meter Reading</span>
                                <span className="font-medium">{selectedBill.details.lastMeterReading}</span>
                              </div>
                            )}
                            
                            <div className="flex flex-col gap-2">
                              <span className="text-neutral-500 dark:text-neutral-400">Choose Provider</span>
                              <div className="grid grid-cols-2 gap-2">
                                {utilityProviders.slice(0, 4).map(provider => (
                                  <div 
                                    key={provider.id}
                                    className={`border rounded px-3 py-2 text-xs cursor-pointer ${
                                      provider.name === selectedBill.payee 
                                        ? "border-primary bg-primary/5" 
                                        : "border-neutral-200 dark:border-neutral-700"
                                    }`}
                                  >
                                    <div className="font-medium">{provider.name}</div>
                                    <div className="text-neutral-500 dark:text-neutral-400 mt-1">{provider.service}</div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                      
                      {/* Rent-specific details */}
                      {selectedBill.category === "rent" && (
                        <div className="mt-4 pt-4 border-t border-neutral-200 dark:border-neutral-700">
                          <h4 className="font-medium mb-3">Property Details</h4>
                          <div className="space-y-3">
                            {selectedBill.details?.leaseEnd && (
                              <div className="flex items-center justify-between">
                                <span className="text-neutral-500 dark:text-neutral-400">Lease End Date</span>
                                <span className="font-medium">{formatDate(selectedBill.details.leaseEnd)}</span>
                              </div>
                            )}
                            
                            {selectedBill.details?.propertyManager && (
                              <div className="flex items-center justify-between">
                                <span className="text-neutral-500 dark:text-neutral-400">Property Manager</span>
                                <span className="font-medium">{selectedBill.details.propertyManager}</span>
                              </div>
                            )}
                            
                            {selectedBill.details?.latePaymentFee && (
                              <div className="flex items-center justify-between">
                                <span className="text-neutral-500 dark:text-neutral-400">Late Payment Fee</span>
                                <span className="font-medium">{selectedBill.details.latePaymentFee}</span>
                              </div>
                            )}
                            
                            <div className="flex flex-col gap-2">
                              <span className="text-neutral-500 dark:text-neutral-400">Property Type</span>
                              <div className="grid grid-cols-2 gap-2">
                                {propertyTypes.slice(0, 4).map(property => (
                                  <div 
                                    key={property.id}
                                    className={`border rounded px-3 py-2 text-xs cursor-pointer ${
                                      property.id === "apartment" 
                                        ? "border-primary bg-primary/5" 
                                        : "border-neutral-200 dark:border-neutral-700"
                                    }`}
                                  >
                                    <div className="font-medium">{property.name}</div>
                                    <div className="text-neutral-500 dark:text-neutral-400 mt-1">{formatCurrency(property.avgRent)}/mo avg</div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {/* Payment Timeline */}
                  <div>
                    <h3 className="text-sm font-medium mb-3">Payment Timeline</h3>
                    <div className="relative border-l-2 border-neutral-200 dark:border-neutral-700 pl-6 pb-2 ml-3">
                      <div className="mb-4 relative">
                        <div className="absolute -left-[29px] w-5 h-5 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center">
                          <CheckCircle className="h-3 w-3 text-green-600 dark:text-green-400" />
                        </div>
                        <h4 className="text-sm font-medium">Payment Created</h4>
                        <p className="text-xs text-neutral-500 dark:text-neutral-400">
                          {formatDate(new Date(new Date(selectedBill.dueDate).getTime() - 7 * 24 * 60 * 60 * 1000))}
                        </p>
                      </div>
                      
                      {selectedBill.status === "paid" ? (
                        <div className="mb-4 relative">
                          <div className="absolute -left-[29px] w-5 h-5 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center">
                            <CheckCircle className="h-3 w-3 text-green-600 dark:text-green-400" />
                          </div>
                          <h4 className="text-sm font-medium">Payment Processed</h4>
                          <p className="text-xs text-neutral-500 dark:text-neutral-400">
                            {selectedBill.details?.paymentDate ? formatDate(selectedBill.details.paymentDate) : formatDate(selectedBill.dueDate)}
                          </p>
                        </div>
                      ) : (
                        <div className="mb-4 relative">
                          <div className="absolute -left-[29px] w-5 h-5 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center">
                            <Schedule className="h-3 w-3 text-blue-600 dark:text-blue-400" />
                          </div>
                          <h4 className="text-sm font-medium">Payment Scheduled</h4>
                          <p className="text-xs text-neutral-500 dark:text-neutral-400">{formatDate(selectedBill.dueDate)}</p>
                        </div>
                      )}
                      
                      {selectedBill.isRecurring && (
                        <div className="relative">
                          <div className="absolute -left-[29px] w-5 h-5 rounded-full bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center">
                            <Schedule className="h-3 w-3 text-neutral-500 dark:text-neutral-400" />
                          </div>
                          <h4 className="text-sm font-medium">Next Payment</h4>
                          <p className="text-xs text-neutral-500 dark:text-neutral-400">
                            {formatDate(new Date(new Date(selectedBill.dueDate).getTime() + 30 * 24 * 60 * 60 * 1000))}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {/* Customer Service */}
                  <div className="p-4 bg-neutral-50 dark:bg-neutral-800/50 rounded-lg border border-neutral-200 dark:border-neutral-700">
                    <div className="flex items-center gap-2">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-500">
                        <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                      </svg>
                      <h3 className="font-medium">Customer Service</h3>
                    </div>
                    <p className="mt-2 font-mono text-lg text-center">{selectedBill.details?.customerService}</p>
                  </div>
                </div>
              )}
            </div>
            
            {selectedBill && (
              <div className="border-t border-neutral-200 dark:border-neutral-700 p-4">
                <div className="mx-auto max-w-2xl flex justify-end gap-3">
                  <Button
                    variant="outline"
                    onClick={() => setBillDetailsOpen(false)}
                  >
                    Close
                  </Button>
                  
                  {selectedBill.status === "pending" && (
                    <Button
                      variant="default"
                      disabled={payBillMutation.isPending}
                      onClick={() => {
                        handlePayBill(selectedBill.id);
                        setBillDetailsOpen(false);
                      }}
                    >
                      Pay Now
                    </Button>
                  )}
                  
                  {selectedBill.status === "paid" && (
                    <Button variant="outline">
                      Download Receipt
                    </Button>
                  )}
                </div>
              </div>
            )}
          </Drawer.Content>
        </Drawer.Portal>
      </Drawer.Root>
      
      {/* Add Bill Dialog */}
      <Dialog open={isAddBillOpen} onOpenChange={setIsAddBillOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle className="text-xl flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect width="20" height="14" x="2" y="5" rx="2" />
                <line x1="2" x2="22" y1="10" y2="10" />
              </svg>
              Add a New Payee
            </DialogTitle>
            <DialogDescription>
              Set up a new bill to keep track of your payments
            </DialogDescription>
          </DialogHeader>
          
          <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800 rounded-lg p-3 mb-4 text-sm text-blue-700 dark:text-blue-300">
            <p className="flex items-center">
              <svg className="h-4 w-4 mr-2" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10" />
                <path d="M12 16v-4" />
                <path d="M12 8h.01" />
              </svg>
              Your information is secure and protected by bank-level encryption
            </p>
          </div>
          
          <Form {...billForm}>
            <form onSubmit={billForm.handleSubmit(onAddBillSubmit)} className="space-y-4">
              {/* Bill Category Selection */}
              <FormField
                control={billForm.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Bill Category</FormLabel>
                    <Select
                      onValueChange={(value) => {
                        field.onChange(value);
                        // Reset payee and amount when changing category
                        if (value === "phone") {
                          const defaultPhoneProvider = phoneProviders[0];
                          billForm.setValue("payee", defaultPhoneProvider.name);
                          billForm.setValue("amount", defaultPhoneProvider.price.toString());
                          billForm.setValue("planDetails", defaultPhoneProvider.plan);
                          billForm.setValue("providerId", defaultPhoneProvider.id);
                        } else if (value === "internet") {
                          const defaultInternetProvider = internetProviders[0];
                          billForm.setValue("payee", defaultInternetProvider.name);
                          billForm.setValue("amount", defaultInternetProvider.price.toString());
                          billForm.setValue("planDetails", defaultInternetProvider.plan);
                          billForm.setValue("providerId", defaultInternetProvider.id);
                        } else if (value === "utilities") {
                          const defaultUtilityProvider = utilityProviders[0];
                          billForm.setValue("payee", defaultUtilityProvider.name);
                          billForm.setValue("amount", defaultUtilityProvider.avgBill.toString());
                          billForm.setValue("planDetails", defaultUtilityProvider.service);
                          billForm.setValue("providerId", defaultUtilityProvider.id);
                        } else if (value === "rent") {
                          const defaultProperty = propertyTypes[0];
                          billForm.setValue("payee", "Property Management");
                          billForm.setValue("amount", defaultProperty.avgRent.toString());
                          billForm.setValue("planDetails", defaultProperty.name);
                          billForm.setValue("providerId", defaultProperty.id);
                        }
                      }}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a category" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {billCategories.map((category) => (
                          <SelectItem key={category.id} value={category.id}>
                            <div className="flex items-center gap-2">
                              {React.cloneElement(category.icon as React.ReactElement, { className: "h-4 w-4" })}
                              <span>{category.name}</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {/* Provider Selection based on category */}
              {billForm.watch("category") === "phone" && (
                <div className="border rounded-lg p-4 space-y-4">
                  <h3 className="font-medium">Select Phone Provider</h3>
                  <div className="grid grid-cols-2 gap-3">
                    {phoneProviders.map(provider => (
                      <div 
                        key={provider.id}
                        className={`border rounded p-3 cursor-pointer ${
                          billForm.watch("providerId") === provider.id 
                            ? "border-primary bg-primary/5" 
                            : "border-neutral-200 dark:border-neutral-700"
                        }`}
                        onClick={() => {
                          billForm.setValue("providerId", provider.id);
                          billForm.setValue("payee", provider.name);
                          billForm.setValue("amount", provider.price.toString());
                          billForm.setValue("planDetails", provider.plan);
                        }}
                      >
                        <div className="font-medium">{provider.name}</div>
                        <div className="flex justify-between text-sm mt-1">
                          <span className="text-neutral-500 dark:text-neutral-400">{provider.plan}</span>
                          <span>${provider.price.toFixed(2)}/mo</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {billForm.watch("category") === "internet" && (
                <div className="border rounded-lg p-4 space-y-4">
                  <h3 className="font-medium">Select Internet Provider</h3>
                  <div className="grid grid-cols-2 gap-3">
                    {internetProviders.map(provider => (
                      <div 
                        key={provider.id}
                        className={`border rounded p-3 cursor-pointer ${
                          billForm.watch("providerId") === provider.id 
                            ? "border-primary bg-primary/5" 
                            : "border-neutral-200 dark:border-neutral-700"
                        }`}
                        onClick={() => {
                          billForm.setValue("providerId", provider.id);
                          billForm.setValue("payee", provider.name);
                          billForm.setValue("amount", provider.price.toString());
                          billForm.setValue("planDetails", provider.plan);
                        }}
                      >
                        <div className="font-medium">{provider.name}</div>
                        <div className="flex justify-between text-sm mt-1">
                          <span className="text-neutral-500 dark:text-neutral-400">{provider.plan}</span>
                          <span>${provider.price.toFixed(2)}/mo</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {billForm.watch("category") === "utilities" && (
                <div className="border rounded-lg p-4 space-y-4">
                  <h3 className="font-medium">Select Utility Provider</h3>
                  <div className="grid grid-cols-2 gap-3">
                    {utilityProviders.map(provider => (
                      <div 
                        key={provider.id}
                        className={`border rounded p-3 cursor-pointer ${
                          billForm.watch("providerId") === provider.id 
                            ? "border-primary bg-primary/5" 
                            : "border-neutral-200 dark:border-neutral-700"
                        }`}
                        onClick={() => {
                          billForm.setValue("providerId", provider.id);
                          billForm.setValue("payee", provider.name);
                          billForm.setValue("amount", provider.avgBill.toString());
                          billForm.setValue("planDetails", provider.service);
                        }}
                      >
                        <div className="font-medium">{provider.name}</div>
                        <div className="flex justify-between text-sm mt-1">
                          <span className="text-neutral-500 dark:text-neutral-400">{provider.service}</span>
                          <span>~${provider.avgBill.toFixed(2)}/mo</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {billForm.watch("category") === "rent" && (
                <div className="border rounded-lg p-4 space-y-4">
                  <h3 className="font-medium">Select Property Type</h3>
                  <div className="grid grid-cols-2 gap-3">
                    {propertyTypes.map(property => (
                      <div 
                        key={property.id}
                        className={`border rounded p-3 cursor-pointer ${
                          billForm.watch("providerId") === property.id 
                            ? "border-primary bg-primary/5" 
                            : "border-neutral-200 dark:border-neutral-700"
                        }`}
                        onClick={() => {
                          billForm.setValue("providerId", property.id);
                          billForm.setValue("payee", `${property.name} Rental`);
                          billForm.setValue("amount", property.avgRent.toString());
                          billForm.setValue("planDetails", property.name);
                        }}
                      >
                        <div className="font-medium">{property.name}</div>
                        <div className="flex justify-between text-sm mt-1">
                          <span className="text-neutral-500 dark:text-neutral-400">Rental</span>
                          <span>${property.avgRent.toFixed(2)}/mo</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Manual payee entry for fallback and other categories */}
              {(!billForm.watch("category") || 
                (billForm.watch("category") !== "phone" && 
                 billForm.watch("category") !== "internet" && 
                 billForm.watch("category") !== "utilities" && 
                 billForm.watch("category") !== "rent")) && (
                <FormField
                  control={billForm.control}
                  name="payee"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Payee Name</FormLabel>
                      <FormControl>
                        <Input placeholder="E.g. Electric Company" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}
              
              <FormField
                control={billForm.control}
                name="accountNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Account Number (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="Your account number with the payee" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={billForm.control}
                  name="amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Amount</FormLabel>
                      <FormControl>
                        <Input placeholder="0.00" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={billForm.control}
                  name="dueDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Due Date</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={billForm.control}
                name="isRecurring"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">
                        Recurring Payment
                      </FormLabel>
                      <FormDescription>
                        Set up automatic recurring payments
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              {billForm.watch("isRecurring") && (
                <FormField
                  control={billForm.control}
                  name="frequency"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Frequency</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select frequency" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="weekly">Weekly</SelectItem>
                          <SelectItem value="biweekly">Bi-weekly</SelectItem>
                          <SelectItem value="monthly">Monthly</SelectItem>
                          <SelectItem value="quarterly">Quarterly</SelectItem>
                          <SelectItem value="annually">Annually</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}
              
              <DialogFooter>
                <Button type="submit" disabled={billMutation.isPending}>
                  {billMutation.isPending ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Processing...
                    </>
                  ) : (
                    "Add Bill"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}