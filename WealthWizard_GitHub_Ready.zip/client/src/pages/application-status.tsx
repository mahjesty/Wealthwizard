import { useState, useEffect, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { Loader2, Search, AlertTriangle, CheckCircle2, Clock, XCircle, ChevronLeft, RotateCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { FortisLogo } from "@/components/ui/fortis-logo";
import { Link } from "wouter";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";

const statusLookupSchema = z.object({
  applicationNumber: z
    .string()
    .min(10, "Application number must be at least 10 characters")
    .regex(/^FCA-[A-Za-z0-9]+$/, "Application number must be in the format FCA-XXXXXXXX")
});

type StatusLookupFormValues = z.infer<typeof statusLookupSchema>;

// Define application status type
type ApplicationStatus = {
  applicationNumber: string;
  status: string;
  submittedAt: string;
  lastUpdatedAt: string;
  reasonForDenial: string | null;
};

export default function ApplicationStatusPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [applicationStatus, setApplicationStatus] = useState<ApplicationStatus | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [autoLoaded, setAutoLoaded] = useState(false);
  const [isPolling, setIsPolling] = useState(false);
  const [refreshTime, setRefreshTime] = useState<Date | null>(null);
  const prevStatusRef = useRef<string | null>(null);
  const pollingIntervalRef = useRef<number | null>(null);
  const { toast } = useToast();

  // Get application number from URL if provided
  const searchParams = new URLSearchParams(window.location.search);
  const applicationParam = searchParams.get('application');

  const form = useForm<StatusLookupFormValues>({
    resolver: zodResolver(statusLookupSchema),
    defaultValues: {
      applicationNumber: applicationParam || ""
    }
  });

  // Function to fetch application status
  async function fetchApplicationStatus(applicationNumber: string) {
    if (!applicationNumber || applicationNumber.trim() === '') {
      return;
    }

    setIsLoading(true);
    setError(null);
    
    try {
      const response = await apiRequest(
        "GET", 
        `/api/account-applications/status/${applicationNumber}`
      );
      
      if (!response.ok) {
        throw new Error(`Application not found or error occurred: ${response.status}`);
      }
      
      const result = await response.json();
      setApplicationStatus(result);
    } catch (error) {
      console.error("Error checking application status:", error);
      setError("Application not found. Please check your application number and try again.");
      setApplicationStatus(null);
    } finally {
      setIsLoading(false);
    }
  }

  // Load application on form submit
  async function onSubmit(data: StatusLookupFormValues) {
    await fetchApplicationStatus(data.applicationNumber);
    
    // Start polling for this application
    if (data.applicationNumber) {
      stopPolling(); // Stop any existing polling
      startPolling(data.applicationNumber);
    }
  }
  
  // Auto-refresh function that polls for status changes
  const startPolling = (applicationNumber: string) => {
    // Clear any existing polling interval
    if (pollingIntervalRef.current) {
      window.clearInterval(pollingIntervalRef.current);
    }
    
    setIsPolling(true);
    setRefreshTime(new Date());
    
    // Store the current status for comparison
    if (applicationStatus) {
      prevStatusRef.current = applicationStatus.status;
    }
    
    // Set polling interval (every 15 seconds)
    pollingIntervalRef.current = window.setInterval(async () => {
      try {
        if (!applicationNumber) return;
        
        console.log("Polling for application status updates...");
        // Add timestamp param to prevent caching
        const timestamp = Date.now();
        const response = await apiRequest(
          "GET", 
          `/api/account-applications/status/${applicationNumber}?t=${timestamp}`
        );
        
        if (!response.ok) {
          throw new Error(`Error checking for updates`);
        }
        
        const result = await response.json();
        setRefreshTime(new Date());
        
        // Log the response for debugging
        console.log("Auto-refresh response:", result.status, "Current status:", prevStatusRef.current);
        
        // Check if status has changed
        if (prevStatusRef.current && result.status !== prevStatusRef.current) {
          console.log(`Status changed from ${prevStatusRef.current} to ${result.status}`);
          
          // Show toast notification
          toast({
            title: "Application Status Updated",
            description: `Your application status has changed to: ${result.status.replace(/_/g, ' ').toUpperCase()}`,
            variant: result.status === "approved" ? "default" : (result.status === "denied" ? "destructive" : "default"),
          });
          
          // Update the status
          setApplicationStatus(result);
          prevStatusRef.current = result.status;
        } else {
          // Quietly update the status without notification if only the timestamp changed
          setApplicationStatus(result);
        }
      } catch (error) {
        console.error("Error in polling for status updates:", error);
        // Don't show errors to the user during background polling
      }
    }, 15000); // Poll every 15 seconds
  };
  
  // Stop polling when component unmounts or when application number changes
  const stopPolling = () => {
    if (pollingIntervalRef.current) {
      window.clearInterval(pollingIntervalRef.current);
      pollingIntervalRef.current = null;
    }
    setIsPolling(false);
    prevStatusRef.current = null;
  };
  
  // Auto-load application status from URL parameter if present
  useEffect(() => {
    if (applicationParam && !autoLoaded) {
      fetchApplicationStatus(applicationParam);
      setAutoLoaded(true);
      
      // Start polling for this application
      startPolling(applicationParam);
    }
    
    // Cleanup polling when component unmounts
    return () => {
      stopPolling();
    };
  }, [applicationParam, autoLoaded]);

  // Function to get status badge based on application status
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending_review":
        return (
          <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
            <Clock className="w-3 h-3 mr-1" />
            Pending Review
          </div>
        );
      case "approved":
        return (
          <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
            <CheckCircle2 className="w-3 h-3 mr-1" />
            Approved
          </div>
        );
      case "denied":
        return (
          <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
            <XCircle className="w-3 h-3 mr-1" />
            Denied
          </div>
        );
      case "completed":
        return (
          <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
            <CheckCircle2 className="w-3 h-3 mr-1" />
            Completed
          </div>
        );
      default:
        return (
          <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
            {status}
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen flex flex-col justify-center items-center bg-gray-50 p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-6">
          <div className="inline-block mb-2">
            <FortisLogo width={50} height={50} className="text-primary mx-auto" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900">Application Status</h1>
          <p className="text-sm text-gray-600 mt-1">
            Check the status of your Fortis Capital account application
          </p>
        </div>

        <Card className="shadow-md border-0">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Check Your Application</CardTitle>
            <CardDescription>
              Enter your application number to check its status
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="applicationNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Application Number</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                            <Search className="h-4 w-4" />
                          </div>
                          <Input 
                            placeholder="FCA-XXXXXXXX" 
                            className="pl-10 bg-gray-50 border-gray-200 focus:bg-white" 
                            {...field} 
                            disabled={isLoading} 
                          />
                        </div>
                      </FormControl>
                      <FormDescription>
                        Your application number was provided when you submitted your application
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Checking...
                    </>
                  ) : (
                    "Check Status"
                  )}
                </Button>
              </form>
            </Form>
            
            {error && (
              <Alert className="mt-4 bg-red-50 border-red-200 text-red-800">
                <AlertTriangle className="h-4 w-4 text-red-600" />
                <AlertTitle>Not Found</AlertTitle>
                <AlertDescription className="text-red-700 text-sm">
                  {error}
                </AlertDescription>
              </Alert>
            )}
            
            {applicationStatus && (
              <div className="mt-4 pt-4 border-t">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-medium text-gray-800">Application Found</h3>
                  
                  {/* Auto-update toggle */}
                  <div className="flex items-center space-x-1">
                    {isPolling && (
                      <span className="text-xs text-gray-500 mr-1 flex items-center">
                        <span className="relative flex h-2 w-2 mr-1">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                        </span>
                        Auto-updating
                      </span>
                    )}
                    <Button 
                      type="button"
                      variant="outline"
                      size="sm"
                      className={`h-7 px-2 text-xs ${isPolling ? 'bg-gray-100' : 'bg-white'}`}
                      onClick={() => {
                        if (isPolling) {
                          stopPolling();
                        } else if (applicationStatus?.applicationNumber) {
                          startPolling(applicationStatus.applicationNumber);
                          toast({
                            title: "Auto-updates enabled",
                            description: "We'll notify you when the status changes",
                            duration: 3000,
                          });
                        }
                      }}
                    >
                      {isPolling ? (
                        <>
                          <RotateCw className="h-3 w-3 mr-1 animate-spin" />
                          Stop updates
                        </>
                      ) : (
                        <>
                          <RotateCw className="h-3 w-3 mr-1" />
                          Enable auto-updates
                        </>
                      )}
                    </Button>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div>
                    <p className="text-sm text-gray-600">Status:</p>
                    <div className="mt-1">
                      {getStatusBadge(applicationStatus.status)}
                    </div>
                  </div>
                  
                  <div>
                    <p className="text-sm text-gray-600">Application Number:</p>
                    <p className="font-medium">{applicationStatus.applicationNumber}</p>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <p className="text-sm text-gray-600">Submitted:</p>
                      <p className="font-medium">
                        {applicationStatus.submittedAt && format(new Date(applicationStatus.submittedAt), 'MMM d, yyyy')}
                      </p>
                    </div>
                    
                    <div>
                      <p className="text-sm text-gray-600">Last Updated:</p>
                      <p className="font-medium">
                        {applicationStatus.lastUpdatedAt && format(new Date(applicationStatus.lastUpdatedAt), 'MMM d, yyyy')}
                        {refreshTime && isPolling && (
                          <span className="text-xs text-gray-500 block">
                            Last checked: {format(refreshTime, 'h:mm:ss a')}
                          </span>
                        )}
                      </p>
                    </div>
                  </div>
                  
                  {applicationStatus.status === "pending_review" && (
                    <div className="bg-yellow-50 p-3 rounded border border-yellow-200 mt-2">
                      <p className="text-sm text-yellow-800">
                        Your application is currently under review. We'll notify you when there's an update.
                      </p>
                      <p className="text-xs text-yellow-700 mt-1">
                        This page will automatically refresh to show you the latest status.
                      </p>
                    </div>
                  )}
                  
                  {applicationStatus.status === "denied" && applicationStatus.reasonForDenial && (
                    <div>
                      <p className="text-sm text-gray-600">Reason for Denial:</p>
                      <p className="font-medium text-red-700">{applicationStatus.reasonForDenial}</p>
                      
                      <div className="bg-red-50 p-3 rounded border border-red-200 mt-2">
                        <p className="text-sm text-red-800">
                          Your application has been denied. You may submit a new application with updated information.
                        </p>
                        <Button 
                          size="sm" 
                          className="mt-2 bg-red-600 hover:bg-red-700"
                          onClick={() => window.location.href = "/auth?tab=apply"}
                        >
                          Submit New Application
                        </Button>
                      </div>
                    </div>
                  )}
                  
                  {applicationStatus.status === "approved" && (
                    <div className="bg-green-50 p-3 rounded border border-green-200 mt-2">
                      <p className="text-sm text-green-800">
                        Your application has been approved! You can now create your login credentials.
                      </p>
                      <Button 
                        size="sm" 
                        className="mt-2 bg-green-600 hover:bg-green-700"
                        onClick={() => window.location.href = "/auth?tab=register"}
                      >
                        Create Login
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            )}
          </CardContent>
          <CardFooter className="flex justify-between border-t pt-4">
            <Button variant="outline" asChild>
              <Link href="/auth">
                <ChevronLeft className="h-4 w-4 mr-1" />
                Back to Login
              </Link>
            </Button>
            
            <Button variant="ghost" size="sm" asChild>
              <a href="mailto:support@fortiscapital.com">
                Need Help?
              </a>
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}