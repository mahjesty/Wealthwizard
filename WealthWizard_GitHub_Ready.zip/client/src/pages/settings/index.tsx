import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { 
  Loader2, Save, Check, Key, Bell, Shield, User, Globe, Smartphone, 
  Fingerprint, CreditCard, BanknoteIcon, ClockIcon, LockIcon, BookOpenIcon, 
  AlertTriangle, Activity, ShieldCheck, LogOut, Mail, BellRing, KeyIcon,
  LogIn, CheckCircle, MapPin, Download, Laptop, Clock, UserIcon, ArrowLeft
} from "lucide-react";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  isWebAuthnSupported, 
  isPlatformAuthenticatorAvailable,
  registerCredential,
  removeCredential
} from "@/lib/webauthn";

// UI Components
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { BiometricSection } from "@/components/settings/biometric-section";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

// Type definitions
interface UserSettings {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  role: string;
  username: string;
  isVerified: boolean;
  preferences: {
    notifications: {
      email: boolean;
      sms: boolean;
      push: boolean;
    };
    security: {
      twoFactorEnabled: boolean;
      loginNotifications: boolean;
      sessionTimeout: number;
      passwordChangeAlerts: boolean;
      profileUpdatesAlerts: boolean;
      locationAlerts: boolean;
    };
    display: {
      language: string;
      dateFormat: string;
      theme: string;
    };
  };
}

// Form schemas
const profileFormSchema = z.object({
  firstName: z.string().min(2, { message: "First name must be at least 2 characters." }),
  lastName: z.string().min(2, { message: "Last name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  phone: z.string().optional()
});

const passwordFormSchema = z.object({
  currentPassword: z.string().min(8, { message: "Current password is required" }),
  newPassword: z.string().min(8, { message: "Password must be at least 8 characters." }),
  confirmPassword: z.string().min(8, { message: "Please confirm your new password." })
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

export default function Settings() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("security");
  const { user } = useAuth();
  
  // UI State
  const [passwordDialogOpen, setPasswordDialogOpen] = useState(false);
  const [recoveryOptionsOpen, setRecoveryOptionsOpen] = useState(false);
  const [ipAllowlistOpen, setIpAllowlistOpen] = useState(false);
  const [securityQuestionsOpen, setSecurityQuestionsOpen] = useState(false);
  const [deleteAccountDialogOpen, setDeleteAccountDialogOpen] = useState(false);
  const [confirmDeleteText, setConfirmDeleteText] = useState('');
  const [viewLogDialogOpen, setViewLogDialogOpen] = useState(false);
  
  // Form states
  const [ipAddresses, setIpAddresses] = useState<string[]>([]);
  const [currentIpAddress, setCurrentIpAddress] = useState('');
  const [recoveryEmail, setRecoveryEmail] = useState('');
  const [recoveryPhone, setRecoveryPhone] = useState('');
  
  // Security questions state
  const [securityQuestions, setSecurityQuestions] = useState<{
    question: string;
    answer: string;
  }[]>([
    { question: "What was the name of your first pet?", answer: "" },
    { question: "In what city were you born?", answer: "" },
    { question: "What was the make of your first car?", answer: "" }
  ]);
  
  // WebAuthn state
  const [biometricsSupported, setBiometricsSupported] = useState<boolean | null>(null);
  const [isRegisteringBiometrics, setIsRegisteringBiometrics] = useState(false);
  const [isRemovingBiometrics, setIsRemovingBiometrics] = useState(false);
  const [registeredCredentials, setRegisteredCredentials] = useState<any[]>([]);
  
  // Query for registered WebAuthn credentials
  const { data: credentials, isLoading: isLoadingCredentials, refetch: refetchCredentials } = useQuery({
    queryKey: ["/api/webauthn/credentials"],
    enabled: biometricsSupported === true,
    refetchOnWindowFocus: false,
  });
  
  // Fetch user settings
  const { data: settings, isLoading } = useQuery<UserSettings>({
    queryKey: ["/api/settings"],
    refetchOnWindowFocus: false,
  });

  // Profile form
  const profileForm = useForm<z.infer<typeof profileFormSchema>>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      phone: ""
    },
  });

  // Password form
  const passwordForm = useForm<z.infer<typeof passwordFormSchema>>({
    resolver: zodResolver(passwordFormSchema),
    defaultValues: {
      currentPassword: "",
      newPassword: "",
      confirmPassword: ""
    },
  });

  // Update form values when settings data is loaded
  useEffect(() => {
    if (settings) {
      profileForm.reset({
        firstName: settings.firstName,
        lastName: settings.lastName,
        email: settings.email,
        phone: settings.phone || ""
      });
    }
  }, [settings, profileForm]);
  
  // Check if biometrics are supported
  useEffect(() => {
    const checkBiometricSupport = async () => {
      try {
        // Check basic WebAuthn support
        const supported = isWebAuthnSupported();
        
        if (supported) {
          // Check if platform authenticator is available (TouchID, FaceID, Windows Hello)
          const platformAvailable = await isPlatformAuthenticatorAvailable();
          setBiometricsSupported(platformAvailable);
        } else {
          setBiometricsSupported(false);
        }
      } catch (error) {
        console.error('Error checking biometric support:', error);
        setBiometricsSupported(false);
      }
    };
    
    checkBiometricSupport();
  }, []);
  
  // Update registered credentials when data is loaded
  useEffect(() => {
    if (credentials) {
      setRegisteredCredentials(credentials);
    }
  }, [credentials]);

  // Update profile mutation
  const profileMutation = useMutation({
    mutationFn: async (data: z.infer<typeof profileFormSchema>) => {
      const response = await apiRequest("PATCH", "/api/settings", data);
      if (!response.ok) {
        throw new Error("Failed to update profile");
      }
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Profile updated",
        description: "Your profile information has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
    },
    onError: (error) => {
      toast({
        title: "Update failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Password change mutation
  const passwordMutation = useMutation({
    mutationFn: async (data: z.infer<typeof passwordFormSchema>) => {
      const response = await apiRequest("POST", "/api/settings/change-password", {
        currentPassword: data.currentPassword,
        newPassword: data.newPassword
      });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to change password");
      }
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Password changed",
        description: "Your password has been changed successfully.",
      });
      passwordForm.reset({
        currentPassword: "",
        newPassword: "",
        confirmPassword: ""
      });
    },
    onError: (error) => {
      toast({
        title: "Password change failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Toggle preference mutation
  const preferencesMutation = useMutation({
    mutationFn: async (data: { path: string; value: boolean | number | string }) => {
      const { path, value } = data;
      const [category, setting] = path.split('.');
      
      const preferences = { 
        ...settings?.preferences,
        [category]: {
          ...settings?.preferences[category as keyof typeof settings.preferences],
          [setting]: value
        }
      };
      
      const response = await apiRequest("PATCH", "/api/settings", { preferences });
      if (!response.ok) {
        throw new Error("Failed to update preference");
      }
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({
        title: "Settings updated",
        description: "Your security preferences have been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Update failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Handle device removal
  const removeDeviceMutation = useMutation({
    mutationFn: async (deviceId: string) => {
      const response = await apiRequest("DELETE", `/api/settings/devices/${deviceId}`);
      if (!response.ok) {
        throw new Error("Failed to remove device");
      }
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Device removed",
        description: "The device has been removed from your trusted devices list.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to remove device",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Handle sign out all devices
  const signOutAllDevicesMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/settings/devices/sign-out-all");
      if (!response.ok) {
        throw new Error("Failed to sign out all devices");
      }
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "All other devices have been signed out.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to sign out devices",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Account recovery options mutation
  const updateRecoveryOptionsMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/settings/recovery-options", data);
      if (!response.ok) {
        throw new Error("Failed to update recovery options");
      }
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Recovery options updated",
        description: "Your account recovery options have been updated successfully.",
      });
      setRecoveryOptionsOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Update failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // IP Allowlist mutation
  const updateIpAllowlistMutation = useMutation({
    mutationFn: async (data: { ipAddresses: string[] }) => {
      const response = await apiRequest("POST", "/api/settings/ip-allowlist", data);
      if (!response.ok) {
        throw new Error("Failed to update IP allowlist");
      }
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "IP allowlist updated",
        description: "Your IP address allowlist has been updated successfully.",
      });
      setIpAllowlistOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Update failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Security questions mutation
  const updateSecurityQuestionsMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/settings/security-questions", data);
      if (!response.ok) {
        throw new Error("Failed to update security questions");
      }
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Security questions updated",
        description: "Your security questions and answers have been updated successfully.",
      });
      setSecurityQuestionsOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Update failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Delete account mutation
  const deleteAccountMutation = useMutation({
    mutationFn: async (confirmation: string) => {
      if (confirmation !== "DELETE") {
        throw new Error("Please type DELETE to confirm account deletion");
      }
      const response = await apiRequest("DELETE", "/api/settings/account");
      if (!response.ok) {
        throw new Error("Failed to delete account");
      }
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Account deleted",
        description: "Your account has been permanently deleted.",
      });
      // Redirect to logout
      window.location.href = "/api/logout";
    },
    onError: (error) => {
      toast({
        title: "Delete failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Notification settings mutation
  const updateNotificationChannelMutation = useMutation({
    mutationFn: async (data: { channel: string; enabled: boolean }) => {
      const response = await apiRequest("POST", "/api/settings/notification-channels", data);
      if (!response.ok) {
        throw new Error("Failed to update notification channel");
      }
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
    },
    onError: (error) => {
      toast({
        title: "Update failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Alert types mutation
  const updateAlertTypeMutation = useMutation({
    mutationFn: async (data: { alertType: string; enabled: boolean }) => {
      const response = await apiRequest("POST", "/api/settings/alert-types", data);
      if (!response.ok) {
        throw new Error("Failed to update alert type");
      }
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
    },
    onError: (error) => {
      toast({
        title: "Update failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Submit handlers
  const onProfileSubmit = (data: z.infer<typeof profileFormSchema>) => {
    profileMutation.mutate(data);
  };

  const onPasswordSubmit = (data: z.infer<typeof passwordFormSchema>) => {
    passwordMutation.mutate(data);
  };

  // Biometric registration mutation
  const registerBiometricMutation = useMutation({
    mutationFn: async () => {
      if (!user?.id || !user?.username) {
        throw new Error("User information not available. Please log in again.");
      }
      
      // Register with WebAuthn
      return await registerCredential(user.username, user.id.toString());
    },
    onSuccess: () => {
      toast({
        title: "Biometric Registration Successful",
        description: "Your device biometrics have been successfully registered for login.",
      });
      
      // Refresh the credentials list
      refetchCredentials();
      
      // The registered credentials will be checked from the database, no need for localStorage
    },
    onError: (error) => {
      toast({
        title: "Registration Failed",
        description: error instanceof Error ? error.message : "Failed to register biometrics",
        variant: "destructive",
      });
    },
    onSettled: () => {
      setIsRegisteringBiometrics(false);
    }
  });
  
  // Remove biometric credential mutation
  const removeBiometricMutation = useMutation({
    mutationFn: async (credentialId: string) => {
      // Call API to remove the credential
      return await removeCredential(credentialId);
    },
    onSuccess: () => {
      toast({
        title: "Biometric Credentials Removed",
        description: "Your device biometrics have been removed from this account.",
      });
      
      // Refresh the credentials list
      refetchCredentials();
      
      // No need to update localStorage as credentials are stored in the database
    },
    onError: (error) => {
      toast({
        title: "Removal Failed",
        description: error instanceof Error ? error.message : "Failed to remove biometric credentials",
        variant: "destructive",
      });
    },
    onSettled: () => {
      setIsRemovingBiometrics(false);
    }
  });
  
  // Handle register biometrics
  const handleRegisterBiometrics = () => {
    setIsRegisteringBiometrics(true);
    registerBiometricMutation.mutate();
  };
  
  // Handle remove biometrics
  const handleRemoveBiometrics = (credentialId: string) => {
    setIsRemovingBiometrics(true);
    removeBiometricMutation.mutate(credentialId);
  };

  const handleToggle = (path: string, value: boolean | number | string) => {
    preferencesMutation.mutate({ path, value });
  };
  
  // Device handlers
  const handleRemoveDevice = (deviceId: string) => {
    removeDeviceMutation.mutate(deviceId);
  };
  
  const handleSignOutAllDevices = () => {
    signOutAllDevicesMutation.mutate();
  };
  
  // Recovery options handlers
  const handleSaveRecoveryOptions = () => {
    updateRecoveryOptionsMutation.mutate({
      recoveryEmail,
      recoveryPhone
    });
  };
  
  // IP allowlist handlers
  const handleAddIpAddress = () => {
    if (currentIpAddress && /^(\d{1,3}\.){3}\d{1,3}$/.test(currentIpAddress)) {
      setIpAddresses([...ipAddresses, currentIpAddress]);
      setCurrentIpAddress('');
    } else {
      toast({
        title: "Invalid IP Address",
        description: "Please enter a valid IPv4 address",
        variant: "destructive"
      });
    }
  };
  
  const handleRemoveIpAddress = (ip: string) => {
    setIpAddresses(ipAddresses.filter(address => address !== ip));
  };
  
  const handleSaveIpAllowlist = () => {
    updateIpAllowlistMutation.mutate({ ipAddresses });
  };
  
  // Security questions handlers
  const handleQuestionChange = (index: number, answer: string) => {
    const updatedQuestions = [...securityQuestions];
    updatedQuestions[index].answer = answer;
    setSecurityQuestions(updatedQuestions);
  };
  
  const handleSaveSecurityQuestions = () => {
    // Validate all questions have answers
    const allAnswered = securityQuestions.every(q => q.answer.trim().length > 0);
    if (!allAnswered) {
      toast({
        title: "Missing answers",
        description: "Please answer all security questions",
        variant: "destructive"
      });
      return;
    }
    
    updateSecurityQuestionsMutation.mutate({ questions: securityQuestions });
  };
  
  // Delete account handler
  const handleDeleteAccount = () => {
    deleteAccountMutation.mutate(confirmDeleteText);
  };
  
  // Notification handlers
  const handleToggleNotificationChannel = (channel: string, enabled: boolean) => {
    updateNotificationChannelMutation.mutate({ channel, enabled });
  };
  
  const handleToggleAlertType = (alertType: string, enabled: boolean) => {
    updateAlertTypeMutation.mutate({ alertType, enabled });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // Wouter navigation hook
  const [, navigate] = useLocation();
  
  // Function to navigate back to dashboard
  const handleBackToDashboard = () => {
    navigate("/dashboard");
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-5xl mx-auto">
        <div className="flex justify-between items-center mb-2">
          <h1 className="text-3xl font-bold text-neutral-900 dark:text-white">Account Settings</h1>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleBackToDashboard}
            className="flex items-center"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
        </div>
        <p className="text-neutral-600 dark:text-neutral-400 mb-6">Manage your profile, security preferences, and account settings</p>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-neutral-100 dark:bg-neutral-800 p-1 mb-6">
            <TabsTrigger value="profile" className="data-[state=active]:bg-white dark:data-[state=active]:bg-neutral-700 flex items-center gap-2">
              <User className="h-4 w-4" />
              <span>Profile</span>
            </TabsTrigger>
            <TabsTrigger value="security" className="data-[state=active]:bg-white dark:data-[state=active]:bg-neutral-700 flex items-center gap-2">
              <Shield className="h-4 w-4" />
              <span>Security</span>
            </TabsTrigger>
            <TabsTrigger value="notifications" className="data-[state=active]:bg-white dark:data-[state=active]:bg-neutral-700 flex items-center gap-2">
              <Bell className="h-4 w-4" />
              <span>Notifications</span>
            </TabsTrigger>
            <TabsTrigger value="preferences" className="data-[state=active]:bg-white dark:data-[state=active]:bg-neutral-700 flex items-center gap-2">
              <Globe className="h-4 w-4" />
              <span>Preferences</span>
            </TabsTrigger>
          </TabsList>
          
          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Personal Information</CardTitle>
                <CardDescription>Update your personal details and contact information</CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...profileForm}>
                  <form onSubmit={profileForm.handleSubmit(onProfileSubmit)} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={profileForm.control}
                        name="firstName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>First Name</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={profileForm.control}
                        name="lastName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Last Name</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={profileForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email Address</FormLabel>
                          <FormControl>
                            <Input {...field} type="email" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={profileForm.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone Number</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormDescription>
                            Used for account security and notifications
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="flex justify-end">
                      <Button 
                        type="submit" 
                        className="flex items-center gap-2"
                        disabled={profileMutation.isPending}
                      >
                        {profileMutation.isPending ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Save className="h-4 w-4" />
                        )}
                        Save Changes
                      </Button>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
              
            <Card>
              <CardHeader>
                <CardTitle>Account Information</CardTitle>
                <CardDescription>View your account details and banking information</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-neutral-50 dark:bg-neutral-800/50 p-4 rounded-md border border-neutral-200 dark:border-neutral-700">
                  <h3 className="text-lg font-semibold text-neutral-900 dark:text-white mb-4 flex items-center gap-2">
                    <div className="p-1.5 rounded-md bg-primary/10">
                      <User className="h-5 w-5 text-primary" />
                    </div>
                    Personal Details
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label className="text-xs text-neutral-500 dark:text-neutral-400">Customer ID</Label>
                      <div className="mt-1 p-2 bg-neutral-100 dark:bg-neutral-800 rounded-md text-neutral-700 dark:text-neutral-300 font-medium">
                        FRT-{settings?.id.toString().padStart(8, '0')}
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-xs text-neutral-500 dark:text-neutral-400">Username</Label>
                      <div className="mt-1 p-2 bg-neutral-100 dark:bg-neutral-800 rounded-md text-neutral-700 dark:text-neutral-300">
                        {settings?.username}
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-xs text-neutral-500 dark:text-neutral-400">Account Type</Label>
                      <div className="mt-1 p-2 bg-neutral-100 dark:bg-neutral-800 rounded-md text-neutral-700 dark:text-neutral-300">
                        Personal Banking
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-xs text-neutral-500 dark:text-neutral-400">Account Status</Label>
                      <div className="mt-1 p-2 flex items-center gap-2">
                        <div className={`h-3 w-3 rounded-full ${settings?.isVerified ? 'bg-green-500' : 'bg-amber-500'}`}></div>
                        <span className="text-neutral-700 dark:text-neutral-300 font-medium">
                          {settings?.isVerified ? 'Verified' : 'Pending Verification'}
                        </span>
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-xs text-neutral-500 dark:text-neutral-400">Member Since</Label>
                      <div className="mt-1 p-2 bg-neutral-100 dark:bg-neutral-800 rounded-md text-neutral-700 dark:text-neutral-300">
                        January 15, 2023
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-xs text-neutral-500 dark:text-neutral-400">Last Login</Label>
                      <div className="mt-1 p-2 bg-neutral-100 dark:bg-neutral-800 rounded-md text-neutral-700 dark:text-neutral-300">
                        Today, {new Date().toLocaleTimeString()}
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="bg-neutral-50 dark:bg-neutral-800/50 p-4 rounded-md border border-neutral-200 dark:border-neutral-700">
                  <h3 className="text-lg font-semibold text-neutral-900 dark:text-white mb-4 flex items-center gap-2">
                    <div className="p-1.5 rounded-md bg-primary/10">
                      <BanknoteIcon className="h-5 w-5 text-primary" />
                    </div>
                    Banking Profile
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label className="text-xs text-neutral-500 dark:text-neutral-400">Primary Branch</Label>
                      <div className="mt-1 p-2 bg-neutral-100 dark:bg-neutral-800 rounded-md text-neutral-700 dark:text-neutral-300">
                        Financial District - New York
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-xs text-neutral-500 dark:text-neutral-400">Relationship Manager</Label>
                      <div className="mt-1 p-2 bg-neutral-100 dark:bg-neutral-800 rounded-md text-neutral-700 dark:text-neutral-300">
                        Michael Thompson
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-xs text-neutral-500 dark:text-neutral-400">Account Services</Label>
                      <div className="mt-1 p-2 bg-neutral-100 dark:bg-neutral-800 rounded-md text-neutral-700 dark:text-neutral-300">
                        <div className="flex flex-wrap gap-2">
                          <span className="px-2 py-1 bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 rounded text-xs">Checking</span>
                          <span className="px-2 py-1 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 rounded text-xs">Savings</span>
                          <span className="px-2 py-1 bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-200 rounded text-xs">Credit Card</span>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-xs text-neutral-500 dark:text-neutral-400">Document Delivery</Label>
                      <div className="mt-1 p-2 bg-neutral-100 dark:bg-neutral-800 rounded-md text-neutral-700 dark:text-neutral-300">
                        Paperless (E-Statements)
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-end">
                  <Button variant="outline" className="flex items-center gap-2">
                    <CreditCard className="h-4 w-4" />
                    Request Account Upgrades
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Security Tab */}
          <TabsContent value="security" className="space-y-6">
            {/* Security Overview Card */}
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Security Overview</CardTitle>
                    <CardDescription>Your account security status</CardDescription>
                  </div>
                  <div className="bg-blue-50 dark:bg-blue-900 text-blue-700 dark:text-blue-200 px-3 py-1 rounded-full text-xs font-medium flex items-center">
                    <ShieldCheck className="h-3.5 w-3.5 mr-1" />
                    {/* Calculate security score based on enabled security features */}
                    {(settings?.preferences.security.twoFactorEnabled ? 1 : 0) +
                     (settings?.preferences.security.loginNotifications ? 1 : 0) +
                     (credentials?.length > 0 ? 1 : 0) === 3 
                      ? 'Protected' 
                      : 'Vulnerable'}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Security Score Progress Bar */}
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="text-sm font-medium">Security Score</h4>
                      <span className="text-sm font-medium">
                        {/* Calculate percentage based on enabled security features */}
                        {Math.round(((settings?.preferences.security.twoFactorEnabled ? 1 : 0) +
                        (settings?.preferences.security.loginNotifications ? 1 : 0) +
                        (credentials?.length > 0 ? 1 : 0)) / 3 * 100)}%
                      </span>
                    </div>
                    <Progress 
                      value={((settings?.preferences.security.twoFactorEnabled ? 1 : 0) +
                      (settings?.preferences.security.loginNotifications ? 1 : 0) +
                      (credentials?.length > 0 ? 1 : 0)) / 3 * 100} 
                      className="h-2" 
                    />
                  </div>
                  
                  {/* Security Recommendations */}
                  <div className="rounded-md border border-neutral-200 dark:border-neutral-700 overflow-hidden">
                    <div className="bg-neutral-50 dark:bg-neutral-800 px-4 py-3 border-b border-neutral-200 dark:border-neutral-700">
                      <h4 className="font-medium text-sm flex items-center">
                        <AlertTriangle className="h-4 w-4 mr-2 text-amber-500" />
                        Security Recommendations
                      </h4>
                    </div>
                    <div className="p-0">
                      <ul className="divide-y divide-neutral-200 dark:divide-neutral-700">
                        {!settings?.preferences.security.twoFactorEnabled && (
                          <li className="flex items-start px-4 py-3">
                            <div className="flex-shrink-0 pt-1">
                              <Shield className="h-5 w-5 text-amber-500" />
                            </div>
                            <div className="ml-3">
                              <p className="text-sm font-medium">Enable two-factor authentication</p>
                              <p className="text-xs text-neutral-600 dark:text-neutral-400 mt-0.5">
                                Add an extra layer of security to your account by requiring a second verification step when logging in.
                              </p>
                              <Button 
                                variant="outline" 
                                size="sm" 
                                className="mt-2"
                                onClick={() => handleToggle('security.twoFactorEnabled', true)}
                              >
                                Enable 2FA
                              </Button>
                            </div>
                          </li>
                        )}
                        
                        {(!credentials || credentials.length === 0) && (
                          <li className="flex items-start px-4 py-3">
                            <div className="flex-shrink-0 pt-1">
                              <Fingerprint className="h-5 w-5 text-amber-500" />
                            </div>
                            <div className="ml-3">
                              <p className="text-sm font-medium">Set up biometric authentication</p>
                              <p className="text-xs text-neutral-600 dark:text-neutral-400 mt-0.5">
                                Enable fingerprint or face recognition for faster and more secure login on supported devices.
                              </p>
                            </div>
                          </li>
                        )}
                        
                        {!settings?.preferences.security.loginNotifications && (
                          <li className="flex items-start px-4 py-3">
                            <div className="flex-shrink-0 pt-1">
                              <Bell className="h-5 w-5 text-amber-500" />
                            </div>
                            <div className="ml-3">
                              <p className="text-sm font-medium">Enable login notifications</p>
                              <p className="text-xs text-neutral-600 dark:text-neutral-400 mt-0.5">
                                Receive alerts when someone logs into your account from a new device or location.
                              </p>
                              <Button 
                                variant="outline" 
                                size="sm" 
                                className="mt-2"
                                onClick={() => handleToggle('security.loginNotifications', true)}
                              >
                                Enable Notifications
                              </Button>
                            </div>
                          </li>
                        )}
                        
                        {(settings?.preferences.security.twoFactorEnabled && 
                          settings?.preferences.security.loginNotifications && 
                          (credentials && credentials.length > 0)) && (
                          <li className="flex items-start px-4 py-3">
                            <div className="flex-shrink-0 pt-1">
                              <CheckCircle className="h-5 w-5 text-green-500" />
                            </div>
                            <div className="ml-3">
                              <p className="text-sm font-medium">Your account is well-protected</p>
                              <p className="text-xs text-neutral-600 dark:text-neutral-400 mt-0.5">
                                You've enabled all recommended security features. Continue to monitor your account regularly.
                              </p>
                            </div>
                          </li>
                        )}
                      </ul>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Account Protection Card */}
            <Card>
              <CardHeader>
                <CardTitle>Account Protection</CardTitle>
                <CardDescription>Configure security features to protect your account</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Two-Factor Authentication */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center">
                      <div className="bg-primary/10 p-2 rounded-full mr-3">
                        <Smartphone className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-neutral-900 dark:text-white">Two-Factor Authentication</h4>
                        <p className="text-sm text-neutral-600 dark:text-neutral-400">Require a verification code in addition to your password</p>
                      </div>
                    </div>
                    <Switch 
                      checked={settings?.preferences.security.twoFactorEnabled} 
                      onCheckedChange={(checked) => handleToggle('security.twoFactorEnabled', checked)}
                    />
                  </div>
                  
                  {settings?.preferences.security.twoFactorEnabled && (
                    <div className="ml-12 pl-3 border-l-2 border-neutral-200 dark:border-neutral-700 space-y-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <h5 className="text-sm font-medium">Verification Method</h5>
                          <p className="text-xs text-neutral-600 dark:text-neutral-400">Choose how you receive verification codes</p>
                        </div>
                        <Select 
                          defaultValue="sms"
                          onValueChange={() => {}}
                        >
                          <SelectTrigger className="w-[180px]">
                            <SelectValue placeholder="Method" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="sms">Text Message (SMS)</SelectItem>
                            <SelectItem value="email">Email</SelectItem>
                            <SelectItem value="app">Authenticator App</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <h5 className="text-sm font-medium">Recovery Codes</h5>
                          <p className="text-xs text-neutral-600 dark:text-neutral-400">Use these if you lose access to your device</p>
                        </div>
                        <Button variant="outline" size="sm">
                          <Download className="h-4 w-4 mr-2" />
                          Download Codes
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
                
                <Separator />
                
                {/* Login Notifications */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="bg-primary/10 p-2 rounded-full mr-3">
                      <Bell className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-neutral-900 dark:text-white">Login Notifications</h4>
                      <p className="text-sm text-neutral-600 dark:text-neutral-400">Get alerted of any suspicious account activity</p>
                    </div>
                  </div>
                  <Switch 
                    checked={settings?.preferences.security.loginNotifications}
                    onCheckedChange={(checked) => handleToggle('security.loginNotifications', checked)}
                  />
                </div>
                
                <Separator />
                
                {/* Trusted Devices */}
                <div>
                  <div className="flex items-center mb-3">
                    <div className="bg-primary/10 p-2 rounded-full mr-3">
                      <Laptop className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-neutral-900 dark:text-white">Trusted Devices</h4>
                      <p className="text-sm text-neutral-600 dark:text-neutral-400">Manage the devices that have access to your account</p>
                    </div>
                  </div>
                  
                  <div className="ml-12 bg-neutral-50 dark:bg-neutral-800 rounded-md border border-neutral-200 dark:border-neutral-700 p-4">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <div className="bg-green-100 dark:bg-green-900/50 p-2 rounded-full">
                            <Laptop className="h-4 w-4 text-green-600 dark:text-green-400" />
                          </div>
                          <div className="ml-3">
                            <h5 className="text-sm font-medium">Current Device</h5>
                            <p className="text-xs text-neutral-500">Last active: Just now</p>
                          </div>
                        </div>
                        <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300 font-normal">
                          Current
                        </Badge>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <div className="bg-neutral-100 dark:bg-neutral-700 p-2 rounded-full">
                            <Smartphone className="h-4 w-4 text-neutral-600 dark:text-neutral-400" />
                          </div>
                          <div className="ml-3">
                            <h5 className="text-sm font-medium">iPhone 13</h5>
                            <p className="text-xs text-neutral-500">Last active: Yesterday, 3:42 PM</p>
                          </div>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="h-7 text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950"
                          onClick={() => handleRemoveDevice("iphone13")}
                        >
                          Remove
                        </Button>
                      </div>
                    </div>
                    
                    <div className="mt-3 pt-3 border-t border-neutral-200 dark:border-neutral-700">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="w-full"
                        onClick={handleSignOutAllDevices}
                      >
                        <LogOut className="h-4 w-4 mr-2" />
                        Sign Out All Other Devices
                      </Button>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                {/* Session Timeout */}
                <div>
                  <div className="flex items-center mb-3">
                    <div className="bg-primary/10 p-2 rounded-full mr-3">
                      <Clock className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-neutral-900 dark:text-white">Session Timeout</h4>
                      <p className="text-sm text-neutral-600 dark:text-neutral-400">Automatically log out after a period of inactivity</p>
                    </div>
                  </div>
                  
                  <div className="ml-12">
                    <Select 
                      value={settings?.preferences.security.sessionTimeout.toString()} 
                      onValueChange={(value) => handleToggle('security.sessionTimeout', parseInt(value))}
                    >
                      <SelectTrigger className="w-full sm:w-1/3">
                        <SelectValue placeholder="Select timeout period" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="15">15 minutes</SelectItem>
                        <SelectItem value="30">30 minutes</SelectItem>
                        <SelectItem value="60">1 hour</SelectItem>
                        <SelectItem value="120">2 hours</SelectItem>
                        <SelectItem value="240">4 hours</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <Separator />
                
                {/* Recent Account Activity */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center">
                      <div className="bg-primary/10 p-2 rounded-full mr-3">
                        <Activity className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-neutral-900 dark:text-white">Recent Account Activity</h4>
                        <p className="text-sm text-neutral-600 dark:text-neutral-400">Monitor recent access to your account</p>
                      </div>
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => setViewLogDialogOpen(true)}
                    >
                      View Full Log
                    </Button>
                  </div>
                  
                  <div className="ml-12 bg-neutral-50 dark:bg-neutral-800 rounded-md border border-neutral-200 dark:border-neutral-700 overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Time</TableHead>
                          <TableHead>Activity</TableHead>
                          <TableHead>Location</TableHead>
                          <TableHead>Device</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        <TableRow>
                          <TableCell>
                            <div className="text-xs">Today, 2:35 PM</div>
                          </TableCell>
                          <TableCell>
                            <div className="text-xs font-medium">Account Login</div>
                          </TableCell>
                          <TableCell>
                            <div className="text-xs">New York, US</div>
                          </TableCell>
                          <TableCell>
                            <div className="text-xs">Chrome / Windows</div>
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell>
                            <div className="text-xs">Yesterday, 4:23 PM</div>
                          </TableCell>
                          <TableCell>
                            <div className="text-xs font-medium">Password Changed</div>
                          </TableCell>
                          <TableCell>
                            <div className="text-xs">New York, US</div>
                          </TableCell>
                          <TableCell>
                            <div className="text-xs">Chrome / Windows</div>
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell>
                            <div className="text-xs">Apr 24, 10:15 AM</div>
                          </TableCell>
                          <TableCell>
                            <div className="text-xs font-medium">Account Login</div>
                          </TableCell>
                          <TableCell>
                            <div className="text-xs">New York, US</div>
                          </TableCell>
                          <TableCell>
                            <div className="text-xs">Safari / iOS</div>
                          </TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                </div>
                
                <Separator />
                
                {/* Password Management */}
                <div>
                  <div className="flex items-center mb-3">
                    <div className="bg-primary/10 p-2 rounded-full mr-3">
                      <KeyIcon className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-neutral-900 dark:text-white">Password Management</h4>
                      <p className="text-sm text-neutral-600 dark:text-neutral-400">Update your password regularly for better security</p>
                    </div>
                  </div>
                  
                  <div className="ml-12 flex flex-col sm:flex-row gap-4">
                    <div className="flex-1 border border-neutral-200 dark:border-neutral-700 rounded-md p-4">
                      <h5 className="text-sm font-medium mb-1">Password Strength</h5>
                      <div className="flex items-center gap-2 mb-3">
                        <Progress value={75} className="h-2" />
                        <span className="text-xs font-medium">Good</span>
                      </div>
                      <p className="text-xs text-neutral-600 dark:text-neutral-400">
                        Last changed: 30 days ago
                      </p>
                    </div>
                    
                    <div className="sm:w-48 flex items-center">
                      <Button className="w-full" onClick={() => setPasswordDialogOpen(true)}>
                        <KeyIcon className="h-4 w-4 mr-2" />
                        Change Password
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Biometric Authentication */}
            <BiometricSection />
            
            {/* Security Alerts */}
            <Card>
              <CardHeader>
                <CardTitle>Security Alerts & Notifications</CardTitle>
                <CardDescription>Configure how you want to be alerted about security events</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <h4 className="text-sm font-medium text-neutral-900 dark:text-white">Notification Channels</h4>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <div className="w-8 flex justify-center mr-2">
                            <Smartphone className="h-4 w-4 text-neutral-700 dark:text-neutral-300" />
                          </div>
                          <span className="text-sm">SMS Text Messages</span>
                        </div>
                        <Switch 
                          checked={settings?.preferences?.notifications?.sms ?? true}
                          onCheckedChange={(checked) => handleToggleNotificationChannel('sms', checked)}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <div className="w-8 flex justify-center mr-2">
                            <Mail className="h-4 w-4 text-neutral-700 dark:text-neutral-300" />
                          </div>
                          <span className="text-sm">Email Notifications</span>
                        </div>
                        <Switch 
                          checked={settings?.preferences?.notifications?.email ?? true}
                          onCheckedChange={(checked) => handleToggleNotificationChannel('email', checked)}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <div className="w-8 flex justify-center mr-2">
                            <BellRing className="h-4 w-4 text-neutral-700 dark:text-neutral-300" />
                          </div>
                          <span className="text-sm">In-App Notifications</span>
                        </div>
                        <Switch 
                          checked={settings?.preferences?.notifications?.push ?? true}
                          onCheckedChange={(checked) => handleToggleNotificationChannel('push', checked)}
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <h4 className="text-sm font-medium text-neutral-900 dark:text-white">Alert Types</h4>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <div className="w-8 flex justify-center mr-2">
                            <LogIn className="h-4 w-4 text-neutral-700 dark:text-neutral-300" />
                          </div>
                          <span className="text-sm">New Login Attempts</span>
                        </div>
                        <Switch 
                          checked={settings?.preferences?.security?.loginNotifications ?? true}
                          onCheckedChange={(checked) => handleToggleAlertType('loginAttempts', checked)}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <div className="w-8 flex justify-center mr-2">
                            <KeyIcon className="h-4 w-4 text-neutral-700 dark:text-neutral-300" />
                          </div>
                          <span className="text-sm">Password Changes</span>
                        </div>
                        <Switch 
                          checked={settings?.preferences?.security?.passwordChangeAlerts ?? true}
                          onCheckedChange={(checked) => handleToggleAlertType('passwordChanges', checked)}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <div className="w-8 flex justify-center mr-2">
                            <UserIcon className="h-4 w-4 text-neutral-700 dark:text-neutral-300" />
                          </div>
                          <span className="text-sm">Profile Information Updates</span>
                        </div>
                        <Switch 
                          checked={settings?.preferences?.security?.profileUpdatesAlerts ?? true}
                          onCheckedChange={(checked) => handleToggleAlertType('profileUpdates', checked)}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <div className="w-8 flex justify-center mr-2">
                            <MapPin className="h-4 w-4 text-neutral-700 dark:text-neutral-300" />
                          </div>
                          <span className="text-sm">Unusual Location Logins</span>
                        </div>
                        <Switch 
                          checked={settings?.preferences?.security?.locationAlerts ?? true}
                          onCheckedChange={(checked) => handleToggleAlertType('unusualLocation', checked)}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Advanced Security */}
            <Card>
              <CardHeader>
                <CardTitle>Advanced Security Options</CardTitle>
                <CardDescription>Additional security settings for enhanced protection</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-medium text-neutral-900 dark:text-white">Account Recovery Options</h4>
                    <p className="text-sm text-neutral-600 dark:text-neutral-400">Manage methods to recover your account</p>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => setRecoveryOptionsOpen(true)}>
                    Manage Options
                  </Button>
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-medium text-neutral-900 dark:text-white">IP Allowlist</h4>
                    <p className="text-sm text-neutral-600 dark:text-neutral-400">Restrict account access to specific IP addresses</p>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => setIpAllowlistOpen(true)}>
                    Configure
                  </Button>
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-medium text-neutral-900 dark:text-white">Security Questions</h4>
                    <p className="text-sm text-neutral-600 dark:text-neutral-400">Update your security question answers</p>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => setSecurityQuestionsOpen(true)}>
                    Update Questions
                  </Button>
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-medium text-neutral-900 dark:text-white flex items-center gap-1.5">
                      <AlertTriangle className="h-4 w-4 text-red-500" />
                      Delete Account
                    </h4>
                    <p className="text-sm text-neutral-600 dark:text-neutral-400">Permanently delete your Fortis Capital account</p>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950 border-red-300 dark:border-red-800"
                    onClick={() => setDeleteAccountDialogOpen(true)}
                  >
                    Delete Account
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            {/* Password Change Dialog */}
            <Dialog open={passwordDialogOpen} onOpenChange={setPasswordDialogOpen}>
              <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                  <DialogTitle>Change Password</DialogTitle>
                  <DialogDescription>
                    Enter your current password and create a new secure password for your account.
                  </DialogDescription>
                </DialogHeader>
                <Form {...passwordForm}>
                  <form onSubmit={passwordForm.handleSubmit(onPasswordSubmit)} className="space-y-4">
                    <FormField
                      control={passwordForm.control}
                      name="currentPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Current Password</FormLabel>
                          <FormControl>
                            <Input {...field} type="password" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={passwordForm.control}
                      name="newPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>New Password</FormLabel>
                          <FormControl>
                            <Input {...field} type="password" />
                          </FormControl>
                          <FormDescription>
                            Password must be at least 8 characters
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={passwordForm.control}
                      name="confirmPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Confirm New Password</FormLabel>
                          <FormControl>
                            <Input {...field} type="password" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="flex justify-end gap-2 mt-4">
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => setPasswordDialogOpen(false)}
                      >
                        Cancel
                      </Button>
                      <Button 
                        type="submit" 
                        disabled={passwordMutation.isPending}
                      >
                        {passwordMutation.isPending ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            Changing...
                          </>
                        ) : (
                          <>
                            <KeyIcon className="h-4 w-4 mr-2" />
                            Change Password
                          </>
                        )}
                      </Button>
                    </div>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
            
            {/* Delete Account Dialog */}
            <Dialog open={deleteAccountDialogOpen} onOpenChange={setDeleteAccountDialogOpen}>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle className="text-red-500 flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5" />
                    Delete Account
                  </DialogTitle>
                  <DialogDescription>
                    This action will permanently delete your Fortis Capital account and all associated data.
                  </DialogDescription>
                </DialogHeader>
                <div className="bg-red-50 dark:bg-red-950 p-4 rounded-md border border-red-200 dark:border-red-800 text-red-800 dark:text-red-300">
                  <h4 className="text-sm font-medium mb-2">Warning: This action cannot be undone</h4>
                  <p className="text-xs">
                    Once you delete your account, all of your personal information, account history, and financial data will be permanently removed from our systems. Any funds in your accounts will need to be transferred out before account deletion.
                  </p>
                  <div className="mt-3 pt-2 border-t border-red-200 dark:border-red-700 text-xs">
                    <p className="italic">
                      Note: According to financial regulations, some basic transaction records may be retained for legal and compliance purposes.
                    </p>
                  </div>
                </div>
                
                <div className="mt-2">
                  <Label className="text-sm font-medium">To confirm, type "DELETE" below</Label>
                  <Input className="mt-2" placeholder="Type DELETE to confirm" />
                </div>
                
                <DialogFooter>
                  <Button 
                    variant="outline" 
                    onClick={() => setDeleteAccountDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button 
                    variant="destructive"
                    disabled={true}
                  >
                    Permanently Delete Account
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </TabsContent>
          
          {/* Notifications Tab */}
          <TabsContent value="notifications" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Notification Preferences</CardTitle>
                <CardDescription>Control how you receive notifications from Fortis Capital</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium text-neutral-900 dark:text-white">Communication Channels</h3>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-medium text-neutral-900 dark:text-white">Email Notifications</h4>
                      <p className="text-sm text-neutral-600 dark:text-neutral-400">Receive account updates and alerts via email</p>
                    </div>
                    <Switch 
                      checked={settings?.preferences.notifications.email} 
                      onCheckedChange={(checked) => handleToggleNotificationChannel('email', checked)}
                    />
                  </div>
                  
                  <Separator />
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-medium text-neutral-900 dark:text-white">SMS Notifications</h4>
                      <p className="text-sm text-neutral-600 dark:text-neutral-400">Receive text message alerts for important account activities</p>
                    </div>
                    <Switch 
                      checked={settings?.preferences.notifications.sms} 
                      onCheckedChange={(checked) => handleToggleNotificationChannel('sms', checked)}
                    />
                  </div>
                  
                  <Separator />
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-medium text-neutral-900 dark:text-white">Push Notifications</h4>
                      <p className="text-sm text-neutral-600 dark:text-neutral-400">Receive notifications in your browser</p>
                    </div>
                    <Switch 
                      checked={settings?.preferences.notifications.push} 
                      onCheckedChange={(checked) => handleToggleNotificationChannel('push', checked)}
                    />
                  </div>
                </div>
                
                <Alert variant="default" className="bg-blue-50 text-blue-800 dark:bg-blue-950 dark:text-blue-200 border-blue-200 dark:border-blue-800">
                  <AlertTitle className="text-blue-800 dark:text-blue-200">Important Notice</AlertTitle>
                  <AlertDescription className="text-blue-700 dark:text-blue-300">
                    For security reasons, some critical notifications will always be sent to your primary email address regardless of these settings.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Preferences Tab */}
          <TabsContent value="preferences" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Display Preferences</CardTitle>
                <CardDescription>Customize how Fortis Capital appears to you</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium mb-2 text-neutral-900 dark:text-white">Language</h4>
                  <Select 
                    value={settings?.preferences.display.language} 
                    onValueChange={(value) => handleToggle('display.language', value)}
                  >
                    <SelectTrigger className="w-full sm:w-1/3">
                      <SelectValue placeholder="Select language" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="en-US">English (US)</SelectItem>
                      <SelectItem value="es-ES">Español</SelectItem>
                      <SelectItem value="fr-FR">Français</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <Separator />
                
                <div>
                  <h4 className="text-sm font-medium mb-2 text-neutral-900 dark:text-white">Date Format</h4>
                  <Select 
                    value={settings?.preferences.display.dateFormat} 
                    onValueChange={(value) => handleToggle('display.dateFormat', value)}
                  >
                    <SelectTrigger className="w-full sm:w-1/3">
                      <SelectValue placeholder="Select date format" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                      <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                      <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <Separator />
                
                <div>
                  <h4 className="text-sm font-medium mb-2 text-neutral-900 dark:text-white">Theme</h4>
                  <Select 
                    value={settings?.preferences.display.theme} 
                    onValueChange={(value) => handleToggle('display.theme', value)}
                  >
                    <SelectTrigger className="w-full sm:w-1/3">
                      <SelectValue placeholder="Select theme" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="light">Light</SelectItem>
                      <SelectItem value="dark">Dark</SelectItem>
                      <SelectItem value="system">System</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}