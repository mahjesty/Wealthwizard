import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Account, Transaction } from "@shared/schema";

// Extended transaction interface for our custom properties
interface ExtendedTransaction extends Transaction {
  date?: string;
  frequency?: string;
  memo?: string;
  transferType?: string;
  recipientDetails?: {
    bankName: string;
    routingNumber: string;
    accountNumber: string;
    accountType: string;
    accountName: string;
    saveRecipient: boolean;
  };
}
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage,
  FormDescription 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  AccountBalance, 
  SwapHoriz,
  Send,
  History,
  Schedule,
  AddCircle,
  CreditCard,
  Payments,
  Info,
  Warning,
  Check,
  Receipt
} from "@mui/icons-material";
import { formatCurrency, formatDate } from "@/lib/utils";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const transferSchema = z.object({
  fromAccountId: z.string().min(1, { message: "From account is required" }),
  toAccountId: z.string().min(1, { message: "To account is required" }),
  amount: z.string().min(1, { message: "Amount is required" })
    .refine(val => !isNaN(parseFloat(val)) && parseFloat(val) > 0, {
      message: "Amount must be a positive number"
    }),
  date: z.string().min(1, { message: "Date is required" }),
  memo: z.string().optional(),
  frequency: z.string().optional().default("once"),
}).refine(data => data.fromAccountId !== data.toAccountId, {
  message: "From and To accounts must be different",
  path: ["toAccountId"]
});

const externalTransferSchema = z.object({
  fromAccountId: z.string().min(1, { message: "From account is required" }),
  bankName: z.string().min(1, { message: "Bank name is required" }),
  routingNumber: z.string().min(9, { message: "Valid routing number is required" })
    .refine(val => /^\d{9}$/.test(val), {
      message: "Routing number must be 9 digits"
    }),
  accountNumber: z.string().min(5, { message: "Valid account number is required" }),
  accountType: z.string().min(1, { message: "Account type is required" }),
  accountName: z.string().min(1, { message: "Account holder name is required" }),
  amount: z.string().min(1, { message: "Amount is required" })
    .refine(val => !isNaN(parseFloat(val)) && parseFloat(val) > 0, {
      message: "Amount must be a positive number"
    }),
  transferType: z.string().default("standard"),
  date: z.string().min(1, { message: "Date is required" }),
  memo: z.string().optional(),
  saveRecipient: z.boolean().default(false),
});

export default function Transfers() {
  const [activeTab, setActiveTab] = useState("between-accounts");
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const today = new Date().toISOString().split('T')[0];
  
  // State for dialogs
  const [internalConfirmDialogOpen, setInternalConfirmDialogOpen] = useState(false);
  const [externalConfirmDialogOpen, setExternalConfirmDialogOpen] = useState(false);
  const [feeAlertDialogOpen, setFeeAlertDialogOpen] = useState(false);
  const [transactionDetailsOpen, setTransactionDetailsOpen] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState<ExtendedTransaction | null>(null);
  const [pendingExternalTransfer, setPendingExternalTransfer] = useState<Partial<ExtendedTransaction> | null>(null);
  const [currentFee, setCurrentFee] = useState(0);
  
  // Fetch accounts
  const { data: accounts = [], isLoading: isLoadingAccounts } = useQuery<Account[]>({
    queryKey: ["/api/accounts"],
  });
  
  // Fetch recent transfers
  const { data: recentTransfers = [], isLoading: isLoadingTransfers } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions/recent"],
  });
  
  // Internal transfer form
  const internalForm = useForm<z.infer<typeof transferSchema>>({
    resolver: zodResolver(transferSchema),
    defaultValues: {
      fromAccountId: "",
      toAccountId: "",
      amount: "",
      date: today,
      memo: "",
      frequency: "once"
    }
  });
  
  // External transfer form
  const externalForm = useForm<z.infer<typeof externalTransferSchema>>({
    resolver: zodResolver(externalTransferSchema),
    defaultValues: {
      fromAccountId: "",
      bankName: "",
      routingNumber: "",
      accountNumber: "",
      accountType: "checking",
      accountName: "",
      amount: "",
      transferType: "standard",
      date: today,
      memo: "",
      saveRecipient: false
    }
  });
  
  // Transfer mutation
  const transferMutation = useMutation({
    mutationFn: (data: any) => {
      return apiRequest("POST", "/api/transactions", data);
    },
    onSuccess: () => {
      // Invalidate queries
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions/recent"] });
      
      // Reset forms
      internalForm.reset({
        fromAccountId: "",
        toAccountId: "",
        amount: "",
        date: today,
        memo: "",
        frequency: "once"
      });
      
      externalForm.reset({
        fromAccountId: "",
        bankName: "",
        routingNumber: "",
        accountNumber: "",
        accountType: "checking",
        accountName: "",
        amount: "",
        transferType: "standard",
        date: today,
        memo: "",
        saveRecipient: false
      });
      
      // Reset state
      setPendingExternalTransfer(null);
      
      // Show success toast
      toast({
        title: "Transfer initiated",
        description: "Your transfer has been initiated successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Transfer failed",
        description: error.message || "There was an error processing your transfer.",
        variant: "destructive",
      });
    }
  });
  
  const prepareInternalTransfer = (values: z.infer<typeof transferSchema>) => {
    // For demo purposes, simulate a successful transfer
    const fromAccount = accounts.find((acc: Account) => acc.id.toString() === values.fromAccountId);
    const toAccount = accounts.find((acc: Account) => acc.id.toString() === values.toAccountId);
    
    if (!fromAccount || !toAccount) {
      toast({
        title: "Transfer failed",
        description: "One or more selected accounts could not be found.",
        variant: "destructive",
      });
      return;
    }
    
    const amountValue = parseFloat(values.amount);
    if (amountValue > parseFloat(fromAccount.availableBalance.toString())) {
      toast({
        title: "Insufficient funds",
        description: "The transfer amount exceeds your available balance.",
        variant: "destructive",
      });
      return;
    }
    
    // Open confirmation dialog instead of immediately submitting
    setInternalConfirmDialogOpen(true);
  };
  
  const onInternalTransferSubmit = () => {
    const values = internalForm.getValues();
    const fromAccount = accounts.find((acc: any) => acc.id.toString() === values.fromAccountId);
    const toAccount = accounts.find((acc: any) => acc.id.toString() === values.toAccountId);
    
    transferMutation.mutate({
      accountId: parseInt(values.fromAccountId),
      toAccountId: parseInt(values.toAccountId),
      transactionType: "transfer",
      amount: values.amount,
      description: values.memo || `Transfer from ${fromAccount?.accountName} to ${toAccount?.accountName}`,
      category: "transfer",
      frequency: values.frequency,
      date: values.date
    });
    
    // Close dialog
    setInternalConfirmDialogOpen(false);
  };
  
  const prepareExternalTransfer = (values: z.infer<typeof externalTransferSchema>) => {
    const fromAccount = accounts.find((acc: Account) => acc.id.toString() === values.fromAccountId);
    
    if (!fromAccount) {
      toast({
        title: "Transfer failed",
        description: "The selected account could not be found.",
        variant: "destructive",
      });
      return;
    }
    
    const amountValue = parseFloat(values.amount);
    if (amountValue > parseFloat(fromAccount.availableBalance.toString())) {
      toast({
        title: "Insufficient funds",
        description: "The transfer amount exceeds your available balance.",
        variant: "destructive",
      });
      return;
    }
    
    // For demo purposes, show different fees based on transfer type
    let fee = 0;
    if (values.transferType === "wire") {
      fee = 25;
    } else if (values.transferType === "next-day") {
      fee = 10;
    }
    
    // Store the transfer data
    setPendingExternalTransfer({
      accountId: parseInt(values.fromAccountId),
      toAccountId: null, // External account
      transactionType: "transfer",
      amount: values.amount,
      description: `External transfer to ${values.accountName} (${values.bankName})`,
      category: "transfer",
      transferType: values.transferType,
      date: values.date,
      recipientDetails: {
        bankName: values.bankName,
        routingNumber: values.routingNumber,
        accountNumber: values.accountNumber,
        accountType: values.accountType,
        accountName: values.accountName,
        saveRecipient: values.saveRecipient
      }
    });
    
    if (fee > 0) {
      // Store the fee amount and open the fee alert dialog
      setCurrentFee(fee);
      setFeeAlertDialogOpen(true);
    } else {
      // If no fee, directly open the confirmation dialog
      setExternalConfirmDialogOpen(true);
    }
  };
  
  const onExternalTransferSubmit = () => {
    if (pendingExternalTransfer) {
      transferMutation.mutate(pendingExternalTransfer);
    }
    
    // Close dialog
    setExternalConfirmDialogOpen(false);
  };
  
  const openTransactionDetails = (transaction: Transaction) => {
    setSelectedTransaction(transaction as ExtendedTransaction);
    setTransactionDetailsOpen(true);
  };
  
  // Sample frequent recipients
  const frequentRecipients = [
    { id: 1, name: "John Smith", bankName: "Chase Bank", accountNumber: "******1234", avatarUrl: "" },
    { id: 2, name: "Sarah Johnson", bankName: "Bank of America", accountNumber: "******5678", avatarUrl: "" },
    { id: 3, name: "Michael Brown", bankName: "Wells Fargo", accountNumber: "******9012", avatarUrl: "" },
  ];
  
  // Get transfers from transaction history
  const transfers = recentTransfers
    .filter((transaction: any) => transaction.transactionType === "transfer")
    .slice(0, 5);
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow bg-neutral-50 dark:bg-neutral-900">
        <div className="container mx-auto px-4 py-6">
          {/* Page Header */}
          <div className="mb-6">
            <h1 className="text-2xl md:text-3xl font-bold text-neutral-900 dark:text-white">Transfers</h1>
            <p className="text-neutral-600 dark:text-neutral-400 mt-1">
              Move money between your accounts or to external accounts
            </p>
          </div>
          
          {/* Accounts Summary */}
          <div className="mb-8">
            <h2 className="text-lg font-semibold mb-3">Your Accounts</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {accounts.map((account: any) => (
                <Card key={account.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">{account.accountName}</h3>
                        <p className="text-sm text-neutral-500 dark:text-neutral-400">****{account.accountNumber}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-semibold">{formatCurrency(account.balance)}</p>
                        <p className="text-xs text-neutral-500 dark:text-neutral-400">Available: {formatCurrency(account.availableBalance)}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
          
          {/* Transfer Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            <Card className={`cursor-pointer hover:shadow-md transition-shadow ${activeTab === "between-accounts" ? "border-primary bg-primary/5" : ""}`} onClick={() => setActiveTab("between-accounts")}>
              <CardContent className="p-6 flex items-center">
                <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center mr-4">
                  <SwapHoriz className="text-blue-600 dark:text-blue-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Between My Accounts</h3>
                  <p className="text-sm text-neutral-600 dark:text-neutral-400">
                    Transfer between your Fortis Capital accounts
                  </p>
                </div>
              </CardContent>
            </Card>
            
            <Card className={`cursor-pointer hover:shadow-md transition-shadow ${activeTab === "send-money" ? "border-primary bg-primary/5" : ""}`} onClick={() => setActiveTab("send-money")}>
              <CardContent className="p-6 flex items-center">
                <div className="w-12 h-12 rounded-full bg-purple-100 dark:bg-purple-900 flex items-center justify-center mr-4">
                  <Send className="text-purple-600 dark:text-purple-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Send Money</h3>
                  <p className="text-sm text-neutral-600 dark:text-neutral-400">
                    Transfer to other banks or people
                  </p>
                </div>
              </CardContent>
            </Card>
            
            <Card className={`cursor-pointer hover:shadow-md transition-shadow ${activeTab === "scheduled" ? "border-primary bg-primary/5" : ""}`} onClick={() => setActiveTab("scheduled")}>
              <CardContent className="p-6 flex items-center">
                <div className="w-12 h-12 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center mr-4">
                  <Schedule className="text-green-600 dark:text-green-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Scheduled Transfers</h3>
                  <p className="text-sm text-neutral-600 dark:text-neutral-400">
                    Manage your upcoming transfers
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Transfer Form */}
          <Card className="mb-8">
            <Tabs defaultValue={activeTab} value={activeTab} onValueChange={setActiveTab}>
              <CardHeader>
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="between-accounts">Between My Accounts</TabsTrigger>
                  <TabsTrigger value="send-money">Send Money</TabsTrigger>
                  <TabsTrigger value="scheduled">Scheduled</TabsTrigger>
                </TabsList>
              </CardHeader>
              
              <CardContent>
                <TabsContent value="between-accounts">
                  <div className="bg-blue-50 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-800 rounded-lg p-3 mb-6 text-sm text-blue-700 dark:text-blue-300">
                    <p className="flex items-center">
                      <svg className="h-4 w-4 mr-2" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <circle cx="12" cy="12" r="10" />
                        <path d="M12 16v-4" />
                        <path d="M12 8h.01" />
                      </svg>
                      Schedule a one-time or recurring transfer between your Fortis Capital accounts
                    </p>
                  </div>
                
                  <Form {...internalForm}>
                    <form onSubmit={internalForm.handleSubmit(onInternalTransferSubmit)} className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={internalForm.control}
                          name="fromAccountId"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>From Account</FormLabel>
                              <Select 
                                onValueChange={field.onChange} 
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select account" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {accounts.map((account: any) => (
                                    <SelectItem key={account.id} value={account.id.toString()}>
                                      {account.accountName} (****{account.accountNumber}) - {formatCurrency(account.availableBalance)}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={internalForm.control}
                          name="toAccountId"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>To Account</FormLabel>
                              <Select 
                                onValueChange={field.onChange} 
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select account" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {accounts.map((account: any) => (
                                    <SelectItem key={account.id} value={account.id.toString()}>
                                      {account.accountName} (****{account.accountNumber}) - {formatCurrency(account.availableBalance)}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={internalForm.control}
                          name="amount"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Amount</FormLabel>
                              <FormControl>
                                <Input 
                                  type="text" 
                                  placeholder="0.00" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={internalForm.control}
                          name="frequency"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Frequency</FormLabel>
                              <Select 
                                onValueChange={field.onChange} 
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select frequency" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="once">One time</SelectItem>
                                  <SelectItem value="weekly">Weekly</SelectItem>
                                  <SelectItem value="biweekly">Every 2 weeks</SelectItem>
                                  <SelectItem value="monthly">Monthly</SelectItem>
                                  <SelectItem value="quarterly">Quarterly</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={internalForm.control}
                          name="date"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Date</FormLabel>
                              <FormControl>
                                <Input 
                                  type="date" 
                                  {...field} 
                                  min={today}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={internalForm.control}
                          name="memo"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Memo (Optional)</FormLabel>
                              <FormControl>
                                <Input 
                                  type="text" 
                                  placeholder="What's this for?" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      {/* Transfer summary */}
                      {internalForm.watch("fromAccountId") && internalForm.watch("toAccountId") && internalForm.watch("amount") && (
                        <div className="bg-neutral-50 dark:bg-neutral-800 p-4 rounded-lg border border-neutral-200 dark:border-neutral-700 mt-4">
                          <h3 className="font-medium text-sm mb-2">Transfer Summary</h3>
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span className="text-neutral-600 dark:text-neutral-400">From</span>
                              <span>
                                {accounts.find((acc: any) => acc.id.toString() === internalForm.watch("fromAccountId"))?.accountName}
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-neutral-600 dark:text-neutral-400">To</span>
                              <span>
                                {accounts.find((acc: any) => acc.id.toString() === internalForm.watch("toAccountId"))?.accountName}
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-neutral-600 dark:text-neutral-400">Amount</span>
                              <span className="font-semibold">{formatCurrency(parseFloat(internalForm.watch("amount") || "0"))}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-neutral-600 dark:text-neutral-400">Date</span>
                              <span>{internalForm.watch("date")}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-neutral-600 dark:text-neutral-400">Frequency</span>
                              <span className="capitalize">{internalForm.watch("frequency")}</span>
                            </div>
                            {internalForm.watch("memo") && (
                              <div className="flex justify-between">
                                <span className="text-neutral-600 dark:text-neutral-400">Memo</span>
                                <span>{internalForm.watch("memo")}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                      
                      <div className="flex justify-end space-x-2 pt-4">
                        <Button 
                          variant="outline" 
                          type="button"
                          onClick={() => internalForm.reset()}
                        >
                          Cancel
                        </Button>
                        <Button 
                          type="button"
                          onClick={internalForm.handleSubmit(prepareInternalTransfer)}
                          disabled={transferMutation.isPending || isLoadingAccounts}
                        >
                          {transferMutation.isPending ? "Processing..." : "Continue"}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </TabsContent>
                
                <TabsContent value="send-money">
                  <div className="bg-purple-50 dark:bg-purple-900/10 border border-purple-100 dark:border-purple-800 rounded-lg p-3 mb-6 text-sm text-purple-700 dark:text-purple-300">
                    <p className="flex items-center">
                      <svg className="h-4 w-4 mr-2" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <circle cx="12" cy="12" r="10" />
                        <path d="M12 16v-4" />
                        <path d="M12 8h.01" />
                      </svg>
                      Send money to external accounts at other financial institutions
                    </p>
                  </div>
                  
                  {/* Frequent Recipients */}
                  {frequentRecipients.length > 0 && (
                    <div className="mb-6">
                      <h3 className="text-sm font-medium mb-3">Frequent Recipients</h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                        {frequentRecipients.map(recipient => (
                          <div 
                            key={recipient.id} 
                            className="flex items-center gap-3 p-3 border border-neutral-200 dark:border-neutral-700 rounded-lg cursor-pointer hover:bg-neutral-50 dark:hover:bg-neutral-800"
                            onClick={() => {
                              externalForm.setValue("accountName", recipient.name);
                              externalForm.setValue("bankName", recipient.bankName);
                              // Other values would be set here in a real app
                            }}
                          >
                            <Avatar>
                              <AvatarFallback>{recipient.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium">{recipient.name}</p>
                              <p className="text-xs text-neutral-500 dark:text-neutral-400">{recipient.bankName} • {recipient.accountNumber}</p>
                            </div>
                          </div>
                        ))}
                        
                        <div 
                          className="flex items-center justify-center gap-2 p-3 border border-dashed border-neutral-300 dark:border-neutral-700 rounded-lg cursor-pointer hover:bg-neutral-50 dark:hover:bg-neutral-800"
                        >
                          <AddCircle className="text-neutral-400 h-5 w-5" />
                          <span className="text-sm text-neutral-500 dark:text-neutral-400">Add recipient</span>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  <Form {...externalForm}>
                    <form onSubmit={externalForm.handleSubmit(prepareExternalTransfer)} className="space-y-4">
                      <FormField
                        control={externalForm.control}
                        name="fromAccountId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>From Account</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select account" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {accounts.map((account: any) => (
                                  <SelectItem key={account.id} value={account.id.toString()}>
                                    {account.accountName} (****{account.accountNumber}) - {formatCurrency(account.availableBalance)}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={externalForm.control}
                          name="bankName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Bank Name</FormLabel>
                              <FormControl>
                                <Input 
                                  type="text" 
                                  placeholder="Recipient's bank name" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={externalForm.control}
                          name="routingNumber"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Routing Number</FormLabel>
                              <FormControl>
                                <Input 
                                  type="text" 
                                  placeholder="9-digit routing number" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={externalForm.control}
                          name="accountNumber"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Account Number</FormLabel>
                              <FormControl>
                                <Input 
                                  type="text" 
                                  placeholder="Recipient's account number" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={externalForm.control}
                          name="accountType"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Account Type</FormLabel>
                              <Select 
                                onValueChange={field.onChange} 
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select account type" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="checking">Checking</SelectItem>
                                  <SelectItem value="savings">Savings</SelectItem>
                                  <SelectItem value="business">Business</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={externalForm.control}
                        name="accountName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Account Holder Name</FormLabel>
                            <FormControl>
                              <Input 
                                type="text" 
                                placeholder="Recipient's name" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={externalForm.control}
                          name="amount"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Amount</FormLabel>
                              <FormControl>
                                <Input 
                                  type="text" 
                                  placeholder="0.00" 
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={externalForm.control}
                          name="transferType"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Transfer Type</FormLabel>
                              <Select 
                                onValueChange={field.onChange} 
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select transfer type" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="standard">Standard (2-3 business days)</SelectItem>
                                  <SelectItem value="next-day">Next Day (+$10 fee)</SelectItem>
                                  <SelectItem value="wire">Wire Transfer - Same day (+$25 fee)</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={externalForm.control}
                          name="date"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Date</FormLabel>
                              <FormControl>
                                <Input 
                                  type="date" 
                                  {...field} 
                                  min={today}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={externalForm.control}
                          name="memo"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Memo (Optional)</FormLabel>
                              <FormControl>
                                <Input 
                                  type="text" 
                                  placeholder="What's this for?" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={externalForm.control}
                        name="saveRecipient"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center space-x-3 space-y-0 rounded-md border p-3">
                            <FormControl>
                              <input
                                type="checkbox"
                                className="h-4 w-4 rounded border-gray-300"
                                checked={field.value}
                                onChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                Save recipient for future transfers
                              </FormLabel>
                              <FormDescription className="text-xs">
                                This will store their banking information securely
                              </FormDescription>
                            </div>
                          </FormItem>
                        )}
                      />
                      
                      {/* External transfer summary */}
                      {externalForm.watch("fromAccountId") && externalForm.watch("accountNumber") && 
                       externalForm.watch("bankName") && externalForm.watch("amount") && (
                        <div className="bg-neutral-50 dark:bg-neutral-800 p-4 rounded-lg border border-neutral-200 dark:border-neutral-700 mt-4">
                          <h3 className="font-medium text-sm mb-2">Transfer Summary</h3>
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span className="text-neutral-600 dark:text-neutral-400">From</span>
                              <span>
                                {accounts.find((acc: any) => acc.id.toString() === externalForm.watch("fromAccountId"))?.accountName}
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-neutral-600 dark:text-neutral-400">To</span>
                              <span>
                                {externalForm.watch("accountName")} ({externalForm.watch("bankName")})
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-neutral-600 dark:text-neutral-400">Account</span>
                              <span className="font-mono">
                                ••••{externalForm.watch("accountNumber").slice(-4)}
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-neutral-600 dark:text-neutral-400">Amount</span>
                              <span className="font-semibold">{formatCurrency(parseFloat(externalForm.watch("amount") || "0"))}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-neutral-600 dark:text-neutral-400">Transfer Type</span>
                              <span>{externalForm.watch("transferType") === "standard" ? "Standard" : 
                                      externalForm.watch("transferType") === "next-day" ? "Next Day" : "Wire Transfer"}</span>
                            </div>
                            
                            {externalForm.watch("transferType") !== "standard" && (
                              <div className="flex justify-between">
                                <span className="text-neutral-600 dark:text-neutral-400">Fee</span>
                                <span className="text-amber-600 dark:text-amber-400">
                                  {externalForm.watch("transferType") === "next-day" ? "+ $10.00" : "+ $25.00"}
                                </span>
                              </div>
                            )}
                            
                            <div className="flex justify-between">
                              <span className="text-neutral-600 dark:text-neutral-400">Date</span>
                              <span>{externalForm.watch("date")}</span>
                            </div>
                          </div>
                        </div>
                      )}
                      
                      <div className="flex justify-end space-x-2 pt-4">
                        <Button 
                          variant="outline" 
                          type="button"
                          onClick={() => externalForm.reset()}
                        >
                          Cancel
                        </Button>
                        <Button 
                          type="submit"
                          disabled={transferMutation.isPending || isLoadingAccounts}
                        >
                          {transferMutation.isPending ? "Processing..." : "Continue"}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </TabsContent>
                
                <TabsContent value="scheduled">
                  <div className="flex flex-col items-center justify-center py-8 text-center">
                    <div className="w-16 h-16 rounded-full bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center mb-4">
                      <Schedule className="h-8 w-8 text-neutral-500 dark:text-neutral-400" />
                    </div>
                    <h3 className="text-lg font-medium mb-2">No Scheduled Transfers</h3>
                    <p className="text-neutral-500 dark:text-neutral-400 max-w-md mb-6">
                      You don't have any scheduled transfers. Schedule a transfer to automate your payments.
                    </p>
                    <Button onClick={() => setActiveTab("between-accounts")}>
                      Schedule a Transfer
                    </Button>
                  </div>
                </TabsContent>
              </CardContent>
            </Tabs>
          </Card>
          
          {/* Recent Transfers */}
          <Card>
            <CardHeader className="border-b border-neutral-100 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-800/30">
              <div className="flex items-center justify-between">
                <CardTitle>Recent Transfers</CardTitle>
                <Button variant="outline" size="sm" className="flex items-center gap-1 text-xs font-medium">
                  <History className="h-3.5 w-3.5" />
                  View All
                </Button>
              </div>
            </CardHeader>
            
            {isLoadingTransfers ? (
              <div className="flex justify-center py-10">
                <div className="animate-spin rounded-full h-8 w-8 border-2 border-neutral-300 dark:border-neutral-600 border-t-primary"></div>
              </div>
            ) : transfers.length === 0 ? (
              <div className="text-center py-10 text-neutral-500 dark:text-neutral-400 px-6">
                <div className="w-12 h-12 rounded-full bg-neutral-100 dark:bg-neutral-800 mx-auto flex items-center justify-center mb-3">
                  <History className="h-6 w-6 text-neutral-400 dark:text-neutral-500" />
                </div>
                <p className="text-sm">Your recent transfer history will appear here.</p>
              </div>
            ) : (
              <>
                <div className="px-4 py-2 bg-neutral-50 dark:bg-neutral-800/30 border-b border-neutral-100 dark:border-neutral-800 text-xs font-medium text-neutral-500 dark:text-neutral-400 hidden md:grid md:grid-cols-12">
                  <div className="md:col-span-5">Transaction</div>
                  <div className="md:col-span-2 text-center">Date</div>
                  <div className="md:col-span-2 text-center">Status</div>
                  <div className="md:col-span-3 text-right">Amount</div>
                </div>
                
                <CardContent className="p-0">
                  <div className="divide-y divide-neutral-100 dark:divide-neutral-800">
                    {transfers.map((transfer: Transaction) => (
                      <div 
                        key={transfer.id} 
                        className="p-4 hover:bg-neutral-50 dark:hover:bg-neutral-800/30 transition-colors cursor-pointer"
                        onClick={() => openTransactionDetails(transfer)}
                      >
                        <div className="md:grid md:grid-cols-12 md:items-center flex flex-col gap-2 md:gap-0">
                          <div className="md:col-span-5 w-full flex items-center">
                            <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center mr-3 flex-shrink-0">
                              <SwapHoriz className="text-primary h-4 w-4" />
                            </div>
                            <div className="truncate">
                              <p className="font-medium text-sm truncate">{transfer.description}</p>
                              <p className="text-xs text-neutral-500 dark:text-neutral-400 truncate">
                                {transfer.referenceNumber ? `Ref: ${transfer.referenceNumber}` : 'Internal Transfer'}
                              </p>
                            </div>
                          </div>
                          
                          <div className="md:col-span-2 md:text-center text-xs text-neutral-600 dark:text-neutral-400 flex justify-between md:block">
                            <span className="md:hidden font-medium text-neutral-500">Date:</span>
                            <span>{formatDate(transfer.transactionDate || new Date())}</span>
                          </div>
                          
                          <div className="md:col-span-2 md:text-center flex justify-between md:block">
                            <span className="md:hidden text-xs font-medium text-neutral-500">Status:</span>
                            <Badge 
                              variant={transfer.status === "completed" ? "outline" : 
                                    transfer.status === "pending" ? "secondary" : "destructive"} 
                              className="text-xs font-normal">
                              {transfer.status.charAt(0).toUpperCase() + transfer.status.slice(1)}
                            </Badge>
                          </div>
                          
                          <div className="md:col-span-3 md:text-right font-medium flex justify-between md:block">
                            <span className="md:hidden text-xs font-medium text-neutral-500">Amount:</span>
                            <span className={transfer.toAccountId ? "text-neutral-900 dark:text-neutral-100" : "text-red-600 dark:text-red-400"}>
                              {transfer.toAccountId ? '' : '- '}{formatCurrency(transfer.amount)}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </>
            )}
            
            {transfers.length > 0 && (
              <div className="px-4 py-3 border-t border-neutral-100 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-800/30 text-xs text-neutral-500 flex justify-between items-center">
                <span>Showing {transfers.length} of {recentTransfers.filter((t: any) => t.transactionType === "transfer").length} transfers</span>
                <Button variant="ghost" size="sm" className="h-8 text-xs">
                  Download CSV
                </Button>
              </div>
            )}
          </Card>
        </div>
      </main>
      
      <Footer />
      
      {/* Internal Transfer Confirmation Dialog */}
      <Dialog open={internalConfirmDialogOpen} onOpenChange={setInternalConfirmDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Confirm Transfer</DialogTitle>
            <DialogDescription>
              Please review the details of your transfer before confirming.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800 rounded-lg p-4">
              <div className="flex items-center mb-4">
                <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-800 flex items-center justify-center mr-3">
                  <SwapHoriz className="text-blue-600 dark:text-blue-400" />
                </div>
                <div>
                  <h3 className="font-medium">Internal Transfer</h3>
                  <p className="text-xs text-blue-600 dark:text-blue-300">
                    Between your Fortis Capital accounts
                  </p>
                </div>
              </div>
              
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-neutral-700 dark:text-neutral-300">From</span>
                  <span className="font-medium">
                    {accounts.find((acc: any) => acc.id.toString() === internalForm.watch("fromAccountId"))?.accountName}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-700 dark:text-neutral-300">To</span>
                  <span className="font-medium">
                    {accounts.find((acc: any) => acc.id.toString() === internalForm.watch("toAccountId"))?.accountName}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-700 dark:text-neutral-300">Amount</span>
                  <span className="font-semibold">{formatCurrency(parseFloat(internalForm.watch("amount") || "0"))}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-700 dark:text-neutral-300">Date</span>
                  <span>{internalForm.watch("date")}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-700 dark:text-neutral-300">Frequency</span>
                  <span className="capitalize">{internalForm.watch("frequency")}</span>
                </div>
                {internalForm.watch("memo") && (
                  <div className="flex justify-between">
                    <span className="text-neutral-700 dark:text-neutral-300">Memo</span>
                    <span>{internalForm.watch("memo")}</span>
                  </div>
                )}
              </div>
            </div>
            
            <div className="px-2 py-3 bg-yellow-50 dark:bg-yellow-900/10 border border-yellow-100 dark:border-yellow-900 rounded text-sm flex items-start">
              <Info className="h-5 w-5 text-yellow-600 dark:text-yellow-500 flex-shrink-0 mr-2 mt-0.5" />
              <p className="text-yellow-800 dark:text-yellow-300">
                By proceeding, you authorize Fortis Capital to process this transfer according to the terms of your account agreement.
              </p>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setInternalConfirmDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={onInternalTransferSubmit} disabled={transferMutation.isPending}>
              {transferMutation.isPending ? "Processing..." : "Confirm Transfer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* External Transfer Confirmation Dialog */}
      <Dialog open={externalConfirmDialogOpen} onOpenChange={setExternalConfirmDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Confirm External Transfer</DialogTitle>
            <DialogDescription>
              Please review the details of your transfer before confirming.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="bg-purple-50 dark:bg-purple-900/20 border border-purple-100 dark:border-purple-800 rounded-lg p-4">
              <div className="flex items-center mb-4">
                <div className="w-10 h-10 rounded-full bg-purple-100 dark:bg-purple-800 flex items-center justify-center mr-3">
                  <Send className="text-purple-600 dark:text-purple-400" />
                </div>
                <div>
                  <h3 className="font-medium">External Transfer</h3>
                  <p className="text-xs text-purple-600 dark:text-purple-300">
                    To an account at another financial institution
                  </p>
                </div>
              </div>
              
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-neutral-700 dark:text-neutral-300">From</span>
                  <span className="font-medium">
                    {accounts.find((acc: any) => acc.id.toString() === externalForm.watch("fromAccountId"))?.accountName}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-700 dark:text-neutral-300">To</span>
                  <span className="font-medium">
                    {externalForm.watch("accountName")}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-700 dark:text-neutral-300">Bank</span>
                  <span>{externalForm.watch("bankName")}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-700 dark:text-neutral-300">Account</span>
                  <span className="font-mono">••••{externalForm.watch("accountNumber")?.slice(-4)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-700 dark:text-neutral-300">Amount</span>
                  <span className="font-semibold">{formatCurrency(parseFloat(externalForm.watch("amount") || "0"))}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-700 dark:text-neutral-300">Transfer Type</span>
                  <span>
                    {externalForm.watch("transferType") === "standard" ? "Standard" : 
                     externalForm.watch("transferType") === "next-day" ? "Next Day" : "Wire Transfer"}
                  </span>
                </div>
                
                {(externalForm.watch("transferType") === "next-day" || externalForm.watch("transferType") === "wire") && (
                  <div className="flex justify-between">
                    <span className="text-neutral-700 dark:text-neutral-300">Fee</span>
                    <span className="text-amber-600 dark:text-amber-400">
                      {externalForm.watch("transferType") === "next-day" ? "$10.00" : "$25.00"}
                    </span>
                  </div>
                )}
                
                <div className="flex justify-between">
                  <span className="text-neutral-700 dark:text-neutral-300">Date</span>
                  <span>{externalForm.watch("date")}</span>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-neutral-700 dark:text-neutral-300">Expected Arrival</span>
                  <span>
                    {externalForm.watch("transferType") === "standard" 
                      ? "2-3 business days" 
                      : externalForm.watch("transferType") === "next-day" 
                        ? "Next business day"
                        : "Same business day"}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="px-2 py-3 bg-yellow-50 dark:bg-yellow-900/10 border border-yellow-100 dark:border-yellow-900 rounded text-sm flex items-start">
              <Info className="h-5 w-5 text-yellow-600 dark:text-yellow-500 flex-shrink-0 mr-2 mt-0.5" />
              <p className="text-yellow-800 dark:text-yellow-300">
                By proceeding, you authorize Fortis Capital to process this transfer according to the terms of your account agreement. External transfers are subject to review for security purposes.
              </p>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setExternalConfirmDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={onExternalTransferSubmit} disabled={transferMutation.isPending}>
              {transferMutation.isPending ? "Processing..." : "Confirm Transfer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Fee Alert Dialog */}
      <AlertDialog open={feeAlertDialogOpen} onOpenChange={setFeeAlertDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center text-amber-700 dark:text-amber-400">
              <Warning className="h-5 w-5 mr-2" />
              Transfer Fee Notice
            </AlertDialogTitle>
            <AlertDialogDescription>
              <p className="mb-4">
                There is a <span className="font-medium">{formatCurrency(currentFee)}</span> fee associated with this transfer type.
              </p>
              <p className="mb-4">
                This fee will be deducted from your account in addition to the transfer amount.
              </p>
              <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-100 dark:border-amber-800 rounded p-3 text-sm">
                <p className="font-medium mb-1">Fee Details:</p>
                <ul className="list-disc list-inside space-y-1 text-amber-800 dark:text-amber-300">
                  {currentFee === 10 && (
                    <li>Next Day Transfer: $10.00 processing fee</li>
                  )}
                  {currentFee === 25 && (
                    <li>Wire Transfer: $25.00 processing fee</li>
                  )}
                </ul>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => {
              // Reset transfer type to standard (no fee)
              externalForm.setValue("transferType", "standard");
            }}>
              Change Transfer Type
            </AlertDialogCancel>
            <AlertDialogAction onClick={() => {
              setFeeAlertDialogOpen(false);
              setExternalConfirmDialogOpen(true);
            }}>
              Accept Fee & Continue
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      {/* Transaction Details Dialog */}
      <Dialog open={transactionDetailsOpen} onOpenChange={setTransactionDetailsOpen}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <Receipt className="h-5 w-5 mr-2" />
              Transaction Details
            </DialogTitle>
          </DialogHeader>
          
          {selectedTransaction && (
            <div className="space-y-4 py-2">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium">{selectedTransaction.description}</h3>
                <Badge variant={selectedTransaction.status === "Pending" ? "outline" : "default"}>
                  {selectedTransaction.status || "Completed"}
                </Badge>
              </div>
              
              <div className="flex items-center justify-center py-4">
                <div className="text-center">
                  <p className="text-sm text-neutral-600 dark:text-neutral-400">Amount</p>
                  <p className={`text-2xl font-bold ${selectedTransaction.accountId ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400'}`}>
                    {selectedTransaction.accountId ? '- ' : '+ '}{formatCurrency(selectedTransaction.amount)}
                  </p>
                </div>
              </div>
              
              <div className="space-y-3 text-sm border-t border-b border-neutral-200 dark:border-neutral-700 py-4">
                <div className="flex justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Transaction Date</span>
                  <span>{formatDate(selectedTransaction.date || new Date())}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Reference Number</span>
                  <span className="font-mono text-xs">{selectedTransaction.referenceNumber || `TX${Math.floor(Math.random() * 10000000)}`}</span>
                </div>
                {selectedTransaction.accountId && (
                  <div className="flex justify-between">
                    <span className="text-neutral-600 dark:text-neutral-400">From Account</span>
                    <span>
                      {accounts.find((acc: any) => acc.id === selectedTransaction.accountId)?.accountName || "Your Account"}
                    </span>
                  </div>
                )}
                {selectedTransaction.toAccountId && (
                  <div className="flex justify-between">
                    <span className="text-neutral-600 dark:text-neutral-400">To Account</span>
                    <span>
                      {accounts.find((acc: any) => acc.id === selectedTransaction.toAccountId)?.accountName || "External Account"}
                    </span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Category</span>
                  <span className="capitalize">{selectedTransaction.category}</span>
                </div>
                {selectedTransaction.transferType && (
                  <div className="flex justify-between">
                    <span className="text-neutral-600 dark:text-neutral-400">Transfer Type</span>
                    <span>
                      {selectedTransaction.transferType === "standard" ? "Standard" : 
                       selectedTransaction.transferType === "next-day" ? "Next Day" : 
                       selectedTransaction.transferType === "wire" ? "Wire Transfer" : selectedTransaction.transferType}
                    </span>
                  </div>
                )}
                
                {selectedTransaction.frequency && selectedTransaction.frequency !== "once" && (
                  <div className="flex justify-between">
                    <span className="text-neutral-600 dark:text-neutral-400">Frequency</span>
                    <span className="capitalize">{selectedTransaction.frequency}</span>
                  </div>
                )}
                
                {selectedTransaction.memo && (
                  <div className="flex justify-between">
                    <span className="text-neutral-600 dark:text-neutral-400">Memo</span>
                    <span>{selectedTransaction.memo}</span>
                  </div>
                )}
              </div>
              
              <div className="bg-neutral-50 dark:bg-neutral-800 p-3 rounded-lg flex items-center">
                <Check className="h-5 w-5 text-green-600 dark:text-green-400 mr-2" />
                <span className="text-sm">
                  {selectedTransaction.status === "Pending" 
                    ? "This transaction is being processed and may take up to 3 business days to complete."
                    : "This transaction has been completed successfully."}
                </span>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button onClick={() => setTransactionDetailsOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}