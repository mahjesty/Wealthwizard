import { useState, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import TransferModal from "@/components/modals/transfer-modal";
import { formatCurrency, formatDate, formatTime } from "@/lib/utils";
import { 
  AccountBalance, 
  Savings, 
  CreditCard as CreditCardIcon,
  SwapHoriz,
  Receipt,
  Search,
  FilterList,
  GetApp,
  Print,
  Info,
  Check,
  ArrowBack
} from "@mui/icons-material";

export default function AccountDetails() {
  const { id } = useParams<{ id: string }>();
  const accountId = parseInt(id);
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [transactionFilter, setTransactionFilter] = useState("");
  const [timeframe, setTimeframe] = useState("all");
  const [selectedTransaction, setSelectedTransaction] = useState<any>(null);
  const [isTransactionDetailOpen, setIsTransactionDetailOpen] = useState(false);
  const transactionTableRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const { user } = useAuth();
  
  // Fetch account details
  const accountQuery = useQuery({
    queryKey: [`/api/accounts/${accountId}`],
    enabled: !isNaN(accountId),
  });
  
  const { data: account, isLoading: isLoadingAccount } = accountQuery;
  
  // Fetch transactions
  const transactionsQuery = useQuery({
    queryKey: [`/api/accounts/${accountId}/transactions`],
    enabled: !isNaN(accountId),
  });
  
  const { data: transactions = [], isLoading: isLoadingTransactions } = transactionsQuery;
  
  // Function to approve a pending transaction
  const approveTransaction = async (transactionId: number) => {
    try {
      const response = await fetch(`/api/admin/transactions/${transactionId}/approve`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('fortis_admin_auth_token')}`
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to approve transaction');
      }
      
      toast({
        title: "Transaction approved",
        description: "The transaction has been successfully approved and is now processing.",
        variant: "default",
      });
      
      // Refresh data after approval
      refetchData();
    } catch (error) {
      console.error('Error approving transaction:', error);
      toast({
        title: "Approval failed",
        description: "There was an error approving the transaction. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  // Function to cancel a pending transaction
  const cancelTransaction = async (transactionId: number) => {
    try {
      const response = await fetch(`/api/admin/transactions/${transactionId}/cancel`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('fortis_admin_auth_token')}`
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to cancel transaction');
      }
      
      toast({
        title: "Transaction cancelled",
        description: "The transaction has been cancelled and will not be processed.",
        variant: "default",
      });
      
      // Refresh data after cancellation
      refetchData();
    } catch (error) {
      console.error('Error cancelling transaction:', error);
      toast({
        title: "Cancellation failed",
        description: "There was an error cancelling the transaction. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  // Function to refresh all account and transaction data
  const refetchData = () => {
    // Refetch account data
    accountQuery.refetch();
    // Refetch transactions
    transactionsQuery.refetch();
    // Close any open dialogs
    setIsTransactionDetailOpen(false);
  };
  
  // Filter transactions based on search and timeframe
  const filteredTransactions = transactions.filter((transaction: any) => {
    // Search filter
    const searchMatch = transactionFilter === "" || 
      transaction.description.toLowerCase().includes(transactionFilter.toLowerCase()) ||
      transaction.merchantName?.toLowerCase().includes(transactionFilter.toLowerCase()) ||
      transaction.category?.toLowerCase().includes(transactionFilter.toLowerCase());
    
    // Timeframe filter
    let timeframeMatch = true;
    if (timeframe !== "all") {
      const transactionDate = new Date(transaction.transactionDate);
      const now = new Date();
      
      switch (timeframe) {
        case "30days":
          const thirtyDaysAgo = new Date();
          thirtyDaysAgo.setDate(now.getDate() - 30);
          timeframeMatch = transactionDate >= thirtyDaysAgo;
          break;
        case "90days":
          const ninetyDaysAgo = new Date();
          ninetyDaysAgo.setDate(now.getDate() - 90);
          timeframeMatch = transactionDate >= ninetyDaysAgo;
          break;
        case "year":
          const oneYearAgo = new Date();
          oneYearAgo.setFullYear(now.getFullYear() - 1);
          timeframeMatch = transactionDate >= oneYearAgo;
          break;
      }
    }
    
    return searchMatch && timeframeMatch;
  });
  
  // Handle exporting transactions to CSV
  const exportTransactionsToCSV = () => {
    // Create CSV content
    const headers = ['Date', 'Description', 'Category', 'Amount', 'Type', 'Status', 'Reference'];
    const csvContent = filteredTransactions.map((t: any) => {
      return [
        formatDate(t.transactionDate),
        t.description,
        t.category || t.transactionType,
        t.amount,
        t.transactionType,
        t.status || 'completed',
        t.referenceNumber || `TX${t.id}`
      ].join(',');
    });
    
    // Create the full CSV with headers
    const fullCSV = [headers.join(','), ...csvContent].join('\n');
    
    // Create a blob and download link
    const blob = new Blob([fullCSV], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    
    // Set up and trigger download
    link.setAttribute('href', url);
    link.setAttribute('download', `fortis-capital-${account.accountNumber}-transactions.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  // Handle printing the transaction table
  const printTransactionHistory = () => {
    const printContent = document.createElement('div');
    printContent.innerHTML = `
      <html>
        <head>
          <title>Fortis Capital - Account Transactions</title>
          <style>
            body { font-family: Arial, sans-serif; }
            h1 { font-size: 18px; margin-bottom: 5px; }
            h2 { font-size: 16px; margin-bottom: 20px; color: #666; }
            table { width: 100%; border-collapse: collapse; }
            th { background-color: #f3f4f6; text-align: left; padding: 10px; font-size: 12px; border-bottom: 1px solid #ddd; }
            td { padding: 10px; border-bottom: 1px solid #eee; font-size: 12px; }
            .amount { text-align: right; }
            .debit { color: #e11d48; }
            .credit { color: #10b981; }
            .footer { margin-top: 20px; font-size: 12px; color: #666; }
          </style>
        </head>
        <body>
          <h1>Account Statement - ${account.accountName}</h1>
          <h2>Account Number: ****${account.accountNumber} | Balance: ${formatCurrency(account.balance)}</h2>
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Description</th>
                <th>Category</th>
                <th>Reference</th>
                <th>Status</th>
                <th class="amount">Amount</th>
              </tr>
            </thead>
            <tbody>
              ${filteredTransactions.map((t: any) => `
                <tr>
                  <td>${formatDate(t.transactionDate)}</td>
                  <td>${t.description}</td>
                  <td>${t.category || t.transactionType}</td>
                  <td>${t.referenceNumber || `TX${t.id}`}</td>
                  <td>${t.status || 'completed'}</td>
                  <td class="amount ${t.transactionType === 'deposit' ? 'credit' : 'debit'}">
                    ${t.transactionType === 'deposit' ? '+' : '-'}${formatCurrency(t.amount)}
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          <div class="footer">
            <p>Generated on ${formatDate(new Date())} at ${formatTime(new Date())} | Fortis Capital</p>
          </div>
        </body>
      </html>
    `;
    
    // Open a new window and print
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent.innerHTML);
      printWindow.document.close();
      printWindow.focus();
      // Print after a short delay to ensure content is loaded
      setTimeout(() => {
        printWindow.print();
        printWindow.close();
      }, 500);
    }
  };
  
  // View transaction details
  const openTransactionDetails = (transaction: any) => {
    setSelectedTransaction(transaction);
    setIsTransactionDetailOpen(true);
  };
  
  const getAccountIcon = () => {
    if (!account) return <AccountBalance className="h-6 w-6 text-white" />;
    
    switch (account.accountType) {
      case "checking":
        return <AccountBalance className="h-6 w-6 text-white" />;
      case "savings":
        return <Savings className="h-6 w-6 text-white" />;
      case "credit_card":
        return <CreditCardIcon className="h-6 w-6 text-white" />;
      default:
        return <AccountBalance className="h-6 w-6 text-white" />;
    }
  };
  
  const getTransactionIcon = (category: string, type: string) => {
    // Type-based icons
    if (type === "deposit") {
      return (
        <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center">
          <span className="material-icons-round text-green-600 dark:text-green-400">attach_money</span>
        </div>
      );
    }
    
    // Category-based icons
    switch (category) {
      case "groceries":
        return (
          <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center">
            <span className="material-icons-round text-blue-600 dark:text-blue-400">shopping_bag</span>
          </div>
        );
      case "utilities":
        return (
          <div className="w-10 h-10 rounded-full bg-purple-100 dark:bg-purple-900 flex items-center justify-center">
            <span className="material-icons-round text-purple-600 dark:text-purple-400">electric_bolt</span>
          </div>
        );
      case "dining":
        return (
          <div className="w-10 h-10 rounded-full bg-amber-100 dark:bg-amber-900 flex items-center justify-center">
            <span className="material-icons-round text-amber-600 dark:text-amber-400">restaurant</span>
          </div>
        );
      case "entertainment":
        return (
          <div className="w-10 h-10 rounded-full bg-red-100 dark:bg-red-900 flex items-center justify-center">
            <span className="material-icons-round text-red-600 dark:text-red-400">movie</span>
          </div>
        );
      default:
        return (
          <div className="w-10 h-10 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
            <span className="material-icons-round text-gray-600 dark:text-gray-400">payments</span>
          </div>
        );
    }
  };
  
  if (isLoadingAccount) {
    return (
      <div className="flex flex-col min-h-screen">
        <Header />
        <main className="flex-grow bg-neutral-50 dark:bg-neutral-900 flex justify-center items-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
        </main>
        <Footer />
      </div>
    );
  }
  
  if (!account) {
    return (
      <div className="flex flex-col min-h-screen">
        <Header />
        <main className="flex-grow bg-neutral-50 dark:bg-neutral-900 flex justify-center items-center">
          <Card className="w-full max-w-md">
            <CardContent className="p-6 text-center">
              <h2 className="text-xl font-bold mb-2">Account Not Found</h2>
              <p className="text-neutral-600 dark:text-neutral-400 mb-4">
                The account you're looking for doesn't exist or you don't have access to it.
              </p>
              <Button onClick={() => window.history.back()}>Go Back</Button>
            </CardContent>
          </Card>
        </main>
        <Footer />
      </div>
    );
  }
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow bg-neutral-50 dark:bg-neutral-900">
        <div className="container mx-auto px-4 py-6">
          {/* Account Header */}
          <div className="mb-8">
            <div className="flex flex-col md:flex-row md:items-center gap-4 mb-4">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center">
                  {getAccountIcon()}
                </div>
                <div>
                  <h1 className="text-2xl md:text-3xl font-bold text-neutral-900 dark:text-white">
                    {account.accountName}
                  </h1>
                  <div className="flex items-center text-neutral-600 dark:text-neutral-400">
                    <span className="text-xs bg-neutral-200 dark:bg-neutral-700 px-2 py-1 rounded mr-2">
                      ****{account.accountNumber}
                    </span>
                    <span>
                      {account.accountType.charAt(0).toUpperCase() + account.accountType.slice(1).replace('_', ' ')}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="md:ml-auto flex gap-2 mt-4 md:mt-0">
                <Button 
                  onClick={() => setIsTransferModalOpen(true)}
                  className="flex items-center gap-1"
                  size="sm"
                >
                  <SwapHoriz className="h-4 w-4" />
                  Transfer Money
                </Button>
              </div>
            </div>
          </div>
          
          {/* Account Overview */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Current Balance</CardTitle>
              </CardHeader>
              <CardContent>
                <p className={`text-2xl font-bold ${account.accountType === 'credit_card' ? 'text-red-600 dark:text-red-400' : ''}`}>
                  {formatCurrency(account.balance)}
                </p>
                <p className="text-sm text-neutral-600 dark:text-neutral-400 mt-1">
                  Updated on {formatDate(account.lastUpdated)}
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Available Balance</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold">
                  {formatCurrency(account.availableBalance)}
                </p>
                <p className="text-sm text-neutral-600 dark:text-neutral-400 mt-1">
                  {account.accountType === 'credit_card' ? 'Available Credit' : 'Available to Withdraw'}
                </p>
              </CardContent>
            </Card>
          </div>
          
          {/* Transactions */}
          <Card className="mb-8">
            <CardHeader className="border-b border-neutral-100 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-800/30">
              <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
                <div>
                  <CardTitle>Transaction History</CardTitle>
                  <p className="text-sm text-neutral-500 dark:text-neutral-400 mt-1">
                    View and search your recent account activity
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex items-center gap-1 text-xs"
                    onClick={exportTransactionsToCSV}
                  >
                    <GetApp className="h-3.5 w-3.5" />
                    Export CSV
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex items-center gap-1 text-xs"
                    onClick={printTransactionHistory}
                  >
                    <Print className="h-3.5 w-3.5" />
                    Print
                  </Button>
                </div>
              </div>
            </CardHeader>
            
            <div className="p-4 border-b border-neutral-100 dark:border-neutral-800">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-500 h-4 w-4" />
                  <Input 
                    placeholder="Search by description, merchant or category"
                    className="pl-10 text-sm"
                    value={transactionFilter}
                    onChange={(e) => setTransactionFilter(e.target.value)}
                  />
                </div>
                
                <div className="flex gap-2 items-center flex-wrap">
                  <span className="text-xs font-medium text-neutral-600 dark:text-neutral-400">Time period:</span>
                  <Tabs value={timeframe} onValueChange={setTimeframe} className="w-auto">
                    <TabsList className="h-8">
                      <TabsTrigger value="all" className="text-xs px-2.5 py-1">All</TabsTrigger>
                      <TabsTrigger value="30days" className="text-xs px-2.5 py-1">30 Days</TabsTrigger>
                      <TabsTrigger value="90days" className="text-xs px-2.5 py-1">90 Days</TabsTrigger>
                      <TabsTrigger value="year" className="text-xs px-2.5 py-1">Year</TabsTrigger>
                    </TabsList>
                  </Tabs>
                  
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <FilterList className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
              
            {isLoadingTransactions ? (
              <div className="flex justify-center py-16">
                <div className="animate-spin rounded-full h-10 w-10 border-2 border-neutral-300 dark:border-neutral-600 border-t-primary"></div>
              </div>
            ) : filteredTransactions.length === 0 ? (
              <div className="text-center py-16 text-neutral-500 dark:text-neutral-400 px-6">
                <div className="w-16 h-16 rounded-full bg-neutral-100 dark:bg-neutral-800 mx-auto flex items-center justify-center mb-4">
                  <Search className="h-8 w-8 text-neutral-400 dark:text-neutral-500" />
                </div>
                <h3 className="text-lg font-medium mb-1">No transactions found</h3>
                <p className="text-sm max-w-md mx-auto">
                  Try adjusting your search criteria or filter to find what you're looking for.
                </p>
              </div>
            ) : (
              <>
                {/* Table Header - Desktop */}
                <div className="hidden md:grid md:grid-cols-12 gap-4 px-6 py-3 bg-neutral-50 dark:bg-neutral-800/30 border-b border-neutral-100 dark:border-neutral-800 text-xs font-medium text-neutral-500 dark:text-neutral-400">
                  <div className="md:col-span-5">Description</div>
                  <div className="md:col-span-2">Date</div>
                  <div className="md:col-span-2">Category</div>
                  <div className="md:col-span-1">Status</div>
                  <div className="md:col-span-2 text-right">Amount</div>
                </div>
                
                <div className="px-0">
                  <div className="divide-y divide-neutral-100 dark:divide-neutral-800">
                    {filteredTransactions.map((transaction: any) => (
                      <div 
                        key={transaction.id} 
                        className="px-6 py-4 hover:bg-neutral-50 dark:hover:bg-neutral-800/30 transition-colors cursor-pointer"
                        onClick={() => openTransactionDetails(transaction)}
                      >
                        <div className="md:grid md:grid-cols-12 md:gap-4 md:items-center flex flex-col gap-2 md:gap-0">
                          {/* Description Column */}
                          <div className="md:col-span-5 w-full flex items-center">
                            <div className="w-10 h-10 flex-shrink-0 mr-3 rounded-full flex items-center justify-center">
                              {getTransactionIcon(transaction.category || '', transaction.transactionType)}
                            </div>
                            <div className="min-w-0">
                              <p className="font-medium text-sm truncate">
                                {transaction.merchantName || transaction.description}
                              </p>
                              <p className="text-xs text-neutral-500 dark:text-neutral-400 truncate">
                                {transaction.referenceNumber ? 
                                  `Ref: ${transaction.referenceNumber}` : 
                                  transaction.description}
                              </p>
                            </div>
                          </div>
                          
                          {/* Date Column */}
                          <div className="md:col-span-2 text-xs text-neutral-600 dark:text-neutral-400 flex justify-between md:block">
                            <span className="md:hidden font-medium text-neutral-500">Date:</span>
                            <span>{formatDate(transaction.transactionDate)}</span>
                          </div>
                          
                          {/* Category Column */}
                          <div className="md:col-span-2 text-xs text-neutral-600 dark:text-neutral-400 flex justify-between md:block">
                            <span className="md:hidden font-medium text-neutral-500">Category:</span>
                            <span className="capitalize">{transaction.category || transaction.transactionType}</span>
                          </div>
                          
                          {/* Status Column */}
                          <div className="md:col-span-1 flex justify-between md:block">
                            <span className="md:hidden text-xs font-medium text-neutral-500">Status:</span>
                            <div className="inline-flex items-center">
                              <div className={`w-2 h-2 rounded-full mr-1.5 
                                ${transaction.status === "completed" ? "bg-green-500" : 
                                  transaction.status === "pending" ? "bg-amber-500" : 
                                  transaction.status === "processing" ? "bg-blue-500" :
                                  transaction.status === "cancelled" ? "bg-red-500" :
                                  "bg-neutral-500"}`}>
                              </div>
                              <span className="text-xs capitalize">
                                {transaction.status === "pending" ? 
                                  "Pending admin approval" : 
                                  transaction.status || 'completed'}
                              </span>
                              {transaction.status === "pending" && user?.role === "admin" && (
                                <div className="flex gap-1 mt-1">
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    className="h-6 px-2 text-[10px] text-green-600 hover:text-green-700 hover:bg-green-50 border-green-200"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      approveTransaction(transaction.id);
                                    }}
                                  >
                                    Approve
                                  </Button>
                                  <Button
                                    size="sm" 
                                    variant="outline"
                                    className="h-6 px-2 text-[10px] text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      cancelTransaction(transaction.id);
                                    }}
                                  >
                                    Cancel
                                  </Button>
                                </div>
                              )}
                            </div>
                          </div>
                          
                          {/* Amount Column */}
                          <div className="md:col-span-2 md:text-right font-medium text-sm flex justify-between md:block">
                            <span className="md:hidden text-xs font-medium text-neutral-500">Amount:</span>
                            <span 
                              className={`${transaction.transactionType === 'deposit' ? 
                                'text-green-600 dark:text-green-400' : 
                                'text-red-600 dark:text-red-400'}`}
                            >
                              {transaction.transactionType === 'deposit' ? '+' : '-'}{formatCurrency(transaction.amount)}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Table Footer with Summary */}
                <div className="px-6 py-4 border-t border-neutral-100 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-800/30 text-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-2">
                  <div className="text-neutral-500 dark:text-neutral-400">
                    Showing {filteredTransactions.length} of {transactions.length} transactions
                  </div>
                  
                  <div className="flex flex-col md:flex-row md:items-center gap-2 md:gap-6">
                    <div className="flex gap-6">
                      <div>
                        <span className="text-neutral-500 dark:text-neutral-400">Total deposits:</span>
                        <span className="ml-2 font-medium text-green-600 dark:text-green-400">
                          {formatCurrency(
                            filteredTransactions
                              .filter(t => t.transactionType === 'deposit')
                              .reduce((sum, t) => sum + parseFloat(t.amount.toString()), 0)
                          )}
                        </span>
                      </div>
                      
                      <div>
                        <span className="text-neutral-500 dark:text-neutral-400">Total debits:</span>
                        <span className="ml-2 font-medium">
                          {formatCurrency(
                            filteredTransactions
                              .filter(t => t.transactionType !== 'deposit')
                              .reduce((sum, t) => sum + parseFloat(t.amount.toString()), 0)
                          )}
                        </span>
                      </div>
                    </div>
                    
                    <div className="md:ml-auto flex items-center gap-2">
                      <button className="text-primary hover:underline text-xs flex items-center">
                        <span>View all</span>
                      </button>
                    </div>
                  </div>
                </div>
              </>
            )}
          </Card>
        </div>
      </main>
      
      <Footer />
      
      <TransferModal 
        isOpen={isTransferModalOpen} 
        onClose={() => setIsTransferModalOpen(false)}
        fromAccountId={accountId}
        fromAccountName={account.accountName}
        fromAccountNumber={account.accountNumber}
        fromAccountBalance={account.balance}
      />
      
      {/* Transaction Details Dialog */}
      <Dialog 
        open={isTransactionDetailOpen} 
        onOpenChange={setIsTransactionDetailOpen}
      >
        {selectedTransaction && (
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle className="flex items-center">
                <span className="flex-1">Transaction Details</span>
                <Button 
                  variant="outline" 
                  size="icon" 
                  className="ml-auto h-7 w-7" 
                  onClick={() => setIsTransactionDetailOpen(false)}
                >
                  <span className="sr-only">Close</span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-4 w-4"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M18 6 6 18" />
                    <path d="m6 6 12 12" />
                  </svg>
                </Button>
              </DialogTitle>
            </DialogHeader>
            
            <div className="p-1">
              {/* Header with amount */}
              <div className="text-center py-4">
                <div className={`text-2xl font-bold ${
                  selectedTransaction.transactionType === 'deposit' ? 
                  'text-green-600 dark:text-green-400' : 
                  'text-red-600 dark:text-red-400'
                }`}>
                  {selectedTransaction.transactionType === 'deposit' ? '+' : '-'}
                  {formatCurrency(selectedTransaction.amount)}
                </div>
                <p className="text-neutral-500 dark:text-neutral-400 text-sm mt-1">
                  {selectedTransaction.status === 'pending' ? 'Pending - ' : ''}
                  {selectedTransaction.merchantName || selectedTransaction.description}
                </p>
              </div>
              
              {/* Transaction info */}
              <div className="bg-neutral-50 dark:bg-neutral-800/50 rounded-lg p-4 space-y-3 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Date</span>
                  <span className="font-medium">{formatDate(selectedTransaction.transactionDate)}</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Time</span>
                  <span className="font-medium">
                    {formatTime(new Date(selectedTransaction.transactionDate || new Date()))}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Status</span>
                  <div className="inline-flex items-center">
                    <div className={`w-2 h-2 rounded-full mr-1.5 
                      ${selectedTransaction.status === "completed" ? "bg-green-500" : 
                        selectedTransaction.status === "pending" ? "bg-amber-500" : 
                        selectedTransaction.status === "processing" ? "bg-blue-500" :
                        selectedTransaction.status === "cancelled" ? "bg-red-500" :
                        "bg-neutral-500"}`}>
                    </div>
                    <span className="font-medium capitalize">
                      {selectedTransaction.status === "pending" ? 
                        "Pending admin approval" : 
                        selectedTransaction.status || 'completed'}
                    </span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Type</span>
                  <span className="font-medium capitalize">
                    {selectedTransaction.transactionType}
                  </span>
                </div>
                
                {selectedTransaction.category && (
                  <div className="flex items-center justify-between">
                    <span className="text-neutral-600 dark:text-neutral-400">Category</span>
                    <span className="font-medium capitalize">{selectedTransaction.category}</span>
                  </div>
                )}
                
                <div className="flex items-center justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Reference</span>
                  <span className="font-mono text-xs">
                    {selectedTransaction.referenceNumber || `TX${selectedTransaction.id}`}
                  </span>
                </div>
                
                {selectedTransaction.merchantName && (
                  <div className="flex items-center justify-between">
                    <span className="text-neutral-600 dark:text-neutral-400">Merchant</span>
                    <span className="font-medium">{selectedTransaction.merchantName}</span>
                  </div>
                )}
                
                {selectedTransaction.description && (
                  <div className="flex-col space-y-1">
                    <span className="text-neutral-600 dark:text-neutral-400">Description</span>
                    <p className="text-sm">{selectedTransaction.description}</p>
                  </div>
                )}
              </div>
              
              <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-900 rounded-lg flex items-start">
                <Info className="h-5 w-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mr-2 mt-0.5" />
                <p className="text-xs text-blue-800 dark:text-blue-300">
                  {selectedTransaction.status === 'pending' 
                    ? "This transaction requires administrative approval before processing. Once approved, it will be processed on your account."
                    : selectedTransaction.status === 'cancelled'
                      ? "This transaction has been cancelled by an administrator and will not be processed."
                      : selectedTransaction.status === 'processing'
                        ? "This transaction has been approved and is currently being processed."
                        : `This transaction ${selectedTransaction.status === 'completed' ? 'was processed' : 'will be processed'} on your account 
                           ${selectedTransaction.transactionDate ? `on ${formatDate(selectedTransaction.transactionDate)}` : ''}.`
                  }
                </p>
              </div>
              
              <DialogFooter className="mt-6">
                <Button variant="outline" className="w-full sm:w-auto" onClick={() => printTransactionHistory()}>
                  <Print className="h-4 w-4 mr-2" />
                  Print Receipt
                </Button>
                <Button className="w-full sm:w-auto" onClick={() => setIsTransactionDetailOpen(false)}>
                  Close
                </Button>
              </DialogFooter>
            </div>
          </DialogContent>
        )}
      </Dialog>
    </div>
  );
}
