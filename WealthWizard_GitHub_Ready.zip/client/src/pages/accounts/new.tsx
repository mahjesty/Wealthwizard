import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { insertAccountSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage,
  FormDescription
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { 
  AccountBalance,
  Savings,
  CreditCard as CreditCardIcon,
  ArrowBack
} from "@mui/icons-material";
import { Link } from "wouter";

// Enhanced schema with validation
const newAccountSchema = insertAccountSchema.extend({
  initialDeposit: z.string().optional(),
  accountType: z.enum(["checking", "savings", "credit_card"]),
  accountName: z.string().min(3, "Account name must be at least 3 characters")
});

type NewAccountFormValues = z.infer<typeof newAccountSchema>;

export default function NewAccount() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Get user data for the form
  const { data: userData } = useQuery({
    queryKey: ["/api/auth/me"],
  });
  
  // Form setup
  const form = useForm<NewAccountFormValues>({
    resolver: zodResolver(newAccountSchema),
    defaultValues: {
      accountName: "",
      accountType: "checking",
      balance: "0",
      availableBalance: "0",
      routingNumber: "211927207", // Example routing number
      accountNumber: "",
      userId: userData?.id || 0,
    },
  });
  
  // Update the userId and suggest account name when user data is available
  useEffect(() => {
    if (userData?.id) {
      form.setValue("userId", userData.id);
      
      // Set a default account name suggestion based on the account type and user name
      const accountType = form.getValues("accountType");
      const firstName = userData.firstName || "";
      const suggestedName = accountType === "checking" ? 
        `${firstName}'s Primary Checking` : 
        accountType === "savings" ? 
        `${firstName}'s Savings` : 
        `${firstName}'s Credit Card`;
      
      // Only set if the field is empty
      if (!form.getValues("accountName")) {
        form.setValue("accountName", suggestedName);
      }
    }
  }, [userData, form]);
  
  // Update account name when account type changes
  useEffect(() => {
    const subscription = form.watch((value, { name }) => {
      if (name === "accountType" && userData?.firstName) {
        const accountType = value.accountType as string;
        const firstName = userData.firstName as string;
        
        const suggestedName = accountType === "checking" ? 
          `${firstName}'s Primary Checking` : 
          accountType === "savings" ? 
          `${firstName}'s Savings` : 
          `${firstName}'s Credit Card`;
        
        form.setValue("accountName", suggestedName);
      }
    });
    
    return () => subscription.unsubscribe();
  }, [form, userData]);
  
  // Handle form submission
  const createAccountMutation = useMutation({
    mutationFn: (data: NewAccountFormValues) => {
      // Generate random account number if not provided
      if (!data.accountNumber) {
        const randomNumbers = Array.from({length: 8}, () => Math.floor(Math.random() * 10)).join('');
        data.accountNumber = randomNumbers;
      }
      
      // Set available balance equal to balance initially
      data.availableBalance = data.balance;
      
      // Convert initialDeposit to balance if provided
      if (data.initialDeposit) {
        data.balance = data.initialDeposit;
        data.availableBalance = data.initialDeposit;
      }
      
      // Set userId
      if (userData?.id) {
        data.userId = userData.id;
      }
      
      return apiRequest("POST", "/api/accounts", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      toast({
        title: "Account created",
        description: "Your new account has been successfully created.",
      });
      navigate("/accounts");
    },
    onError: (error: any) => {
      toast({
        title: "Error creating account",
        description: error.message || "There was an error creating your account.",
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (values: NewAccountFormValues) => {
    createAccountMutation.mutate(values);
  };
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow bg-neutral-50 dark:bg-neutral-900">
        <div className="container mx-auto px-4 py-6">
          <div className="mb-6 flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/accounts">
                <ArrowBack className="h-4 w-4 mr-1" />
                Back to Accounts
              </Link>
            </Button>
          </div>
          
          <div className="mb-8">
            <h1 className="text-2xl md:text-3xl font-bold text-neutral-900 dark:text-white">Open a New Account</h1>
            <p className="text-neutral-600 dark:text-neutral-400 mt-1">
              Add a new financial account to your Fortis Capital profile
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Account Details</CardTitle>
                  <CardDescription>
                    Provide the information needed to open your new account
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      <FormField
                        control={form.control}
                        name="accountType"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Account Type</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select account type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="checking">Checking Account</SelectItem>
                                <SelectItem value="savings">Savings Account</SelectItem>
                                <SelectItem value="credit_card">Credit Card</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormDescription>
                              Choose the type of account you want to open
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="accountName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Account Name</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g. Primary Checking" {...field} />
                            </FormControl>
                            <FormDescription>
                              Choose a name to help you identify this account
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="initialDeposit"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Initial Deposit</FormLabel>
                            <FormControl>
                              <Input placeholder="0.00" {...field} type="number" step="0.01" min="0" />
                            </FormControl>
                            <FormDescription>
                              How much would you like to initially deposit? (Optional)
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <Button type="submit" className="w-full">Create Account</Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </div>
            
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Benefits & Features</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex gap-3">
                    <div className="bg-primary/10 p-2 rounded-full h-10 w-10 flex items-center justify-center">
                      <AccountBalance className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-medium">Checking Accounts</h3>
                      <p className="text-sm text-muted-foreground">No monthly fees, unlimited transactions, access to ATM network</p>
                    </div>
                  </div>
                  
                  <div className="flex gap-3">
                    <div className="bg-primary/10 p-2 rounded-full h-10 w-10 flex items-center justify-center">
                      <Savings className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-medium">Savings Accounts</h3>
                      <p className="text-sm text-muted-foreground">Competitive interest rates, automatic savings plans, goal tracking</p>
                    </div>
                  </div>
                  
                  <div className="flex gap-3">
                    <div className="bg-primary/10 p-2 rounded-full h-10 w-10 flex items-center justify-center">
                      <CreditCardIcon className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-medium">Credit Cards</h3>
                      <p className="text-sm text-muted-foreground">Rewards program, secure online shopping, worldwide acceptance</p>
                    </div>
                  </div>
                  
                  <Alert className="mt-6">
                    <AlertTitle>Important Information</AlertTitle>
                    <AlertDescription>
                      Fortis Capital requires a valid ID and personal information to open new accounts. 
                      All accounts are subject to our terms and conditions.
                    </AlertDescription>
                  </Alert>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}