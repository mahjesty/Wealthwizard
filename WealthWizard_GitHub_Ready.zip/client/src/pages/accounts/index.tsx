import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { 
  AccountBalance,
  Savings,
  CreditCard as CreditCardIcon,
  ChevronRight,
  History,
  Add,
  CameraAlt,
  Upload
} from "@mui/icons-material";
import CheckDepositDialog from "@/components/accounts/check-deposit-dialog";
import { formatCurrency } from "@/lib/utils";

export default function Accounts() {
  const [activeTab, setActiveTab] = useState("all");
  const [isCheckDepositOpen, setIsCheckDepositOpen] = useState(false);
  
  // Fetch accounts
  const { data: accounts = [], isLoading } = useQuery({
    queryKey: ["/api/accounts"],
  });
  
  // Filter accounts based on active tab
  const filteredAccounts = accounts.filter(account => {
    if (activeTab === "all") return true;
    return account.accountType === activeTab;
  });
  
  // Calculate totals
  const totalBalance = accounts.reduce((sum, account) => {
    if (account.accountType !== "credit_card") {
      return sum + parseFloat(account.balance);
    }
    return sum;
  }, 0);
  
  const totalDebt = accounts.reduce((sum, account) => {
    if (account.accountType === "credit_card") {
      return sum + parseFloat(account.balance);
    }
    return sum;
  }, 0);
  
  // Get icon for account
  const getAccountIcon = (type: string) => {
    switch (type) {
      case "checking":
        return <AccountBalance className="h-5 w-5 text-primary" />;
      case "savings":
        return <Savings className="h-5 w-5 text-primary" />;
      case "credit_card":
        return <CreditCardIcon className="h-5 w-5 text-primary" />;
      default:
        return <AccountBalance className="h-5 w-5 text-primary" />;
    }
  };
  
  const formatAccountType = (type: string) => {
    return type.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  };
  
  if (isLoading) {
    return (
      <div className="flex flex-col min-h-screen">
        <Header />
        <main className="flex-grow bg-neutral-50 dark:bg-neutral-900 flex justify-center items-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
        </main>
        <Footer />
      </div>
    );
  }
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow bg-neutral-50 dark:bg-neutral-900">
        <div className="container mx-auto px-4 py-6">
          <div className="mb-8">
            <h1 className="text-2xl md:text-3xl font-bold text-neutral-900 dark:text-white">Accounts</h1>
            <p className="text-neutral-600 dark:text-neutral-400 mt-1">
              Manage all your financial accounts in one place
            </p>
          </div>
          
          {/* Account Summary */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Total Balance</CardTitle>
                <CardDescription>Your assets across all accounts</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                  {formatCurrency(totalBalance)}
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Total Debt</CardTitle>
                <CardDescription>Your liabilities across credit cards</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold text-red-600 dark:text-red-400">
                  {formatCurrency(totalDebt)}
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Active Accounts</CardTitle>
                <CardDescription>Number of accounts you have</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold">{accounts.length}</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Net Worth</CardTitle>
                <CardDescription>Your total assets minus debt</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold">
                  {formatCurrency(totalBalance - totalDebt)}
                </p>
              </CardContent>
            </Card>
          </div>
          
          {/* Account Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <div className="flex justify-between items-center mb-4">
              <TabsList>
                <TabsTrigger value="all">All Accounts</TabsTrigger>
                <TabsTrigger value="checking">Checking</TabsTrigger>
                <TabsTrigger value="savings">Savings</TabsTrigger>
                <TabsTrigger value="credit_card">Credit Cards</TabsTrigger>
              </TabsList>
              
              <div className="flex space-x-2">
                <Button 
                  variant="outline" 
                  className="flex items-center gap-1"
                  onClick={() => setIsCheckDepositOpen(true)}
                >
                  <CameraAlt className="h-4 w-4" />
                  Deposit Check
                </Button>
                <Button variant="outline" className="flex items-center gap-1" asChild>
                  <Link href="/accounts/new">
                    <Add className="h-4 w-4" />
                    Add Account
                  </Link>
                </Button>
              </div>
            </div>
            
            <TabsContent value={activeTab} className="space-y-4">
              {filteredAccounts.length === 0 ? (
                <Card>
                  <CardContent className="flex flex-col items-center justify-center p-6">
                    <div className="text-neutral-500 dark:text-neutral-400 text-center py-8">
                      <p className="mb-2">No accounts found</p>
                      <Button variant="outline" asChild>
                        <Link href="/accounts/new">Add an Account</Link>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                filteredAccounts.map((account) => (
                  <Link key={account.id} href={`/accounts/${account.id}`}>
                    <Card className="cursor-pointer hover:shadow-md transition-shadow">
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                              {getAccountIcon(account.accountType)}
                            </div>
                            <div>
                              <h3 className="font-semibold text-lg">{account.accountName}</h3>
                              <div className="flex items-center gap-2">
                                <span className="text-sm text-muted-foreground">
                                  {formatAccountType(account.accountType)}
                                </span>
                                <span className="text-xs bg-neutral-200 dark:bg-neutral-700 px-2 py-0.5 rounded">
                                  ****{account.accountNumber}
                                </span>
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-4">
                            <div className="text-right">
                              <p className={`font-bold text-lg ${account.accountType === 'credit_card' ? 'text-red-600 dark:text-red-400' : ''}`}>
                                {formatCurrency(account.balance)}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {account.accountType === 'credit_card' ? 'Current Balance' : 'Available Balance'}
                              </p>
                            </div>
                            <ChevronRight className="h-5 w-5 text-muted-foreground" />
                          </div>
                        </div>
                        
                        <div className="mt-4 flex justify-between items-center pt-4 border-t border-neutral-200 dark:border-neutral-700">
                          <Button variant="ghost" className="text-primary flex items-center gap-1">
                            <History className="h-4 w-4" />
                            View Transactions
                          </Button>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline">Transfer</Button>
                            <Button size="sm">Pay</Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      <Footer />
      
      {/* Check Deposit Dialog */}
      <CheckDepositDialog 
        isOpen={isCheckDepositOpen} 
        onClose={() => setIsCheckDepositOpen(false)} 
        accounts={accounts.filter(account => account.accountType !== "credit_card")}
      />
    </div>
  );
}
