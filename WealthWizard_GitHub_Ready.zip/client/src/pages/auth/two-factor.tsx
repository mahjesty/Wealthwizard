import { useState, useRef, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { AccountBalance, Security } from "@mui/icons-material";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useTheme } from "@/lib/theme-provider";
import { DarkMode, LightMode } from "@mui/icons-material";

export default function TwoFactor() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { theme, setTheme } = useTheme();
  const [isLoading, setIsLoading] = useState(false);
  const [code, setCode] = useState<string[]>(Array(6).fill(""));
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
  
  // Focus the first input on mount
  useEffect(() => {
    if (inputRefs.current[0]) {
      inputRefs.current[0].focus();
    }
  }, []);
  
  const handleChange = (index: number, value: string) => {
    // Allow only numbers
    if (!/^\d*$/.test(value)) return;
    
    // Update code state
    const newCode = [...code];
    newCode[index] = value;
    setCode(newCode);
    
    // If value is filled and not the last input, focus next input
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };
  
  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    // If backspace and empty, focus previous input
    if (e.key === "Backspace" && !code[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };
  
  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData("text/plain").trim();
    
    // Check if pasted data is a 6-digit number
    if (/^\d{6}$/.test(pastedData)) {
      const newCode = pastedData.split("");
      setCode(newCode);
      
      // Focus last input
      inputRefs.current[5]?.focus();
    }
  };
  
  const handleVerify = () => {
    const verificationCode = code.join("");
    
    // Validate code
    if (verificationCode.length !== 6) {
      toast({
        title: "Invalid code",
        description: "Please enter the 6-digit verification code.",
        variant: "destructive",
      });
      return;
    }
    
    setIsLoading(true);
    
    // In a real app, this would call an API to verify the code
    // For the demo, we'll simulate a successful verification
    setTimeout(() => {
      setIsLoading(false);
      toast({
        title: "Verification successful",
        description: "You have been successfully verified.",
      });
      navigate("/dashboard");
    }, 1500);
  };
  
  const handleResend = () => {
    toast({
      title: "Code resent",
      description: "A new verification code has been sent to your device.",
    });
  };
  
  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };
  
  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-neutral-50 dark:bg-neutral-900">
      <div className="absolute top-4 right-4">
        <Button variant="ghost" size="icon" onClick={toggleTheme}>
          {theme === "dark" ? (
            <LightMode className="h-5 w-5 text-neutral-600 dark:text-neutral-400" />
          ) : (
            <DarkMode className="h-5 w-5 text-neutral-600 dark:text-neutral-400" />
          )}
        </Button>
      </div>
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center">
              <Security className="text-white" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold">Two-Step Verification</CardTitle>
          <CardDescription>Enter the code sent to your mobile device</CardDescription>
        </CardHeader>
        <CardContent>
          <form className="space-y-5" onSubmit={(e) => { e.preventDefault(); handleVerify(); }}>
            <div className="flex justify-center gap-2">
              {[0, 1, 2, 3, 4, 5].map((index) => (
                <Input
                  key={index}
                  ref={(el) => (inputRefs.current[index] = el)}
                  type="text"
                  maxLength={1}
                  className="w-12 h-14 text-center text-xl font-medium"
                  value={code[index]}
                  onChange={(e) => handleChange(index, e.target.value)}
                  onKeyDown={(e) => handleKeyDown(index, e)}
                  onPaste={index === 0 ? handlePaste : undefined}
                />
              ))}
            </div>
            
            <p className="text-center text-sm text-neutral-600 dark:text-neutral-400">
              Didn't receive a code? <Button variant="link" className="p-0 h-auto" onClick={handleResend}>Resend</Button>
            </p>
            
            <Button 
              type="submit" 
              className="w-full"
              disabled={isLoading}
            >
              {isLoading ? "Verifying..." : "Verify"}
            </Button>
          </form>
          
          <div className="mt-4 text-center">
            <Link href="/login">
              <Button variant="ghost" className="text-sm">Back to login</Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
