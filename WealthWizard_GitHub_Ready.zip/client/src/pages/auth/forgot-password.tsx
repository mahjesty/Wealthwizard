import { useState } from 'react';
import { Link } from 'wouter';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, Mail, AlertCircle, CheckCircle } from 'lucide-react';
import { FortisLogo } from '@/components/ui/fortis-logo';

const forgotPasswordSchema = z.object({
  email: z.string().email({ message: 'Please enter a valid email address' }),
});

type ForgotPasswordFormValues = z.infer<typeof forgotPasswordSchema>;

export default function ForgotPassword() {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const form = useForm<ForgotPasswordFormValues>({
    resolver: zodResolver(forgotPasswordSchema),
    defaultValues: {
      email: '',
    },
  });

  async function onSubmit(values: ForgotPasswordFormValues) {
    setIsLoading(true);
    setError(null);
    
    try {
      // Make API call to forgot password endpoint
      await apiRequest('POST', '/api/auth/forgot-password', values);
      
      setIsSubmitted(true);
      
      // Show success toast
      toast({
        title: 'Reset link sent',
        description: 'If an account exists with that email, we have sent password reset instructions.',
        variant: 'default',
      });
    } catch (err: any) {
      setError(err.message || 'An error occurred. Please try again.');
      toast({
        title: 'Error',
        description: 'Failed to send reset instructions. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center p-4 md:p-8">
      <div className="w-full max-w-md space-y-6">
        <div className="text-center">
          <div className="flex justify-center mb-4">
            <FortisLogo width={70} height={70} className="text-primary" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-primary mb-2">Fortis Capital</h1>
          <p className="text-muted-foreground mb-6">
            Enter your email address and we'll send you instructions to reset your password.
          </p>
        </div>

        {isSubmitted ? (
          <div className="space-y-6">
            <Alert className="bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-800">
              <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
              <AlertDescription className="text-green-700 dark:text-green-400">
                If an account exists with that email, we have sent password reset instructions.
                Please check your email inbox and spam folder.
              </AlertDescription>
            </Alert>
            <div className="flex flex-col space-y-2 text-center">
              <Link href="/login">
                <a className="text-primary hover:underline">Return to login</a>
              </Link>
            </div>
          </div>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email address</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Mail className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                        <Input
                          placeholder="your.email@example.com"
                          className="pl-10"
                          {...field}
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button
                type="submit"
                className="w-full py-6 text-base"
                disabled={isLoading}
              >
                {isLoading ? (
                  <span className="flex items-center justify-center">
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Sending instructions...
                  </span>
                ) : (
                  "Send reset instructions"
                )}
              </Button>

              <div className="flex flex-col space-y-2 text-center">
                <p className="text-sm text-muted-foreground">
                  Remembered your password?
                </p>
                <Link href="/login">
                  <a className="text-primary hover:underline font-medium">
                    Back to login
                  </a>
                </Link>
              </div>
            </form>
          </Form>
        )}
      </div>
    </div>
  );
}