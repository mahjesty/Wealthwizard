import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { BiometricLogin } from "@/components/auth/biometric-login";
import { RestrictionModal } from "@/components/auth/restriction-modal";
import { 
  Loader2, 
  User, 
  KeyRound, 
  ShieldCheck,
  Fingerprint
} from "lucide-react";

const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
  rememberMe: z.boolean().optional(),
});

type LoginFormValues = z.infer<typeof loginSchema>;

export default function LoginForm() {
  const { login } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [loginError, setLoginError] = useState<{
    restricted: boolean;
    restrictionReason?: string;
    message?: string;
  } | null>(null);
  const [showRestrictionModal, setShowRestrictionModal] = useState(false);
  
  const form = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
      rememberMe: false,
    },
  });

  async function onSubmit(data: LoginFormValues) {
    try {
      // Clear any previous errors
      setLoginError(null);
      setIsLoading(true);
      await login(data.username, data.password);
      // Navigation happens in the login function
    } catch (error: any) {
      // Check if this is a restriction error
      if (error.restricted) {
        setLoginError({
          restricted: true,
          restrictionReason: error.restrictionReason,
          message: error.message
        });
        // Immediately show the modal
        setShowRestrictionModal(true);
      } else {
        // Clear any previous restriction errors
        setLoginError(null);
        setShowRestrictionModal(false);
      }
      // Other error handling is done in the login function
      console.error("Login error:", error);
    } finally {
      setIsLoading(false);
    }
  }
  
  // Handle successful biometric authentication with proper credentials
  const handleBiometricSuccess = async (username: string, password: string) => {
    try {
      // Clear any previous errors
      setLoginError(null);
      setIsLoading(true);
      await login(username, password);
    } catch (error: any) {
      // Check if this is a restriction error
      if (error.restricted) {
        setLoginError({
          restricted: true,
          restrictionReason: error.restrictionReason,
          message: error.message
        });
        // Immediately show the modal
        setShowRestrictionModal(true);
      } else {
        // Clear any previous restriction errors
        setLoginError(null);
        setShowRestrictionModal(false);
      }
      console.error("Biometric login error:", error);
    } finally {
      setIsLoading(false);
    }
  };
  
  // After successful login, store credentials for biometric auth if "Remember device" is checked
  useEffect(() => {
    // Check for successful login and rememberMe value
    const saveCredentialsForBiometricAuth = async () => {
      const username = form.getValues("username");
      const password = form.getValues("password");
      const rememberMe = form.getValues("rememberMe");
      
      if (username && password && rememberMe) {
        try {
          // First, check if the device supports biometric authentication
          if (window.PublicKeyCredential) {
            const biometricAvailable = await window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
            
            if (biometricAvailable) {
              // In a production app, we would:
              // 1. Register the device with the server for this user
              // 2. Create a WebAuthn credential with the biometric sensor
              // 3. Store the credential ID for future authentications
              
              // For now, we'll store credentials in localStorage, but in a real
              // implementation we would use a more secure approach
              localStorage.setItem(
                'fortis_biometric_credentials', 
                JSON.stringify({ username, password })
              );
              
              // Show success message to user
              toast({
                title: "Biometric login enabled",
                description: "You can now use your fingerprint or face ID to sign in on this device.",
              });
            }
          }
        } catch (error) {
          console.error("Error setting up biometric auth:", error);
        }
      } else if (!rememberMe) {
        // If user unchecked "Remember device", remove any stored credentials
        localStorage.removeItem('fortis_biometric_credentials');
      }
    };
    
    const formSubmitSuccessful = form.formState.isSubmitSuccessful;
    if (formSubmitSuccessful && !isLoading) {
      saveCredentialsForBiometricAuth();
    }
  }, [form.formState.isSubmitSuccessful, isLoading, toast]);

  // Effect to show modal when a login restriction is detected
  useEffect(() => {
    if (loginError?.restricted) {
      setShowRestrictionModal(true);
    } else {
      setShowRestrictionModal(false);
    }
  }, [loginError]);

  // Handle modal close
  const handleCloseRestrictionModal = () => {
    setShowRestrictionModal(false);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
        {/* Restriction Modal */}
        <RestrictionModal
          isOpen={showRestrictionModal}
          onClose={handleCloseRestrictionModal}
          title="Account Access Restricted"
          description={loginError?.restrictionReason || "Your account access has been restricted by Fortis Capital for security reasons."}
          restrictionType="login"
          showContactInfo={true}
        />
        
        <FormField
          control={form.control}
          name="username"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="text-gray-700">Username</FormLabel>
              <FormControl>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                    <User className="h-4 w-4" />
                  </div>
                  <Input
                    placeholder="Enter your username"
                    className="pl-10 bg-gray-50 border-gray-200 focus:bg-white text-gray-900"
                    {...field}
                    disabled={isLoading}
                  />
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="password"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="text-gray-700">Password</FormLabel>
              <FormControl>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                    <KeyRound className="h-4 w-4" />
                  </div>
                  <Input
                    type="password"
                    placeholder="••••••••"
                    className="pl-10 bg-gray-50 border-gray-200 focus:bg-white text-gray-900"
                    {...field}
                    disabled={isLoading}
                  />
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <div className="flex justify-between items-center">
          <FormField
            control={form.control}
            name="rememberMe"
            render={({ field }) => (
              <FormItem className="flex flex-row items-center space-x-2 space-y-0 mb-0">
                <FormControl>
                  <Checkbox
                    checked={field.value}
                    onCheckedChange={field.onChange}
                    disabled={isLoading}
                    className="text-primary border-gray-300"
                  />
                </FormControl>
                <div className="leading-none">
                  <FormLabel className="text-sm text-gray-600">Remember device</FormLabel>
                </div>
              </FormItem>
            )}
          />
        </div>
        
        <Button 
          type="submit" 
          className="w-full py-6 text-base font-medium" 
          disabled={isLoading}
          size="lg"
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              Signing in...
            </>
          ) : (
            <>
              <ShieldCheck className="mr-2 h-5 w-5" />
              Secure Sign In
            </>
          )}
        </Button>
        
        <div className="relative py-2">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-gray-200"></div>
          </div>
          <div className="relative flex justify-center">
            <span className="bg-white px-2 text-xs text-gray-500">OR</span>
          </div>
        </div>
        
        <BiometricLogin 
          onBiometricLogin={handleBiometricSuccess}
          className="w-full"
        />
      </form>
    </Form>
  );
}