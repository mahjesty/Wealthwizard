import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Loader2,
  User,
  Mail,
  Key,
  ShieldCheck,
  AtSign,
  Lock,
  FileText,
  AlertTriangle,
  Info,
  CheckCircle,
  ChevronRight,
  ChevronLeft,
  BriefcaseBusiness,
  DollarSign
} from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
const US_STATES = [
  { value: "AL", label: "Alabama" },
  { value: "AK", label: "Alaska" },
  { value: "AZ", label: "Arizona" },
  { value: "AR", label: "Arkansas" },
  { value: "CA", label: "California" },
  { value: "CO", label: "Colorado" },
  { value: "CT", label: "Connecticut" },
  { value: "DE", label: "Delaware" },
  { value: "FL", label: "Florida" },
  { value: "GA", label: "Georgia" },
  { value: "HI", label: "Hawaii" },
  { value: "ID", label: "Idaho" },
  { value: "IL", label: "Illinois" },
  { value: "IN", label: "Indiana" },
  { value: "IA", label: "Iowa" },
  { value: "KS", label: "Kansas" },
  { value: "KY", label: "Kentucky" },
  { value: "LA", label: "Louisiana" },
  { value: "ME", label: "Maine" },
  { value: "MD", label: "Maryland" },
  { value: "MA", label: "Massachusetts" },
  { value: "MI", label: "Michigan" },
  { value: "MN", label: "Minnesota" },
  { value: "MS", label: "Mississippi" },
  { value: "MO", label: "Missouri" },
  { value: "MT", label: "Montana" },
  { value: "NE", label: "Nebraska" },
  { value: "NV", label: "Nevada" },
  { value: "NH", label: "New Hampshire" },
  { value: "NJ", label: "New Jersey" },
  { value: "NM", label: "New Mexico" },
  { value: "NY", label: "New York" },
  { value: "NC", label: "North Carolina" },
  { value: "ND", label: "North Dakota" },
  { value: "OH", label: "Ohio" },
  { value: "OK", label: "Oklahoma" },
  { value: "OR", label: "Oregon" },
  { value: "PA", label: "Pennsylvania" },
  { value: "RI", label: "Rhode Island" },
  { value: "SC", label: "South Carolina" },
  { value: "SD", label: "South Dakota" },
  { value: "TN", label: "Tennessee" },
  { value: "TX", label: "Texas" },
  { value: "UT", label: "Utah" },
  { value: "VT", label: "Vermont" },
  { value: "VA", label: "Virginia" },
  { value: "WA", label: "Washington" },
  { value: "WV", label: "West Virginia" },
  { value: "WI", label: "Wisconsin" },
  { value: "WY", label: "Wyoming" },
  { value: "DC", label: "District of Columbia" },
];

// Industry types
const INDUSTRY_TYPES = [
  "Healthcare",
  "Technology",
  "Finance/Banking",
  "Education",
  "Government",
  "Retail",
  "Manufacturing",
  "Construction",
  "Legal Services",
  "Transportation",
  "Hospitality",
  "Real Estate",
  "Energy/Utilities",
  "Agriculture",
  "Non-profit",
  "Media/Entertainment",
  "Self-employed",
  "Student",
  "Retired",
  "Other"
];

// Income ranges
const INCOME_RANGES = [
  { value: "under25k", label: "Under $25,000" },
  { value: "25k-50k", label: "$25,000 - $49,999" },
  { value: "50k-75k", label: "¢50,000 - $74,999" },
  { value: "75k-100k", label: "$75,000 - $99,999" },
  { value: "100k-150k", label: "$100,000 - $149,999" },
  { value: "150k-200k", label: "$150,000 - $199,999" },
  { value: "200k-plus", label: "$200,000+" },
  { value: "prefer-not-say", label: "Prefer not to say" }
];

// Security questions
const SECURITY_QUESTIONS = [
  "What was the name of your first pet?",
  "In which city were you born?",
  "What was the model of your first car?",
  "What is your mother's maiden name?",
  "What was the name of your elementary school?",
  "What is the name of your favorite childhood teacher?",
  "What is your favorite movie?",
  "What was your childhood nickname?",
  "What is the name of the street you grew up on?",
  "What is your favorite book?"
];

// Simplified registration schema for approved applications
const registerSchema = z
  .object({
    // Application information
    applicationNumber: z.string()
      .min(1, "Application number is required"),
    
    // Email (to verify identity)
    email: z.string().email("Invalid email address"),
    
    // Login credentials
    username: z.string()
      .min(5, "Username must be at least 5 characters")
      .regex(/^[a-zA-Z0-9_]+$/, "Username can only contain letters, numbers, and underscores"),
    password: z
      .string()
      .min(8, "Password must be at least 8 characters")
      .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
      .regex(/[a-z]/, "Password must contain at least one lowercase letter")
      .regex(/[0-9]/, "Password must contain at least one number")
      .regex(/[^A-Za-z0-9]/, "Password must contain at least one special character"),
    confirmPassword: z.string(),
    
    // Security questions
    securityQuestion1: z.string().min(1, "Security question 1 is required"),
    securityAnswer1: z.string().min(1, "Security answer 1 is required"),
    securityQuestion2: z.string().min(1, "Security question 2 is required"),
    securityAnswer2: z.string().min(1, "Security answer 2 is required"),
    
    // Legal Agreements
    agreeTerms: z.boolean().refine(val => val === true, {
      message: "You must agree to the terms and conditions",
    }),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords don't match",
    path: ["confirmPassword"],
  })
  .refine(
    (data) => data.securityAnswer1.toLowerCase() !== data.securityAnswer2.toLowerCase(),
    {
      message: "Security answers must be different",
      path: ["securityAnswer2"],
    }
  );

type RegisterFormValues = z.infer<typeof registerSchema>;

export default function RegisterForm() {
  const { register } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState(0);
  const [formStep, setFormStep] = useState(0);
  const [verificationError, setVerificationError] = useState<string | null>(null);
  const [applicationVerified, setApplicationVerified] = useState(false);
  const { toast } = useToast();
  
  const form = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      applicationNumber: "",
      email: "",
      username: "",
      password: "",
      confirmPassword: "",
      securityQuestion1: "",
      securityAnswer1: "",
      securityQuestion2: "",
      securityAnswer2: "",
      agreeTerms: false,
    },
    mode: "onChange",
  });

  // Calculate password strength score
  const calculatePasswordStrength = (password: string) => {
    let score = 0;
    
    if (password.length >= 8) score += 1;
    if (/[A-Z]/.test(password)) score += 1;
    if (/[a-z]/.test(password)) score += 1;
    if (/[0-9]/.test(password)) score += 1;
    if (/[^A-Za-z0-9]/.test(password)) score += 1;
    
    setPasswordStrength(score);
  };

  // Verify application before proceeding
  async function verifyApplication() {
    try {
      setIsLoading(true);
      setVerificationError(null);
      
      const applicationNumber = form.getValues("applicationNumber");
      const email = form.getValues("email");
      
      // Verify application with backend
      const response = await apiRequest(
        "POST",
        "/api/auth/verify-application",
        { applicationNumber, email }
      );
      
      if (!response.ok) {
        const errorData = await response.json();
        setVerificationError(errorData.message || "Application verification failed");
        return false;
      }
      
      const verificationResult = await response.json();
      
      if (!verificationResult.verified) {
        setVerificationError(verificationResult.message || "Application verification failed");
        return false;
      }
      
      // Application verified successfully
      setApplicationVerified(true);
      toast({
        title: "Application Verified",
        description: "Your application has been verified. You can now create your account.",
        variant: "default",
      });
      
      return true;
    } catch (error: any) {
      console.error("Application verification error:", error);
      setVerificationError(error.message || "An error occurred during application verification");
      return false;
    } finally {
      setIsLoading(false);
    }
  }

  async function onSubmit(data: RegisterFormValues) {
    try {
      setIsLoading(true);
      
      // Remove confirmPassword and other fields not needed for backend
      const { 
        confirmPassword, 
        agreeTerms,
        ...userData 
      } = data;
      
      await register(userData);
      // Navigation happens in the register function
    } catch (error) {
      // Error handling is done in the register function
      console.error("Registration error:", error);
    } finally {
      setIsLoading(false);
    }
  }
  
  async function onNextStep() {
    const fieldsToValidate = formStep === 0
      ? ["applicationNumber", "email"]
      : ["username", "password", "confirmPassword"]
    
    const isValid = await form.trigger(fieldsToValidate as any);
    
    if (isValid) {
      // If we're at the application verification step
      if (formStep === 0) {
        // First verify the application
        const verified = await verifyApplication();
        if (!verified) return;
      }
      
      setFormStep(current => current + 1);
      window.scrollTo(0, 0);
    }
  };
  
  function onPrevStep() {
    setFormStep(current => current - 1);
    window.scrollTo(0, 0);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
        {/* Form step indicator */}
        <div className="w-full mb-6">
          <div className="flex justify-between mb-2">
            <div className={`font-medium text-sm ${formStep >= 0 ? "text-primary" : "text-gray-400"}`}>Application</div>
            <div className={`font-medium text-sm ${formStep >= 1 ? "text-primary" : "text-gray-400"}`}>Account Setup</div>
            <div className={`font-medium text-sm ${formStep >= 2 ? "text-primary" : "text-gray-400"}`}>Security</div>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-primary h-2 rounded-full transition-all duration-300" 
              style={{ width: `${(formStep / 2) * 100}%` }}
            ></div>
          </div>
        </div>

        {formStep === 0 && (
          <>
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200 mb-4">
              <div className="flex">
                <div className="mr-3 mt-1">
                  <Info className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <h4 className="text-sm font-medium text-blue-700">Create Your Login</h4>
                  <p className="text-xs text-blue-600 mt-1">
                    Before creating your login, we need to verify your approved application. 
                    Please enter your application number and the email you used in your application.
                  </p>
                </div>
              </div>
            </div>
            
            {/* Application verification status messages */}
            {verificationError && (
              <div className="bg-red-50 p-4 rounded-lg border border-red-200 mb-4">
                <div className="flex">
                  <div className="mr-3 mt-1">
                    <AlertTriangle className="h-5 w-5 text-red-600" />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-red-700">Verification Failed</h4>
                    <p className="text-xs text-red-600 mt-1">{verificationError}</p>
                  </div>
                </div>
              </div>
            )}
            
            {applicationVerified && (
              <div className="bg-green-50 p-4 rounded-lg border border-green-200 mb-4">
                <div className="flex">
                  <div className="mr-3 mt-1">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-green-700">Application Verified</h4>
                    <p className="text-xs text-green-600 mt-1">
                      Your application has been verified successfully. You can now proceed to create your account.
                    </p>
                  </div>
                </div>
              </div>
            )}
            
            <div className="space-y-4">
              <FormField
                control={form.control}
                name="applicationNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700">Application Number *</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                          <FileText className="h-4 w-4" />
                        </div>
                        <Input 
                          placeholder="APP-123456-789" 
                          className={`pl-10 ${applicationVerified ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200'} focus:bg-white`}
                          {...field} 
                          disabled={isLoading || applicationVerified} 
                        />
                      </div>
                    </FormControl>
                    <FormDescription className="text-xs text-gray-500">
                      Your application number was provided after your application was submitted
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700">Email Address *</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                          <AtSign className="h-4 w-4" />
                        </div>
                        <Input 
                          type="email"
                          placeholder="johndoe@example.com" 
                          className={`pl-10 ${applicationVerified ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200'} focus:bg-white`}
                          {...field} 
                          disabled={isLoading || applicationVerified} 
                        />
                      </div>
                    </FormControl>
                    <FormDescription className="text-xs text-gray-500">
                      Must match the email you used in your application
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="flex justify-end mt-6">
              {!applicationVerified ? (
                <Button 
                  type="button" 
                  className="px-6" 
                  onClick={async () => {
                    // Only verify first, don't proceed to next step
                    const isValid = await form.trigger(["applicationNumber", "email"]);
                    if (isValid) {
                      await verifyApplication();
                    }
                  }}
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Verifying...
                    </>
                  ) : (
                    <>
                      Verify Application
                    </>
                  )}
                </Button>
              ) : (
                <Button 
                  type="button" 
                  className="px-6 bg-green-600 hover:bg-green-700" 
                  onClick={onNextStep}
                  disabled={isLoading}
                >
                  Continue
                  <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
              )}
            </div>
          </>
        )}
        
        {formStep === 1 && (
          <>
            <div className="space-y-1 mb-4">
              <h4 className="font-semibold text-gray-800">2. Financial Information</h4>
              <p className="text-sm text-gray-600">Tell us about your employment and financial situation.</p>
            </div>
            
            <FormField
              control={form.control}
              name="employmentStatus"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-700">Employment Status *</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <div className="relative">
                        <div className="absolute top-3 left-3 z-10 pointer-events-none text-gray-400">
                          <BriefcaseBusiness className="h-4 w-4" />
                        </div>
                        <SelectTrigger className="pl-10 bg-gray-50 border-gray-200 focus:bg-white">
                          <SelectValue placeholder="Select employment status" />
                        </SelectTrigger>
                      </div>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="employed">Employed</SelectItem>
                      <SelectItem value="selfEmployed">Self-employed</SelectItem>
                      <SelectItem value="retired">Retired</SelectItem>
                      <SelectItem value="student">Student</SelectItem>
                      <SelectItem value="unemployed">Unemployed</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {(form.watch("employmentStatus") === "employed" || form.watch("employmentStatus") === "selfEmployed") && (
              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="employerName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700">Employer Name *</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Company Name"
                          className="bg-gray-50 border-gray-200 focus:bg-white"
                          {...field}
                          disabled={isLoading}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid gap-4 grid-cols-1 sm:grid-cols-2">
                  <FormField
                    control={form.control}
                    name="industryType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gray-700">Industry *</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="bg-gray-50 border-gray-200 focus:bg-white">
                              <SelectValue placeholder="Select industry" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {INDUSTRY_TYPES.map((industry) => (
                              <SelectItem key={industry} value={industry.toLowerCase().replace(/\s+/g, '-')}>
                                {industry}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="occupation"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gray-700">Occupation/Job Title *</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Software Engineer"
                            className="bg-gray-50 border-gray-200 focus:bg-white"
                            {...field}
                            disabled={isLoading}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
            )}
            
            <FormField
              control={form.control}
              name="annualIncome"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-700">Annual Income (Optional)</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <div className="relative">
                        <div className="absolute top-3 left-3 z-10 pointer-events-none text-gray-400">
                          <DollarSign className="h-4 w-4" />
                        </div>
                        <SelectTrigger className="pl-10 bg-gray-50 border-gray-200 focus:bg-white">
                          <SelectValue placeholder="Select income range" />
                        </SelectTrigger>
                      </div>
                    </FormControl>
                    <SelectContent>
                      {INCOME_RANGES.map((range) => (
                        <SelectItem key={range.value} value={range.value}>{range.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormDescription className="text-xs text-gray-500">
                    This helps us recommend appropriate banking products
                  </FormDescription>
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="sourceOfFunds"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-700">Primary Source of Funds *</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger className="bg-gray-50 border-gray-200 focus:bg-white">
                        <SelectValue placeholder="Select source of funds" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="salary">Salary/Wages</SelectItem>
                      <SelectItem value="self-employment">Self-employment Income</SelectItem>
                      <SelectItem value="investments">Investment Income</SelectItem>
                      <SelectItem value="retirement">Retirement/Pension</SelectItem>
                      <SelectItem value="social-security">Social Security</SelectItem>
                      <SelectItem value="inheritance">Inheritance</SelectItem>
                      <SelectItem value="gift">Gift</SelectItem>
                      <SelectItem value="loan-proceeds">Loan Proceeds</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Separator className="my-6" />
            
            <div className="space-y-1 mb-4">
              <h4 className="font-semibold text-gray-800">Account Information</h4>
              <p className="text-sm text-gray-600">Select the account type and features you'd like.</p>
            </div>
            
            <FormField
              control={form.control}
              name="accountType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-700">Account Type *</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <div className="relative">
                        <div className="absolute top-3 left-3 z-10 pointer-events-none text-gray-400">
                          <CreditCard className="h-4 w-4" />
                        </div>
                        <SelectTrigger className="pl-10 bg-gray-50 border-gray-200 focus:bg-white">
                          <SelectValue placeholder="Select an account type" />
                        </SelectTrigger>
                      </div>
                    </FormControl>
                    <SelectContent className="max-h-80">
                      <SelectItem value="checking">Essential Checking - No monthly fees</SelectItem>
                      <SelectItem value="premium-checking">Premium Checking - Enhanced benefits</SelectItem>
                      <SelectItem value="savings">High-Yield Savings - 4.25% APY</SelectItem>
                      <SelectItem value="money-market">Money Market Account - 3.75% APY</SelectItem>
                      <SelectItem value="cd">Certificate of Deposit (CD) - 5.05% APY</SelectItem>
                      <SelectItem value="student">Student Banking - No fees until 25</SelectItem>
                      <SelectItem value="business">Business Banking - For businesses</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormDescription className="text-xs text-gray-500">
                    Learn more about our account options:
                    <div className="mt-2 p-3 bg-blue-50 border border-blue-100 rounded-md text-xs">
                      <div className="font-semibold mb-1">Account Features Overview</div>
                      <ul className="space-y-1 text-gray-700 list-disc pl-4">
                        <li><span className="font-medium">Essential Checking:</span> No minimum balance, no monthly fees, free mobile banking</li>
                        <li><span className="font-medium">Premium Checking:</span> $25 monthly fee (waived with $5000+ balance), premium services, ATM fee refunds</li>
                        <li><span className="font-medium">High-Yield Savings:</span> 4.25% APY, $100 minimum to open, no monthly fees with $500+ balance</li>
                        <li><span className="font-medium">Money Market:</span> 3.75% APY, tiered rates based on balance, check writing privileges</li>
                        <li><span className="font-medium">Certificate of Deposit:</span> 5.05% APY, terms from 3 months to 5 years, $1000 minimum deposit</li>
                      </ul>
                    </div>
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="accountPurpose"
              render={({ field }) => (
                <FormItem className="space-y-3">
                  <FormLabel className="text-gray-700">Account Purpose *</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="flex flex-col space-y-1"
                    >
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="primary" />
                        </FormControl>
                        <FormLabel className="font-normal text-sm cursor-pointer">
                          Primary Banking Account
                        </FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="savings" />
                        </FormControl>
                        <FormLabel className="font-normal text-sm cursor-pointer">
                          Savings/Emergency Fund
                        </FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="investment" />
                        </FormControl>
                        <FormLabel className="font-normal text-sm cursor-pointer">
                          Investment/Wealth Building
                        </FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="business" />
                        </FormControl>
                        <FormLabel className="font-normal text-sm cursor-pointer">
                          Business Operations
                        </FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="other" />
                        </FormControl>
                        <FormLabel className="font-normal text-sm cursor-pointer">
                          Other Purpose
                        </FormLabel>
                      </FormItem>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="taxWithholding"
              render={({ field }) => (
                <FormItem className="space-y-3">
                  <FormLabel className="text-gray-700">
                    Tax Withholding Certification *
                    <span className="ml-1 inline-flex">
                      <CircleHelp className="h-4 w-4 text-gray-400 cursor-help" />
                    </span>
                  </FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="flex flex-col space-y-1"
                    >
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="subject" />
                        </FormControl>
                        <div className="space-y-1">
                          <FormLabel className="font-normal text-sm cursor-pointer">
                            I am subject to backup withholding
                          </FormLabel>
                          <p className="text-xs text-gray-500">
                            The IRS has notified you that you are currently subject to backup withholding.
                          </p>
                        </div>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="exempt" />
                        </FormControl>
                        <div className="space-y-1">
                          <FormLabel className="font-normal text-sm cursor-pointer">
                            I am exempt from backup withholding
                          </FormLabel>
                          <p className="text-xs text-gray-500">
                            You are not subject to backup withholding (most people select this option).
                          </p>
                        </div>
                      </FormItem>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
  
            <div className="flex justify-between mt-6">
              <Button 
                type="button" 
                variant="outline" 
                className="px-4" 
                onClick={prevFormStep}
                disabled={isLoading}
              >
                <ChevronRight className="mr-2 h-4 w-4 rotate-180" />
                Back
              </Button>
              
              <Button 
                type="button" 
                className="px-6" 
                onClick={nextFormStep}
                disabled={isLoading}
              >
                Continue
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </>
        )}
        
        {formStep === 2 && (
          <>
            <div className="space-y-1 mb-4">
              <h4 className="font-semibold text-gray-800">3. Security & Authentication</h4>
              <p className="text-sm text-gray-600">Create your login credentials and security measures.</p>
            </div>
            
            <FormField
              control={form.control}
              name="username"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-700">Choose a Username *</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                        <AtSign className="h-4 w-4" />
                      </div>
                      <Input
                        placeholder="johnsmith2024"
                        className="pl-10 bg-gray-50 border-gray-200 focus:bg-white"
                        {...field}
                        disabled={isLoading}
                      />
                    </div>
                  </FormControl>
                  <FormDescription className="text-xs text-gray-500">
                    Must be 5+ characters and can contain letters, numbers, and underscores.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="password"
              render={({ field: { onChange, ...field } }) => (
                <FormItem>
                  <FormLabel className="text-gray-700">Create Password *</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                        <KeyRound className="h-4 w-4" />
                      </div>
                      <Input
                        type="password"
                        placeholder="••••••••"
                        className="pl-10 bg-gray-50 border-gray-200 focus:bg-white"
                        {...field}
                        onChange={(e) => {
                          onChange(e);
                          calculatePasswordStrength(e.target.value);
                        }}
                        disabled={isLoading}
                      />
                    </div>
                  </FormControl>
                  <div className="mt-2">
                    <div className="flex gap-1 mb-1">
                      {[...Array(5)].map((_, i) => (
                        <div
                          key={i}
                          className={`h-1.5 flex-1 rounded-full ${
                            i < passwordStrength
                              ? passwordStrength < 3
                                ? "bg-red-400"
                                : passwordStrength < 5
                                  ? "bg-yellow-400"
                                  : "bg-green-500"
                              : "bg-gray-200"
                          }`}
                        />
                      ))}
                    </div>
                    <p className="text-xs text-gray-500 flex items-center">
                      <Lock className="h-3 w-3 mr-1" />
                      Requires uppercase, lowercase, number, special character, and 8+ characters
                    </p>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="confirmPassword"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-700">Confirm Password *</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                        <CheckCircle className="h-4 w-4" />
                      </div>
                      <Input
                        type="password"
                        placeholder="••••••••"
                        className="pl-10 bg-gray-50 border-gray-200 focus:bg-white"
                        {...field}
                        disabled={isLoading}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Separator className="my-6" />
            
            <div className="space-y-1 mb-4">
              <h4 className="font-semibold text-gray-800">Security Questions</h4>
              <p className="text-sm text-gray-600">Set up security questions to help verify your identity.</p>
            </div>
            
            <FormField
              control={form.control}
              name="securityQuestion1"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-700">Security Question 1 *</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger className="bg-gray-50 border-gray-200 focus:bg-white">
                        <SelectValue placeholder="Select a security question" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="mother-maiden-name">What is your mother's maiden name?</SelectItem>
                      <SelectItem value="first-pet">What was the name of your first pet?</SelectItem>
                      <SelectItem value="childhood-street">What street did you grow up on?</SelectItem>
                      <SelectItem value="high-school">What high school did you attend?</SelectItem>
                      <SelectItem value="first-car">What was the make of your first car?</SelectItem>
                      <SelectItem value="childhood-best-friend">What is the name of your childhood best friend?</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="securityAnswer1"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-700">Answer 1 *</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Your answer"
                      className="bg-gray-50 border-gray-200 focus:bg-white"
                      {...field}
                      disabled={isLoading}
                    />
                  </FormControl>
                  <FormDescription className="text-xs text-gray-500">
                    Answers are case-sensitive. Don't use personal information that can be easily found.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="securityQuestion2"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-700">Security Question 2 *</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger className="bg-gray-50 border-gray-200 focus:bg-white">
                        <SelectValue placeholder="Select a security question" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="birth-city">In what city were you born?</SelectItem>
                      <SelectItem value="favorite-teacher">Who was your favorite teacher?</SelectItem>
                      <SelectItem value="first-job">What was your first job?</SelectItem>
                      <SelectItem value="childhood-hero">Who was your childhood hero?</SelectItem>
                      <SelectItem value="parents-meeting-place">Where did your parents meet?</SelectItem>
                      <SelectItem value="favorite-vacation">What is your favorite vacation destination?</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="securityAnswer2"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-700">Answer 2 *</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Your answer"
                      className="bg-gray-50 border-gray-200 focus:bg-white"
                      {...field}
                      disabled={isLoading}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
  
            <div className="flex justify-between mt-6">
              <Button 
                type="button" 
                variant="outline" 
                className="px-4" 
                onClick={prevFormStep}
                disabled={isLoading}
              >
                <ChevronRight className="mr-2 h-4 w-4 rotate-180" />
                Back
              </Button>
              
              <Button 
                type="button" 
                className="px-6" 
                onClick={nextFormStep}
                disabled={isLoading}
              >
                Continue
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </>
        )}
        
        {formStep === 3 && (
          <>
            <div className="space-y-1 mb-4">
              <h4 className="font-semibold text-gray-800">4. Review & Submit</h4>
              <p className="text-sm text-gray-600">Please review your information and agree to terms before submitting.</p>
            </div>
            
            <div className="p-4 mb-6 bg-amber-50 border border-amber-200 rounded-lg">
              <div className="flex items-start">
                <AlertTriangle className="h-5 w-5 text-amber-500 mt-0.5 mr-3 flex-shrink-0" />
                <div className="text-sm text-amber-800">
                  <p className="font-medium mb-1">Important Notice</p>
                  <p className="text-xs leading-relaxed">
                    By submitting this application, you certify that all information provided is accurate and complete to the 
                    best of your knowledge. Providing false information may result in rejection of your application and potential 
                    legal consequences.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="space-y-6 bg-gray-50 p-4 rounded-lg text-sm">
              <div>
                <h5 className="font-semibold text-gray-700 mb-2 flex items-center">
                  <User className="h-4 w-4 mr-2 text-primary" />
                  Personal Information
                </h5>
                <div className="ml-6 grid grid-cols-2 gap-x-4 gap-y-1">
                  <p className="text-gray-700">Name:</p>
                  <p className="text-gray-800 font-medium">
                    {form.watch("firstName")} {form.watch("middleName")} {form.watch("lastName")}
                  </p>
                  <p className="text-gray-700">Date of Birth:</p>
                  <p className="text-gray-800 font-medium">
                    {form.watch("dateOfBirth") ? new Date(form.watch("dateOfBirth")).toLocaleDateString() : ""}
                  </p>
                  <p className="text-gray-700">SSN:</p>
                  <p className="text-gray-800 font-medium">
                    {form.watch("ssn") ? "••••••" + form.watch("ssn").slice(-4) : ""}
                  </p>
                  <p className="text-gray-700">Citizenship:</p>
                  <p className="text-gray-800 font-medium">
                    {form.watch("citizenshipStatus") === "usCitizen" ? "U.S. Citizen" : 
                     form.watch("citizenshipStatus") === "usResident" ? "U.S. Permanent Resident" : 
                     "Non-Resident Alien"}
                  </p>
                </div>
              </div>
              
              <div>
                <h5 className="font-semibold text-gray-700 mb-2 flex items-center">
                  <Home className="h-4 w-4 mr-2 text-primary" />
                  Contact Information
                </h5>
                <div className="ml-6 grid grid-cols-2 gap-x-4 gap-y-1">
                  <p className="text-gray-500">Email:</p>
                  <p className="text-gray-800 font-medium">
                    {form.watch("email")}
                  </p>
                  <p className="text-gray-500">Phone:</p>
                  <p className="text-gray-800 font-medium">
                    {form.watch("phoneNumber")}
                  </p>
                  <p className="text-gray-500">Address:</p>
                  <p className="text-gray-800 font-medium">
                    {form.watch("streetAddress")}{form.watch("aptSuite") ? `, ${form.watch("aptSuite")}` : ""}
                    <br />
                    {form.watch("city")}, {form.watch("state")} {form.watch("zipCode")}
                  </p>
                </div>
              </div>
              
              <div>
                <h5 className="font-semibold text-gray-700 mb-2 flex items-center">
                  <BriefcaseBusiness className="h-4 w-4 mr-2 text-primary" />
                  Employment & Financial
                </h5>
                <div className="ml-6 grid grid-cols-2 gap-x-4 gap-y-1">
                  <p className="text-gray-500">Employment Status:</p>
                  <p className="text-gray-800 font-medium capitalize">
                    {form.watch("employmentStatus")?.replace('-', ' ')}
                  </p>
                  {(form.watch("employmentStatus") === "employed" || form.watch("employmentStatus") === "selfEmployed") && (
                    <>
                      <p className="text-gray-500">Employer:</p>
                      <p className="text-gray-800 font-medium">
                        {form.watch("employerName")}
                      </p>
                      <p className="text-gray-500">Occupation:</p>
                      <p className="text-gray-800 font-medium">
                        {form.watch("occupation")}
                      </p>
                    </>
                  )}
                  <p className="text-gray-500">Source of Funds:</p>
                  <p className="text-gray-800 font-medium capitalize">
                    {form.watch("sourceOfFunds")?.replace('-', ' ')}
                  </p>
                </div>
              </div>
              
              <div>
                <h5 className="font-semibold text-gray-700 mb-2 flex items-center">
                  <CreditCard className="h-4 w-4 mr-2 text-primary" />
                  Account Information
                </h5>
                <div className="ml-6 grid grid-cols-2 gap-x-4 gap-y-1">
                  <p className="text-gray-500">Account Type:</p>
                  <p className="text-gray-800 font-medium capitalize">
                    {form.watch("accountType")?.replace('-', ' ')}
                  </p>
                  <p className="text-gray-500">Account Purpose:</p>
                  <p className="text-gray-800 font-medium capitalize">
                    {form.watch("accountPurpose") === "primary" ? "Primary Banking Account" :
                     form.watch("accountPurpose") === "savings" ? "Savings/Emergency Fund" :
                     form.watch("accountPurpose") === "investment" ? "Investment/Wealth Building" :
                     form.watch("accountPurpose") === "business" ? "Business Operations" : "Other"}
                  </p>
                  <p className="text-gray-500">Tax Withholding:</p>
                  <p className="text-gray-800 font-medium">
                    {form.watch("taxWithholding") === "subject" ? "Subject to backup withholding" : "Exempt from backup withholding"}
                  </p>
                </div>
              </div>
            </div>
            
            <Separator className="my-6" />
            
            <div className="space-y-3">
              <FormField
                control={form.control}
                name="agreeTerms"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        disabled={isLoading}
                        className="text-primary border-gray-300 mt-1"
                      />
                    </FormControl>
                    <div className="leading-none">
                      <FormLabel className="text-sm text-gray-700">
                        I agree to Fortis Capital's{" "}
                        <Link
                          to="/legal/terms-conditions?from=register"
                          className="text-primary hover:underline"
                        >
                          Account Agreement and Terms and Conditions
                        </Link>
                      </FormLabel>
                      <FormDescription className="text-xs mt-1">
                        Including account agreements, fee schedules, and funds availability policy
                      </FormDescription>
                      <FormMessage />
                    </div>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="agreePrivacyPolicy"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        disabled={isLoading}
                        className="text-primary border-gray-300 mt-1"
                      />
                    </FormControl>
                    <div className="leading-none">
                      <FormLabel className="text-sm text-gray-700">
                        I consent to Fortis Capital's{" "}
                        <Link
                          to="/legal/privacy-policy?from=register"
                          className="text-primary hover:underline"
                        >
                          Privacy Policy and Information Sharing Practices
                        </Link>
                      </FormLabel>
                      <FormDescription className="text-xs mt-1">
                        How we collect, use, share and protect your personal information
                      </FormDescription>
                      <FormMessage />
                    </div>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="agreeElectronicComm"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        disabled={isLoading}
                        className="text-primary border-gray-300 mt-1"
                      />
                    </FormControl>
                    <div className="leading-none">
                      <FormLabel className="text-sm text-gray-700">
                        I consent to receive electronic communications, statements, and notices
                      </FormLabel>
                      <FormDescription className="text-xs mt-1">
                        You'll receive account statements, tax documents, and important notices via email
                      </FormDescription>
                      <FormMessage />
                    </div>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="agreeCreditCheck"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        disabled={isLoading}
                        className="text-primary border-gray-300 mt-1"
                      />
                    </FormControl>
                    <div className="leading-none">
                      <FormLabel className="text-sm text-gray-700">
                        I authorize Fortis Capital to obtain consumer reports and verify my information
                      </FormLabel>
                      <FormDescription className="text-xs mt-1">
                        This may include credit checks and identity verification as required by federal regulations
                      </FormDescription>
                      <FormMessage />
                    </div>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="certifyInformation"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        disabled={isLoading}
                        className="text-primary border-gray-300 mt-1"
                      />
                    </FormControl>
                    <div className="leading-none">
                      <FormLabel className="text-sm text-gray-700 font-medium">
                        I certify that the information provided is true and correct
                      </FormLabel>
                      <FormDescription className="text-xs mt-1">
                        Under penalties of perjury, I certify that: (1) The information provided is true, correct, and complete, and (2) I am not subject to backup withholding, or I have indicated above that I am subject to backup withholding.
                      </FormDescription>
                      <FormMessage />
                    </div>
                  </FormItem>
                )}
              />
            </div>
  
            <div className="flex justify-between mt-6">
              <Button 
                type="button" 
                variant="outline" 
                className="px-4" 
                onClick={prevFormStep}
                disabled={isLoading}
              >
                <ChevronRight className="mr-2 h-4 w-4 rotate-180" />
                Back
              </Button>
              
              <Button 
                type="submit" 
                className="px-8 py-6 text-base font-medium" 
                disabled={isLoading}
                size="lg"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Landmark className="mr-2 h-5 w-5" />
                    Submit Application
                  </>
                )}
              </Button>
            </div>
          </>
        )}
        
        {/* Legal links footer - visible across all form steps */}
        <div className="mt-6 pt-4 border-t border-gray-200 text-center text-xs text-gray-500">
          By continuing, you agree to our{" "}
          <Link to="/legal/terms-conditions?from=register" className="text-primary hover:underline">
            Terms and Conditions
          </Link>{" "}
          and{" "}
          <Link to="/legal/privacy-policy?from=register" className="text-primary hover:underline">
            Privacy Policy
          </Link>
        </div>
      </form>
    </Form>
  );
}