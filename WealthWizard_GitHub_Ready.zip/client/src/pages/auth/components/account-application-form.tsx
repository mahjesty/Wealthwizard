import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Link } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";

// Utility function for debouncing
function debounce<F extends (...args: any[]) => any>(fn: F, delay: number) {
  let timeoutId: ReturnType<typeof setTimeout>;
  return function(...args: Parameters<F>) {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => fn(...args), delay);
  } as F;
}
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Loader2,
  User,
  Mail,
  Calendar,
  Home,
  Phone,
  Camera,
  Upload,
  FileCheck,
  IdCard,
  BriefcaseBusiness,
  Copy,
  Landmark,
  DollarSign,
  FileText,
  ShieldAlert,
  CircleHelp,
  AlertTriangle,
  CheckCircle2,
  ChevronRight,
  Clock
} from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

// US state options
const US_STATES = [
  { value: "AL", label: "Alabama" },
  { value: "AK", label: "Alaska" },
  { value: "AZ", label: "Arizona" },
  { value: "AR", label: "Arkansas" },
  { value: "CA", label: "California" },
  { value: "CO", label: "Colorado" },
  { value: "CT", label: "Connecticut" },
  { value: "DE", label: "Delaware" },
  { value: "FL", label: "Florida" },
  { value: "GA", label: "Georgia" },
  { value: "HI", label: "Hawaii" },
  { value: "ID", label: "Idaho" },
  { value: "IL", label: "Illinois" },
  { value: "IN", label: "Indiana" },
  { value: "IA", label: "Iowa" },
  { value: "KS", label: "Kansas" },
  { value: "KY", label: "Kentucky" },
  { value: "LA", label: "Louisiana" },
  { value: "ME", label: "Maine" },
  { value: "MD", label: "Maryland" },
  { value: "MA", label: "Massachusetts" },
  { value: "MI", label: "Michigan" },
  { value: "MN", label: "Minnesota" },
  { value: "MS", label: "Mississippi" },
  { value: "MO", label: "Missouri" },
  { value: "MT", label: "Montana" },
  { value: "NE", label: "Nebraska" },
  { value: "NV", label: "Nevada" },
  { value: "NH", label: "New Hampshire" },
  { value: "NJ", label: "New Jersey" },
  { value: "NM", label: "New Mexico" },
  { value: "NY", label: "New York" },
  { value: "NC", label: "North Carolina" },
  { value: "ND", label: "North Dakota" },
  { value: "OH", label: "Ohio" },
  { value: "OK", label: "Oklahoma" },
  { value: "OR", label: "Oregon" },
  { value: "PA", label: "Pennsylvania" },
  { value: "RI", label: "Rhode Island" },
  { value: "SC", label: "South Carolina" },
  { value: "SD", label: "South Dakota" },
  { value: "TN", label: "Tennessee" },
  { value: "TX", label: "Texas" },
  { value: "UT", label: "Utah" },
  { value: "VT", label: "Vermont" },
  { value: "VA", label: "Virginia" },
  { value: "WA", label: "Washington" },
  { value: "WV", label: "West Virginia" },
  { value: "WI", label: "Wisconsin" },
  { value: "WY", label: "Wyoming" },
  { value: "DC", label: "District of Columbia" },
];

// Industry types
const INDUSTRY_TYPES = [
  "Healthcare",
  "Technology",
  "Finance/Banking",
  "Education",
  "Government",
  "Retail",
  "Manufacturing",
  "Construction",
  "Legal Services",
  "Transportation",
  "Hospitality",
  "Real Estate",
  "Energy/Utilities",
  "Agriculture",
  "Non-profit",
  "Media/Entertainment",
  "Self-employed",
  "Student",
  "Retired",
  "Other"
];

// Income ranges
const INCOME_RANGES = [
  { value: "under25k", label: "Under $25,000" },
  { value: "25k-50k", label: "$25,000 - $49,999" },
  { value: "50k-75k", label: "$50,000 - $74,999" },
  { value: "75k-100k", label: "$75,000 - $99,999" },
  { value: "100k-150k", label: "$100,000 - $149,999" },
  { value: "150k-200k", label: "$150,000 - $199,999" },
  { value: "200k-plus", label: "$200,000+" },
  { value: "prefer-not-say", label: "Prefer not to say" }
];

// Account application schema
const applicationSchema = z
  .object({
    // Personal Information
    firstName: z.string().min(1, "First name is required"),
    middleName: z.string().optional(),
    lastName: z.string().min(1, "Last name is required"),
    dateOfBirth: z.string().refine((val) => {
      if (!val) return false;
      const dob = new Date(val);
      const today = new Date();
      const ageDiff = today.getFullYear() - dob.getFullYear();
      const monthDiff = today.getMonth() - dob.getMonth();
      const isAtLeast18 = ageDiff > 18 || (ageDiff === 18 && monthDiff >= 0);
      return isAtLeast18;
    }, "You must be at least 18 years old to apply for an account"),
    ssn: z.string()
      .min(9, "Social Security Number must be 9 digits")
      .max(11, "Social Security Number must be 9 digits")
      .regex(/^(\d{3}-?\d{2}-?\d{4})$/, "Please enter a valid SSN (123-45-6789)"),
    citizenshipStatus: z.enum(["usCitizen", "usResident", "nonResident"], {
      required_error: "Citizenship status is required",
    }),
    
    // Contact Information
    contactEmail: z.string().email("Invalid email address"),
    contactPhone: z.string()
      .min(10, "Phone number must be at least 10 digits")
      .regex(/^(\+\d{1,2}\s?)?(\(\d{3}\)|\d{3})[\s.-]?\d{3}[\s.-]?\d{4}$/, "Please enter a valid phone number"),
    streetAddress: z.string().min(1, "Street address is required"),
    aptSuite: z.string().optional(),
    city: z.string().min(1, "City is required"),
    state: z.string().min(1, "State is required"),
    zipCode: z.string()
      .min(5, "ZIP code must be 5 digits")
      .max(10, "ZIP code must be 5-9 digits")
      .regex(/^\d{5}(-\d{4})?$/, "Please enter a valid ZIP code"),
      
    // Employment Information
    employmentStatus: z.enum(["employed", "selfEmployed", "retired", "student", "unemployed", "other"], {
      required_error: "Employment status is required",
    }),
    employerName: z.string().optional(),
    industryType: z.string().optional(),
    occupation: z.string().optional(),
    annualIncome: z.string().optional(),
    sourceOfFunds: z.string().min(1, "Source of funds is required"),
    
    // Banking Details
    accountType: z.string().min(1, "Please select an account type"),
    accountPurpose: z.string().min(1, "Please select an account purpose"),
    
    // Identification Documents
    idType: z.enum(["passport", "driver_license", "national_id"], {
      required_error: "ID type is required",
    }),
    idNumber: z.string().min(1, "Document number is required"),
    idExpiryDate: z.string().min(1, "Document expiry date is required"),
    documentFront: z.string().min(1, "Front of ID document is required"),
    documentBack: z.string().min(1, "Back of ID document is required"),
    selfieImage: z.string().min(1, "Selfie photo is required"),
    
    // Additional Details
    hasBankruptcyHistory: z.boolean().default(false),
    bankruptcyDetails: z.string().optional(),
    hasTaxLiens: z.boolean().default(false),
    taxLienDetails: z.string().optional(),
    
    // Legal Agreements
    agreeTerms: z.boolean().refine(val => val === true, {
      message: "You must agree to the terms and conditions",
    }),
    agreePrivacyPolicy: z.boolean().refine(val => val === true, {
      message: "You must agree to the privacy policy",
    }),
    agreeElectronicComm: z.boolean().refine(val => val === true, {
      message: "You must agree to electronic communications",
    }),
    agreeCreditCheck: z.boolean().refine(val => val === true, {
      message: "You must agree to credit checks",
    }),
    certifyInformation: z.boolean().refine(val => val === true, {
      message: "You must certify that your information is true and correct",
    }),
  })
  .refine(
    (data) => 
      !(data.employmentStatus === "employed") || 
      (data.employerName && data.industryType && data.occupation), 
    {
      message: "Employer details are required for employed status",
      path: ["employerName"],
    }
  )
  .refine(
    (data) => 
      !(data.employmentStatus === "selfEmployed") || 
      (data.industryType && data.occupation), 
    {
      message: "Industry and occupation are required for self-employed status",
      path: ["industryType"],
    }
  )
  .refine(
    (data) => 
      !(data.hasBankruptcyHistory) || 
      (data.bankruptcyDetails && data.bankruptcyDetails.length > 0), 
    {
      message: "Please provide details about your bankruptcy history",
      path: ["bankruptcyDetails"],
    }
  )
  .refine(
    (data) => 
      !(data.hasTaxLiens) || 
      (data.taxLienDetails && data.taxLienDetails.length > 0), 
    {
      message: "Please provide details about your tax lien history",
      path: ["taxLienDetails"],
    }
  );

type ApplicationFormValues = z.infer<typeof applicationSchema>;

interface AccountApplicationFormProps {
  setActiveTab?: (value: string) => void;
}

export default function AccountApplicationForm({ setActiveTab }: AccountApplicationFormProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [formStep, setFormStep] = useState(0);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [applicationNumber, setApplicationNumber] = useState<string | null>(null);
  const [submissionError, setSubmissionError] = useState<string | null>(null);
  const [existingApplication, setExistingApplication] = useState<{number: string, status: string} | null>(null);
  const [currentStep, setCurrentStep] = useState<"form" | "success">("form");
  const { toast } = useToast();
  
  const form = useForm<ApplicationFormValues>({
    resolver: zodResolver(applicationSchema),
    defaultValues: {
      firstName: "",
      middleName: "",
      lastName: "",
      dateOfBirth: "",
      ssn: "",
      citizenshipStatus: "usCitizen",
      contactEmail: "",
      contactPhone: "",
      streetAddress: "",
      aptSuite: "",
      city: "",
      state: "",
      zipCode: "",
      employmentStatus: "employed",
      employerName: "",
      industryType: "",
      occupation: "",
      annualIncome: "",
      sourceOfFunds: "",
      accountType: "checking",
      accountPurpose: "primary",
      // Identification Document Fields
      idType: "driver_license",
      idNumber: "",
      idExpiryDate: "",
      documentFront: "",
      documentBack: "",
      selfieImage: "",
      // Other fields
      hasBankruptcyHistory: false,
      bankruptcyDetails: "",
      hasTaxLiens: false,
      taxLienDetails: "",
      agreeTerms: false,
      agreePrivacyPolicy: false,
      agreeElectronicComm: false,
      agreeCreditCheck: false,
      certifyInformation: false,
    },
    mode: "onChange",
  });
  
  // Check for saved form data on component mount
  useEffect(() => {
    // Check if there's a saved application in localStorage
    const savedForm = localStorage.getItem('fortis_app_form_data');
    const submissionStatus = localStorage.getItem('fortis_app_submission_status');
    const savedAppNumber = localStorage.getItem('fortis_app_application_number');
    
    // If we have a successful submission, show success state
    if (submissionStatus === 'submitted' && savedAppNumber) {
      setApplicationNumber(savedAppNumber);
      setIsSubmitted(true);
      setCurrentStep("success");
      return;
    }
    
    // If there's saved form data, populate the form
    if (savedForm) {
      try {
        const parsedForm = JSON.parse(savedForm);
        // Reset the form with saved values
        form.reset(parsedForm);
        toast({
          title: "Form data restored",
          description: "Your previous application data has been restored.",
          variant: "default",
        });
      } catch (e) {
        console.error("Error parsing saved form data:", e);
        // Clear invalid saved data
        localStorage.removeItem('fortis_app_form_data');
      }
    }
    
    // Also check if they have an existing application via cookie
    const cookies = document.cookie.split('; ');
    const appSubmittedCookie = cookies.find(row => row.startsWith('app_submitted='));
    if (appSubmittedCookie) {
      // They've submitted an application before, check the status
      fetch('/api/account-applications/check-ip')
        .then(res => res.json())
        .then(data => {
          if (data.hasApplication && data.applicationNumber) {
            setExistingApplication({
              number: data.applicationNumber,
              status: data.applicationStatus || "pending"
            });
          }
        })
        .catch(err => {
          console.error("Error checking application status:", err);
        });
    }
  }, []);
  
  // Save form data as user types (debounced)
  useEffect(() => {
    const saveFormData = () => {
      const currentValues = form.getValues();
      localStorage.setItem('fortis_app_form_data', JSON.stringify(currentValues));
    };
    
    // Create debounced version of saveFormData function
    const debouncedSave = debounce(saveFormData, 1000);
    
    // Subscribe to form changes
    const subscription = form.watch(() => {
      debouncedSave();
    });
    
    // Clean up the subscription and debounce timeouts
    return () => {
      subscription.unsubscribe();
    };
  }, [form]);

  async function onSubmit(data: ApplicationFormValues) {
    try {
      setIsLoading(true);
      setSubmissionError(null); // Reset error state
      
      console.log("Form data before submission:", data);
      
      // Format the data to match the schema requirements
      // The server expects: applicationData, contactEmail, contactPhone, etc.
      const formData: any = {
        // Required fields from schema: applicationData, contactEmail
        contactEmail: data.contactEmail,
        contactPhone: data.contactPhone || null,
        notifyViaEmail: true,
        notifyViaSms: data.contactPhone ? true : false,
        applicationData: {
          personal: {
            firstName: data.firstName,
            middleName: data.middleName,
            lastName: data.lastName,
            dateOfBirth: data.dateOfBirth,
            ssn: data.ssn,
            citizenshipStatus: data.citizenshipStatus
          },
          contact: {
            email: data.contactEmail,
            phone: data.contactPhone,
            address: {
              street: data.streetAddress,
              aptSuite: data.aptSuite,
              city: data.city,
              state: data.state,
              zipCode: data.zipCode
            }
          },
          employment: {
            status: data.employmentStatus,
            employerName: data.employerName,
            industryType: data.industryType,
            occupation: data.occupation,
            annualIncome: data.annualIncome,
            sourceOfFunds: data.sourceOfFunds
          },
          banking: {
            accountType: data.accountType,
            accountPurpose: data.accountPurpose
          },
          identification: {
            idType: data.idType,
            idNumber: data.idNumber,
            idExpiryDate: data.idExpiryDate,
            documentFront: data.documentFront,
            documentBack: data.documentBack,
            selfieImage: data.selfieImage
          },
          additionalInfo: {
            hasBankruptcyHistory: data.hasBankruptcyHistory,
            bankruptcyDetails: data.bankruptcyDetails,
            hasTaxLiens: data.hasTaxLiens,
            taxLienDetails: data.taxLienDetails
          }
        }
      };
      
      // Add device info and browser data for better security tracking
      formData.ipAddress = ""; // This will be captured on the server
      formData.userAgent = navigator.userAgent || "";
      formData.deviceInfo = JSON.stringify({
        screenWidth: window.screen.width,
        screenHeight: window.screen.height,
        language: navigator.language,
        platform: navigator.platform
      });
      
      // Submit the application
      const response = await apiRequest("POST", "/api/account-applications/apply", formData);
      const result = await response.json();
      
      if (!response.ok) {
        // Enhanced error handling to display more detailed information
        let errorMessage = "There was an error submitting your application";
        
        if (result.message) {
          errorMessage = result.message;
        }
        
        // If we have validation errors, display them in a more user-friendly way
        if (result.errors && result.errors.length > 0) {
          // Get the first few error messages to show to the user
          const validationErrors = result.errors
            .slice(0, 3)
            .map((err: { path?: string[], message: string }) => 
              err.path ? `${err.path.join('.')}: ${err.message}` : err.message
            )
            .join('; ');
            
          errorMessage = `${errorMessage}. ${validationErrors}`;
        }
        
        setSubmissionError(errorMessage);
        
        // If the user already has an application, we should still get the number
        if (result.applicationNumber) {
          setApplicationNumber(result.applicationNumber);
          setIsSubmitted(true);
        }
        return;
      }
      
      // Success handling
      setApplicationNumber(result.applicationNumber);
      setIsSubmitted(true);
      setCurrentStep("success");
      
      // Store successful submission in localStorage and cookies for persistent state
      localStorage.setItem('fortis_app_submission_status', 'submitted');
      localStorage.setItem('fortis_app_application_number', result.applicationNumber);
      
      // Set a cookie that expires in 365 days to indicate a submitted application
      document.cookie = `app_submitted=true; path=/; max-age=${60*60*24*365}`;
      document.cookie = `app_application_number=${result.applicationNumber}; path=/; max-age=${60*60*24*365}`;
      
      // Clear form data from localStorage since we've successfully submitted
      localStorage.removeItem('fortis_app_form_data');
      
      // Show a success toast notification
      toast({
        title: "Application Submitted Successfully",
        description: "Your application has been received and is now under review.",
        variant: "default",
      });
      
      // After a longer delay (5 seconds), redirect to the check-status tab
      setTimeout(() => {
        // Use the context to switch tabs if provided (from parent component)
        if (setActiveTab) {
          setActiveTab("check-status");
          
          // Pre-fill the application number in the status field
          setTimeout(() => {
            const input = document.getElementById('checkStatusNumber') as HTMLInputElement;
            if (input) {
              input.value = result.applicationNumber;
              // Trigger the form submission
              const button = input.closest('form')?.querySelector('button[type="submit"]');
              if (button) (button as HTMLButtonElement).click();
            }
          }, 500);
        }
      }, 5000);
      
      // Scroll to top to ensure user sees success message
      window.scrollTo(0, 0);
    } catch (error) {
      console.error("Application submission error:", error);
      setSubmissionError("An unexpected error occurred. Please try again later.");
    } finally {
      setIsLoading(false);
    }
  }
  
  const nextFormStep = async () => {
    let fieldsToValidate: string[] = [];
    
    switch (formStep) {
      case 0:
        fieldsToValidate = [
          "firstName", "lastName", "dateOfBirth", "ssn", "citizenshipStatus", 
          "contactEmail", "contactPhone", "streetAddress", "city", "state", "zipCode"
        ];
        break;
      case 1:
        fieldsToValidate = [
          "employmentStatus", "sourceOfFunds", "accountType", "accountPurpose"
        ];
        
        // Conditionally add employment fields based on employment status
        const employmentStatus = form.getValues("employmentStatus");
        if (employmentStatus === "employed") {
          fieldsToValidate.push("employerName", "industryType", "occupation");
        } else if (employmentStatus === "selfEmployed") {
          fieldsToValidate.push("industryType", "occupation");
        }
        
        // Add conditional bankruptcy and tax lien fields
        const hasBankruptcy = form.getValues("hasBankruptcyHistory");
        const hasTaxLiens = form.getValues("hasTaxLiens");
        
        if (hasBankruptcy) {
          fieldsToValidate.push("bankruptcyDetails");
        }
        
        if (hasTaxLiens) {
          fieldsToValidate.push("taxLienDetails");
        }
        break;
      case 2:
        fieldsToValidate = [
          "idType", "idNumber", "idExpiryDate", "documentFront", "documentBack", "selfieImage"
        ];
        break;
      case 3:
        fieldsToValidate = [
          "agreeTerms", "agreePrivacyPolicy", "agreeElectronicComm", 
          "agreeCreditCheck", "certifyInformation"
        ];
        break;
    }
    
    const isValid = await form.trigger(fieldsToValidate as any);
    
    if (isValid) {
      if (formStep === 3) {
        // Submit the form on the last step
        await form.handleSubmit(onSubmit)();
      } else {
        // Otherwise go to next step
        setFormStep(current => current + 1);
        window.scrollTo(0, 0);
      }
    }
  };
  
  const prevFormStep = () => {
    setFormStep(current => current - 1);
    window.scrollTo(0, 0);
  };

  if (isSubmitted && applicationNumber) {
    // Show success state with application details and next steps
    return (
      <div className="space-y-6 py-4">
        <div className="bg-green-50 p-6 rounded-lg border border-green-200">
          <div className="flex flex-col items-center text-center space-y-4">
            <div className="h-16 w-16 bg-green-100 rounded-full flex items-center justify-center">
              <CheckCircle2 className="h-8 w-8 text-green-600" />
            </div>
            <h3 className="text-xl font-semibold text-green-800">Application Submitted Successfully</h3>
            <p className="text-green-700 max-w-md">
              Your account application has been received and is being reviewed by our team.
            </p>
            
            {/* Application Number - Highlighted for visibility */}
            <div className="bg-white p-5 rounded-md border-2 border-primary shadow-sm w-full max-w-sm animate-pulse">
              <h4 className="font-semibold text-gray-800 mb-2">Your Application Number</h4>
              <div className="bg-primary/5 p-3 rounded-md border border-primary/20 mb-2 flex items-center justify-between">
                <p className="text-xl font-bold text-primary tracking-wide">{applicationNumber}</p>
                <Button 
                  type="button" 
                  variant="ghost" 
                  size="sm"
                  className="h-8 px-2 text-gray-500 hover:text-primary"
                  onClick={() => {
                    navigator.clipboard.writeText(applicationNumber);
                    toast({
                      title: "Copied to clipboard",
                      description: "Application number has been copied to your clipboard",
                      variant: "default",
                    });
                  }}
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
              <p className="text-sm text-gray-700 font-medium">⚠️ Please save this number</p>
              <p className="text-xs text-gray-600 mt-1">You'll need it to check your application status</p>
            </div>
          </div>
        </div>
        
        <div className="space-y-4 bg-gray-50 p-5 rounded-lg border border-gray-200">
          <h4 className="font-medium text-gray-700">What happens next?</h4>
          <ol className="space-y-3">
            <li className="flex items-start">
              <div className="bg-primary/10 rounded-full h-6 w-6 flex items-center justify-center mr-2 mt-0.5">
                <span className="text-xs font-medium text-primary">1</span>
              </div>
              <p className="text-sm text-gray-600">
                Our team will review your application within 1-2 business days.
              </p>
            </li>
            <li className="flex items-start">
              <div className="bg-primary/10 rounded-full h-6 w-6 flex items-center justify-center mr-2 mt-0.5">
                <span className="text-xs font-medium text-primary">2</span>
              </div>
              <p className="text-sm text-gray-600">
                You'll receive an email notification once your application is approved.
              </p>
            </li>
            <li className="flex items-start">
              <div className="bg-primary/10 rounded-full h-6 w-6 flex items-center justify-center mr-2 mt-0.5">
                <span className="text-xs font-medium text-primary">3</span>
              </div>
              <p className="text-sm text-gray-600">
                After approval, you'll be able to create your username and password and access your new account.
              </p>
            </li>
          </ol>
        </div>
        
        <div className="mt-6 border-t pt-6">
          <h4 className="font-medium text-gray-700 mb-3">Application Status</h4>
          <div className="space-y-3">
            <div>
              <p className="text-sm text-gray-600">Status:</p>
              <div className="mt-1">
                <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                  <Clock className="w-3 h-3 mr-1" />
                  Pending Review
                </div>
              </div>
            </div>
            
            <div>
              <p className="text-sm text-gray-600">Submitted:</p>
              <p className="font-medium">{format(new Date(), 'MMM d, yyyy')}</p>
            </div>
            
            <div>
              <p className="text-sm text-gray-600">Estimated Review Time:</p>
              <p className="font-medium">1-2 business days</p>
            </div>
          </div>
        </div>
                
        <div className="flex items-center justify-between pt-4">
          <Button
            variant="outline"
            onClick={() => {
              if (setActiveTab) setActiveTab("login");
              else {
                window.location.href = "/auth";
              }
            }}
            className="text-gray-600"
          >
            Return to Login
          </Button>
          
          <Button
            variant="ghost"
            onClick={() => {
              // Reset local state
              setIsSubmitted(false);
              setApplicationNumber(null);
              form.reset();
              setFormStep(0);
              
              // Clear all stored application data
              localStorage.removeItem('fortis_app_submission_status');
              localStorage.removeItem('fortis_app_application_number');
              localStorage.removeItem('fortis_app_form_data');
              
              // Expire the cookies by setting max-age to 0
              document.cookie = "app_submitted=; path=/; max-age=0";
              document.cookie = "app_application_number=; path=/; max-age=0";
            }}
            className="text-primary"
          >
            Create New Application
          </Button>
        </div>
      </div>
    );
  }

  return (
    <Form {...form}>
      <form className="space-y-5">
        {/* Form step indicator */}
        <div className="w-full mb-6">
          <div className="flex justify-between mb-2">
            <div className={`font-medium text-sm ${formStep >= 0 ? "text-primary" : "text-gray-400"}`}>Personal Information</div>
            <div className={`font-medium text-sm ${formStep >= 1 ? "text-primary" : "text-gray-400"}`}>Financial Details</div>
            <div className={`font-medium text-sm ${formStep >= 2 ? "text-primary" : "text-gray-400"}`}>Identity Verification</div>
            <div className={`font-medium text-sm ${formStep >= 3 ? "text-primary" : "text-gray-400"}`}>Review & Submit</div>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-primary h-2 rounded-full transition-all duration-300" 
              style={{ width: `${(formStep / 3) * 100}%` }}
            ></div>
          </div>
        </div>

        {formStep === 0 && (
          <>
            <div className="space-y-1 mb-4">
              <h4 className="font-semibold text-gray-800">1. Personal Information</h4>
              <p className="text-sm text-gray-600">Please provide your personal details as they appear on your legal documents.</p>
            </div>
            
            <div className="grid gap-4 grid-cols-1 sm:grid-cols-3">
              <FormField
                control={form.control}
                name="firstName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700">First Name *</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                          <User className="h-4 w-4" />
                        </div>
                        <Input 
                          placeholder="John" 
                          className="pl-10 bg-gray-50 border-gray-200 focus:bg-white" 
                          {...field} 
                          disabled={isLoading} 
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="middleName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700">Middle Name (Optional)</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="William" 
                        className="bg-gray-50 border-gray-200 focus:bg-white" 
                        {...field} 
                        disabled={isLoading} 
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="lastName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700">Last Name *</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                          <User className="h-4 w-4" />
                        </div>
                        <Input 
                          placeholder="Doe" 
                          className="pl-10 bg-gray-50 border-gray-200 focus:bg-white" 
                          {...field} 
                          disabled={isLoading} 
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="grid gap-4 grid-cols-1 sm:grid-cols-2">
              <FormField
                control={form.control}
                name="dateOfBirth"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700">Date of Birth *</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                          <Calendar className="h-4 w-4" />
                        </div>
                        <Input 
                          type="date" 
                          className="pl-10 bg-gray-50 border-gray-200 focus:bg-white" 
                          {...field} 
                          disabled={isLoading} 
                        />
                      </div>
                    </FormControl>
                    <FormDescription className="text-xs">
                      You must be at least 18 years old to apply for an account.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="ssn"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700">Social Security Number *</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                          <ShieldAlert className="h-4 w-4" />
                        </div>
                        <Input 
                          placeholder="123-45-6789" 
                          className="pl-10 bg-gray-50 border-gray-200 focus:bg-white" 
                          {...field} 
                          disabled={isLoading} 
                        />
                      </div>
                    </FormControl>
                    <FormDescription className="text-xs">
                      Your SSN is securely encrypted and protected.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="citizenshipStatus"
              render={({ field }) => (
                <FormItem className="space-y-1">
                  <FormLabel className="text-gray-700">Citizenship Status *</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="flex flex-col space-y-1"
                      disabled={isLoading}
                    >
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="usCitizen" />
                        </FormControl>
                        <FormLabel className="font-normal cursor-pointer">
                          U.S. Citizen
                        </FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="usResident" />
                        </FormControl>
                        <FormLabel className="font-normal cursor-pointer">
                          U.S. Permanent Resident
                        </FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="nonResident" />
                        </FormControl>
                        <FormLabel className="font-normal cursor-pointer">
                          Non-U.S. Citizen/Non-Permanent Resident
                        </FormLabel>
                      </FormItem>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Separator className="my-6" />
            
            <div className="space-y-1 mb-4">
              <h4 className="font-semibold text-gray-800">Contact Information</h4>
              <p className="text-sm text-gray-600">How can we reach you regarding your application?</p>
            </div>
            
            <div className="grid gap-4 grid-cols-1 sm:grid-cols-2">
              <FormField
                control={form.control}
                name="contactEmail"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700">Email Address *</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                          <Mail className="h-4 w-4" />
                        </div>
                        <Input 
                          type="email"
                          placeholder="johndoe@example.com" 
                          className="pl-10 bg-gray-50 border-gray-200 focus:bg-white" 
                          {...field} 
                          disabled={isLoading} 
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="contactPhone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700">Phone Number *</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                          <Phone className="h-4 w-4" />
                        </div>
                        <Input 
                          placeholder="(555) 123-4567" 
                          className="pl-10 bg-gray-50 border-gray-200 focus:bg-white" 
                          {...field} 
                          disabled={isLoading} 
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="space-y-4">
              <FormField
                control={form.control}
                name="streetAddress"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700">Street Address *</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                          <Home className="h-4 w-4" />
                        </div>
                        <Input 
                          placeholder="123 Main St" 
                          className="pl-10 bg-gray-50 border-gray-200 focus:bg-white" 
                          {...field} 
                          disabled={isLoading} 
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="aptSuite"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700">Apartment/Suite (Optional)</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Apt 4B" 
                        className="bg-gray-50 border-gray-200 focus:bg-white" 
                        {...field} 
                        disabled={isLoading} 
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <div className="grid gap-4 grid-cols-1 sm:grid-cols-3">
                <FormField
                  control={form.control}
                  name="city"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700">City *</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="New York" 
                          className="bg-gray-50 border-gray-200 focus:bg-white" 
                          {...field} 
                          disabled={isLoading} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="state"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700">State *</FormLabel>
                      <Select
                        disabled={isLoading}
                        onValueChange={field.onChange}
                        value={field.value}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger className="bg-gray-50 border-gray-200 focus:bg-white">
                            <SelectValue placeholder="Select a state" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {US_STATES.map((state) => (
                            <SelectItem key={state.value} value={state.value}>
                              {state.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="zipCode"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700">ZIP Code *</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="10001" 
                          className="bg-gray-50 border-gray-200 focus:bg-white" 
                          {...field} 
                          disabled={isLoading} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>
          </>
        )}

        {formStep === 1 && (
          <>
            <div className="space-y-1 mb-4">
              <h4 className="font-semibold text-gray-800">2. Financial Information</h4>
              <p className="text-sm text-gray-600">Please provide information about your financial status.</p>
            </div>

            <FormField
              control={form.control}
              name="employmentStatus"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-700">Employment Status *</FormLabel>
                  <Select
                    disabled={isLoading}
                    onValueChange={field.onChange}
                    value={field.value}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger className="bg-gray-50 border-gray-200 focus:bg-white">
                        <SelectValue placeholder="Select your employment status" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="employed">Employed</SelectItem>
                      <SelectItem value="selfEmployed">Self-Employed</SelectItem>
                      <SelectItem value="retired">Retired</SelectItem>
                      <SelectItem value="student">Student</SelectItem>
                      <SelectItem value="unemployed">Unemployed</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {(form.watch("employmentStatus") === "employed") && (
              <div className="grid gap-4 grid-cols-1 sm:grid-cols-2">
                <FormField
                  control={form.control}
                  name="employerName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700">Employer Name *</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                            <BriefcaseBusiness className="h-4 w-4" />
                          </div>
                          <Input 
                            placeholder="Acme Corporation" 
                            className="pl-10 bg-gray-50 border-gray-200 focus:bg-white" 
                            {...field} 
                            disabled={isLoading} 
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="occupation"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700">Occupation/Job Title *</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Software Engineer" 
                          className="bg-gray-50 border-gray-200 focus:bg-white" 
                          {...field} 
                          disabled={isLoading} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            )}
            
            {(form.watch("employmentStatus") === "employed" || form.watch("employmentStatus") === "selfEmployed") && (
              <div className="grid gap-4 grid-cols-1 sm:grid-cols-2">
                <FormField
                  control={form.control}
                  name="industryType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700">Industry *</FormLabel>
                      <Select
                        disabled={isLoading}
                        onValueChange={field.onChange}
                        value={field.value}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger className="bg-gray-50 border-gray-200 focus:bg-white">
                            <SelectValue placeholder="Select your industry" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {INDUSTRY_TYPES.map((industry) => (
                            <SelectItem key={industry} value={industry}>
                              {industry}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="annualIncome"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700">Annual Income (Optional)</FormLabel>
                      <Select
                        disabled={isLoading}
                        onValueChange={field.onChange}
                        value={field.value}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger className="bg-gray-50 border-gray-200 focus:bg-white">
                            <SelectValue placeholder="Select your income range" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {INCOME_RANGES.map((range) => (
                            <SelectItem key={range.value} value={range.value}>
                              {range.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            )}
            
            <FormField
              control={form.control}
              name="sourceOfFunds"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-gray-700">Source of Funds *</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                        <DollarSign className="h-4 w-4" />
                      </div>
                      <Input 
                        placeholder="e.g., Salary, Investments, Inheritance" 
                        className="pl-10 bg-gray-50 border-gray-200 focus:bg-white" 
                        {...field} 
                        disabled={isLoading} 
                      />
                    </div>
                  </FormControl>
                  <FormDescription className="text-xs">
                    Please specify where the funds for this account will come from.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Separator className="my-6" />
            
            <div className="space-y-1 mb-4">
              <h4 className="font-semibold text-gray-800">Account Details</h4>
              <p className="text-sm text-gray-600">Choose the type of account you'd like to open.</p>
            </div>
            
            <div className="grid gap-4 grid-cols-1 sm:grid-cols-2">
              <FormField
                control={form.control}
                name="accountType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700">Account Type *</FormLabel>
                    <Select
                      disabled={isLoading}
                      onValueChange={field.onChange}
                      value={field.value}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger className="bg-gray-50 border-gray-200 focus:bg-white">
                          <SelectValue placeholder="Select an account type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="checking">Checking Account</SelectItem>
                        <SelectItem value="savings">Savings Account</SelectItem>
                        <SelectItem value="money_market">Money Market Account</SelectItem>
                        <SelectItem value="cd">Certificate of Deposit (CD)</SelectItem>
                        <SelectItem value="joint">Joint Account</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="accountPurpose"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700">Account Purpose *</FormLabel>
                    <Select
                      disabled={isLoading}
                      onValueChange={field.onChange}
                      value={field.value}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger className="bg-gray-50 border-gray-200 focus:bg-white">
                          <SelectValue placeholder="Select account purpose" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="primary">Primary Banking</SelectItem>
                        <SelectItem value="savings">Savings</SelectItem>
                        <SelectItem value="business">Business Operations</SelectItem>
                        <SelectItem value="education">Education</SelectItem>
                        <SelectItem value="retirement">Retirement</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <Separator className="my-6" />
            
            <div className="space-y-1 mb-4">
              <h4 className="font-semibold text-gray-800">Additional Information</h4>
              <p className="text-sm text-gray-600">Please answer the following questions truthfully.</p>
            </div>
            
            <div className="space-y-4">
              <FormField
                control={form.control}
                name="hasBankruptcyHistory"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <div className="flex items-center gap-2">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          disabled={isLoading}
                        />
                      </FormControl>
                      <FormLabel className="text-gray-700 font-medium cursor-pointer">
                        Have you filed for bankruptcy in the last 7 years?
                      </FormLabel>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {form.watch("hasBankruptcyHistory") && (
                <FormField
                  control={form.control}
                  name="bankruptcyDetails"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700">Please provide details *</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Please include dates, type of bankruptcy, and current status" 
                          className="bg-gray-50 border-gray-200 focus:bg-white resize-none min-h-[80px]" 
                          {...field} 
                          disabled={isLoading} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}
              
              <FormField
                control={form.control}
                name="hasTaxLiens"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <div className="flex items-center gap-2">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          disabled={isLoading}
                        />
                      </FormControl>
                      <FormLabel className="text-gray-700 font-medium cursor-pointer">
                        Do you currently have any outstanding tax liens or judgments?
                      </FormLabel>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {form.watch("hasTaxLiens") && (
                <FormField
                  control={form.control}
                  name="taxLienDetails"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700">Please provide details *</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Please include dates, amounts, and status" 
                          className="bg-gray-50 border-gray-200 focus:bg-white resize-none min-h-[80px]" 
                          {...field} 
                          disabled={isLoading} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}
              
              <Alert className="bg-blue-50 border-blue-200 text-blue-800">
                <CircleHelp className="h-4 w-4 text-blue-600" />
                <AlertTitle>Important Information</AlertTitle>
                <AlertDescription className="text-blue-700 text-sm">
                  Answering "Yes" to these questions does not automatically disqualify your application. 
                  We consider each application individually.
                </AlertDescription>
              </Alert>
            </div>
          </>
        )}

        {formStep === 2 && (
          <>
            <div className="space-y-1 mb-4">
              <h4 className="font-semibold text-gray-800">3. Identity Verification</h4>
              <p className="text-sm text-gray-600">To verify your identity, we need photos of your government-issued ID and a selfie.</p>
            </div>
            
            {submissionError && (
              <Alert variant="destructive" className="mb-4 border-red-300 bg-red-50 text-red-800">
                <AlertTriangle className="h-4 w-4 text-red-600" />
                <AlertTitle className="text-red-800">Application Error</AlertTitle>
                <AlertDescription className="text-red-700 mt-1">{submissionError}</AlertDescription>
              </Alert>
            )}
            
            <div className="bg-blue-50 p-4 rounded-md mb-6 border border-blue-100">
              <div className="flex items-start">
                <div className="mr-3 mt-1">
                  <CircleHelp className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <h5 className="font-medium text-blue-800 text-sm">Important Instructions</h5>
                  <ul className="text-xs text-blue-700 mt-1 space-y-1 list-disc pl-4">
                    <li>Use high-quality, well-lit images</li>
                    <li>Make sure all text is clearly visible</li>
                    <li>Include all corners of your ID document</li>
                    <li>Remove any protective covers before taking photos</li>
                    <li>Your selfie should clearly show your face</li>
                  </ul>
                </div>
              </div>
            </div>
            
            <div className="grid gap-5 grid-cols-1 sm:grid-cols-2 mb-6">
              <FormField
                control={form.control}
                name="idType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700">ID Type *</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                      disabled={isLoading}
                    >
                      <FormControl>
                        <SelectTrigger className="bg-gray-50 border-gray-200">
                          <SelectValue placeholder="Select ID type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="driver_license">Driver's License</SelectItem>
                        <SelectItem value="passport">Passport</SelectItem>
                        <SelectItem value="national_id">National ID Card</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormDescription className="text-xs">
                      Choose the type of government-issued ID you'll be using.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="idNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700">ID Number *</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                          <FileText className="h-4 w-4" />
                        </div>
                        <Input 
                          placeholder="Enter document number" 
                          className="pl-10 bg-gray-50 border-gray-200 focus:bg-white" 
                          {...field} 
                          disabled={isLoading} 
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="idExpiryDate"
              render={({ field }) => (
                <FormItem className="mb-6">
                  <FormLabel className="text-gray-700">ID Expiration Date *</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                        <Calendar className="h-4 w-4" />
                      </div>
                      <Input 
                        type="date" 
                        className="pl-10 bg-gray-50 border-gray-200 focus:bg-white" 
                        {...field} 
                        disabled={isLoading} 
                      />
                    </div>
                  </FormControl>
                  <FormDescription className="text-xs">
                    Your ID must not be expired.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Separator className="my-6" />
            
            <div className="space-y-1 mb-5">
              <h5 className="font-medium text-gray-700">Document Photos</h5>
              <p className="text-sm text-gray-600">Upload clear photos of your identification document.</p>
            </div>
            
            <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 mb-8">
              <FormField
                control={form.control}
                name="documentFront"
                render={({ field }) => (
                  <FormItem className="w-full">
                    <FormLabel className="text-gray-700">Front of ID *</FormLabel>
                    <FormControl>
                      <div className="w-full">
                        <div className={`w-full h-40 border-2 border-dashed rounded-lg flex flex-col items-center justify-center p-4 transition-colors ${field.value ? 'bg-green-50 border-green-300' : 'bg-gray-50 border-gray-300 hover:bg-gray-100'} relative`}>
                          {field.value ? (
                            <div className="flex flex-col items-center">
                              <CheckCircle2 className="h-8 w-8 text-green-600 mb-2" />
                              <span className="text-xs text-green-700 font-medium">Document uploaded</span>
                              <Button 
                                type="button" 
                                variant="ghost" 
                                size="sm" 
                                className="mt-2 text-xs"
                                onClick={() => form.setValue('documentFront', '')}
                              >
                                Remove
                              </Button>
                            </div>
                          ) : (
                            <>
                              <Upload className="h-8 w-8 text-gray-400 mb-2" />
                              <p className="text-sm text-gray-500 text-center">
                                Click to upload or drag and drop
                              </p>
                              <Input 
                                type="file" 
                                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
                                accept="image/*"
                                onChange={(e) => {
                                  const file = e.target.files?.[0];
                                  if (file) {
                                    // In a real app, we would upload this to a server
                                    // For now, just store a placeholder
                                    form.setValue('documentFront', 'id_front_uploaded');
                                  }
                                }}
                                disabled={isLoading}
                              />
                            </>
                          )}
                        </div>
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="documentBack"
                render={({ field }) => (
                  <FormItem className="w-full">
                    <FormLabel className="text-gray-700">Back of ID *</FormLabel>
                    <FormControl>
                      <div className="w-full">
                        <div className={`w-full h-40 border-2 border-dashed rounded-lg flex flex-col items-center justify-center p-4 transition-colors ${field.value ? 'bg-green-50 border-green-300' : 'bg-gray-50 border-gray-300 hover:bg-gray-100'} relative`}>
                          {field.value ? (
                            <div className="flex flex-col items-center">
                              <CheckCircle2 className="h-8 w-8 text-green-600 mb-2" />
                              <span className="text-xs text-green-700 font-medium">Document uploaded</span>
                              <Button 
                                type="button" 
                                variant="ghost" 
                                size="sm" 
                                className="mt-2 text-xs"
                                onClick={() => form.setValue('documentBack', '')}
                              >
                                Remove
                              </Button>
                            </div>
                          ) : (
                            <>
                              <Upload className="h-8 w-8 text-gray-400 mb-2" />
                              <p className="text-sm text-gray-500 text-center">
                                Click to upload or drag and drop
                              </p>
                              <Input 
                                type="file" 
                                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
                                accept="image/*"
                                onChange={(e) => {
                                  const file = e.target.files?.[0];
                                  if (file) {
                                    // In a real app, we would upload this to a server
                                    // For now, just store a placeholder
                                    form.setValue('documentBack', 'id_back_uploaded');
                                  }
                                }}
                                disabled={isLoading}
                              />
                            </>
                          )}
                        </div>
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="selfieImage"
                render={({ field }) => (
                  <FormItem className="w-full sm:col-span-2 lg:col-span-1">
                    <FormLabel className="text-gray-700">Selfie Photo *</FormLabel>
                    <FormControl>
                      <div className="w-full">
                        <div className={`w-full h-40 border-2 border-dashed rounded-lg flex flex-col items-center justify-center p-4 transition-colors ${field.value ? 'bg-green-50 border-green-300' : 'bg-gray-50 border-gray-300 hover:bg-gray-100'} relative`}>
                          {field.value ? (
                            <div className="flex flex-col items-center">
                              <CheckCircle2 className="h-8 w-8 text-green-600 mb-2" />
                              <span className="text-xs text-green-700 font-medium">Selfie uploaded</span>
                              <Button 
                                type="button" 
                                variant="ghost" 
                                size="sm" 
                                className="mt-2 text-xs"
                                onClick={() => form.setValue('selfieImage', '')}
                              >
                                Remove
                              </Button>
                            </div>
                          ) : (
                            <>
                              <Camera className="h-8 w-8 text-gray-400 mb-2" />
                              <p className="text-sm text-gray-500 text-center">
                                Take a selfie or upload a photo
                              </p>
                              <Input 
                                type="file" 
                                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
                                accept="image/*"
                                onChange={(e) => {
                                  const file = e.target.files?.[0];
                                  if (file) {
                                    // In a real app, we would upload this to a server
                                    // For now, just store a placeholder
                                    form.setValue('selfieImage', 'selfie_uploaded');
                                  }
                                }}
                                disabled={isLoading}
                              />
                            </>
                          )}
                        </div>
                      </div>
                    </FormControl>
                    <FormDescription className="text-xs">
                      Take a clear photo of your face while holding your ID.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </>
        )}
        
        {formStep === 3 && (
          <>
            <div className="space-y-1 mb-4">
              <h4 className="font-semibold text-gray-800">4. Legal Agreements</h4>
              <p className="text-sm text-gray-600">Please review and accept the following agreements.</p>
            </div>
            
            {submissionError && (
              <Alert variant="destructive" className="mb-4 border-red-300 bg-red-50 text-red-800">
                <AlertTriangle className="h-4 w-4 text-red-600" />
                <AlertTitle className="text-red-800">Application Error</AlertTitle>
                <AlertDescription className="text-red-700 mt-1">{submissionError}</AlertDescription>
              </Alert>
            )}
            
            <div className="bg-gray-50 p-5 rounded-lg border border-gray-200 mb-6">
              <h5 className="font-medium text-gray-800 mb-2">Application Summary</h5>
              <div className="space-y-2">
                <p className="text-sm"><span className="font-medium">Name:</span> {form.getValues("firstName")} {form.getValues("middleName")} {form.getValues("lastName")}</p>
                <p className="text-sm"><span className="font-medium">Email:</span> {form.getValues("contactEmail")}</p>
                <p className="text-sm"><span className="font-medium">Account Type:</span> {form.getValues("accountType")}</p>
                <p className="text-sm"><span className="font-medium">ID Type:</span> {form.getValues("idType") === "driver_license" ? "Driver's License" : form.getValues("idType") === "passport" ? "Passport" : "National ID"}</p>
              </div>
            </div>
            
            <Alert className="bg-amber-50 border-amber-200 text-amber-800 mb-6">
              <AlertTriangle className="h-4 w-4 text-amber-600" />
              <AlertTitle>Important Notice</AlertTitle>
              <AlertDescription className="text-amber-700 text-sm">
                Please review all information for accuracy before submitting. Your application will be reviewed by our team before account setup.
              </AlertDescription>
            </Alert>
            
            <div className="space-y-4 bg-gray-50 p-4 rounded-md border border-gray-200">
              <FormField
                control={form.control}
                name="agreeTerms"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <div className="flex items-start gap-2">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          disabled={isLoading}
                          className="mt-1"
                        />
                      </FormControl>
                      <div className="space-y-1">
                        <FormLabel className="text-gray-700 font-medium cursor-pointer">
                          Terms and Conditions
                        </FormLabel>
                        <p className="text-xs text-gray-600">
                          I agree to the <a href="/legal/terms-conditions" target="_blank" className="text-primary underline">Terms and Conditions</a> of Fortis Capital, 
                          including the account agreement and fee schedule.
                        </p>
                      </div>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="agreePrivacyPolicy"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <div className="flex items-start gap-2">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          disabled={isLoading}
                          className="mt-1"
                        />
                      </FormControl>
                      <div className="space-y-1">
                        <FormLabel className="text-gray-700 font-medium cursor-pointer">
                          Privacy Policy
                        </FormLabel>
                        <p className="text-xs text-gray-600">
                          I acknowledge receipt of the <a href="/legal/privacy-policy" target="_blank" className="text-primary underline">Privacy Policy</a> and 
                          understand how my personal information will be used.
                        </p>
                      </div>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="agreeElectronicComm"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <div className="flex items-start gap-2">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          disabled={isLoading}
                          className="mt-1"
                        />
                      </FormControl>
                      <div className="space-y-1">
                        <FormLabel className="text-gray-700 font-medium cursor-pointer">
                          Electronic Communications
                        </FormLabel>
                        <p className="text-xs text-gray-600">
                          I consent to receive account statements, notices, and other communications electronically.
                        </p>
                      </div>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="agreeCreditCheck"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <div className="flex items-start gap-2">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          disabled={isLoading}
                          className="mt-1"
                        />
                      </FormControl>
                      <div className="space-y-1">
                        <FormLabel className="text-gray-700 font-medium cursor-pointer">
                          Credit Report Authorization
                        </FormLabel>
                        <p className="text-xs text-gray-600">
                          I authorize Fortis Capital to obtain consumer reports and credit information about me 
                          from credit reporting agencies as part of this application.
                        </p>
                      </div>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="certifyInformation"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <div className="flex items-start gap-2">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          disabled={isLoading}
                          className="mt-1"
                        />
                      </FormControl>
                      <div className="space-y-1">
                        <FormLabel className="text-gray-700 font-medium cursor-pointer">
                          Information Certification
                        </FormLabel>
                        <p className="text-xs text-gray-600">
                          I certify that all information provided in this application is true and correct to the 
                          best of my knowledge. I understand that providing false information may result in 
                          rejection of my application or termination of my account.
                        </p>
                      </div>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </>
        )}

        <div className="flex items-center justify-between pt-6">
          {formStep > 0 && (
            <Button
              type="button"
              variant="outline"
              onClick={prevFormStep}
              disabled={isLoading}
              className="flex items-center"
            >
              <ChevronRight className="h-4 w-4 mr-1 rotate-180" />
              Back
            </Button>
          )}
          
          {formStep === 0 && (
            <Button
              type="button"
              variant="outline"
              onClick={() => window.location.href = "/auth"}
              disabled={isLoading}
              className="text-gray-600"
            >
              Cancel
            </Button>
          )}
          
          <Button
            type="button"
            onClick={nextFormStep}
            disabled={isLoading}
            className={`ml-auto flex items-center ${formStep === 3 ? "bg-green-700 hover:bg-green-800" : ""}`}
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Processing...
              </>
            ) : (
              <>
                {formStep === 3 ? "Submit Application" : "Continue"}
                <ChevronRight className="ml-1 h-4 w-4" />
              </>
            )}
          </Button>
        </div>
      </form>
    </Form>
  );
}