import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Loader2,
  User,
  Mail,
  Key,
  ShieldCheck,
  AtSign,
  Lock,
  FileText,
  AlertTriangle,
  Info,
  CheckCircle,
  ChevronRight,
  ChevronLeft,
  BriefcaseBusiness,
  DollarSign
} from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

// Security questions
const SECURITY_QUESTIONS = [
  "What was the name of your first pet?",
  "In which city were you born?",
  "What was the model of your first car?",
  "What is your mother's maiden name?",
  "What was the name of your elementary school?",
  "What is the name of your favorite childhood teacher?",
  "What is your favorite movie?",
  "What was your childhood nickname?",
  "What is the name of the street you grew up on?",
  "What is your favorite book?"
];

// Simplified registration schema for approved applications
const registerSchema = z
  .object({
    // Application information
    applicationNumber: z.string()
      .min(1, "Application number is required"),
    
    // Email (to verify identity)
    email: z.string().email("Invalid email address"),
    
    // Login credentials
    username: z.string()
      .min(5, "Username must be at least 5 characters")
      .regex(/^[a-zA-Z0-9_]+$/, "Username can only contain letters, numbers, and underscores"),
    password: z
      .string()
      .min(8, "Password must be at least 8 characters")
      .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
      .regex(/[a-z]/, "Password must contain at least one lowercase letter")
      .regex(/[0-9]/, "Password must contain at least one number")
      .regex(/[^A-Za-z0-9]/, "Password must contain at least one special character"),
    confirmPassword: z.string(),
    
    // Personal information (required by server)
    firstName: z.string().min(1, "First name is required"),
    lastName: z.string().min(1, "Last name is required"),
    
    // Security questions
    securityQuestion1: z.string().min(1, "Security question 1 is required"),
    securityAnswer1: z.string().min(1, "Security answer 1 is required"),
    securityQuestion2: z.string().min(1, "Security question 2 is required"),
    securityAnswer2: z.string().min(1, "Security answer 2 is required"),
    
    // Legal Agreements
    agreeTerms: z.boolean().refine(val => val === true, {
      message: "You must agree to the terms and conditions",
    }),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords don't match",
    path: ["confirmPassword"],
  })
  .refine(
    (data) => data.securityAnswer1.toLowerCase() !== data.securityAnswer2.toLowerCase(),
    {
      message: "Security answers must be different",
      path: ["securityAnswer2"],
    }
  );

type RegisterFormValues = z.infer<typeof registerSchema>;

export default function RegisterForm() {
  const { register } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState(0);
  const [formStep, setFormStep] = useState(0);
  const [verificationError, setVerificationError] = useState<string | null>(null);
  const [applicationVerified, setApplicationVerified] = useState(false);
  const { toast } = useToast();
  
  const form = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      applicationNumber: "",
      email: "",
      username: "",
      password: "",
      confirmPassword: "",
      firstName: "",
      lastName: "",
      securityQuestion1: "",
      securityAnswer1: "",
      securityQuestion2: "",
      securityAnswer2: "",
      agreeTerms: false,
    },
    mode: "onChange",
  });

  // Calculate password strength score
  const calculatePasswordStrength = (password: string) => {
    let score = 0;
    
    if (password.length >= 8) score += 1;
    if (/[A-Z]/.test(password)) score += 1;
    if (/[a-z]/.test(password)) score += 1;
    if (/[0-9]/.test(password)) score += 1;
    if (/[^A-Za-z0-9]/.test(password)) score += 1;
    
    setPasswordStrength(score);
  };

  // Verify application before proceeding
  async function verifyApplication() {
    try {
      setIsLoading(true);
      setVerificationError(null);
      
      const applicationNumber = form.getValues("applicationNumber");
      const email = form.getValues("email");
      
      console.log("API Request to /api/auth/verify-application with user auth");
      
      // Verify application with backend
      const response = await apiRequest(
        "POST",
        "/api/auth/verify-application",
        { applicationNumber, email }
      );
      
      if (!response.ok) {
        const errorData = await response.json();
        setVerificationError(errorData.message || "Application verification failed");
        return false;
      }
      
      const verificationResult = await response.json();
      
      if (!verificationResult.verified) {
        setVerificationError(verificationResult.message || "Application verification failed");
        return false;
      }
      
      // Application verified successfully
      setApplicationVerified(true);
      
      // Auto-fill personal information from application data if available
      if (verificationResult.firstName) {
        form.setValue("firstName", verificationResult.firstName);
      }
      
      if (verificationResult.lastName) {
        form.setValue("lastName", verificationResult.lastName);
      }
      
      toast({
        title: "Application Verified",
        description: "Your application has been verified. You can now create your account.",
        variant: "default",
      });
      
      return true;
    } catch (error: any) {
      console.error("Application verification error:", error);
      setVerificationError(error.message || "An error occurred during application verification");
      return false;
    } finally {
      setIsLoading(false);
    }
  }

  async function onSubmit(data: RegisterFormValues) {
    try {
      setIsLoading(true);
      
      // Remove confirmPassword and other fields not needed for backend
      const { 
        confirmPassword, 
        agreeTerms,
        ...userData 
      } = data;
      
      // Use register from useAuth
      await register(userData);
      
      // Show success message
      toast({
        title: "Registration Successful",
        description: "Your account has been created. You can now log in.",
        variant: "default",
      });
      
    } catch (error) {
      console.error("Registration error:", error);
      toast({
        title: "Registration Failed",
        description: "There was an error creating your account. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }
  
  async function onNextStep() {
    const fieldsToValidate = formStep === 0
      ? ["applicationNumber", "email"]
      : formStep === 1 
        ? ["firstName", "lastName", "username", "password", "confirmPassword"]
        : ["securityQuestion1", "securityAnswer1", "securityQuestion2", "securityAnswer2", "agreeTerms"];
    
    const isValid = await form.trigger(fieldsToValidate as any);
    
    if (isValid) {
      // If we're at the application verification step
      if (formStep === 0) {
        // First verify the application
        const verified = await verifyApplication();
        if (!verified) return;
      }
      
      // If at final step, submit the form
      if (formStep === 2) {
        form.handleSubmit(onSubmit)();
        return;
      }
      
      setFormStep(current => current + 1);
      window.scrollTo(0, 0);
    }
  }
  
  function onPrevStep() {
    setFormStep(current => current - 1);
    window.scrollTo(0, 0);
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
        {/* Form step indicator */}
        <div className="w-full mb-6">
          <div className="flex justify-between mb-2">
            <div className={`font-medium text-sm ${formStep >= 0 ? "text-primary" : "text-gray-400"}`}>Application</div>
            <div className={`font-medium text-sm ${formStep >= 1 ? "text-primary" : "text-gray-400"}`}>Account Setup</div>
            <div className={`font-medium text-sm ${formStep >= 2 ? "text-primary" : "text-gray-400"}`}>Security</div>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-primary h-2 rounded-full transition-all duration-300" 
              style={{ width: `${(formStep / 2) * 100}%` }}
            ></div>
          </div>
        </div>

        {formStep === 0 && (
          <>
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200 mb-4">
              <div className="flex">
                <div className="mr-3 mt-1">
                  <Info className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <h4 className="text-sm font-medium text-blue-700">Create Your Login</h4>
                  <p className="text-xs text-blue-600 mt-1">
                    Before creating your login, we need to verify your approved application. 
                    Please enter your application number and the email you used in your application.
                  </p>
                </div>
              </div>
            </div>
            
            {/* Application verification status messages */}
            {verificationError && (
              <div className="bg-red-50 p-4 rounded-lg border border-red-200 mb-4">
                <div className="flex">
                  <div className="mr-3 mt-1">
                    <AlertTriangle className="h-5 w-5 text-red-600" />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-red-700">Verification Failed</h4>
                    <p className="text-xs text-red-600 mt-1">{verificationError}</p>
                  </div>
                </div>
              </div>
            )}
            
            {applicationVerified && (
              <div className="bg-green-50 p-4 rounded-lg border border-green-200 mb-4">
                <div className="flex">
                  <div className="mr-3 mt-1">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-green-700">Application Verified</h4>
                    <p className="text-xs text-green-600 mt-1">
                      Your application has been verified successfully. You can now proceed to create your account.
                    </p>
                  </div>
                </div>
              </div>
            )}
            
            <div className="space-y-4">
              <FormField
                control={form.control}
                name="applicationNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700">Application Number *</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                          <FileText className="h-4 w-4" />
                        </div>
                        <Input 
                          placeholder="APP-123456-789" 
                          className={`pl-10 ${applicationVerified ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200'} focus:bg-white`}
                          {...field} 
                          disabled={isLoading || applicationVerified} 
                        />
                      </div>
                    </FormControl>
                    <FormDescription className="text-xs text-gray-500">
                      Your application number was provided after your application was submitted
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700">Email Address *</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                          <AtSign className="h-4 w-4" />
                        </div>
                        <Input 
                          type="email"
                          placeholder="johndoe@example.com" 
                          className={`pl-10 ${applicationVerified ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200'} focus:bg-white`}
                          {...field} 
                          disabled={isLoading || applicationVerified} 
                        />
                      </div>
                    </FormControl>
                    <FormDescription className="text-xs text-gray-500">
                      Must match the email you used in your application
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="flex justify-end mt-6">
              {!applicationVerified ? (
                <Button 
                  type="button" 
                  className="px-6" 
                  onClick={async () => {
                    // Trigger validation for first step fields
                    const isValid = await form.trigger(["applicationNumber", "email"]);
                    if (isValid) {
                      await verifyApplication();
                    }
                  }}
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Verifying...
                    </>
                  ) : (
                    <>
                      Verify Application
                    </>
                  )}
                </Button>
              ) : (
                <Button 
                  type="button" 
                  className="px-6" 
                  onClick={onNextStep}
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      Continue
                      <ChevronRight className="ml-2 h-4 w-4" />
                    </>
                  )}
                </Button>
              )}
            </div>
          </>
        )}

        {formStep === 1 && (
          <>
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200 mb-4">
              <div className="flex">
                <div className="mr-3 mt-1">
                  <Info className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <h4 className="text-sm font-medium text-blue-700">Create Login Credentials</h4>
                  <p className="text-xs text-blue-600 mt-1">
                    Create a unique username and strong password for your account.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              {/* Personal Information */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="firstName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700">First Name *</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                            <User className="h-4 w-4" />
                          </div>
                          <Input 
                            placeholder="John" 
                            className="pl-10 bg-gray-50 border-gray-200 focus:bg-white"
                            {...field} 
                            disabled={isLoading} 
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="lastName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700">Last Name *</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                            <User className="h-4 w-4" />
                          </div>
                          <Input 
                            placeholder="Doe" 
                            className="pl-10 bg-gray-50 border-gray-200 focus:bg-white"
                            {...field} 
                            disabled={isLoading} 
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              {/* Login credentials */}
              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700">Username *</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                          <User className="h-4 w-4" />
                        </div>
                        <Input 
                          placeholder="johndoe" 
                          className="pl-10 bg-gray-50 border-gray-200 focus:bg-white"
                          {...field} 
                          disabled={isLoading}
                        />
                      </div>
                    </FormControl>
                    <FormDescription className="text-xs text-gray-500">
                      At least 5 characters. Letters, numbers, and underscores only.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700">Password *</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                          <Lock className="h-4 w-4" />
                        </div>
                        <Input 
                          type="password"
                          placeholder="••••••••" 
                          className="pl-10 bg-gray-50 border-gray-200 focus:bg-white"
                          {...field} 
                          onChange={(e) => {
                            field.onChange(e);
                            calculatePasswordStrength(e.target.value);
                          }}
                          disabled={isLoading}
                        />
                      </div>
                    </FormControl>
                    
                    {/* Password strength indicator */}
                    <div className="mt-2">
                      <div className="flex justify-between mb-1">
                        <div className="text-xs text-gray-500">Password strength:</div>
                        <div className="text-xs font-medium">
                          {passwordStrength === 0 && "Very weak"}
                          {passwordStrength === 1 && "Weak"}
                          {passwordStrength === 2 && "Fair"}
                          {passwordStrength === 3 && "Good"}
                          {passwordStrength === 4 && "Strong"}
                          {passwordStrength === 5 && "Very strong"}
                        </div>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-1.5">
                        <div 
                          className={`h-1.5 rounded-full transition-all duration-300 ${
                            passwordStrength <= 1 ? 'bg-red-500' : 
                            passwordStrength <= 2 ? 'bg-orange-500' : 
                            passwordStrength <= 3 ? 'bg-yellow-500' : 
                            passwordStrength <= 4 ? 'bg-green-500' : 
                            'bg-emerald-500'
                          }`} 
                          style={{ width: `${(passwordStrength / 5) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                    
                    <FormDescription className="text-xs text-gray-500 mt-2">
                      Password must have at least 8 characters, uppercase & lowercase letters, numbers, and special characters.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="confirmPassword"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700">Confirm Password *</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                          <Key className="h-4 w-4" />
                        </div>
                        <Input 
                          type="password"
                          placeholder="••••••••" 
                          className="pl-10 bg-gray-50 border-gray-200 focus:bg-white"
                          {...field} 
                          disabled={isLoading}
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="flex justify-between mt-6">
              <Button 
                type="button" 
                variant="outline" 
                className="px-4" 
                onClick={onPrevStep}
                disabled={isLoading}
              >
                <ChevronLeft className="mr-2 h-4 w-4" />
                Back
              </Button>
              
              <Button 
                type="button" 
                className="px-6" 
                onClick={onNextStep}
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    Continue
                    <ChevronRight className="ml-2 h-4 w-4" />
                  </>
                )}
              </Button>
            </div>
          </>
        )}

        {formStep === 2 && (
          <>
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200 mb-4">
              <div className="flex">
                <div className="mr-3 mt-1">
                  <ShieldCheck className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <h4 className="text-sm font-medium text-blue-700">Security Questions</h4>
                  <p className="text-xs text-blue-600 mt-1">
                    Set up security questions to help verify your identity if you ever need to recover your account.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <FormField
                control={form.control}
                name="securityQuestion1"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700">Security Question 1 *</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                      disabled={isLoading}
                    >
                      <FormControl>
                        <SelectTrigger className="bg-gray-50 border-gray-200 focus:bg-white">
                          <SelectValue placeholder="Select a security question" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {SECURITY_QUESTIONS.map((question, index) => (
                          <SelectItem key={`q1-${index}`} value={question}>
                            {question}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="securityAnswer1"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700">Answer 1 *</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Your answer" 
                        className="bg-gray-50 border-gray-200 focus:bg-white"
                        {...field} 
                        disabled={isLoading}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <Separator className="my-4" />
              
              <FormField
                control={form.control}
                name="securityQuestion2"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700">Security Question 2 *</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                      disabled={isLoading}
                    >
                      <FormControl>
                        <SelectTrigger className="bg-gray-50 border-gray-200 focus:bg-white">
                          <SelectValue placeholder="Select a security question" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {SECURITY_QUESTIONS.map((question, index) => (
                          <SelectItem key={`q2-${index}`} value={question}>
                            {question}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="securityAnswer2"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700">Answer 2 *</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Your answer" 
                        className="bg-gray-50 border-gray-200 focus:bg-white"
                        {...field} 
                        disabled={isLoading}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <Separator className="my-4" />
              
              <FormField
                control={form.control}
                name="agreeTerms"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0 mt-6">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        disabled={isLoading}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel className="text-sm font-normal">
                        I agree to the <Link href="/legal/terms-conditions" className="text-primary hover:underline">Terms and Conditions</Link> and <Link href="/legal/privacy-policy" className="text-primary hover:underline">Privacy Policy</Link>
                      </FormLabel>
                      <FormMessage />
                    </div>
                  </FormItem>
                )}
              />
            </div>
            
            <div className="flex justify-between mt-6">
              <Button 
                type="button" 
                variant="outline" 
                className="px-4" 
                onClick={onPrevStep}
                disabled={isLoading}
              >
                <ChevronLeft className="mr-2 h-4 w-4" />
                Back
              </Button>
              
              <Button 
                type="submit" 
                className="px-6" 
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating Account...
                  </>
                ) : (
                  "Create Account"
                )}
              </Button>
            </div>
          </>
        )}
      </form>
    </Form>
  );
}