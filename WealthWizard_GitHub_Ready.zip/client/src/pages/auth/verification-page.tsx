import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import {
  CheckCircle2,
  RefreshCw,
  FileCheck,
  ShieldCheck,
  XCircle,
  FileText,
  Calendar,
  ArrowRight,
  Mail,
  AlertCircle,
  Clock,
  CheckCheck,
  Loader2,
  UserCircle,
  Lock
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

interface VerificationPageProps {
  params?: {
    step?: string;
  };
  userId?: number;
  email?: string;
  applicationId?: string;
}

const registerSchema = z.object({
  username: z.string().min(3, {
    message: "Username must be at least 3 characters.",
  }),
  password: z.string().min(6, {
    message: "Password must be at least 6 characters.",
  }),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

type RegisterValues = z.infer<typeof registerSchema>;

export default function VerificationPage(props: VerificationPageProps = {}) {
  const [_, setLocation] = useLocation();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [applicationDate] = useState(new Date());
  const [step, setStep] = useState<'email' | 'review' | 'register' | 'verified'>('email');
  const [verificationCode, setVerificationCode] = useState('');
  const [countdown, setCountdown] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [reviewProgress, setReviewProgress] = useState(0);
  const [applicationData, setApplicationData] = useState<any>(null);
  
  // Get application info from URL params or use defaults
  const urlParams = new URLSearchParams(window.location.search);
  const applicationId = props.applicationId || urlParams.get('applicationId') || "APP-826911-453";
  const email = props.email || urlParams.get('email') || "sjsn@gmail.com";
  
  // Registration form setup
  const registerForm = useForm<RegisterValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      password: "",
      confirmPassword: ""
    },
  });
  
  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(prev => prev - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);
  
  // Effect for handling review progress
  useEffect(() => {
    if (step === 'review' && reviewProgress < 100) {
      console.log("Starting 15-second verification process...");
      
      // Use a 15-second review process
      const interval = setInterval(() => {
        setReviewProgress(prev => {
          // Calculate increment to make the process take 15 seconds
          // We want 5 updates to reach 100% (0%, 20%, 40%, 60%, 80%, 100%)
          // So each increment should be 20% and interval should be 3000ms (15s / 5)
          const newValue = prev + 20;
          
          if (newValue >= 100) {
            clearInterval(interval);
            
            // After review is complete, go to verified step
            setTimeout(() => {
              console.log("Verification process complete, redirecting...");
              setStep('verified');
              toast({
                title: "Verification Complete",
                description: "Your application has been approved. You can now access your account.",
              });
            }, 500);
            
            return 100;
          }
          return newValue;
        });
      }, 3000); // 3 seconds between each update (15 seconds total with 5 updates)
      
      return () => clearInterval(interval);
    }
  }, [step, reviewProgress, toast]);
  
  const handleVerifyEmail = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      // In a real implementation, call the API to verify the application
      const response = await apiRequest("POST", "/api/auth/verify-application", {
        applicationNumber: applicationId,
        email,
        verificationCode: verificationCode
      });
      
      const data = await response.json();
      setApplicationData(data);
      
      console.log("Email verification successful");
      setIsLoading(false);
      
      // Move to review step
      setStep('review');
      setReviewProgress(0);
      
      toast({
        title: "Email Verified",
        description: "Your email has been successfully verified. We're now reviewing your application.",
      });
    } catch (err: any) {
      setIsLoading(false);
      setError(err.message || "Failed to verify email. Please try again.");
      
      toast({
        title: "Verification Failed",
        description: err.message || "Please check your verification code and try again.",
        variant: "destructive"
      });
    }
  };
  
  const handleResendCode = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      // In a real implementation, this would be an API call to resend the code
      await apiRequest("POST", "/api/auth/resend-verification", {
        applicationNumber: applicationId,
        email
      });
      
      setIsLoading(false);
      setCountdown(60);
      
      toast({
        title: "Verification Code Sent",
        description: "A new verification code has been sent to your email address.",
      });
    } catch (err: any) {
      setIsLoading(false);
      setError(err.message || "Failed to resend verification code. Please try again.");
      
      toast({
        title: "Error",
        description: err.message || "Failed to resend verification code. Please try again.",
        variant: "destructive"
      });
    }
  };
  
  const handleAccessAccount = () => {
    setIsLoading(true);
    
    // Redirect to login page
    setTimeout(() => {
      setIsLoading(false);
      setLocation("/auth");
      
      toast({
        title: "Ready to Access Your Account",
        description: "You can now login with your credentials.",
      });
    }, 1000);
  };
  
  const handleRegister = async (values: RegisterValues) => {
    setIsLoading(true);
    setError(null);
    
    try {
      // Create user account from application
      const response = await apiRequest("POST", "/api/auth/create-account-from-application", {
        applicationId: applicationId,
        username: values.username,
        password: values.password,
        email: email
      });
      
      setIsLoading(false);
      setStep('verified');
      
      toast({
        title: "Account Created Successfully",
        description: "Your account has been created and is now ready for use.",
      });
    } catch (err: any) {
      setIsLoading(false);
      setError(err.message || "Failed to create account. Please try again.");
      
      toast({
        title: "Registration Failed",
        description: err.message || "Please try a different username.",
        variant: "destructive"
      });
    }
  };
  
  if (step === 'email') {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md w-full space-y-8">
          {/* Gmail-like header */}
          <div className="text-center">
            <div className="flex justify-center mb-6">
              <div className="bg-white p-3 rounded-xl shadow-md">
                <svg viewBox="0 0 24 24" width="36" height="36" fill="#4285F4">
                  <path d="M22 6c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6zm-2 0l-8 5-8-5h16zm0 12H4V8l8 5 8-5v10z" />
                </svg>
              </div>
            </div>
            <h1 className="text-2xl font-medium text-gray-800">Verify your email</h1>
            <p className="mt-2 text-gray-600">
              To continue setting up your Fortis Capital account
            </p>
            
            {/* Progress indicator */}
            <div className="mt-6 w-full">
              <Progress value={50} className="h-2" />
            </div>
          </div>
          
          <Card className="w-full shadow-lg overflow-hidden border border-gray-200">
            <div className="p-6 space-y-6">
              <div className="flex items-center justify-center space-x-3 mb-4">
                <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                  <Mail className="h-4 w-4 text-blue-600" />
                </div>
                <div className="text-sm font-medium">
                  <p>Verification code sent to:</p>
                  <p className="text-blue-600">{email}</p>
                </div>
              </div>
              
              {error && (
                <Alert variant="destructive" className="mb-4">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription>
                    {error}
                  </AlertDescription>
                </Alert>
              )}
              
              <div className="space-y-5">
                <div className="space-y-3">
                  <Label htmlFor="verification-code" className="text-base font-medium">
                    Enter the verification code
                  </Label>
                  
                  {/* Gmail-like verification code input */}
                  <div className="flex justify-center">
                    <Input 
                      id="verification-code" 
                      placeholder="G-123456" 
                      value={verificationCode}
                      onChange={(e) => setVerificationCode(e.target.value)}
                      maxLength={8}
                      className="text-center text-lg w-2/3 border-b-2 border-blue-500 rounded-none focus:ring-0 focus:border-blue-600"
                    />
                  </div>
                  
                  <div className="text-sm text-gray-600 text-center">
                    We sent your code to <span className="font-medium">{email}</span>
                  </div>
                  
                  <div className="text-sm text-gray-500 text-center">
                    {countdown > 0 ? (
                      <span>You can request a new code in {countdown} seconds</span>
                    ) : (
                      <button 
                        onClick={handleResendCode}
                        disabled={isLoading} 
                        className="text-blue-600 hover:text-blue-800 font-medium"
                      >
                        Resend code
                      </button>
                    )}
                  </div>
                </div>
                
                <div className="flex items-center justify-end pt-4">
                  <Button 
                    onClick={handleVerifyEmail} 
                    disabled={isLoading || verificationCode.length < 6} 
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    {isLoading ? (
                      <RefreshCw className="h-4 w-4 animate-spin" />
                    ) : (
                      "Verify"
                    )}
                  </Button>
                </div>
              </div>
              
              <div className="mt-4 text-xs text-gray-500 text-center border-t pt-4">
                <p>
                  For testing, use code: <span className="font-medium">123456</span>
                </p>
              </div>
            </div>
          </Card>
          
          {/* Footer with Gmail-like style */}
          <div className="text-center text-xs text-gray-500 space-y-2">
            <p>English (United States)</p>
            <div className="flex justify-center space-x-4">
              <a href="#" className="hover:underline">Help</a>
              <a href="#" className="hover:underline">Privacy</a>
              <a href="#" className="hover:underline">Terms</a>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  if (step === 'register') {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md w-full space-y-8">
          <div className="text-center">
            <div className="flex justify-center mb-6">
              <div className="bg-white p-3 rounded-xl shadow-md">
                <svg viewBox="0 0 24 24" width="36" height="36" fill="#4285F4">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
                </svg>
              </div>
            </div>
            <h1 className="text-2xl font-medium text-gray-800">Create Your Account</h1>
            <p className="mt-2 text-gray-600">
              Your application has been approved
            </p>
            
            {/* Progress indicator */}
            <div className="mt-6 w-full">
              <Progress value={85} className="h-2" />
            </div>
          </div>
          
          <Card className="w-full shadow-lg overflow-hidden border border-gray-200">
            <div className="p-6 space-y-6">
              <div className="flex items-center justify-center space-x-3 mb-4">
                <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                </div>
                <div className="text-sm font-medium">
                  <p>Application approved for</p>
                  <p className="text-green-600">{email}</p>
                </div>
              </div>
              
              {error && (
                <Alert variant="destructive" className="mb-4">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription>
                    {error}
                  </AlertDescription>
                </Alert>
              )}
              
              <div className="space-y-5">
                <Form {...registerForm}>
                  <form onSubmit={registerForm.handleSubmit(handleRegister)} className="space-y-4">
                    <FormField
                      control={registerForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Username</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <UserCircle className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                              <Input 
                                placeholder="Choose a username" 
                                className="pl-10" 
                                {...field} 
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={registerForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                              <Input 
                                type="password" 
                                placeholder="Create a password" 
                                className="pl-10" 
                                {...field} 
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={registerForm.control}
                      name="confirmPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Confirm Password</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                              <Input 
                                type="password" 
                                placeholder="Confirm your password" 
                                className="pl-10" 
                                {...field} 
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button 
                      type="submit" 
                      className="w-full mt-4 bg-blue-600 hover:bg-blue-700"
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <div className="flex items-center space-x-2">
                          <RefreshCw className="h-4 w-4 animate-spin" />
                          <span>Creating Account...</span>
                        </div>
                      ) : (
                        "Create Account"
                      )}
                    </Button>
                  </form>
                </Form>
              </div>
              
              <div className="mt-4 text-xs text-gray-500 text-center border-t pt-4">
                <p>
                  By creating an account, you agree to our Terms of Service and Privacy Policy.
                </p>
              </div>
            </div>
          </Card>
          
          <div className="text-center text-xs text-gray-500 space-y-2">
            <p>Need assistance? Contact our support team at</p>
            <div className="flex justify-center space-x-4">
              <a href="mailto:support@fortiscapital.com" className="hover:underline">support@fortiscapital.com</a>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (step === 'review') {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md w-full space-y-8">
          <div className="text-center">
            <div className="flex justify-center mb-6">
              <div className="bg-white p-3 rounded-xl shadow-md">
                <svg viewBox="0 0 24 24" width="36" height="36" fill="#4285F4">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14.5v-9l7 4.5-7 4.5z" />
                </svg>
              </div>
            </div>
            <h1 className="text-2xl font-medium text-gray-800">Application Review</h1>
            <p className="mt-2 text-gray-600">
              We're reviewing your information
            </p>
            
            {/* Progress indicator */}
            <div className="mt-6 w-full">
              <Progress value={75} className="h-2" />
            </div>
          </div>
          
          <Card className="w-full shadow-lg overflow-hidden border border-gray-200">
            <div className="p-6 space-y-6">
              <div className="text-center">
                <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mx-auto">
                  <Clock className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="mt-4 text-lg font-medium">Automated Verification in Progress</h3>
                <p className="mt-2 text-sm text-gray-600">
                  We're verifying your information to ensure a secure account setup.
                </p>
              </div>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-sm text-gray-600">Verification Progress</Label>
                  <Progress value={reviewProgress} className="h-2" />
                  <p className="text-xs text-gray-500 text-right">{reviewProgress}% complete</p>
                </div>
                
                <div className="space-y-3 pt-2">
                  <div className="flex items-center space-x-3">
                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                    <div className="text-sm">
                      <p className="font-medium">Email verification</p>
                      <p className="text-gray-500">Successfully verified</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    {reviewProgress >= 40 ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    ) : (
                      <Loader2 className="h-5 w-5 text-blue-500 animate-spin" />
                    )}
                    <div className="text-sm">
                      <p className="font-medium">Identity verification</p>
                      <p className="text-gray-500">
                        {reviewProgress >= 40 ? "Verified" : "Verifying your information..."}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    {reviewProgress >= 70 ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    ) : (
                      <Clock className="h-5 w-5 text-gray-400" />
                    )}
                    <div className="text-sm">
                      <p className="font-medium">Security checks</p>
                      <p className="text-gray-500">
                        {reviewProgress >= 70 ? "Completed" : "Pending"}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    {reviewProgress >= 90 ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    ) : (
                      <Clock className="h-5 w-5 text-gray-400" />
                    )}
                    <div className="text-sm">
                      <p className="font-medium">Account setup</p>
                      <p className="text-gray-500">
                        {reviewProgress >= 90 ? "Account successfully created" : "Pending"}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              
              <Alert className="bg-blue-50 text-blue-800 border-blue-200">
                <CheckCircle2 className="h-4 w-4 text-blue-600" />
                <AlertTitle>Verification in progress</AlertTitle>
                <AlertDescription>
                  We're processing your application automatically. Please do not close this page.
                </AlertDescription>
              </Alert>
            </div>
          </Card>
          
          {/* Footer with Gmail-like style */}
          <div className="text-center text-xs text-gray-500 space-y-2">
            <p>Need assistance? Contact our support team</p>
            <div className="flex justify-center space-x-4">
              <a href="mailto:support@fortiscapital.com" className="hover:underline">Contact Support</a>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl w-full space-y-8">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-primary">Fortis Capital</h1>
          <p className="mt-2 text-gray-600">Account Setup Complete</p>
          
          {/* Progress indicator */}
          <div className="mt-6 w-full">
            <Progress value={100} className="h-2" />
          </div>
        </div>
        
        <Card className="w-full shadow-lg overflow-hidden">
          <div className="p-6 space-y-6">
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <h3 className="text-xl font-semibold">Application Status</h3>
                <Badge 
                  variant="outline"
                  className="bg-green-100 text-green-800 hover:bg-green-100"
                >
                  Approved
                </Badge>
              </div>
              
              <div className="flex space-x-4 text-sm text-gray-600 mt-1">
                <div className="flex items-center">
                  <span className="font-medium mr-2">Reference:</span>
                  <span>{applicationId}</span>
                </div>
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 mr-1 text-gray-500" />
                  <span>Submitted: {applicationDate.toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric'
                  })}</span>
                </div>
              </div>
            </div>
            
            <div className="bg-green-50 p-4 rounded-lg border border-green-200">
              <div className="flex items-start">
                <CheckCircle2 className="h-5 w-5 text-green-500 mt-0.5 mr-3 flex-shrink-0" />
                <div>
                  <p className="font-medium text-green-800">Application Approved</p>
                  <p className="text-sm text-green-700 mt-1">
                    Your account has been successfully created and is now ready for use. You can now log in
                    to access your account and banking services.
                  </p>
                  
                  <Button 
                    onClick={handleAccessAccount}
                    className="mt-4"
                  >
                    {isLoading ? (
                      <>
                        <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        Access Your Account <ArrowRight className="ml-2 h-4 w-4" />
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </div>
            
            <Separator />
            
            <div className="space-y-4">
              <h4 className="text-md font-medium">Verification Summary</h4>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between bg-gray-50 p-3 rounded-lg">
                  <div className="flex items-center">
                    <Mail className="h-5 w-5 text-gray-500 mr-3" />
                    <span className="text-sm">Email Verification</span>
                  </div>
                  <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                    <CheckCircle2 className="h-3 w-3 mr-1" />
                    Complete
                  </Badge>
                </div>
                
                <div className="flex items-center justify-between bg-gray-50 p-3 rounded-lg">
                  <div className="flex items-center">
                    <FileText className="h-5 w-5 text-gray-500 mr-3" />
                    <span className="text-sm">Document Verification</span>
                  </div>
                  <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                    <CheckCircle2 className="h-3 w-3 mr-1" />
                    Complete
                  </Badge>
                </div>
                
                <div className="flex items-center justify-between bg-gray-50 p-3 rounded-lg">
                  <div className="flex items-center">
                    <ShieldCheck className="h-5 w-5 text-gray-500 mr-3" />
                    <span className="text-sm">Account Security</span>
                  </div>
                  <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                    <CheckCircle2 className="h-3 w-3 mr-1" />
                    Configured
                  </Badge>
                </div>
                
                <div className="flex items-center justify-between bg-gray-50 p-3 rounded-lg">
                  <div className="flex items-center">
                    <FileCheck className="h-5 w-5 text-gray-500 mr-3" />
                    <span className="text-sm">Identity Confirmation</span>
                  </div>
                  <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                    <CheckCircle2 className="h-3 w-3 mr-1" />
                    Complete
                  </Badge>
                </div>
              </div>
            </div>
          </div>
        </Card>
        
        <div className="text-center text-sm text-gray-500">
          <p>
            Need assistance? Contact our support team at{" "}
            <a href="mailto:support@fortiscapital.com" className="text-primary hover:underline">
              support@fortiscapital.com
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}