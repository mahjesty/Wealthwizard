import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import LoginForm from "./components/login-form";
import RegisterForm from "./components/register-form-fixed";
import AccountApplicationForm from "./components/account-application-form";
import { FortisLogo } from "@/components/ui/fortis-logo";
import { 
  LockKeyhole, 
  Shield, 
  ChevronRight, 
  TrendingUp, 
  CreditCard, 
  Clock, 
  Smartphone,
  FileText,
  Search,
  CheckCircle,
  X,
  Copy,
  CheckCheck,
  AlertTriangle,
  RefreshCw
} from "lucide-react";

// Component to handle IP restriction and existing applications check
interface ApplicationTabContentProps {
  setActiveTab: (tab: string) => void;
}

function ApplicationTabContent({ setActiveTab }: ApplicationTabContentProps) {
  const [checkingIP, setCheckingIP] = useState(true);
  const [hasExistingApplication, setHasExistingApplication] = useState(false);
  const [canSubmitNew, setCanSubmitNew] = useState(true);
  const [applicationNumber, setApplicationNumber] = useState<string | null>(null);
  const [applicationStatus, setApplicationStatus] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  
  useEffect(() => {
    // Check if the user has any applications from their IP
    fetch('/api/account-applications/check-ip')
      .then(res => res.json())
      .then(data => {
        console.log("IP check response:", data);
        
        if (data.hasApplication) {
          setHasExistingApplication(true);
          setCanSubmitNew(data.canSubmitNew || false);
          setApplicationNumber(data.applicationNumber);
          setApplicationStatus(data.applicationStatus);
          setStatusMessage(data.message);
          
          // If there's a pending or approved application, redirect to status check
          if (!data.canSubmitNew) {
            // Automatically switch to check status tab
            setTimeout(() => {
              setActiveTab("check-status");
              
              // Pre-fill the application number and manually fetch fresh status
              setTimeout(() => {
                const input = document.getElementById('checkStatusNumber') as HTMLInputElement;
                if (input && data.applicationNumber) {
                  input.value = data.applicationNumber;
                  
                  // Directly fetch fresh status with cache busting
                  const timestamp = new Date().getTime();
                  setStatusLoading(true);
                  setStatusComponentKey(prev => prev + 1);
                  
                  fetch(`/api/account-applications/status/${data.applicationNumber}?t=${timestamp}`)
                    .then(res => res.json())
                    .then(statusData => {
                      // Force new object reference
                      setStatusResult({...statusData});
                      setStatusError(null);
                    })
                    .catch(err => {
                      console.error("Error loading redirected application status:", err);
                      setStatusError("Could not load application status");
                    })
                    .finally(() => {
                      setStatusLoading(false);
                    });
                }
              }, 200);
            }, 1500);
          }
        }
      })
      .catch(err => {
        console.error("Error checking for existing applications:", err);
        setErrorMessage("Could not verify application status");
      })
      .finally(() => {
        setCheckingIP(false);
      });
  }, [setActiveTab]);
  
  if (checkingIP) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mb-3"></div>
        <p className="text-gray-600 text-sm">Checking application status...</p>
      </div>
    );
  }
  
  // User has an application, and it's pending or approved (can't submit a new one)
  if (hasExistingApplication && !canSubmitNew) {
    const isPending = applicationStatus === 'pending_review';
    const statusColor = isPending ? 'amber' : 'green';
    const statusIcon = isPending ? <Clock className="h-6 w-6 text-amber-600" /> : <CheckCircle className="h-6 w-6 text-green-600" />;
    const statusTitle = isPending ? "Pending Application Detected" : "Approved Application";
    
    return (
      <div className={`p-6 bg-${statusColor}-50 border border-${statusColor}-200 rounded-lg`}>
        <div className="flex flex-col items-center text-center space-y-4">
          <div className={`h-12 w-12 bg-${statusColor}-100 rounded-full flex items-center justify-center`}>
            {statusIcon}
          </div>
          <h3 className={`text-lg font-semibold text-${statusColor}-800`}>{statusTitle}</h3>
          <p className={`text-${statusColor}-700 max-w-md`}>
            {statusMessage || "You already have an application. You'll be redirected to check its status."}
          </p>
          
          {applicationNumber && (
            <div className="bg-white p-4 rounded-md border-2 border-amber-300 shadow-sm w-full max-w-sm">
              <h4 className="font-semibold text-gray-800 mb-2">Your Application Number</h4>
              <div className="bg-amber-50 p-2 rounded-md border border-amber-200 mb-2">
                <p className="text-lg font-bold text-amber-700 tracking-wide">{applicationNumber}</p>
              </div>
              <p className="text-xs text-amber-600 mt-1">Please save this number for your records</p>
            </div>
          )}
          
          <div className="flex space-x-4">
            <Button
              variant="outline"
              onClick={() => setActiveTab("login")}
              className="border-amber-300 text-amber-700 hover:bg-amber-50"
            >
              Back to Login
            </Button>
            <Button
              onClick={() => setActiveTab("check-status")}
              className="bg-amber-600 hover:bg-amber-700 text-white"
            >
              Check Status
            </Button>
          </div>
        </div>
      </div>
    );
  }
  
  // Application was rejected (can submit a new one)
  if (hasExistingApplication && canSubmitNew && applicationStatus === 'denied') {
    return (
      <>
        <div className="p-4 mb-6 bg-orange-50 border border-orange-200 rounded-lg">
          <div className="flex items-start">
            <div className="flex-shrink-0 mt-0.5">
              <AlertTriangle className="h-5 w-5 text-orange-600" />
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-orange-800">Previous Application Rejected</h3>
              <p className="text-xs text-orange-700 mt-1">
                Your previous application {applicationNumber && <span className="font-medium">(#{applicationNumber})</span>} was rejected. 
                You may submit a new application with updated information.
              </p>
              <div className="mt-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    setActiveTab("check-status");
                    
                    // Pre-fill application number and trigger status refresh
                    setTimeout(() => {
                      const input = document.getElementById('checkStatusNumber') as HTMLInputElement;
                      if (input && applicationNumber) {
                        input.value = applicationNumber;
                        
                        // Directly fetch fresh status with cache busting
                        const timestamp = new Date().getTime();
                        setStatusLoading(true);
                        setStatusComponentKey(prev => prev + 1);
                        
                        fetch(`/api/account-applications/status/${applicationNumber}?t=${timestamp}`)
                          .then(res => res.json())
                          .then(statusData => {
                            // Force new object reference
                            setStatusResult({...statusData});
                            setStatusError(null);
                          })
                          .catch(err => {
                            console.error("Error loading rejection details:", err);
                            setStatusError("Could not load rejection details");
                          })
                          .finally(() => {
                            setStatusLoading(false);
                          });
                      }
                    }, 100);
                  }}
                  className="border-orange-200 text-orange-700 hover:bg-orange-50 h-7 text-xs py-0"
                >
                  View Rejection Details
                </Button>
              </div>
            </div>
          </div>
        </div>
        
        <div className="space-y-2 mb-4">
          <h3 className="text-xl font-semibold text-gray-900">Open a New Account</h3>
          <p className="text-sm text-gray-600">
            Complete your application to join Fortis Capital
          </p>
          <div className="flex justify-end">
            <button 
              onClick={() => setActiveTab("check-status")}
              className="inline-flex items-center text-xs font-medium text-primary hover:underline"
            >
              <Clock className="h-3 w-3 mr-1" />
              Check application status
              <ChevronRight className="h-3 w-3 ml-1" />
            </button>
          </div>
        </div>
        <AccountApplicationForm />
      </>
    );
  }
  
  if (errorMessage) {
    return (
      <div className="p-4 bg-red-50 border border-red-200 rounded-lg mb-4">
        <p className="text-red-700">{errorMessage}</p>
        <Button
          variant="outline"
          onClick={() => window.location.reload()}
          className="mt-2 border-red-200 text-red-700 hover:bg-red-50"
        >
          Retry
        </Button>
      </div>
    );
  }
  
  // No existing application or error
  return (
    <>
      <div className="space-y-2 mb-4">
        <h3 className="text-xl font-semibold text-gray-900">Open a New Account</h3>
        <p className="text-sm text-gray-600">
          Complete your application to join Fortis Capital
        </p>
        <div className="flex justify-end">
          <button 
            onClick={() => setActiveTab("check-status")}
            className="inline-flex items-center text-xs font-medium text-primary hover:underline"
          >
            <Clock className="h-3 w-3 mr-1" />
            Already applied? Check status
            <ChevronRight className="h-3 w-3 ml-1" />
          </button>
        </div>
      </div>
      <AccountApplicationForm />
    </>
  );
}

export default function AuthPage() {
  console.log("AuthPage component loaded");
  const [location, setLocation] = useLocation();
  const params = new URLSearchParams(location.split("?")[1] || "");
  const tabParam = params.get("tab");
  
  const [activeTab, setActiveTab] = useState(tabParam === "register" ? "register" : tabParam === "apply" ? "apply" : tabParam === "check-status" ? "check-status" : "login");
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [currentTime, setCurrentTime] = useState(new Date());
  const [statusLoading, setStatusLoading] = useState(false);
  const [statusResult, setStatusResult] = useState<any>(null);
  const [statusError, setStatusError] = useState<string | null>(null);
  // Add a key to force re-render of the status component when checking status
  const [statusComponentKey, setStatusComponentKey] = useState(0);
  
  // Auto-refresh functionality with progressive loading states
  useEffect(() => {
    // If we have application status result, set up an interval to refresh it
    let refreshInterval: NodeJS.Timeout | null = null;
    
    if (statusResult && statusResult.applicationNumber) {
      // Only auto-refresh pending or in-review applications 
      // (approved and denied are terminal states)
      if (statusResult.status === 'pending_review' || statusResult.status === 'in_review') {
        console.log("Setting up auto-refresh for application", statusResult.applicationNumber);
        
        refreshInterval = setInterval(() => {
          // Silent refresh - don't show loading state
          const timestamp = new Date().getTime();
          
          console.log("Auto-refreshing application status:", statusResult.applicationNumber);
          
          // Fetch with cache busting
          fetch(`/api/account-applications/status/${statusResult.applicationNumber}?t=${timestamp}`)
            .then(res => res.json())
            .then(data => {
              console.log("Auto-refresh response:", data.status, "Current status:", statusResult.status);
              
              // Check if status has changed
              const statusChanged = data.status !== statusResult.status;
              
              // Create completely new object
              const updatedStatusResult = {
                ...data,
                _refreshTimestamp: new Date().getTime() // Add this to force React to detect changes
              };
              
              // Force new reference to ensure React detects the change
              setStatusResult(updatedStatusResult);
              setStatusError(null);
              
              // Force component re-render on every status check
              setStatusComponentKey(prevKey => prevKey + 1);
              
              // Show toast notification only if status changed
              if (statusChanged) {
                toast({
                  title: "Status Updated",
                  description: `Application status changed to: ${data.status.replace('_', ' ')}`,
                  variant: "default",
                });
              }
            })
            .catch(err => {
              console.error("Auto-refresh error:", err);
              // Don't show errors for silent auto-refresh
            });
        }, 15000); // Check every 15 seconds (more frequent checks)
      }
    }
    
    // Clean up interval on unmount or when status result changes
    return () => {
      if (refreshInterval) {
        console.log("Cleaning up auto-refresh interval");
        clearInterval(refreshInterval);
      }
    };
  }, [statusResult, toast]);
  
  // We've implemented the auto-refresh functionality in a more comprehensive way above

  // Update current time
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => {
      clearInterval(timer);
    };
  }, []);

  // Format time
  const formattedTime = currentTime.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit'
  });
  
  const formattedDate = currentTime.toLocaleDateString([], {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric'
  });

  // Redirect to dashboard if already authenticated
  if (isAuthenticated) {
    // Use setTimeout to avoid the "Cannot update a component while rendering a different component" warning
    setTimeout(() => {
      setLocation("/dashboard");
    }, 0);
    return null;
  }

  return (
    <div className="flex flex-col md:flex-row min-h-screen w-full bg-gray-50">
      {/* Header - Only visible on mobile */}
      <div className="block md:hidden w-full bg-primary p-4 text-white">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">Fortis Capital</h1>
          <div className="text-sm text-right">
            <div className="font-semibold">{formattedTime}</div>
            <div className="text-xs opacity-80">{formattedDate}</div>
          </div>
        </div>
      </div>

      {/* Left Section - Auth Forms */}
      <div className="flex-1 flex flex-col items-center justify-center px-4 sm:px-6 py-8 bg-white">
        <div className="flex flex-col items-center justify-center max-w-md w-full mx-auto space-y-8">
          <div className="flex flex-col items-center space-y-2 text-center">
            <div className="flex justify-center mb-4">
              <FortisLogo width={80} height={80} className="text-primary" />
            </div>
            <h1 className="text-3xl font-bold text-primary">Fortis Capital</h1>
            <p className="text-muted-foreground text-sm max-w-xs">
              Secure online banking for a better financial future
            </p>
          </div>

          <Tabs
            defaultValue="login"
            value={activeTab}
            onValueChange={setActiveTab}
            className="w-full"
          >
            <Card className="w-full shadow-lg border-0 overflow-hidden bg-white">
              <div className="bg-primary/5 p-4 border-b border-gray-200">
                <TabsList className="grid w-full grid-cols-4 bg-gray-100">
                  <TabsTrigger value="login" className="data-[state=active]:bg-white">
                    Sign In
                  </TabsTrigger>
                  <TabsTrigger value="apply" className="data-[state=active]:bg-white">
                    Apply Now
                  </TabsTrigger>
                  <TabsTrigger value="register" className="data-[state=active]:bg-white">
                    Create Login
                  </TabsTrigger>
                  <TabsTrigger value="check-status" className="data-[state=active]:bg-white">
                    Check Status
                  </TabsTrigger>
                </TabsList>
              </div>
              
              <div className="p-6">
                <TabsContent value="login" className="mt-0 space-y-4">
                  <div className="space-y-2 mb-4">
                    <h3 className="text-xl font-semibold text-gray-900">Welcome back</h3>
                    <p className="text-sm text-gray-600">
                      Access your accounts securely with your credentials
                    </p>
                  </div>
                  <LoginForm />
                  
                  <div className="flex justify-end pt-4">
                    <a
                      href="/forgot-password"
                      className="text-sm text-primary hover:underline"
                    >
                      Forgot your password?
                    </a>
                  </div>
                </TabsContent>
                
                <TabsContent value="apply" className="mt-0 space-y-4">
                  <ApplicationTabContent setActiveTab={setActiveTab} />
                </TabsContent>
                
                <TabsContent value="register" className="mt-0 space-y-4">
                  <div className="space-y-2 mb-4">
                    <h3 className="text-xl font-semibold text-gray-900">Create your login</h3>
                    <p className="text-sm text-gray-600">
                      Set up credentials for your approved account
                    </p>
                  </div>
                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-200 mb-4">
                    <div className="flex items-start">
                      <div className="mr-3 mt-1">
                        <FileText className="h-5 w-5 text-blue-600" />
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-blue-700">Already Applied?</h4>
                        <p className="text-xs text-blue-600 mt-1">
                          If your application has been approved, you can create your login credentials here.
                          You'll need your application number and the email address you used in your application.
                        </p>
                        <div className="mt-2">
                          <button 
                            onClick={() => setActiveTab("check-status")}
                            className="inline-flex items-center text-xs font-medium text-primary hover:underline"
                          >
                            <Clock className="h-3 w-3 mr-1" />
                            Check your application status
                            <ChevronRight className="h-3 w-3 ml-1" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <RegisterForm />
                </TabsContent>
                
                <TabsContent value="check-status" className="mt-0 space-y-4">
                  <div className="space-y-2 mb-4">
                    <h3 className="text-xl font-semibold text-gray-900">Application Status</h3>
                    <p className="text-sm text-gray-600">
                      Check the progress of your account application
                    </p>
                  </div>
                  
                  <form className="space-y-4" onSubmit={(e) => {
                    e.preventDefault();
                    const input = document.getElementById('checkStatusNumber') as HTMLInputElement;
                    const appNumber = input.value.trim();
                    if (appNumber) {
                      setStatusLoading(true);
                      // Increment the key to force re-render
                      setStatusComponentKey(prev => prev + 1);
                      
                      // Add timestamp to prevent caching
                      const timestamp = new Date().getTime();
                      fetch(`/api/account-applications/status/${appNumber}?t=${timestamp}`)
                        .then(res => res.json())
                        .then(data => {
                          // Create new object reference to ensure React updates
                          setStatusResult({...data});
                          setStatusError(null);
                        })
                        .catch(err => {
                          console.error("Error checking application status:", err);
                          setStatusError("Application not found or an error occurred");
                          setStatusResult(null);
                        })
                        .finally(() => {
                          setStatusLoading(false);
                        });
                    }
                  }}>
                    <div>
                      <div className="mb-2">
                        <label htmlFor="checkStatusNumber" className="text-sm font-medium text-gray-700">
                          Application Number
                        </label>
                        <p className="text-xs text-gray-500 mb-1">
                          Enter the application number you received when you applied
                        </p>
                      </div>
                      <div className="flex w-full gap-2">
                        <div className="relative flex-1">
                          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                            <Search className="h-4 w-4" />
                          </div>
                          <input 
                            id="checkStatusNumber"
                            placeholder="e.g. APP-123456-789" 
                            className="w-full h-10 px-3 pl-10 py-2 text-sm border border-gray-200 rounded-md focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none bg-gray-50 focus:bg-white" 
                          />
                        </div>
                        <Button 
                          type="submit" 
                          className="bg-primary hover:bg-primary-dark"
                          disabled={statusLoading}
                        >
                          {statusLoading ? (
                            <>
                              <span className="mr-2">Checking</span>
                              <span className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full" />
                            </>
                          ) : "Check Status"}
                        </Button>
                      </div>
                    </div>
                    
                    {statusError && (
                      <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-md text-red-800 text-sm">
                        {statusError}
                      </div>
                    )}
                    
                    {statusResult && (
                      <div className="mt-4 p-4 bg-gray-50 border border-gray-200 rounded-md relative overflow-hidden">
                        {/* Auto-refresh indicator */}
                        <div className="absolute top-3 right-3 text-xs bg-primary/5 p-1 px-2 rounded-full text-primary flex items-center border border-primary/10">
                          <RefreshCw className="h-3 w-3 mr-1 animate-spin" />
                          <span>Auto-refreshes every 15s</span>
                        </div>
                        
                        <h4 className="font-medium text-gray-800 mb-2">Application Status</h4>
                        <div className="space-y-3">
                          <div>
                            <span className="text-sm text-gray-600">Application #:</span>
                            <div className="mt-1 flex items-center gap-2">
                              <div className="bg-primary/5 px-3 py-2 rounded border border-primary/10">
                                <code className="font-medium text-primary">{statusResult.applicationNumber}</code>
                              </div>
                              <Button 
                                type="button" 
                                variant="ghost" 
                                size="sm"
                                className="h-8 px-2 text-gray-500 hover:text-primary"
                                onClick={() => {
                                  navigator.clipboard.writeText(statusResult.applicationNumber);
                                  toast({
                                    title: "Copied",
                                    description: "Application number copied to clipboard",
                                  });
                                }}
                              >
                                <Copy className="h-4 w-4 mr-1" />
                                Copy
                              </Button>
                            </div>
                          </div>
                          
                          <div>
                            <span className="text-sm text-gray-600">Status:</span>
                            <div className="mt-1">
                              <div className="flex items-center space-x-2">
                            {statusResult.status === 'pending_review' && (
                              <span key={statusComponentKey} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800 animate-pulse">
                                <Clock className="w-3 h-3 mr-1" />
                                Pending Review
                              </span>
                            )}
                            {statusResult.status === 'in_review' && (
                              <span key={statusComponentKey} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800 animate-pulse">
                                <Clock className="w-3 h-3 mr-1" />
                                In Review
                              </span>
                            )}
                            {statusResult.status === 'approved' && (
                              <span key={statusComponentKey} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                <CheckCircle className="w-3 h-3 mr-1" />
                                Approved
                              </span>
                            )}
                            {statusResult.status === 'denied' && (
                              <span key={statusComponentKey} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                <X className="w-3 h-3 mr-1" />
                                Denied
                              </span>
                            )}
                            {statusResult.status === 'additional_info' && (
                              <span key={statusComponentKey} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800 animate-pulse">
                                <AlertTriangle className="w-3 h-3 mr-1" />
                                Info Required
                              </span>
                            )}
                            
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              className="h-7 ml-2 text-xs"
                              onClick={() => {
                                setStatusLoading(true);
                                setStatusComponentKey(prev => prev + 1);
                                const timestamp = new Date().getTime();
                                fetch(`/api/account-applications/status/${statusResult.applicationNumber}?t=${timestamp}`)
                                  .then(res => res.json())
                                  .then(data => {
                                    setStatusResult({...data});
                                    setStatusError(null);
                                    toast({
                                      title: "Status Updated",
                                      description: "Latest application status loaded",
                                    });
                                  })
                                  .catch(err => {
                                    console.error("Error refreshing status:", err);
                                    setStatusError("Could not refresh application status");
                                  })
                                  .finally(() => {
                                    setStatusLoading(false);
                                  });
                              }}
                            >
                              <RefreshCw className={`h-3 w-3 mr-1 ${statusLoading ? "animate-spin" : ""}`} />
                              Refresh Now
                            </Button>
                          </div>
                            </div>
                          </div>
                          
                          {/* Status message and next steps */}
                          {statusResult.statusMessage && (
                            <div className="bg-white p-3 rounded-md border border-gray-200 mt-2">
                              <p className="text-sm">{statusResult.statusMessage}</p>
                              {statusResult.nextSteps && (
                                <p className="text-xs text-gray-600 mt-1">{statusResult.nextSteps}</p>
                              )}
                            </div>
                          )}
                          
                          <div>
                            <span className="text-sm text-gray-600">Submitted:</span>
                            <p className="mt-1 font-medium">{new Date(statusResult.submittedAt).toLocaleDateString()}</p>
                          </div>
                          
                          {/* Last updated date if different from submission date */}
                          {statusResult.lastUpdatedAt && new Date(statusResult.lastUpdatedAt).getTime() > new Date(statusResult.submittedAt).getTime() && (
                            <div>
                              <span className="text-sm text-gray-600">Last Updated:</span>
                              <p className="mt-1 font-medium">
                                {new Date(statusResult.lastUpdatedAt).toLocaleDateString()} at {new Date(statusResult.lastUpdatedAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                              </p>
                            </div>
                          )}
                          
                          {statusResult.status === 'denied' && statusResult.reasonForDenial && (
                            <div className="pt-3 mt-3 border-t border-gray-200">
                              <span className="text-sm text-gray-600">Reason for denial:</span>
                              <p className="mt-1 text-sm text-red-700 p-2 bg-red-50 rounded">{statusResult.reasonForDenial}</p>
                            </div>
                          )}
                          
                          {statusResult.status === 'approved' && (
                            <div className="pt-3 mt-3 border-t border-gray-200">
                              <div className="bg-green-50 p-3 rounded border border-green-100">
                                <p className="text-sm text-green-800">
                                  <CheckCircle className="inline-flex h-4 w-4 mr-1" />
                                  Your application has been approved. You can now create your login credentials.
                                </p>
                                <div className="mt-2">
                                  <Button
                                    onClick={() => setActiveTab("register")}
                                    size="sm"
                                    className="bg-green-600 hover:bg-green-700 text-white"
                                  >
                                    Create Login Now
                                  </Button>
                                </div>
                              </div>
                            </div>
                          )}
                          
                          {/* Action buttons based on status */}
                          <div className="pt-3 mt-3 border-t border-gray-200 flex flex-wrap gap-2">
                            {statusResult.status === 'denied' && statusResult.canSubmitNew && (
                              <Button 
                                className="flex-1"
                                variant="default" 
                                onClick={() => setActiveTab("apply")}
                              >
                                Submit New Application
                              </Button>
                            )}
                            
                            <Button 
                              variant="outline" 
                              className="flex-1"
                              onClick={() => {
                                const input = document.getElementById('checkStatusNumber') as HTMLInputElement;
                                if (input && input.value) {
                                  // Force clear cache and fetch fresh data with a cache-busting timestamp
                                  setStatusLoading(true);
                                  setStatusComponentKey(prev => prev + 1);
                                  
                                  // Add a timestamp to avoid caching
                                  const timestamp = new Date().getTime();
                                  fetch(`/api/account-applications/status/${input.value.trim()}?t=${timestamp}`)
                                    .then(res => res.json())
                                    .then(data => {
                                      // Force new reference to ensure React detects the change
                                      setStatusResult({...data});
                                      setStatusError(null);
                                      
                                      // Display a toast notification about refreshed data
                                      toast({
                                        title: "Status Updated",
                                        description: "Application status has been refreshed",
                                      });
                                    })
                                    .catch(err => {
                                      console.error("Error refreshing application status:", err);
                                      setStatusError("Could not refresh application status");
                                    })
                                    .finally(() => {
                                      setStatusLoading(false);
                                    });
                                }
                              }}
                            >
                              <CheckCheck className="h-4 w-4 mr-1" />
                              Refresh Status
                            </Button>
                          </div>
                        </div>
                      </div>
                    )}
                  </form>
                </TabsContent>
              </div>
            </Card>
          </Tabs>
          
          <div className="w-full flex flex-col space-y-4 mt-6 bg-gray-50 p-4 rounded-lg border border-gray-200">
            <div className="flex items-center">
              <div className="bg-green-100 p-2 rounded-full mr-3">
                <Shield className="h-5 w-5 text-green-600" />
              </div>
              <div className="text-sm text-gray-700">
                <span className="font-semibold">Secure Banking:</span> 256-bit encryption with multi-factor authentication
              </div>
            </div>
            <div className="flex items-center">
              <div className="bg-blue-100 p-2 rounded-full mr-3">
                <Clock className="h-5 w-5 text-blue-600" />
              </div>
              <div className="text-sm text-gray-700">
                <span className="font-semibold">24/7 Access:</span> Manage your finances anytime, anywhere
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right Section - Marketing Content */}
      <div className="hidden lg:flex flex-1 bg-gradient-to-br from-primary to-primary-foreground text-white relative overflow-hidden">
        {/* Decorative circles */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -mt-20 -mr-20"></div>
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-white/5 rounded-full -mb-40 -ml-40"></div>
        
        <div className="relative flex flex-col max-w-xl mx-auto px-10 py-20 justify-center h-full">
          <div className="absolute top-8 right-8 text-right">
            <div className="text-xl font-semibold">{formattedTime}</div>
            <div className="text-sm opacity-80">{formattedDate}</div>
          </div>
          
          <h2 className="text-4xl font-bold mb-6">
            Banking Excellence <br />for Your Financial Journey
          </h2>
          <p className="text-lg mb-10 text-primary-foreground/90">
            Experience premium banking services designed to help you achieve your financial goals with confidence and security.
          </p>

          <div className="space-y-8">
            <div className="flex items-start space-x-4">
              <div className="mt-1 bg-white/10 p-3 rounded-lg">
                <LockKeyhole className="h-6 w-6" />
              </div>
              <div>
                <h3 className="font-semibold text-xl flex items-center">
                  Enhanced Security
                  <ChevronRight className="ml-2 h-5 w-5 opacity-70" />
                </h3>
                <p className="text-primary-foreground/80 mt-1">
                  State-of-the-art encryption and multi-factor authentication to
                  keep your accounts safe.
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="mt-1 bg-white/10 p-3 rounded-lg">
                <TrendingUp className="h-6 w-6" />
              </div>
              <div>
                <h3 className="font-semibold text-xl flex items-center">
                  Wealth Management
                  <ChevronRight className="ml-2 h-5 w-5 opacity-70" />
                </h3>
                <p className="text-primary-foreground/80 mt-1">
                  Expert financial advisors and powerful tools to help your money grow and build wealth for the future.
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="mt-1 bg-white/10 p-3 rounded-lg">
                <CreditCard className="h-6 w-6" />
              </div>
              <div>
                <h3 className="font-semibold text-xl flex items-center">
                  Premium Cards
                  <ChevronRight className="ml-2 h-5 w-5 opacity-70" />
                </h3>
                <p className="text-primary-foreground/80 mt-1">
                  Exclusive credit and debit cards with rewards, travel benefits, and comprehensive fraud protection.
                </p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4">
              <div className="mt-1 bg-white/10 p-3 rounded-lg">
                <Smartphone className="h-6 w-6" />
              </div>
              <div>
                <h3 className="font-semibold text-xl flex items-center">
                  Mobile Banking
                  <ChevronRight className="ml-2 h-5 w-5 opacity-70" />
                </h3>
                <p className="text-primary-foreground/80 mt-1">
                  Manage all your finances on the go with our award-winning banking app and digital services.
                </p>
              </div>
            </div>
          </div>

          <div className="mt-12">
            <Button
              variant="outline"
              size="lg"
              className="border-2 border-white text-white hover:bg-white hover:text-primary px-6 py-6 h-auto text-lg font-medium rounded-lg"
              onClick={() => setActiveTab("apply")}
            >
              Apply for an Account
              <ChevronRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
          
          <div className="absolute bottom-8 left-10 text-sm flex items-center opacity-70">
            <Shield className="h-4 w-4 mr-2" />
            <span>FDIC Insured • Members protected up to $250,000</span>
          </div>
        </div>
      </div>
    </div>
  );
}