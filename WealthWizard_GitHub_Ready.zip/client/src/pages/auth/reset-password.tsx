import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, AlertCircle, CheckCircle, Lock } from 'lucide-react';
import { FortisLogo } from '@/components/ui/fortis-logo';

const resetPasswordSchema = z.object({
  password: z.string().min(8, { message: 'Password must be at least 8 characters' })
    .regex(/[A-Z]/, { message: 'Password must contain at least one uppercase letter' })
    .regex(/[a-z]/, { message: 'Password must contain at least one lowercase letter' })
    .regex(/[0-9]/, { message: 'Password must contain at least one number' })
    .regex(/[^A-Za-z0-9]/, { message: 'Password must contain at least one special character' }),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

type ResetPasswordFormValues = z.infer<typeof resetPasswordSchema>;

export default function ResetPassword() {
  const { toast } = useToast();
  const [location, setLocation] = useLocation();
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Get token from URL query parameter
  const params = new URLSearchParams(window.location.search);
  const token = params.get('token');
  
  const form = useForm<ResetPasswordFormValues>({
    resolver: zodResolver(resetPasswordSchema),
    defaultValues: {
      password: '',
      confirmPassword: '',
    },
  });

  async function onSubmit(values: ResetPasswordFormValues) {
    if (!token) {
      setError('Invalid or expired password reset token. Please try again.');
      return;
    }
    
    setIsLoading(true);
    setError(null);
    
    try {
      // Make API call to reset password endpoint
      await apiRequest('POST', '/api/auth/reset-password', {
        token,
        password: values.password,
      });
      
      setIsSubmitted(true);
      
      // Show success toast
      toast({
        title: 'Password reset complete',
        description: 'Your password has been successfully reset. You can now log in with your new password.',
        variant: 'default',
      });
    } catch (err: any) {
      setError(err.message || 'An error occurred. Please try again.');
      toast({
        title: 'Error',
        description: 'Failed to reset your password. The link may have expired or is invalid.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  }

  // If no token is provided, show an error
  if (!token && !isSubmitted) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center p-4 md:p-8">
        <div className="w-full max-w-md space-y-6">
          <div className="text-center">
            <div className="flex justify-center mb-4">
              <FortisLogo width={70} height={70} className="text-primary" />
            </div>
            <h1 className="text-3xl font-bold tracking-tight text-primary mb-2">Invalid Reset Link</h1>
            <p className="text-muted-foreground mb-6">
              The password reset link is invalid or has expired. Please request a new password reset.
            </p>
          </div>
          
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              This password reset link is invalid or has expired. Please request a new one.
            </AlertDescription>
          </Alert>
          
          <div className="flex flex-col space-y-2 text-center mt-6">
            <Link href="/forgot-password">
              <a className="text-primary hover:underline">
                Request a new password reset
              </a>
            </Link>
            <Link href="/login">
              <a className="text-primary hover:underline">
                Return to login
              </a>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center p-4 md:p-8">
      <div className="w-full max-w-md space-y-6">
        <div className="text-center">
          <div className="flex justify-center mb-4">
            <FortisLogo width={70} height={70} className="text-primary" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-primary mb-2">Fortis Capital</h1>
          <p className="text-muted-foreground mb-6">
            Please create a new password for your account.
          </p>
        </div>

        {isSubmitted ? (
          <div className="space-y-6">
            <Alert className="bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-800">
              <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
              <AlertDescription className="text-green-700 dark:text-green-400">
                Your password has been successfully reset. You can now log in with your new password.
              </AlertDescription>
            </Alert>
            <div className="flex flex-col space-y-2 text-center">
              <Link href="/login">
                <a className="text-primary hover:underline">Return to login</a>
              </Link>
            </div>
          </div>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>New Password</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Lock className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                        <Input
                          type="password"
                          placeholder="Enter your new password"
                          className="pl-10"
                          {...field}
                        />
                      </div>
                    </FormControl>
                    <FormDescription className="text-xs">
                      Password must be at least 8 characters and include uppercase, lowercase, number, and special character.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="confirmPassword"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Confirm Password</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Lock className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                        <Input
                          type="password"
                          placeholder="Confirm your new password"
                          className="pl-10"
                          {...field}
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button
                type="submit"
                className="w-full py-6 text-base"
                disabled={isLoading}
              >
                {isLoading ? (
                  <span className="flex items-center justify-center">
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Resetting password...
                  </span>
                ) : (
                  "Reset Password"
                )}
              </Button>

              <div className="flex flex-col space-y-2 text-center">
                <p className="text-sm text-muted-foreground">
                  Remembered your password?
                </p>
                <Link href="/login">
                  <a className="text-primary hover:underline font-medium">
                    Back to login
                  </a>
                </Link>
              </div>
            </form>
          </Form>
        )}
      </div>
    </div>
  );
}