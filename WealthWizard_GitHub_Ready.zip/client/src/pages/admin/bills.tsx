import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Search, 
  FilterList, 
  Visibility, 
  Schedule,
  Receipt,
  Description
} from "@mui/icons-material";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { formatCurrency, formatDate } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Check, 
  X, 
  PieChart, 
  Shield, 
  Menu, 
  FileText, 
  DollarSign, 
  Users 
} from "lucide-react";

interface Bill {
  id: number;
  payee: string;
  accountNumber: string;
  amount: string;
  dueDate: string;
  status: string;
  isRecurring: boolean;
  frequency: string | null;
  category: string | null;
  user: {
    id: number;
    name: string;
  };
}

export default function AdminBills() {
  const [location] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'paid' | 'cancelled' | 'processing'>('all');
  const [selectedBill, setSelectedBill] = useState<Bill | null>(null);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch bills
  const { data: bills = [], isLoading } = useQuery<Bill[]>({
    queryKey: ["/api/admin/bills"],
  });
  
  // Approve bill mutation
  const approveMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest("POST", `/api/admin/bills/${id}/approve`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/bills"] });
      toast({
        title: "Bill payment approved",
        description: "The bill payment is now being processed.",
      });
      setIsDetailsOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: "Approval failed",
        description: error.message || "There was an error approving the bill payment.",
        variant: "destructive",
      });
    }
  });
  
  // Cancel bill mutation
  const cancelMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest("POST", `/api/admin/bills/${id}/cancel`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/bills"] });
      toast({
        title: "Bill payment cancelled",
        description: "The bill payment has been cancelled.",
      });
      setIsDetailsOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: "Cancellation failed",
        description: error.message || "There was an error cancelling the bill payment.",
        variant: "destructive",
      });
    }
  });
  
  const handleApproveBill = (id: number) => {
    approveMutation.mutate(id);
  };
  
  const handleCancelBill = (id: number) => {
    cancelMutation.mutate(id);
  };
  
  // Filter bills based on search query and status filter
  const filteredBills = bills.filter(bill => {
    const matchesSearch = 
      searchQuery === "" || 
      bill.payee.toLowerCase().includes(searchQuery.toLowerCase()) ||
      bill.accountNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      bill.user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (bill.category && bill.category.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesStatus = 
      statusFilter === 'all' || 
      bill.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });
  
  const viewDetails = (bill: Bill) => {
    setSelectedBill(bill);
    setIsDetailsOpen(true);
  };
  
  // Generate status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "paid":
        return (
          <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
            Paid
          </Badge>
        );
      case "pending":
        return (
          <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
            Pending
          </Badge>
        );
      case "processing":
        return (
          <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">
            Processing
          </Badge>
        );
      case "cancelled":
        return (
          <Badge className="bg-red-100 text-red-800 hover:bg-red-100">
            Cancelled
          </Badge>
        );
      default:
        return (
          <Badge variant="outline">
            {status}
          </Badge>
        );
    }
  };
  
  // Get category badge with icon
  const getCategoryBadge = (category: string | null) => {
    if (!category) return 'Uncategorized';
    
    return (
      <div className="flex items-center gap-1">
        <Receipt className="h-4 w-4 text-neutral-600" />
        <span className="capitalize">{category}</span>
      </div>
    );
  };
  
  // Sidebar state
  const [sidebarOpen, setSidebarOpen] = useState(true);
  
  // Navigation helper function
  const navigateTo = (path: string) => {
    window.location.href = path;
  };
  
  return (
    <div className="flex h-screen bg-amber-50 dark:bg-neutral-900">
      {/* Admin Sidebar */}
      <div className={`${sidebarOpen ? 'w-64' : 'w-20'} bg-amber-900 dark:bg-amber-950 text-white transition-all duration-300 ease-in-out flex flex-col h-full shrink-0`}>
        <div className="flex items-center justify-between p-4 border-b border-amber-700/50">
          <div className={`flex items-center ${!sidebarOpen && 'justify-center w-full'}`}>
            <Shield className="h-8 w-8 text-amber-400" />
            {sidebarOpen && <span className="ml-2 font-semibold text-xl">Admin Portal</span>}
          </div>
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="text-amber-400 hover:text-amber-300">
            {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
        
        <div className="overflow-y-auto flex-grow">
          <div className="px-4 py-4">
            {sidebarOpen && <p className="text-xs font-semibold text-amber-500 uppercase tracking-wider mb-2">Main</p>}
            <nav className="space-y-1">
              <div 
                onClick={() => navigateTo("/admin/dashboard")}
                className={`flex items-center ${!sidebarOpen ? 'justify-center' : ''} py-2.5 px-2 rounded-md text-amber-300 hover:bg-amber-800/60 transition-colors duration-200 cursor-pointer`}
              >
                <PieChart className="h-5 w-5" />
                {sidebarOpen && <span className="ml-3">Dashboard</span>}
              </div>
              <div 
                onClick={() => navigateTo("/admin/users")}
                className={`flex items-center ${!sidebarOpen ? 'justify-center' : ''} py-2.5 px-2 rounded-md text-amber-300 hover:bg-amber-800/60 transition-colors duration-200 cursor-pointer`}
              >
                <Users className="h-5 w-5" />
                {sidebarOpen && <span className="ml-3">Users</span>}
              </div>
              <div 
                onClick={() => navigateTo("/admin/transactions")}
                className={`flex items-center ${!sidebarOpen ? 'justify-center' : ''} py-2.5 px-2 rounded-md text-amber-300 hover:bg-amber-800/60 transition-colors duration-200 cursor-pointer`}
              >
                <DollarSign className="h-5 w-5" />
                {sidebarOpen && <span className="ml-3">Transactions</span>}
              </div>
              <div 
                onClick={() => navigateTo("/admin/bills")}
                className={`flex items-center ${!sidebarOpen ? 'justify-center' : ''} py-2.5 px-2 rounded-md bg-amber-800 text-amber-300 transition-colors duration-200 cursor-pointer`}
              >
                <Receipt className="h-5 w-5" />
                {sidebarOpen && <span className="ml-3">Bill Payments</span>}
              </div>
              <div 
                onClick={() => navigateTo("/admin/kyc")}
                className={`flex items-center ${!sidebarOpen ? 'justify-center' : ''} py-2.5 px-2 rounded-md text-amber-300 hover:bg-amber-800/60 transition-colors duration-200 cursor-pointer`}
              >
                <FileText className="h-5 w-5" />
                {sidebarOpen && <span className="ml-3">KYC Verifications</span>}
              </div>
            </nav>
          </div>
        </div>
      </div>
      
      <div className="flex-1 flex flex-col overflow-hidden">
        
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-neutral-100 dark:bg-neutral-800">
          <div className="container mx-auto px-6 py-8">
            <h1 className="text-3xl font-semibold text-neutral-800 dark:text-white mb-6">Bill Payment Management</h1>
            
            <Card className="mb-8">
              <CardHeader className="pb-2">
                <CardTitle>Bill Payments</CardTitle>
                <CardDescription>Review and manage customer bill payments</CardDescription>
              </CardHeader>
              
              <CardContent>
                <div className="flex flex-col md:flex-row justify-between mb-6 gap-4">
                  <div className="relative w-full md:w-96">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <Input 
                      placeholder="Search bills..." 
                      className="pl-10"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  
                  <div className="flex gap-4">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="outline" className="flex items-center gap-2">
                          <FilterList className="h-4 w-4" />
                          Status
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent>
                        <DropdownMenuLabel>Filter by Status</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => setStatusFilter('all')}>
                          All Statuses
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setStatusFilter('pending')}>
                          Pending
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setStatusFilter('processing')}>
                          Processing
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setStatusFilter('paid')}>
                          Paid
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setStatusFilter('cancelled')}>
                          Cancelled
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
                
                {isLoading ? (
                  <div className="flex justify-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                  </div>
                ) : filteredBills.length === 0 ? (
                  <div className="text-center py-8 text-neutral-500 dark:text-neutral-400">
                    <div className="w-16 h-16 rounded-full bg-neutral-100 dark:bg-neutral-800 mx-auto flex items-center justify-center mb-4">
                      <Receipt className="h-8 w-8 text-neutral-500 dark:text-neutral-400" />
                    </div>
                    <p className="mb-2">No bill payments found</p>
                    <p className="text-sm">Try adjusting your search or filters</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableCaption>List of all customer bill payments</TableCaption>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Payee</TableHead>
                          <TableHead>User</TableHead>
                          <TableHead>Category</TableHead>
                          <TableHead>Amount</TableHead>
                          <TableHead>Due Date</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredBills.map(bill => (
                          <TableRow key={bill.id}>
                            <TableCell className="font-medium">{bill.id}</TableCell>
                            <TableCell>{bill.payee}</TableCell>
                            <TableCell>
                              <div className="flex items-center">
                                <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center mr-2">
                                  {bill.user.name.substring(0, 2).toUpperCase()}
                                </div>
                                <span>{bill.user.name}</span>
                              </div>
                            </TableCell>
                            <TableCell>{getCategoryBadge(bill.category)}</TableCell>
                            <TableCell className="font-medium">
                              {formatCurrency(parseFloat(bill.amount))}
                            </TableCell>
                            <TableCell>{formatDate(bill.dueDate)}</TableCell>
                            <TableCell>{getStatusBadge(bill.status)}</TableCell>
                            <TableCell className="text-right space-x-1">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => viewDetails(bill)}
                                className="flex items-center"
                              >
                                <Visibility className="h-4 w-4 mr-1" />
                                View
                              </Button>
                              
                              {bill.status === "pending" && (
                                <>
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    className="text-green-600 hover:text-green-800 hover:bg-green-50"
                                    onClick={() => handleApproveBill(bill.id)}
                                    disabled={approveMutation.isPending}
                                  >
                                    <Check className="h-4 w-4 mr-1" />
                                    Approve
                                  </Button>
                                  
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    className="text-red-600 hover:text-red-800 hover:bg-red-50"
                                    onClick={() => handleCancelBill(bill.id)}
                                    disabled={cancelMutation.isPending}
                                  >
                                    <X className="h-4 w-4 mr-1" />
                                    Cancel
                                  </Button>
                                </>
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
      
      {/* Bill Details Dialog */}
      <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Bill Payment Details</DialogTitle>
            <DialogDescription>
              Review the details of this bill payment.
            </DialogDescription>
          </DialogHeader>
          
          {selectedBill && (
            <div className="space-y-4 my-4 max-h-[40vh] overflow-y-auto pr-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-neutral-500 dark:text-neutral-400">Status</span>
                <div>{getStatusBadge(selectedBill.status)}</div>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="font-semibold text-neutral-500 dark:text-neutral-400">Payee</span>
                <span className="font-medium">{selectedBill.payee}</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="font-semibold text-neutral-500 dark:text-neutral-400">Amount</span>
                <span className="font-medium">{formatCurrency(parseFloat(selectedBill.amount))}</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="font-semibold text-neutral-500 dark:text-neutral-400">Account Number</span>
                <span>{selectedBill.accountNumber}</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="font-semibold text-neutral-500 dark:text-neutral-400">Due Date</span>
                <span>{formatDate(selectedBill.dueDate)}</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="font-semibold text-neutral-500 dark:text-neutral-400">Category</span>
                <span>{selectedBill.category || 'Uncategorized'}</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="font-semibold text-neutral-500 dark:text-neutral-400">Customer</span>
                <span>{selectedBill.user.name}</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="font-semibold text-neutral-500 dark:text-neutral-400">Recurring</span>
                <span>{selectedBill.isRecurring ? `Yes (${selectedBill.frequency})` : 'No'}</span>
              </div>
            </div>
          )}
          
          <DialogFooter className="flex flex-col sm:flex-row gap-2 sm:gap-0">
            {selectedBill && selectedBill.status === "pending" && (
              <>
                <Button
                  type="button"
                  variant="outline"
                  className="text-red-600 hover:text-red-800 hover:bg-red-50 border-red-200"
                  onClick={() => handleCancelBill(selectedBill.id)}
                  disabled={cancelMutation.isPending}
                >
                  <X className="h-4 w-4 mr-2" />
                  Cancel Bill Payment
                </Button>
                <Button
                  type="button"
                  className="bg-green-600 hover:bg-green-700 text-white"
                  onClick={() => handleApproveBill(selectedBill.id)}
                  disabled={approveMutation.isPending}
                >
                  <Check className="h-4 w-4 mr-2" />
                  Approve Payment
                </Button>
              </>
            )}
            
            {selectedBill && selectedBill.status !== "pending" && (
              <>
                <Button 
                  type="button"
                  variant="ghost"
                  onClick={() => setIsDetailsOpen(false)}
                >
                  Close
                </Button>
                <Button 
                  type="button"
                  variant="default"
                  onClick={() => {
                    setIsDetailsOpen(false);
                    // Navigate to user profile page since bills might not always have an account ID
                    window.location.href = `/admin/users/${selectedBill.user.id}`;
                  }}
                >
                  <Visibility className="h-4 w-4 mr-2" />
                  View Customer
                </Button>
              </>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}