import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Search, 
  FilterList, 
  Visibility, 
  ImportExport, 
  ArrowUpward, 
  ArrowDownward, 
  Sync
} from "@mui/icons-material";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { formatCurrency, formatDate } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Check, X } from "lucide-react";

interface Transaction {
  id: number;
  referenceNumber: string;
  user: {
    id: number;
    firstName: string;
    lastName: string;
  };
  type: string;
  amount: string;
  date: string;
  status: string;
  description: string;
  category: string;
  merchantName: string | null;
  accountId: number;
  toAccountId: number | null;
}

export default function AdminTransactions() {
  const [location] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState<'all' | 'deposit' | 'withdrawal' | 'transfer'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'completed' | 'pending' | 'failed'>('all');
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch transactions
  const { data: transactions = [], isLoading } = useQuery<Transaction[]>({
    queryKey: ["/api/admin/transactions"],
  });
  
  // Approve transaction mutation
  const approveMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest("POST", `/api/admin/transactions/${id}/approve`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/transactions"] });
      toast({
        title: "Transaction approved",
        description: "The transaction is now being processed.",
      });
      setIsDetailsOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: "Approval failed",
        description: error.message || "There was an error approving the transaction.",
        variant: "destructive",
      });
    }
  });
  
  // Cancel transaction mutation
  const cancelMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest("POST", `/api/admin/transactions/${id}/cancel`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/transactions"] });
      toast({
        title: "Transaction cancelled",
        description: "The transaction has been cancelled.",
      });
      setIsDetailsOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: "Cancellation failed",
        description: error.message || "There was an error cancelling the transaction.",
        variant: "destructive",
      });
    }
  });
  
  const handleApproveTransaction = (id: number) => {
    approveMutation.mutate(id);
  };
  
  const handleCancelTransaction = (id: number) => {
    cancelMutation.mutate(id);
  };
  
  // Filter transactions based on search query and filters
  const filteredTransactions = transactions.filter(transaction => {
    const matchesSearch = 
      searchQuery === "" || 
      transaction.referenceNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      transaction.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      `${transaction.user.firstName} ${transaction.user.lastName}`.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (transaction.merchantName && transaction.merchantName.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesType = 
      typeFilter === 'all' || 
      (typeFilter === 'deposit' && transaction.type === 'deposit') || 
      (typeFilter === 'withdrawal' && transaction.type === 'withdrawal') ||
      (typeFilter === 'transfer' && transaction.type === 'transfer');
    
    const matchesStatus = 
      statusFilter === 'all' || 
      (statusFilter === 'completed' && transaction.status === 'completed') || 
      (statusFilter === 'pending' && transaction.status === 'pending') ||
      (statusFilter === 'failed' && transaction.status === 'failed');
    
    return matchesSearch && matchesType && matchesStatus;
  });
  
  const viewDetails = (transaction: Transaction) => {
    setSelectedTransaction(transaction);
    setIsDetailsOpen(true);
  };
  
  // Generate transaction type badge
  const getTypeBadge = (type: string) => {
    switch (type) {
      case "deposit":
        return (
          <div className="flex items-center gap-1">
            <ArrowDownward className="h-4 w-4 text-green-600" />
            <span className="capitalize">Deposit</span>
          </div>
        );
      case "withdrawal":
        return (
          <div className="flex items-center gap-1">
            <ArrowUpward className="h-4 w-4 text-red-600" />
            <span className="capitalize">Withdrawal</span>
          </div>
        );
      case "transfer":
        return (
          <div className="flex items-center gap-1">
            <ImportExport className="h-4 w-4 text-blue-600" />
            <span className="capitalize">Transfer</span>
          </div>
        );
      default:
        return (
          <div className="flex items-center gap-1">
            <Sync className="h-4 w-4 text-neutral-600" />
            <span className="capitalize">{type}</span>
          </div>
        );
    }
  };
  
  // Generate status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return (
          <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
            Completed
          </Badge>
        );
      case "pending":
        return (
          <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
            Pending
          </Badge>
        );
      case "failed":
        return (
          <Badge className="bg-red-100 text-red-800 hover:bg-red-100">
            Failed
          </Badge>
        );
      default:
        return (
          <Badge variant="outline">
            {status}
          </Badge>
        );
    }
  };
  
  return (
    <div className="flex h-screen bg-neutral-50 dark:bg-neutral-900">
      {/* Sidebar component would be here */}
      
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header component would be here */}
        
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-neutral-100 dark:bg-neutral-800">
          <div className="container mx-auto px-6 py-8">
            <h1 className="text-3xl font-semibold text-neutral-800 dark:text-white mb-6">Transaction Monitoring</h1>
            
            <Card className="mb-8">
              <CardHeader className="pb-2">
                <CardTitle>Transactions</CardTitle>
                <CardDescription>Monitor and manage all banking transactions</CardDescription>
              </CardHeader>
              
              <CardContent>
                <div className="flex flex-col md:flex-row justify-between mb-6 gap-4">
                  <div className="relative w-full md:w-96">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <Input 
                      placeholder="Search transactions..." 
                      className="pl-10"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  
                  <div className="flex gap-4">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="outline" className="flex items-center gap-2">
                          <FilterList className="h-4 w-4" />
                          Type
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent>
                        <DropdownMenuLabel>Filter by Type</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => setTypeFilter('all')}>
                          All Types
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setTypeFilter('deposit')}>
                          Deposits
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setTypeFilter('withdrawal')}>
                          Withdrawals
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setTypeFilter('transfer')}>
                          Transfers
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                    
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="outline" className="flex items-center gap-2">
                          <FilterList className="h-4 w-4" />
                          Status
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent>
                        <DropdownMenuLabel>Filter by Status</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => setStatusFilter('all')}>
                          All Statuses
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setStatusFilter('completed')}>
                          Completed
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setStatusFilter('pending')}>
                          Pending
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setStatusFilter('failed')}>
                          Failed
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
                
                {isLoading ? (
                  <div className="flex justify-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                  </div>
                ) : filteredTransactions.length === 0 ? (
                  <div className="text-center py-8 text-neutral-500 dark:text-neutral-400">
                    <div className="w-16 h-16 rounded-full bg-neutral-100 dark:bg-neutral-800 mx-auto flex items-center justify-center mb-4">
                      <ImportExport className="h-8 w-8 text-neutral-500 dark:text-neutral-400" />
                    </div>
                    <p className="mb-2">No transactions found</p>
                    <p className="text-sm">Try adjusting your search or filters</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableCaption>List of all transactions in the system</TableCaption>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Reference</TableHead>
                          <TableHead>User</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Amount</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredTransactions.map(transaction => (
                          <TableRow key={transaction.id}>
                            <TableCell className="font-medium">{transaction.id}</TableCell>
                            <TableCell>{transaction.referenceNumber}</TableCell>
                            <TableCell>
                              <div className="flex items-center">
                                <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center mr-2">
                                  {`${transaction.user.firstName[0]}${transaction.user.lastName[0]}`}
                                </div>
                                <span>{transaction.user.firstName} {transaction.user.lastName}</span>
                              </div>
                            </TableCell>
                            <TableCell>{getTypeBadge(transaction.type)}</TableCell>
                            <TableCell 
                              className={
                                transaction.type === "deposit" 
                                  ? "text-green-600 font-medium" 
                                  : transaction.type === "withdrawal" 
                                    ? "text-red-600 font-medium" 
                                    : "font-medium"
                              }
                            >
                              {transaction.type === "deposit" ? "+" : transaction.type === "withdrawal" ? "-" : ""}
                              {formatCurrency(parseFloat(transaction.amount))}
                            </TableCell>
                            <TableCell>{formatDate(transaction.date)}</TableCell>
                            <TableCell>{getStatusBadge(transaction.status)}</TableCell>
                            <TableCell className="text-right space-x-1">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => viewDetails(transaction)}
                                className="flex items-center"
                              >
                                <Visibility className="h-4 w-4 mr-1" />
                                View
                              </Button>
                              
                              {transaction.status === "pending" && (
                                <>
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    className="text-green-600 hover:text-green-800 hover:bg-green-50"
                                    onClick={() => handleApproveTransaction(transaction.id)}
                                    disabled={approveMutation.isPending}
                                  >
                                    <Check className="h-4 w-4 mr-1" />
                                    Approve
                                  </Button>
                                  
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    className="text-red-600 hover:text-red-800 hover:bg-red-50"
                                    onClick={() => handleCancelTransaction(transaction.id)}
                                    disabled={cancelMutation.isPending}
                                  >
                                    <X className="h-4 w-4 mr-1" />
                                    Cancel
                                  </Button>
                                </>
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
                
                <div className="flex justify-between items-center mt-6">
                  <div className="text-sm text-neutral-500 dark:text-neutral-400">
                    Showing {filteredTransactions.length} of {transactions.length} transactions
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" disabled>Previous</Button>
                    <Button variant="outline" size="sm" disabled>Next</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
      
      {/* Transaction Details Dialog */}
      {selectedTransaction && (
        <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Transaction Details</DialogTitle>
              <DialogDescription>
                Detailed information about transaction #{selectedTransaction.id}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 my-4 max-h-[40vh] overflow-y-auto pr-2">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Reference Number</p>
                  <p className="font-semibold">{selectedTransaction.referenceNumber}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Status</p>
                  <div>{getStatusBadge(selectedTransaction.status)}</div>
                </div>
                <div>
                  <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Type</p>
                  <div>{getTypeBadge(selectedTransaction.type)}</div>
                </div>
                <div>
                  <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Amount</p>
                  <p 
                    className={
                      selectedTransaction.type === "deposit" 
                        ? "text-green-600 font-semibold" 
                        : selectedTransaction.type === "withdrawal" 
                          ? "text-red-600 font-semibold" 
                          : "font-semibold"
                    }
                  >
                    {selectedTransaction.type === "deposit" ? "+" : selectedTransaction.type === "withdrawal" ? "-" : ""}
                    {formatCurrency(parseFloat(selectedTransaction.amount))}
                  </p>
                </div>
                <div>
                  <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Date & Time</p>
                  <p className="font-semibold">{formatDate(selectedTransaction.date)}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Category</p>
                  <p className="font-semibold capitalize">{selectedTransaction.category}</p>
                </div>
              </div>
              
              <div className="border-t border-neutral-200 dark:border-neutral-700 pt-4 mt-4">
                <h3 className="font-semibold mb-3">Account Information</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">User</p>
                    <p className="font-semibold">{selectedTransaction.user.firstName} {selectedTransaction.user.lastName}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">User ID</p>
                    <p className="font-semibold">{selectedTransaction.user.id}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Account ID</p>
                    <p className="font-semibold">{selectedTransaction.accountId}</p>
                  </div>
                  {selectedTransaction.toAccountId && (
                    <div>
                      <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Destination Account ID</p>
                      <p className="font-semibold">{selectedTransaction.toAccountId}</p>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="border-t border-neutral-200 dark:border-neutral-700 pt-4 mt-4">
                <h3 className="font-semibold mb-3">Description</h3>
                <p className="text-neutral-700 dark:text-neutral-300">
                  {selectedTransaction.description}
                </p>
                
                {selectedTransaction.merchantName && (
                  <div className="mt-4">
                    <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400 mb-1">Merchant</p>
                    <p className="text-neutral-700 dark:text-neutral-300">
                      {selectedTransaction.merchantName}
                    </p>
                  </div>
                )}
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDetailsOpen(false)}>
                Close
              </Button>
              
              {selectedTransaction.status === "pending" && (
                <>
                  <Button 
                    variant="outline" 
                    className="border-red-300 hover:bg-red-50 text-red-600"
                    onClick={() => handleCancelTransaction(selectedTransaction.id)}
                    disabled={cancelMutation.isPending}
                  >
                    <X className="h-4 w-4 mr-1" />
                    Cancel Transaction
                  </Button>
                  <Button 
                    className="bg-green-600 hover:bg-green-700 text-white"
                    onClick={() => handleApproveTransaction(selectedTransaction.id)}
                    disabled={approveMutation.isPending}
                  >
                    <Check className="h-4 w-4 mr-1" />
                    Approve Transaction
                  </Button>
                </>
              )}
              
              {selectedTransaction.status !== "pending" && (
                <Button 
                  variant="default"
                  onClick={() => {
                    setIsDetailsOpen(false);
                    window.location.href = `/admin/accounts/${selectedTransaction.accountId}`;
                  }}
                >
                  <Visibility className="h-4 w-4 mr-1" />
                  View Related Account
                </Button>
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}