import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { 
  Search, 
  FilterList, 
  Check, 
  Close, 
  Visibility,
  Person,
  Assignment,
  CreditCard,
  Home,
  Download
} from "@mui/icons-material";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatDate } from "@/lib/utils";
import SecureDocumentViewer from "@/components/secure-document-viewer";
import { getKycDocumentUrl, downloadDocument } from "@/lib/document-utils";

interface KycVerification {
  id: number;
  userId: number;
  userName: string;
  idType: string;
  idNumber: string;
  documentNumber: string;
  documentFront: string;
  documentBack: string;
  selfieImage: string;
  status: string;
  submittedDate: string;
  reviewedDate: string | null;
  rejectionReason: string | null;
}

export default function AdminKyc() {
  const [location] = useLocation();
  const [activeTab, setActiveTab] = useState("pending");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedVerification, setSelectedVerification] = useState<KycVerification | null>(null);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [rejectionReason, setRejectionReason] = useState("");
  const [isRejectDialogOpen, setIsRejectDialogOpen] = useState(false);
  
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Fetch KYC verifications
  const { data: verifications = [], isLoading } = useQuery<KycVerification[]>({
    queryKey: ["/api/admin/kyc-verifications"],
  });
  
  // Filtered verifications based on active tab and search query
  const filteredVerifications = verifications.filter(verification => {
    const matchesTab = 
      (activeTab === "pending" && verification.status === "pending") ||
      (activeTab === "approved" && verification.status === "approved") ||
      (activeTab === "rejected" && verification.status === "rejected") ||
      activeTab === "all";
    
    const matchesSearch = 
      searchQuery === "" || 
      verification.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      verification.documentNumber.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesTab && matchesSearch;
  });
  
  // KYC approval mutation
  const approveKycMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest("PATCH", `/api/admin/kyc-verifications/${id}/approve`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/kyc-verifications"] });
      toast({
        title: "KYC verification approved",
        description: "User verification has been approved successfully.",
      });
      setSelectedVerification(null);
      setIsDetailsOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: "Approval failed",
        description: error.message || "There was an error approving the verification.",
        variant: "destructive",
      });
    }
  });
  
  // KYC rejection mutation
  const rejectKycMutation = useMutation({
    mutationFn: ({ id, reason }: { id: number; reason: string }) => {
      return apiRequest("PATCH", `/api/admin/kyc-verifications/${id}/reject`, { rejectionReason: reason });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/kyc-verifications"] });
      toast({
        title: "KYC verification rejected",
        description: "User verification has been rejected.",
      });
      setSelectedVerification(null);
      setIsDetailsOpen(false);
      setIsRejectDialogOpen(false);
      setRejectionReason("");
    },
    onError: (error: any) => {
      toast({
        title: "Rejection failed",
        description: error.message || "There was an error rejecting the verification.",
        variant: "destructive",
      });
    }
  });
  
  const handleApprove = (id: number) => {
    approveKycMutation.mutate(id);
  };
  
  const handleReject = () => {
    if (!selectedVerification) return;
    
    rejectKycMutation.mutate({
      id: selectedVerification.id,
      reason: rejectionReason
    });
  };
  
  const viewDetails = (verification: KycVerification) => {
    setSelectedVerification(verification);
    setIsDetailsOpen(true);
  };
  
  const openRejectDialog = () => {
    setIsRejectDialogOpen(true);
  };
  
  // Generate status badge based on status
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
            Pending
          </Badge>
        );
      case "approved":
        return (
          <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
            Approved
          </Badge>
        );
      case "rejected":
        return (
          <Badge className="bg-red-100 text-red-800 hover:bg-red-100">
            Rejected
          </Badge>
        );
      default:
        return null;
    }
  };
  
  // Get icon for ID type
  const getIdTypeIcon = (idType: string) => {
    switch (idType.toLowerCase()) {
      case "passport":
        return <Assignment />;
      case "driver_license":
        return <CreditCard />;
      case "national_id":
        return <CreditCard />;
      case "utility_bill":
        return <Home />;
      default:
        return <Assignment />;
    }
  };
  
  return (
    <div className="flex h-screen bg-neutral-50 dark:bg-neutral-900">
      {/* Sidebar component would be here */}
      
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header component would be here */}
        
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-neutral-100 dark:bg-neutral-800">
          <div className="container mx-auto px-6 py-8">
            <h1 className="text-3xl font-semibold text-neutral-800 dark:text-white mb-6">KYC Verification</h1>
            
            <Card className="mb-8">
              <CardHeader className="pb-0">
                <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
                  <div>
                    <CardTitle>Verification Requests</CardTitle>
                    <CardDescription>Review and approve user identity verification</CardDescription>
                  </div>
                  <div className="relative w-full md:w-64">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <Input 
                      placeholder="Search requests..." 
                      className="pl-10"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
                <Tabs defaultValue={activeTab} value={activeTab} onValueChange={setActiveTab} className="mt-6">
                  <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="pending">Pending</TabsTrigger>
                    <TabsTrigger value="approved">Approved</TabsTrigger>
                    <TabsTrigger value="rejected">Rejected</TabsTrigger>
                    <TabsTrigger value="all">All</TabsTrigger>
                  </TabsList>
                </Tabs>
              </CardHeader>
              
              <CardContent className="pt-6">
                {isLoading ? (
                  <div className="flex justify-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                  </div>
                ) : filteredVerifications.length === 0 ? (
                  <div className="text-center py-8 text-neutral-500 dark:text-neutral-400">
                    <div className="w-16 h-16 rounded-full bg-neutral-100 dark:bg-neutral-800 mx-auto flex items-center justify-center mb-4">
                      <Person className="h-8 w-8 text-neutral-500 dark:text-neutral-400" />
                    </div>
                    <p className="mb-2">No verification requests found</p>
                    <p className="text-sm">Try adjusting your search or filters</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableCaption>List of KYC verification requests</TableCaption>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>User</TableHead>
                          <TableHead>ID Type</TableHead>
                          <TableHead>Submitted Date</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredVerifications.map(verification => (
                          <TableRow key={verification.id}>
                            <TableCell className="font-medium">{verification.id}</TableCell>
                            <TableCell>
                              <div className="flex items-center">
                                <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center mr-2">
                                  {verification.userName.split(' ').map(n => n[0]).join('')}
                                </div>
                                <span>{verification.userName}</span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center">
                                <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center mr-2">
                                  {getIdTypeIcon(verification.idType)}
                                </div>
                                <span>{verification.idType.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}</span>
                              </div>
                            </TableCell>
                            <TableCell>{formatDate(verification.submittedDate)}</TableCell>
                            <TableCell>{getStatusBadge(verification.status)}</TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-2">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => viewDetails(verification)}
                                  className="flex items-center"
                                >
                                  <Visibility className="h-4 w-4 mr-1" />
                                  View
                                </Button>
                                
                                {verification.status === "pending" && (
                                  <>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => handleApprove(verification.id)}
                                      className="flex items-center text-green-600"
                                      disabled={approveKycMutation.isPending}
                                    >
                                      <Check className="h-4 w-4 mr-1" />
                                      Approve
                                    </Button>
                                    
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => {
                                        setSelectedVerification(verification);
                                        openRejectDialog();
                                      }}
                                      className="flex items-center text-red-600"
                                      disabled={rejectKycMutation.isPending}
                                    >
                                      <Close className="h-4 w-4 mr-1" />
                                      Reject
                                    </Button>
                                  </>
                                )}
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
      
      {/* KYC Verification Details Dialog */}
      {selectedVerification && (
        <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
          <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Verification Details</DialogTitle>
              <DialogDescription>
                Review user's identity verification documents
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 my-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">User</p>
                  <p className="font-semibold">{selectedVerification.userName}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">User ID</p>
                  <p className="font-semibold">{selectedVerification.userId}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">ID Type</p>
                  <p className="font-semibold">{selectedVerification.idType.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Document Number</p>
                  <p className="font-semibold">{selectedVerification.documentNumber}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Submitted Date</p>
                  <p className="font-semibold">{formatDate(selectedVerification.submittedDate)}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Status</p>
                  <div>{getStatusBadge(selectedVerification.status)}</div>
                </div>
              </div>
              
              <div className="border-t border-neutral-200 dark:border-neutral-700 pt-4 mt-4">
                <h3 className="font-semibold mb-3">Document Images</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400 mb-1">Front Image</p>
                    <SecureDocumentViewer
                      documentUrl={selectedVerification.documentFront ? 
                        `/api/admin/documents/kyc/${selectedVerification.id}/id-front` : undefined}
                      documentType="id-front"
                      fileName={`kyc-${selectedVerification.id}-id-front.jpg`}
                      metadata={{
                        idNumber: selectedVerification.idNumber,
                        documentType: selectedVerification.idType,
                        adminView: true
                      }}
                      placeholderText="No ID front image uploaded"
                    />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400 mb-1">Back Image</p>
                    <SecureDocumentViewer
                      documentUrl={selectedVerification.documentBack ? 
                        `/api/admin/documents/kyc/${selectedVerification.id}/id-back` : undefined}
                      documentType="id-back"
                      fileName={`kyc-${selectedVerification.id}-id-back.jpg`}
                      metadata={{
                        idNumber: selectedVerification.idNumber,
                        documentType: selectedVerification.idType,
                        adminView: true
                      }}
                      placeholderText="No ID back image uploaded"
                    />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400 mb-1">Selfie Image</p>
                    <SecureDocumentViewer
                      documentUrl={selectedVerification.selfieImage ? 
                        `/api/admin/documents/kyc/${selectedVerification.id}/selfie` : undefined}
                      documentType="selfie"
                      fileName={`kyc-${selectedVerification.id}-selfie.jpg`}
                      metadata={{
                        idNumber: selectedVerification.idNumber,
                        adminView: true
                      }}
                      placeholderText="No verification selfie uploaded"
                    />
                  </div>
                </div>
              </div>
              
              {selectedVerification.status === "rejected" && selectedVerification.rejectionReason && (
                <div className="border-t border-neutral-200 dark:border-neutral-700 pt-4 mt-4">
                  <h3 className="font-semibold mb-2">Rejection Reason</h3>
                  <p className="text-neutral-700 dark:text-neutral-300 text-sm bg-red-50 dark:bg-red-900/20 p-3 rounded">
                    {selectedVerification.rejectionReason}
                  </p>
                </div>
              )}
            </div>
            
            <DialogFooter className="flex justify-between">
              <Button variant="outline" onClick={() => setIsDetailsOpen(false)}>
                Close
              </Button>
              
              {selectedVerification.status === "pending" && (
                <div className="flex gap-3">
                  <Button 
                    variant="outline"
                    onClick={openRejectDialog}
                    className="text-red-600"
                    disabled={rejectKycMutation.isPending}
                  >
                    <Close className="h-4 w-4 mr-1" />
                    Reject
                  </Button>
                  
                  <Button 
                    onClick={() => handleApprove(selectedVerification.id)}
                    className="bg-green-600 hover:bg-green-700"
                    disabled={approveKycMutation.isPending}
                  >
                    <Check className="h-4 w-4 mr-1" />
                    Approve
                  </Button>
                </div>
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
      
      {/* Rejection Reason Dialog */}
      <Dialog open={isRejectDialogOpen} onOpenChange={setIsRejectDialogOpen}>
        <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Reject Verification</DialogTitle>
            <DialogDescription>
              Please provide a reason for rejecting this verification request.
            </DialogDescription>
          </DialogHeader>
          
          <div className="my-6">
            <label htmlFor="reason" className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
              Rejection Reason
            </label>
            <Input
              id="reason"
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              placeholder="Enter the reason for rejection"
              className="w-full"
            />
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsRejectDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleReject}
              disabled={!rejectionReason.trim() || rejectKycMutation.isPending}
            >
              Reject Verification
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}