import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useAdminAuth } from "@/hooks/use-admin-auth";
import { Loader2, FileText, Search, RefreshCw, Database } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { apiRequest } from "@/lib/queryClient";

// Status badge component
const StatusBadge = ({ status }: { status: string }) => {
  switch (status) {
    case "pending_review":
    case "pending":
      return <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">Pending Review</Badge>;
    case "approved":
      return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Approved</Badge>;
    case "denied":
    case "rejected":
      return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Denied</Badge>;
    case "on_hold":
      return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">On Hold</Badge>;
    case "incomplete":
      return <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">Incomplete</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
};

// Simple application interface
interface SimpleApplication {
  id: number;
  applicationNumber: string;
  name: string;
  email: string;
  status: string;
  submittedAt: string;
  documentFilename?: string;
}

export default function SimpleApplications() {
  const { adminUser, isAuthenticated } = useAdminAuth();
  const { toast } = useToast();
  const [applications, setApplications] = useState<SimpleApplication[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");

  // Fetch applications function
  const fetchApplications = async () => {
    setLoading(true);
    setError(null);
    try {
      console.log("Fetching SQL applications...");
      
      // Try fetching from our dedicated SQL endpoint first
      try {
        const sqlResponse = await apiRequest("GET", "/api/admin/sql-applications");
        const sqlData = await sqlResponse.json();
        console.log("SQL Applications response data:", sqlData);
        
        if (sqlData.applications && sqlData.applications.length > 0) {
          console.log(`Found ${sqlData.applications.length} SQL applications`);
          // Transform the data to match our simple interface
          const simpleApps: SimpleApplication[] = sqlData.applications.map((app: any) => ({
            id: app.id,
            applicationNumber: app.applicationNumber || app.application_id || `APP-${app.id}`,
            name: app.name || `${app.applicationData?.firstName || ''} ${app.applicationData?.lastName || ''}`.trim(),
            email: app.email || app.contactEmail || app.applicationData?.email || '',
            status: app.status,
            submittedAt: app.created_at || app.submittedAt,
            documentFilename: app.document_filename || app.documentFilename
          }));
          console.log("Transformed SQL applications:", simpleApps);
          setApplications(simpleApps);
          setLoading(false);
          return;
        } else {
          console.log("No SQL applications found, falling back to legacy endpoint");
        }
      } catch (sqlError) {
        console.error("Error fetching SQL applications:", sqlError);
        // Continue with the fallback approach
      }
      
      // Fallback to legacy endpoint
      console.log("Falling back to legacy applications endpoint");
      const response = await apiRequest("GET", "/api/admin/account-applications");
      const data = await response.json();
      console.log("Legacy applications response data:", data);
      
      if (data.applications) {
        // Transform the data to match our simple interface
        const simpleApps: SimpleApplication[] = data.applications.map((app: any) => ({
          id: app.id,
          applicationNumber: app.applicationNumber || app.application_id || `APP-${app.id}`,
          name: app.name || `${app.applicationData?.firstName || ''} ${app.applicationData?.lastName || ''}`.trim(),
          email: app.email || app.contactEmail || app.applicationData?.email || '',
          status: app.status,
          submittedAt: app.created_at || app.submittedAt,
          documentFilename: app.document_filename || app.documentFilename
        }));
        console.log("Transformed legacy applications:", simpleApps);
        setApplications(simpleApps);
      } else {
        setApplications([]);
      }
    } catch (err) {
      console.error("Error fetching applications:", err);
      setError("Failed to load applications. Please try again.");
      toast({
        title: "Error",
        description: "Failed to load applications.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  // Fetch applications on component mount
  useEffect(() => {
    if (adminUser) {
      fetchApplications();
    }
  }, [adminUser]);

  // Filter applications based on search term
  const filteredApplications = applications.filter(app => 
    app.applicationNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    app.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    app.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (!isAuthenticated || !adminUser) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-amber-600" />
      </div>
    );
  }

  return (
    <div className="container mx-auto py-6 space-y-6">
      <Card className="border-amber-200">
        <CardHeader className="bg-amber-50">
          <CardTitle className="text-amber-900 text-2xl flex items-center">
            <FileText className="mr-2 h-6 w-6" />
            All Submitted Applications
          </CardTitle>
          <CardDescription>
            Review all submitted account applications with a simplified interface.
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          {/* Search and refresh controls */}
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by application number, name, or email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                className="border-amber-200 hover:bg-amber-50"
                onClick={fetchApplications}
                title="Refresh data"
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
              <Button
                variant="outline"
                className="border-amber-300 hover:bg-amber-100"
                onClick={async () => {
                  try {
                    const response = await apiRequest("GET", "/api/admin/check-applications-table");
                    const data = await response.json();
                    console.log("Applications table check:", data);
                    toast({
                      title: "Applications Table",
                      description: `${data.message}. Found ${data.applicationCount} applications.`,
                    });
                    // Refresh data after checking
                    fetchApplications();
                  } catch (err) {
                    console.error("Error checking applications table:", err);
                    toast({
                      title: "Error",
                      description: "Failed to check applications table.",
                      variant: "destructive"
                    });
                  }
                }}
                title="Check and ensure applications table exists"
              >
                <Database className="h-4 w-4 mr-2" />
                Check DB
              </Button>
            </div>
          </div>

          {/* Loading state */}
          {loading && (
            <div className="flex justify-center items-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-amber-600" />
              <span className="ml-2 text-amber-800">Loading applications...</span>
            </div>
          )}

          {/* Error state */}
          {error && !loading && (
            <div className="bg-red-50 border border-red-200 rounded-md p-4 mb-6">
              <p className="text-red-700">{error}</p>
            </div>
          )}

          {/* Empty state */}
          {!loading && !error && filteredApplications.length === 0 && (
            <div className="text-center py-12 border rounded-md border-dashed border-gray-300 bg-gray-50">
              <h3 className="text-lg font-medium text-gray-900 mb-1">No applications found</h3>
              <p className="text-gray-500 max-w-md mx-auto">
                {searchTerm
                  ? `No applications match your search term "${searchTerm}". Try a different search term.`
                  : "There are no applications in the system yet."}
              </p>
            </div>
          )}

          {/* Applications list */}
          {!loading && !error && filteredApplications.length > 0 && (
            <div className="space-y-4">
              {filteredApplications.map(app => (
                <div 
                  key={app.id} 
                  className="p-4 border rounded-md hover:bg-gray-50 transition-colors"
                >
                  <div className="flex flex-col md:flex-row justify-between">
                    <div>
                      <h3 className="font-medium text-lg">
                        {app.name || "Unnamed Applicant"}
                      </h3>
                      <p className="text-sm text-gray-600">
                        <strong>ID:</strong> {app.applicationNumber}
                      </p>
                      <p className="text-sm text-gray-600">
                        <strong>Email:</strong> {app.email}
                      </p>
                      <p className="text-sm text-gray-600">
                        <strong>Submitted:</strong> {format(new Date(app.submittedAt), "MMM dd, yyyy HH:mm")}
                      </p>
                    </div>
                    <div className="flex flex-col items-start md:items-end mt-3 md:mt-0">
                      <StatusBadge status={app.status} />
                      <div className="mt-3 flex gap-2">
                        <Link href={`/admin/applications/${app.id}`}>
                          <Button 
                            size="sm" 
                            variant="outline"
                            className="h-8 border-amber-200 hover:bg-amber-50"
                          >
                            View Details
                          </Button>
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}