import { useState, useEffect, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation, Link } from "wouter";
import { getApplicationDocumentUrl, getKycDocumentUrl } from "@/lib/document-utils";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { useAdminAuth } from "@/hooks/use-admin-auth";
import SecureDocumentViewer from "@/components/secure-document-viewer";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip as RechartsTooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Legend,
  AreaChart,
  Area
} from "recharts";
import {
  User,
  UserPlus,
  Users,
  CreditCard,
  DollarSign,
  Bell,
  ShieldAlert,
  FileText,
  Home,
  Settings,
  ChevronDown,
  Menu,
  X,
  Search,
  Shield,
  TrendingUp,
  Filter,
  Clock,
  AlertTriangle,
  FileCheck,
  CheckCircle,
  XCircle,
  AlarmClock,
  HelpCircle,
  LogOut,
  Database,
  Activity,
  Calendar,
  RefreshCw,
  Download as DownloadIcon,
  Download,
  BarChart as BarChartIcon
} from "lucide-react";

interface AdminDashboardStats {
  totalUsers: number;
  activeUsers: number;
  pendingKyc: number;
  totalTransactions: number;
  transactionVolume: number;
  fraudAlerts: number;
  totalAccounts: number;
  totalDeposits: number;
  totalWithdrawals: number;
  netDeposits: number;
  accountsOpened: number;
  loanApplications: number;
  averageAccountBalance: number;
  complianceAlerts: number;
}

export default function AdminDashboard() {
  const [location] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeTab, setActiveTab] = useState("dashboard");
  const [selectedApplication, setSelectedApplication] = useState<any>(null);
  const [isApplicationDetailsOpen, setIsApplicationDetailsOpen] = useState(false);
  const { adminUser, logout } = useAdminAuth();
  
  // Fetch dashboard stats from real database
  const { data: stats, isLoading: isLoadingStats } = useQuery<AdminDashboardStats>({
    queryKey: ["/api/admin/dashboard/stats"],
    refetchOnWindowFocus: false,
  });
  
  // Fetch chart data from the real database
  const { data: chartData, isLoading: isLoadingChartData } = useQuery<any>({
    queryKey: ["/api/admin/dashboard/charts"],
    refetchOnWindowFocus: false,
  });
  
  // Real user activity data or fallback to empty array if not loaded yet
  const userActivityData = useMemo(() => {
    if (!chartData || !chartData.userActivity) return [];
    return chartData.userActivity;
  }, [chartData]);
  
  // Real transaction data 
  const transactionData = useMemo(() => {
    if (!chartData || !chartData.transactions) return [];
    return chartData.transactions;
  }, [chartData]);
  
  // Real KYC status data
  const kycStatusData = useMemo(() => {
    if (!stats) return [];
    return [
      { name: "Verified", value: stats.activeUsers || 0 },
      { name: "Pending", value: stats.pendingKyc || 0 },
      { name: "Rejected", value: (stats.totalUsers - stats.activeUsers - stats.pendingKyc) || 0 },
    ];
  }, [stats]);

  // Real financial activity data
  const financialActivityData = useMemo(() => {
    if (!chartData || !chartData.financialActivity) return [];
    return chartData.financialActivity;
  }, [chartData]);
  
  // Fetch admin data for dashboard
  const { data: adminUsers, isLoading: isLoadingUsers } = useQuery({
    queryKey: ["/api/admin/users"],
    refetchOnWindowFocus: false,
  });
  
  const { data: kycVerifications, isLoading: isLoadingKyc } = useQuery({
    queryKey: ["/api/admin/kyc-verifications"],
    refetchOnWindowFocus: false,
  });
  
  const { data: supportTicketsData, isLoading: isLoadingTickets } = useQuery({
    queryKey: ["/api/admin/support-tickets"],
    refetchOnWindowFocus: false,
  });
  
  const { data: fraudAlertsData, isLoading: isLoadingFraud } = useQuery({
    queryKey: ["/api/admin/fraud-alerts"],
    refetchOnWindowFocus: false,
  });
  
  // Fetch account applications
  const { data: accountApplicationsData, isLoading: isLoadingApplications } = useQuery({
    queryKey: ["/api/admin/account-applications"],
    refetchOnWindowFocus: false,
  });
  
  // Process data for display
  const recentUsers = useMemo(() => {
    if (!adminUsers || !Array.isArray(adminUsers)) return [];
    
    return adminUsers.slice(0, 5).map((user: any) => ({
      id: user.id,
      name: `${user.firstName} ${user.lastName}`,
      email: user.email,
      status: user.isVerified ? "Active" : user.kycStatus === "pending" ? "Pending KYC" : "Inactive",
      registrationDate: new Date(user.createdAt).toISOString().split('T')[0],
      lastLogin: user.lastLogin ? new Date(user.lastLogin).toISOString().split('T')[0] : "Never"
    }));
  }, [adminUsers]);
  
  const pendingKycVerifications = useMemo(() => {
    if (!kycVerifications || !Array.isArray(kycVerifications)) return [];
    
    return kycVerifications
      .filter((kyc: any) => kyc.status === "pending")
      .slice(0, 5)
      .map((kyc: any) => ({
        id: kyc.id,
        userId: kyc.userId,
        userName: kyc.userName,
        submittedDate: kyc.submittedAt ? new Date(kyc.submittedAt).toISOString().split('T')[0] : "Unknown",
        documentType: kyc.documentType || "ID Document",
        status: "Pending"
      }));
  }, [kycVerifications]);
  
  const supportTickets = useMemo(() => {
    if (!supportTicketsData || !Array.isArray(supportTicketsData)) return [];
    
    return supportTicketsData
      .filter((ticket: any) => ticket.status === "open")
      .slice(0, 5)
      .map((ticket: any) => ({
        id: ticket.id,
        userId: ticket.userId,
        userName: ticket.userName,
        subject: ticket.subject,
        priority: ticket.priority,
        status: ticket.status,
        createdAt: ticket.createdAt ? new Date(ticket.createdAt).toISOString().split('T')[0] : "Unknown"
      }));
  }, [supportTicketsData]);
  
  const fraudAlerts = useMemo(() => {
    if (!fraudAlertsData || !Array.isArray(fraudAlertsData)) return [];
    
    return fraudAlertsData
      .filter((alert: any) => alert.status === "pending")
      .slice(0, 3)
      .map((alert: any) => ({
        id: alert.id,
        accountId: alert.accountId,
        userName: alert.userName,
        amount: parseFloat(alert.amount),
        transactionType: alert.alertType,
        timestamp: alert.detectedAt,
        status: "Pending Review"
      }));
  }, [fraudAlertsData]);
  
  // Format account applications data for display
  const pendingApplications = useMemo(() => {
    if (!accountApplicationsData || !Array.isArray(accountApplicationsData)) return [];
    
    return accountApplicationsData
      .filter((app: any) => app.status === "pending_review")
      .slice(0, 5)
      .map((app: any) => {
        // Extract applicant data from application JSON
        const applicationData = app.applicationData || {};
        const personalInfo = applicationData.personal || {};
        
        console.log("Application data structure:", JSON.stringify(applicationData, null, 2));
        
        return {
          id: app.id,
          applicationNumber: app.applicationNumber,
          fullName: `${personalInfo.firstName || ''} ${personalInfo.lastName || ''}`.trim(),
          email: app.contactEmail,
          phone: app.contactPhone || 'N/A',
          submittedAt: app.submittedAt ? new Date(app.submittedAt).toISOString().split('T')[0] : 'Unknown',
          status: app.status === "pending_review" ? "Pending Review" : app.status
        };
      });
  }, [accountApplicationsData]);

  // Real daily accounts data
  const dailyAccountsData = useMemo(() => {
    if (!chartData || !chartData.dailyAccounts) return [];
    return chartData.dailyAccounts;
  }, [chartData]);

  // Real risk scoring data
  const riskScoreData = useMemo(() => {
    if (!chartData || !chartData.riskScores) return [];
    return chartData.riskScores.length > 0 ? chartData.riskScores : [
      { category: "Low Risk", value: 0 },
      { category: "Medium Risk", value: 0 },
      { category: "High Risk", value: 0 }
    ];
  }, [chartData]);
  
  // Count of pending applications for notifications
  const pendingApplicationsCount = useMemo(() => {
    return pendingApplications.length;
  }, [pendingApplications]);

  const COLORS = ["#4caf50", "#ff9800", "#f44336"];
  const RISK_COLORS = ["#4caf50", "#ff9800", "#f44336"];
  
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value);
  };

  // Format timestamp to readable format
  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleString();
  };
  
  // Handler for viewing an application's details
  const handleViewApplication = (application: any) => {
    console.log("Viewing application details:", application);
    setSelectedApplication(application);
    setIsApplicationDetailsOpen(true);
  };
  
  // Handler for approving an application
  const handleApproveApplication = async (applicationId: number) => {
    // Implement application approval API call here
    try {
      // Mock approval for now
      console.log("Approving application:", applicationId);
      // Actually call the API in a real implementation
      // await apiRequest("POST", `/api/admin/applications/${applicationId}/approve`);
      
      // Invalidate cache to refresh data
      // queryClient.invalidateQueries({ queryKey: ["/api/admin/account-applications"] });
    } catch (error) {
      console.error("Error approving application:", error);
    }
  };

  return (
    <div className="flex h-screen bg-amber-50 dark:bg-neutral-900">
      {/* Admin Sidebar */}
      <div className={`${sidebarOpen ? 'w-64' : 'w-20'} bg-amber-900 dark:bg-amber-950 text-white transition-all duration-300 ease-in-out flex flex-col h-full shrink-0`}>
        <div className="flex items-center justify-between p-4 border-b border-amber-700/50">
          <div className={`flex items-center ${!sidebarOpen && 'justify-center w-full'}`}>
            <Shield className="h-8 w-8 text-amber-400" />
            {sidebarOpen && <span className="ml-2 font-semibold text-xl">Admin Portal</span>}
          </div>
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="text-amber-400 hover:text-amber-300">
            {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
        
        <div className="overflow-y-auto flex-grow">
          <div className="px-4 py-4">
            {sidebarOpen && <p className="text-xs font-semibold text-amber-500 uppercase tracking-wider mb-2">Main</p>}
            <nav className="space-y-1">
              <Link 
                href="/admin/dashboard"
                onClick={() => setActiveTab('dashboard')}
                className={`flex items-center ${!sidebarOpen ? 'justify-center' : ''} py-2.5 px-2 rounded-md ${activeTab === 'dashboard' ? 'bg-amber-800 text-amber-300' : 'text-amber-300 hover:bg-amber-800/60'} transition-colors duration-200 cursor-pointer`}
              >
                <Home className="h-5 w-5" />
                {sidebarOpen && <span className="ml-3">Dashboard</span>}
              </Link>
              <Link
                href="/admin/users"
                onClick={() => setActiveTab('users')}
                className={`flex items-center ${!sidebarOpen ? 'justify-center' : ''} py-2.5 px-2 rounded-md ${activeTab === 'users' ? 'bg-amber-800 text-amber-300' : 'text-amber-300 hover:bg-amber-800/60'} transition-colors duration-200 cursor-pointer`}
              >
                <Users className="h-5 w-5" />
                {sidebarOpen && <span className="ml-3">Users</span>}
              </Link>
              <Link
                href="/admin/accounts"
                onClick={() => setActiveTab('accounts')}
                className={`flex items-center ${!sidebarOpen ? 'justify-center' : ''} py-2.5 px-2 rounded-md ${activeTab === 'accounts' ? 'bg-amber-800 text-amber-300' : 'text-amber-300 hover:bg-amber-800/60'} transition-colors duration-200 cursor-pointer`}
              >
                <CreditCard className="h-5 w-5" />
                {sidebarOpen && <span className="ml-3">Accounts</span>}
              </Link>
              <Link 
                href="/admin/transactions"
                onClick={() => setActiveTab('transactions')}
                className={`flex items-center ${!sidebarOpen ? 'justify-center' : ''} py-2.5 px-2 rounded-md ${activeTab === 'transactions' ? 'bg-amber-800 text-amber-300' : 'text-amber-300 hover:bg-amber-800/60'} transition-colors duration-200 cursor-pointer`}
              >
                <DollarSign className="h-5 w-5" />
                {sidebarOpen && <span className="ml-3">Transactions</span>}
              </Link>
              <Link 
                href="/admin/kyc"
                onClick={() => setActiveTab('kyc')}
                className={`flex items-center relative ${!sidebarOpen ? 'justify-center' : ''} py-2.5 px-2 rounded-md ${activeTab === 'kyc' ? 'bg-amber-800 text-amber-300' : 'text-amber-300 hover:bg-amber-800/60'} transition-colors duration-200 cursor-pointer`}
              >
                <FileCheck className="h-5 w-5" />
                {sidebarOpen && <div className="ml-3 flex justify-between items-center w-full">
                  <span>KYC Verifications</span>
                  <Badge className="bg-amber-400 text-amber-950 text-xs">{stats?.pendingKyc || 0}</Badge>
                </div>}
                {!sidebarOpen && (stats?.pendingKyc || 0) > 0 && (
                  <Badge className="absolute -right-1 -top-1 bg-amber-400 text-amber-950 text-xs">{stats?.pendingKyc}</Badge>
                )}
              </Link>
              <Link 
                href="/admin/documents"
                onClick={() => setActiveTab('documents')}
                className={`flex items-center ${!sidebarOpen ? 'justify-center' : ''} py-2.5 px-2 rounded-md ${activeTab === 'documents' ? 'bg-amber-800 text-amber-300' : 'text-amber-300 hover:bg-amber-800/60'} transition-colors duration-200 cursor-pointer`}
              >
                <FileText className="h-5 w-5" />
                {sidebarOpen && <span className="ml-3">Document Center</span>}
              </Link>
              <Link 
                href="/admin/simple-applications"
                onClick={() => setActiveTab('simple-applications')}
                className={`flex items-center ${!sidebarOpen ? 'justify-center' : ''} py-2.5 px-2 rounded-md ${activeTab === 'simple-applications' ? 'bg-amber-800 text-amber-300' : 'text-amber-300 hover:bg-amber-800/60'} transition-colors duration-200 cursor-pointer`}
              >
                <Database className="h-5 w-5" />
                {sidebarOpen && <span className="ml-3">SQL Applications</span>}
              </Link>
              <div 
                onClick={() => { setActiveTab('fraud'); window.location.href = "/admin/fraud"; }}
                className={`flex items-center relative ${!sidebarOpen ? 'justify-center' : ''} py-2.5 px-2 rounded-md ${activeTab === 'fraud' ? 'bg-amber-800 text-amber-300' : 'text-amber-300 hover:bg-amber-800/60'} transition-colors duration-200 cursor-pointer`}
              >
                <ShieldAlert className="h-5 w-5" />
                {sidebarOpen && <div className="ml-3 flex justify-between items-center w-full">
                  <span>Fraud Alerts</span>
                  <Badge className="bg-red-400 text-red-950 text-xs">{stats?.fraudAlerts || 0}</Badge>
                </div>}
                {!sidebarOpen && (stats?.fraudAlerts || 0) > 0 && (
                  <Badge className="absolute -right-1 -top-1 bg-red-400 text-red-950 text-xs">{stats?.fraudAlerts}</Badge>
                )}
              </div>
              <div 
                onClick={() => { setActiveTab('support'); window.location.href = "/admin/support"; }}
                className={`flex items-center ${!sidebarOpen ? 'justify-center' : ''} py-2.5 px-2 rounded-md ${activeTab === 'support' ? 'bg-amber-800 text-amber-300' : 'text-amber-300 hover:bg-amber-800/60'} transition-colors duration-200 cursor-pointer`}
              >
                <HelpCircle className="h-5 w-5" />
                {sidebarOpen && <span className="ml-3">Support Tickets</span>}
              </div>
              <div 
                onClick={() => { setActiveTab('reports'); window.location.href = "/admin/reports"; }}
                className={`flex items-center ${!sidebarOpen ? 'justify-center' : ''} py-2.5 px-2 rounded-md ${activeTab === 'reports' ? 'bg-amber-800 text-amber-300' : 'text-amber-300 hover:bg-amber-800/60'} transition-colors duration-200 cursor-pointer`}
              >
                <BarChartIcon className="h-5 w-5" />
                {sidebarOpen && <span className="ml-3">Reports</span>}
              </div>
              
              {/* Separator before switching to user mode */}
              {sidebarOpen && (
                <div className="my-2 border-t border-amber-700/30"></div>
              )}
              
              {/* Switch to User Portal button */}
              <div 
                onClick={() => { window.location.href = "/user-login"; }}
                className={`flex items-center ${!sidebarOpen ? 'justify-center' : ''} py-2.5 px-2 rounded-md text-amber-300 hover:bg-amber-800/60 transition-colors duration-200 cursor-pointer mt-4`}
              >
                <User className="h-5 w-5" />
                {sidebarOpen && <span className="ml-3">Switch to User Portal</span>}
              </div>
            </nav>
          </div>
          
          {sidebarOpen && (
            <div className="px-4 py-4">
              <p className="text-xs font-semibold text-amber-500 uppercase tracking-wider mb-2">Settings</p>
              <nav className="space-y-1">
                <div 
                  onClick={() => { setActiveTab('settings'); window.location.href = "/admin/settings"; }}
                  className={`flex items-center py-2.5 px-2 rounded-md ${activeTab === 'settings' ? 'bg-amber-800 text-amber-300' : 'text-amber-300 hover:bg-amber-800/60'} transition-colors duration-200 cursor-pointer`}
                >
                  <Settings className="h-5 w-5" />
                  <span className="ml-3">Settings</span>
                </div>
              </nav>
            </div>
          )}
        </div>
        
        <div className="p-4 border-t border-amber-700/50">
          {sidebarOpen ? (
            <div className="flex items-center">
              <Avatar className="h-10 w-10 border-2 border-amber-400">
                <AvatarFallback className="bg-amber-700 text-amber-100">
                  {adminUser?.firstName?.charAt(0)}{adminUser?.lastName?.charAt(0)}
                </AvatarFallback>
              </Avatar>
              <div className="ml-3">
                <p className="text-sm font-medium text-amber-100">{adminUser?.firstName} {adminUser?.lastName}</p>
                <p className="text-xs text-amber-400">{adminUser?.role}</p>
              </div>
              <button onClick={logout} className="ml-auto text-amber-400 hover:text-amber-300">
                <LogOut size={18} />
              </button>
            </div>
          ) : (
            <div className="flex flex-col items-center">
              <Avatar className="h-10 w-10 border-2 border-amber-400">
                <AvatarFallback className="bg-amber-700 text-amber-100">
                  {adminUser?.firstName?.charAt(0)}{adminUser?.lastName?.charAt(0)}
                </AvatarFallback>
              </Avatar>
              <button onClick={logout} className="mt-2 text-amber-400 hover:text-amber-300">
                <LogOut size={18} />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Application Details Dialog */}
      {selectedApplication && (
        <Dialog open={isApplicationDetailsOpen} onOpenChange={setIsApplicationDetailsOpen}>
          <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Application Details #{selectedApplication.applicationNumber}</DialogTitle>
              <DialogDescription>
                Complete application information submitted by {selectedApplication.fullName}
              </DialogDescription>
            </DialogHeader>
            
            {accountApplicationsData && Array.isArray(accountApplicationsData) && accountApplicationsData.length > 0 && (
              <div className="space-y-6 py-4">
                {accountApplicationsData.filter((app: any) => app.id === selectedApplication?.id).map((app: any) => {
                  console.log("Rendering application details for ID:", app.id);
                  const appData = app.applicationData || {};
                  return (
                    <div key={app.id} className="space-y-6">
                      {/* Personal Information */}
                      <div>
                        <h3 className="text-lg font-semibold border-b pb-2 mb-3">Personal Information</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm font-medium text-neutral-500">Full Name</p>
                            <p className="font-semibold">
                              {appData.personal?.firstName} {appData.personal?.middleName} {appData.personal?.lastName}
                            </p>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-neutral-500">Date of Birth</p>
                            <p className="font-semibold">{appData.personal?.dateOfBirth}</p>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-neutral-500">SSN</p>
                            <p className="font-semibold">{appData.personal?.ssn}</p>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-neutral-500">Citizenship Status</p>
                            <p className="font-semibold">
                              {appData.personal?.citizenshipStatus === 'usCitizen' ? 'US Citizen' : 
                               appData.personal?.citizenshipStatus === 'permanentResident' ? 'Permanent Resident' : 
                               appData.personal?.citizenshipStatus === 'nonResident' ? 'Non-Resident' : 
                               appData.personal?.citizenshipStatus}
                            </p>
                          </div>
                        </div>
                      </div>
                      
                      {/* Contact Information */}
                      <div>
                        <h3 className="text-lg font-semibold border-b pb-2 mb-3">Contact Information</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm font-medium text-neutral-500">Email</p>
                            <p className="font-semibold">{app.contactEmail}</p>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-neutral-500">Phone</p>
                            <p className="font-semibold">{app.contactPhone || 'N/A'}</p>
                          </div>
                          <div className="col-span-2">
                            <p className="text-sm font-medium text-neutral-500">Address</p>
                            <p className="font-semibold">
                              {appData.contact?.address?.street}
                              {appData.contact?.address?.aptSuite && `, ${appData.contact.address.aptSuite}`}<br />
                              {appData.contact?.address?.city}, {appData.contact?.address?.state} {appData.contact?.address?.zipCode}
                            </p>
                          </div>
                        </div>
                      </div>
                      
                      {/* Employment Information */}
                      <div>
                        <h3 className="text-lg font-semibold border-b pb-2 mb-3">Employment Information</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm font-medium text-neutral-500">Employment Status</p>
                            <p className="font-semibold capitalize">{appData.employment?.status || 'N/A'}</p>
                          </div>
                          {appData.employment?.status !== 'unemployed' && (
                            <>
                              <div>
                                <p className="text-sm font-medium text-neutral-500">Employer</p>
                                <p className="font-semibold">{appData.employment?.employerName || 'N/A'}</p>
                              </div>
                              <div>
                                <p className="text-sm font-medium text-neutral-500">Industry</p>
                                <p className="font-semibold">{appData.employment?.industryType || 'N/A'}</p>
                              </div>
                              <div>
                                <p className="text-sm font-medium text-neutral-500">Occupation</p>
                                <p className="font-semibold">{appData.employment?.occupation || 'N/A'}</p>
                              </div>
                            </>
                          )}
                          <div>
                            <p className="text-sm font-medium text-neutral-500">Annual Income</p>
                            <p className="font-semibold">{appData.employment?.annualIncome ? `$${appData.employment.annualIncome}` : 'N/A'}</p>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-neutral-500">Source of Funds</p>
                            <p className="font-semibold">{appData.employment?.sourceOfFunds || 'N/A'}</p>
                          </div>
                        </div>
                      </div>
                      
                      {/* Banking Information */}
                      <div>
                        <h3 className="text-lg font-semibold border-b pb-2 mb-3">Banking Information</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm font-medium text-neutral-500">Account Type</p>
                            <p className="font-semibold capitalize">{appData.banking?.accountType || 'N/A'}</p>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-neutral-500">Account Purpose</p>
                            <p className="font-semibold capitalize">{appData.banking?.accountPurpose || 'N/A'}</p>
                          </div>
                        </div>
                      </div>
                      
                      {/* Identification Information */}
                      <div>
                        <h3 className="text-lg font-semibold border-b pb-2 mb-3">Identification Information</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm font-medium text-neutral-500">ID Type</p>
                            <p className="font-semibold capitalize">
                              {appData.identification?.idType === 'driver_license' ? 'Driver\'s License' : 
                               appData.identification?.idType === 'passport' ? 'Passport' : 
                               appData.identification?.idType === 'state_id' ? 'State ID' : 
                               appData.identification?.idType || 'N/A'}
                            </p>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-neutral-500">ID Number</p>
                            <p className="font-semibold">{appData.identification?.idNumber || 'N/A'}</p>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-neutral-500">Expiration Date</p>
                            <p className="font-semibold">{appData.identification?.idExpiryDate || 'N/A'}</p>
                          </div>
                        </div>
                        <div className="mt-4">
                          <p className="text-sm font-medium text-neutral-500 mb-2">Document Images</p>
                          <div className="grid grid-cols-3 gap-4">
                            <div>
                              <p className="text-xs text-neutral-500 mb-1">Front Image</p>
                              <SecureDocumentViewer
                                documentUrl={appData.identification?.documentFront ? 
                                  getApplicationDocumentUrl(app.id, 'id-front', true) : undefined}
                                documentType="id-front"
                                fileName={`${app.applicationNumber}-id-front.jpg`}
                                metadata={{
                                  idNumber: appData.identification?.idNumber,
                                  documentType: appData.identification?.idType
                                }}
                                placeholderText="No ID front image uploaded"
                              />
                            </div>
                            <div>
                              <p className="text-xs text-neutral-500 mb-1">Back Image</p>
                              <SecureDocumentViewer
                                documentUrl={appData.identification?.documentBack ? 
                                  getApplicationDocumentUrl(app.id, 'id-back', true) : undefined}
                                documentType="id-back"
                                fileName={`${app.applicationNumber}-id-back.jpg`}
                                metadata={{
                                  idNumber: appData.identification?.idNumber,
                                  documentType: appData.identification?.idType
                                }}
                                placeholderText="No ID back image uploaded"
                              />
                            </div>
                            <div>
                              <p className="text-xs text-neutral-500 mb-1">Selfie Image</p>
                              <SecureDocumentViewer
                                documentUrl={appData.identification?.selfieImage ? 
                                  getApplicationDocumentUrl(app.id, 'selfie', true) : undefined}
                                documentType="selfie"
                                fileName={`${app.applicationNumber}-selfie.jpg`}
                                metadata={{
                                  idNumber: appData.identification?.idNumber
                                }}
                                placeholderText="No verification selfie uploaded"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      {/* Additional Information */}
                      <div>
                        <h3 className="text-lg font-semibold border-b pb-2 mb-3">Additional Information</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm font-medium text-neutral-500">Bankruptcy History</p>
                            <p className="font-semibold">{appData.financial?.hasBankruptcyHistory ? 'Yes' : 'No'}</p>
                          </div>
                          {appData.financial?.hasBankruptcyHistory && (
                            <div className="col-span-2">
                              <p className="text-sm font-medium text-neutral-500">Bankruptcy Details</p>
                              <p className="font-semibold">{appData.financial?.bankruptcyDetails || 'N/A'}</p>
                            </div>
                          )}
                          <div>
                            <p className="text-sm font-medium text-neutral-500">Tax Liens</p>
                            <p className="font-semibold">{appData.financial?.hasTaxLiens ? 'Yes' : 'No'}</p>
                          </div>
                          {appData.financial?.hasTaxLiens && (
                            <div className="col-span-2">
                              <p className="text-sm font-medium text-neutral-500">Tax Lien Details</p>
                              <p className="font-semibold">{appData.financial?.taxLienDetails || 'N/A'}</p>
                            </div>
                          )}
                          
                          {/* Handle application format differences between old and new submissions */}
                          <div>
                            <p className="text-sm font-medium text-neutral-500">Bankruptcy History (alt)</p>
                            <p className="font-semibold">{appData.hasBankruptcyHistory ? 'Yes' : 'No'}</p>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-neutral-500">Tax Liens (alt)</p>
                            <p className="font-semibold">{appData.hasTaxLiens ? 'Yes' : 'No'}</p>
                          </div>
                        </div>
                      </div>
                      
                      {/* Legal Agreements */}
                      <div>
                        <h3 className="text-lg font-semibold border-b pb-2 mb-3">Legal Agreements</h3>
                        <div className="space-y-2">
                          <div className="flex items-start">
                            <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-2" />
                            <p className="text-sm">Terms and Conditions: <span className="font-semibold">{appData.legal?.agreeTerms ? 'Accepted' : 'Not Accepted'}</span></p>
                          </div>
                          <div className="flex items-start">
                            <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-2" />
                            <p className="text-sm">Privacy Policy: <span className="font-semibold">{appData.legal?.agreePrivacyPolicy ? 'Accepted' : 'Not Accepted'}</span></p>
                          </div>
                          <div className="flex items-start">
                            <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-2" />
                            <p className="text-sm">Electronic Communications: <span className="font-semibold">{appData.legal?.agreeElectronicComm ? 'Accepted' : 'Not Accepted'}</span></p>
                          </div>
                          <div className="flex items-start">
                            <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-2" />
                            <p className="text-sm">Credit Check Authorization: <span className="font-semibold">{appData.legal?.agreeCreditCheck ? 'Accepted' : 'Not Accepted'}</span></p>
                          </div>
                          <div className="flex items-start">
                            <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-2" />
                            <p className="text-sm">Information Certification: <span className="font-semibold">{appData.legal?.certifyInformation ? 'Accepted' : 'Not Accepted'}</span></p>
                          </div>
                        </div>
                      </div>
                      
                      {/* Application Metadata */}
                      <div>
                        <h3 className="text-lg font-semibold border-b pb-2 mb-3">Application Metadata</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm font-medium text-neutral-500">Application Number</p>
                            <p className="font-semibold">{app.applicationNumber}</p>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-neutral-500">Submitted Date</p>
                            <p className="font-semibold">{app.submittedAt ? new Date(app.submittedAt).toLocaleString() : 'Unknown'}</p>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-neutral-500">IP Address</p>
                            <p className="font-semibold">{app.ipAddress || 'Unknown'}</p>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-neutral-500">Status</p>
                            <p className="font-semibold">
                              <Badge className="bg-amber-100 text-amber-800 border-amber-200">
                                {app.status === "pending_review" ? "Pending Review" : app.status}
                              </Badge>
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
            
            <DialogFooter className="flex justify-between">
              <Button variant="outline" onClick={() => setIsApplicationDetailsOpen(false)}>
                Close
              </Button>
              <div className="flex gap-2">
                <Button variant="destructive" size="sm">
                  <X className="h-4 w-4 mr-1" />
                  Deny
                </Button>
                <Button className="bg-green-600 hover:bg-green-700" size="sm" onClick={() => handleApproveApplication(selectedApplication.id)}>
                  <CheckCircle className="h-4 w-4 mr-1" />
                  Approve
                </Button>
              </div>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Header */}
        <header className="bg-white dark:bg-neutral-800 shadow-sm border-b border-neutral-200 dark:border-neutral-700">
          <div className="flex items-center justify-between px-6 py-4">
            <div className="flex items-center space-x-3">
              <h1 className="text-xl font-semibold text-neutral-800 dark:text-white">Admin Dashboard</h1>
              <Badge className="bg-amber-100 text-amber-800 border border-amber-200">
                Banking Operations Center
              </Badge>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="relative">
                <input 
                  type="text" 
                  placeholder="Search..." 
                  className="py-1.5 pl-9 pr-4 w-64 rounded-md border border-neutral-300 dark:border-neutral-600 bg-neutral-50 dark:bg-neutral-700 text-sm focus:ring-1 focus:ring-amber-500 dark:focus:ring-amber-400 focus:border-amber-500 dark:focus:border-amber-400"
                />
                <Search className="absolute left-2.5 top-1/2 transform -translate-y-1/2 h-4 w-4 text-neutral-400" />
              </div>
              
              <div className="relative">
                <button className="relative p-1.5 rounded-full bg-neutral-100 dark:bg-neutral-700 hover:bg-neutral-200 dark:hover:bg-neutral-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-500">
                  <Bell className="h-5 w-5 text-neutral-500 dark:text-neutral-300" />
                  <span className="absolute top-0 right-0 block h-2.5 w-2.5 rounded-full bg-amber-500 ring-2 ring-white dark:ring-neutral-800"></span>
                </button>
              </div>
              
              <Button className="bg-amber-600 hover:bg-amber-700">
                <Download className="h-4 w-4 mr-2" />
                Export Data
              </Button>
            </div>
          </div>
        </header>

        {/* Dashboard Content */}
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-neutral-100 dark:bg-neutral-800">
          <div className="container mx-auto px-6 py-8">
            <div className="mb-8">
              <Tabs defaultValue="overview" className="w-full">
                <div className="flex items-center justify-between mb-4">
                  <TabsList className="bg-neutral-200 dark:bg-neutral-700">
                    <TabsTrigger value="overview">Overview</TabsTrigger>
                    <TabsTrigger value="applications" className="relative">
                      Applications
                      {pendingApplicationsCount > 0 && (
                        <span className="ml-1.5 inline-flex items-center justify-center rounded-full bg-amber-200 px-1.5 py-0.5 text-xs font-medium text-amber-800">
                          {pendingApplicationsCount}
                        </span>
                      )}
                    </TabsTrigger>
                    <TabsTrigger value="user-management">User Management</TabsTrigger>
                    <TabsTrigger value="compliance">Compliance & KYC</TabsTrigger>
                    <TabsTrigger value="fraud">Fraud Detection</TabsTrigger>
                    <TabsTrigger value="support">Support</TabsTrigger>
                  </TabsList>
                  
                  <div className="flex items-center space-x-2">
                    <div className="text-sm text-neutral-500 dark:text-neutral-400">
                      Last updated: <span className="font-medium">{new Date().toLocaleString()}</span>
                    </div>
                    <Button variant="outline" size="sm" className="flex items-center">
                      <RefreshCw className="h-3.5 w-3.5 mr-1" />
                      Refresh
                    </Button>
                  </div>
                </div>
                
                <TabsContent value="overview" className="space-y-6">
                  {/* Stats Overview - Banking Metrics Row 1 */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/50 dark:to-blue-800/50 border-blue-200 dark:border-blue-800">
                      <CardContent className="p-6">
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="text-sm font-medium text-blue-700 dark:text-blue-300">Total Accounts</p>
                            <p className="text-3xl font-bold text-neutral-900 dark:text-white">{stats?.totalAccounts}</p>
                          </div>
                          <div className="p-3 rounded-full bg-blue-200 dark:bg-blue-700">
                            <CreditCard className="h-6 w-6 text-blue-700 dark:text-blue-200" />
                          </div>
                        </div>
                        <div className="mt-4 text-sm text-blue-700 dark:text-blue-300">
                          <div className="flex justify-between items-center">
                            <span>New Accounts (30d)</span>
                            <span className="font-medium">{stats?.accountsOpened}</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/50 dark:to-green-800/50 border-green-200 dark:border-green-800">
                      <CardContent className="p-6">
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="text-sm font-medium text-green-700 dark:text-green-300">Net Deposits</p>
                            <p className="text-3xl font-bold text-neutral-900 dark:text-white">{formatCurrency(stats?.netDeposits || 0)}</p>
                          </div>
                          <div className="p-3 rounded-full bg-green-200 dark:bg-green-700">
                            <DollarSign className="h-6 w-6 text-green-700 dark:text-green-200" />
                          </div>
                        </div>
                        <div className="mt-4 text-sm text-green-700 dark:text-green-300">
                          <div className="flex justify-between items-center">
                            <span>Average Balance</span>
                            <span className="font-medium">{formatCurrency(stats?.averageAccountBalance || 0)}</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/50 dark:to-purple-800/50 border-purple-200 dark:border-purple-800">
                      <CardContent className="p-6">
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="text-sm font-medium text-purple-700 dark:text-purple-300">Transaction Volume</p>
                            <p className="text-3xl font-bold text-neutral-900 dark:text-white">{formatCurrency(stats?.transactionVolume || 0)}</p>
                          </div>
                          <div className="p-3 rounded-full bg-purple-200 dark:bg-purple-700">
                            <Activity className="h-6 w-6 text-purple-700 dark:text-purple-200" />
                          </div>
                        </div>
                        <div className="mt-4 text-sm text-purple-700 dark:text-purple-300">
                          <div className="flex justify-between items-center">
                            <span>Total Transactions</span>
                            <span className="font-medium">{stats?.totalTransactions}</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="bg-gradient-to-br from-cyan-50 to-cyan-100 dark:from-cyan-900/50 dark:to-cyan-800/50 border-cyan-200 dark:border-cyan-800">
                      <CardContent className="p-6">
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="text-sm font-medium text-cyan-700 dark:text-cyan-300">Total Users</p>
                            <p className="text-3xl font-bold text-neutral-900 dark:text-white">{stats?.totalUsers}</p>
                          </div>
                          <div className="p-3 rounded-full bg-cyan-200 dark:bg-cyan-700">
                            <Users className="h-6 w-6 text-cyan-700 dark:text-cyan-200" />
                          </div>
                        </div>
                        <div className="mt-4 text-sm text-cyan-700 dark:text-cyan-300">
                          <div className="flex justify-between items-center">
                            <span>Active Users</span>
                            <span className="font-medium">{stats?.activeUsers}</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                  
                  {/* Charts Row */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Transaction Volume Chart */}
                    <Card className="shadow dark:shadow-neutral-800">
                      <CardHeader>
                        <CardTitle>Transaction Volume</CardTitle>
                        <CardDescription>Monthly transaction amounts</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="h-80">
                          <ResponsiveContainer width="100%" height="100%">
                            <AreaChart data={transactionData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="name" />
                              <YAxis tickFormatter={(value) => `$${(value / 1000000).toFixed(1)}M`} />
                              <RechartsTooltip formatter={(value: number) => [formatCurrency(value), 'Volume']} />
                              <Area 
                                type="monotone" 
                                dataKey="value" 
                                stroke="#8884d8" 
                                fillOpacity={0.8}
                                fill="url(#colorGradient)" 
                              />
                              <defs>
                                <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                                  <stop offset="5%" stopColor="#8884d8" stopOpacity={0.8}/>
                                  <stop offset="95%" stopColor="#8884d8" stopOpacity={0.1}/>
                                </linearGradient>
                              </defs>
                            </AreaChart>
                          </ResponsiveContainer>
                        </div>
                      </CardContent>
                    </Card>
                    
                    {/* Account Growth & Risk Assessment */}
                    <div className="grid grid-cols-1 gap-6">
                      {/* Daily New Accounts */}
                      <Card className="shadow dark:shadow-neutral-800">
                        <CardHeader className="pb-2">
                          <CardTitle>Daily New Accounts</CardTitle>
                          <CardDescription>Last 7 days</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="h-32">
                            <ResponsiveContainer width="100%" height="100%">
                              <BarChart data={dailyAccountsData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                <XAxis dataKey="day" />
                                <YAxis />
                                <RechartsTooltip formatter={(value: number) => [`${value} accounts`, 'New Accounts']} />
                                <Bar dataKey="accounts" fill="#f59e0b" />
                              </BarChart>
                            </ResponsiveContainer>
                          </div>
                        </CardContent>
                      </Card>
                      
                      {/* Risk Assessment */}
                      <Card className="shadow dark:shadow-neutral-800">
                        <CardHeader className="pb-2">
                          <CardTitle>Account Risk Assessment</CardTitle>
                          <CardDescription>Distribution by risk level</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="h-32">
                            <ResponsiveContainer width="100%" height="100%">
                              <PieChart margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
                                <Pie
                                  data={riskScoreData}
                                  cx="50%"
                                  cy="50%"
                                  innerRadius={25}
                                  outerRadius={50}
                                  fill="#8884d8"
                                  paddingAngle={2}
                                  dataKey="value"
                                >
                                  {riskScoreData.map((entry: any, index: number) => (
                                    <Cell key={`cell-${index}`} fill={RISK_COLORS[index % RISK_COLORS.length]} />
                                  ))}
                                </Pie>
                                <Legend />
                                <RechartsTooltip formatter={(value: number, name: string) => [`${value} accounts`, name]} />
                              </PieChart>
                            </ResponsiveContainer>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                  
                  {/* Actions Required Row */}
                  <div>
                    <h2 className="text-xl font-semibold mb-4 text-neutral-800 dark:text-white">Actions Required</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {/* Pending KYC */}
                      <Card className="shadow-sm border-l-4 border-l-amber-500">
                        <CardHeader className="pb-2">
                          <div className="flex justify-between">
                            <CardTitle className="text-base font-medium flex items-center">
                              <FileCheck className="h-4 w-4 mr-2 text-amber-500" />
                              Pending KYC Verifications
                            </CardTitle>
                            <Badge className="bg-amber-100 text-amber-800">{stats?.pendingKyc}</Badge>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="text-sm">
                            {pendingKycVerifications.slice(0, 3).map((item) => (
                              <div key={item.id} className="py-2 border-b last:border-b-0 flex justify-between items-center">
                                <div>
                                  <p className="font-medium">{item.userName}</p>
                                  <p className="text-xs text-neutral-500 dark:text-neutral-400">
                                    ID: {item.userId} • {item.documentType}
                                  </p>
                                </div>
                                <Badge className="bg-amber-100 text-amber-800 text-xs">
                                  {item.status}
                                </Badge>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                        <CardFooter className="pt-0">
                          <Button variant="link" size="sm" className="text-amber-600 dark:text-amber-400">
                            View all {stats?.pendingKyc} verifications
                          </Button>
                        </CardFooter>
                      </Card>
                      
                      {/* Fraud Alerts */}
                      <Card className="shadow-sm border-l-4 border-l-red-500">
                        <CardHeader className="pb-2">
                          <div className="flex justify-between">
                            <CardTitle className="text-base font-medium flex items-center">
                              <AlertTriangle className="h-4 w-4 mr-2 text-red-500" />
                              Fraud Alerts
                            </CardTitle>
                            <Badge className="bg-red-100 text-red-800">{stats?.fraudAlerts}</Badge>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="text-sm">
                            {fraudAlerts.map((alert) => (
                              <div key={alert.id} className="py-2 border-b last:border-b-0 flex justify-between items-center">
                                <div>
                                  <p className="font-medium">{alert.userName}</p>
                                  <p className="text-xs text-neutral-500 dark:text-neutral-400">
                                    {formatCurrency(alert.amount)} • {alert.transactionType}
                                  </p>
                                </div>
                                <Badge className="bg-red-100 text-red-800 text-xs">
                                  {alert.status}
                                </Badge>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                        <CardFooter className="pt-0">
                          <Button variant="link" size="sm" className="text-red-600 dark:text-red-400">
                            View all {stats?.fraudAlerts} alerts
                          </Button>
                        </CardFooter>
                      </Card>
                      
                      {/* Support Tickets */}
                      <Card className="shadow-sm border-l-4 border-l-blue-500">
                        <CardHeader className="pb-2">
                          <div className="flex justify-between">
                            <CardTitle className="text-base font-medium flex items-center">
                              <HelpCircle className="h-4 w-4 mr-2 text-blue-500" />
                              Support Tickets
                            </CardTitle>
                            <Badge className="bg-blue-100 text-blue-800">{supportTickets.length}</Badge>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="text-sm">
                            {supportTickets.slice(0, 3).map((ticket) => (
                              <div key={ticket.id} className="py-2 border-b last:border-b-0 flex justify-between items-center">
                                <div>
                                  <p className="font-medium">{ticket.subject}</p>
                                  <p className="text-xs text-neutral-500 dark:text-neutral-400">
                                    {ticket.userName} • {ticket.createdAt}
                                  </p>
                                </div>
                                <Badge className={`${
                                  ticket.priority === 'High' 
                                    ? 'bg-red-100 text-red-800'
                                    : ticket.priority === 'Medium'
                                    ? 'bg-amber-100 text-amber-800'
                                    : 'bg-blue-100 text-blue-800'
                                } text-xs`}>
                                  {ticket.priority}
                                </Badge>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                        <CardFooter className="pt-0">
                          <Button variant="link" size="sm" className="text-blue-600 dark:text-blue-400">
                            View all {supportTickets.length} tickets
                          </Button>
                        </CardFooter>
                      </Card>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="applications" className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        <span>Pending Account Applications</span>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                            {pendingApplications.length} pending
                          </Badge>
                          <Button size="sm" variant="outline">
                            <RefreshCw className="h-3.5 w-3.5 mr-1" />
                            Refresh
                          </Button>
                        </div>
                      </CardTitle>
                      <CardDescription>
                        Review and approve new account applications
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      {isLoadingApplications ? (
                        <div className="flex justify-center p-8">
                          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-amber-700"></div>
                        </div>
                      ) : pendingApplications.length === 0 ? (
                        <div className="text-center p-8 border rounded-md border-dashed border-neutral-300 dark:border-neutral-700">
                          <FileCheck className="h-10 w-10 mx-auto text-neutral-400 dark:text-neutral-600 mb-3" />
                          <p className="text-neutral-600 dark:text-neutral-400 font-medium">No pending applications</p>
                          <p className="text-neutral-500 dark:text-neutral-500 text-sm mt-1">
                            All account applications have been processed.
                          </p>
                        </div>
                      ) : (
                        <div className="overflow-auto">
                          <table className="w-full border-collapse">
                            <thead>
                              <tr className="border-b border-neutral-200 dark:border-neutral-700">
                                <th className="text-left p-3 font-medium text-sm">Application ID</th>
                                <th className="text-left p-3 font-medium text-sm">Applicant</th>
                                <th className="text-left p-3 font-medium text-sm">Email</th>
                                <th className="text-left p-3 font-medium text-sm">Phone</th>
                                <th className="text-left p-3 font-medium text-sm">Submitted</th>
                                <th className="text-left p-3 font-medium text-sm">Status</th>
                                <th className="text-right p-3 font-medium text-sm">Actions</th>
                              </tr>
                            </thead>
                            <tbody>
                              {pendingApplications.map((app) => (
                                <tr key={app.id} className="border-b border-neutral-200 dark:border-neutral-700 hover:bg-neutral-50 dark:hover:bg-neutral-800/50">
                                  <td className="p-3">
                                    <span className="font-mono text-xs bg-neutral-100 dark:bg-neutral-800 p-1 rounded">
                                      {app.applicationNumber}
                                    </span>
                                  </td>
                                  <td className="p-3 font-medium">{app.fullName}</td>
                                  <td className="p-3">{app.email}</td>
                                  <td className="p-3">{app.phone}</td>
                                  <td className="p-3">{app.submittedAt}</td>
                                  <td className="p-3">
                                    <Badge className="bg-amber-100 text-amber-800 border-amber-200">
                                      {app.status}
                                    </Badge>
                                  </td>
                                  <td className="p-3 text-right space-x-2">
                                    <Button 
                                      size="sm" 
                                      variant="outline" 
                                      onClick={() => {
                                        console.log("View application with ID:", app.id);
                                        handleViewApplication(app);
                                      }}
                                    >
                                      View
                                    </Button>
                                    <Button 
                                      size="sm" 
                                      variant="default" 
                                      className="bg-green-600 hover:bg-green-700"
                                      onClick={() => handleApproveApplication(app.id)}
                                    >
                                      Approve
                                    </Button>
                                    <Button size="sm" variant="destructive">
                                      Deny
                                    </Button>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="user-management" className="space-y-6">
                  <Card>
                    <CardHeader>
                      <div className="flex justify-between">
                        <div>
                          <CardTitle>User Management</CardTitle>
                          <CardDescription>View, manage and monitor all banking users</CardDescription>
                        </div>
                        <Button className="bg-amber-600 hover:bg-amber-700">
                          <UserPlus className="h-4 w-4 mr-2" />
                          Add New User
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="flex justify-between items-center mb-4">
                        <div className="relative w-64">
                          <input 
                            type="text" 
                            placeholder="Search users..." 
                            className="w-full py-2 pl-9 pr-4 rounded-md border border-neutral-300 dark:border-neutral-600 bg-white dark:bg-neutral-700 text-sm"
                          />
                          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-neutral-400" />
                        </div>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm" className="flex items-center">
                            <Filter className="h-4 w-4 mr-1" />
                            Filter
                          </Button>
                          <Button variant="outline" size="sm" className="flex items-center">
                            <Download className="h-4 w-4 mr-1" />
                            Export
                          </Button>
                        </div>
                      </div>
                      
                      <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-neutral-200 dark:divide-neutral-700">
                          <thead className="bg-neutral-50 dark:bg-neutral-800">
                            <tr>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
                                User
                              </th>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
                                Email
                              </th>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
                                Status
                              </th>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
                                Registration Date
                              </th>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
                                Last Login
                              </th>
                              <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
                                Actions
                              </th>
                            </tr>
                          </thead>
                          <tbody className="bg-white dark:bg-neutral-800 divide-y divide-neutral-200 dark:divide-neutral-700">
                            {recentUsers.map((user) => (
                              <tr key={user.id} className="hover:bg-neutral-50 dark:hover:bg-neutral-750">
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <div className="flex items-center">
                                    <Avatar className="h-8 w-8 mr-3">
                                      <AvatarFallback className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300">
                                        {user.name.split(' ').map((n: string) => n[0]).join('')}
                                      </AvatarFallback>
                                    </Avatar>
                                    <div>
                                      <div className="text-sm font-medium text-neutral-900 dark:text-neutral-100">{user.name}</div>
                                      <div className="text-xs text-neutral-500 dark:text-neutral-400">ID: {user.id}</div>
                                    </div>
                                  </div>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500 dark:text-neutral-400">
                                  {user.email}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <Badge className={
                                    user.status === 'Active' 
                                      ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300'
                                      : user.status === 'Pending KYC'
                                      ? 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-300' 
                                      : 'bg-neutral-100 text-neutral-800 dark:bg-neutral-700 dark:text-neutral-300'
                                  }>
                                    {user.status}
                                  </Badge>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500 dark:text-neutral-400">
                                  {user.registrationDate}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500 dark:text-neutral-400">
                                  {user.lastLogin}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                  <Button variant="ghost" size="sm">View</Button>
                                  <Button variant="ghost" size="sm">Edit</Button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="compliance" className="space-y-6">
                  <Card>
                    <CardHeader>
                      <div className="flex justify-between">
                        <div>
                          <CardTitle>KYC Verification Management</CardTitle>
                          <CardDescription>Process and validate customer identity verifications</CardDescription>
                        </div>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm" className="flex items-center">
                            <Filter className="h-4 w-4 mr-1" />
                            Filter
                          </Button>
                          <select className="bg-white dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-600 text-sm rounded-md px-2">
                            <option>All Statuses</option>
                            <option>Pending</option>
                            <option>Approved</option>
                            <option>Rejected</option>
                          </select>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-neutral-200 dark:divide-neutral-700">
                          <thead className="bg-neutral-50 dark:bg-neutral-800">
                            <tr>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
                                User
                              </th>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
                                Document Type
                              </th>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
                                Submitted Date
                              </th>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
                                Status
                              </th>
                              <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
                                Actions
                              </th>
                            </tr>
                          </thead>
                          <tbody className="bg-white dark:bg-neutral-800 divide-y divide-neutral-200 dark:divide-neutral-700">
                            {pendingKycVerifications.map((verification) => (
                              <tr key={verification.id} className="hover:bg-neutral-50 dark:hover:bg-neutral-750">
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <div className="flex items-center">
                                    <Avatar className="h-8 w-8 mr-3">
                                      <AvatarFallback className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300">
                                        {verification.userName.split(' ').map((n: string) => n[0]).join('')}
                                      </AvatarFallback>
                                    </Avatar>
                                    <div>
                                      <div className="text-sm font-medium text-neutral-900 dark:text-neutral-100">
                                        {verification.userName}
                                      </div>
                                      <div className="text-xs text-neutral-500 dark:text-neutral-400">
                                        ID: {verification.userId}
                                      </div>
                                    </div>
                                  </div>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500 dark:text-neutral-400">
                                  {verification.documentType}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500 dark:text-neutral-400">
                                  {verification.submittedDate}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <Badge className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-300">
                                    {verification.status}
                                  </Badge>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                  <Button variant="outline" size="sm" className="mr-2">View Documents</Button>
                                  <Button size="sm" className="bg-green-600 hover:bg-green-700 mr-1">Approve</Button>
                                  <Button variant="destructive" size="sm">Reject</Button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="fraud" className="space-y-6">
                  <Card>
                    <CardHeader>
                      <div className="flex justify-between">
                        <div>
                          <CardTitle>Fraud Alert Management</CardTitle>
                          <CardDescription>Review and manage potentially suspicious activity</CardDescription>
                        </div>
                        <div className="flex space-x-2">
                          <Button className="bg-red-600 hover:bg-red-700">
                            <AlertTriangle className="h-4 w-4 mr-1" />
                            Create Alert
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-neutral-200 dark:divide-neutral-700">
                          <thead className="bg-neutral-50 dark:bg-neutral-800">
                            <tr>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
                                Account / User
                              </th>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
                                Amount
                              </th>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
                                Transaction Type
                              </th>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
                                Timestamp
                              </th>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
                                Status
                              </th>
                              <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
                                Actions
                              </th>
                            </tr>
                          </thead>
                          <tbody className="bg-white dark:bg-neutral-800 divide-y divide-neutral-200 dark:divide-neutral-700">
                            {fraudAlerts.map((alert) => (
                              <tr key={alert.id} className="hover:bg-neutral-50 dark:hover:bg-neutral-750">
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <div className="flex items-center">
                                    <div className="p-2 bg-red-100 rounded-full mr-3">
                                      <AlertTriangle className="h-4 w-4 text-red-600" />
                                    </div>
                                    <div>
                                      <div className="text-sm font-medium text-neutral-900 dark:text-neutral-100">
                                        {alert.userName}
                                      </div>
                                      <div className="text-xs text-neutral-500 dark:text-neutral-400">
                                        Account ID: {alert.accountId}
                                      </div>
                                    </div>
                                  </div>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <div className="text-sm font-medium text-red-600 dark:text-red-400">
                                    {formatCurrency(alert.amount)}
                                  </div>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500 dark:text-neutral-400">
                                  {alert.transactionType}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500 dark:text-neutral-400">
                                  {formatTimestamp(alert.timestamp)}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300">
                                    {alert.status}
                                  </Badge>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                  <Button variant="outline" size="sm" className="mr-2">Investigate</Button>
                                  <Button variant="ghost" size="sm" className="text-green-600 hover:text-green-500 mr-1">
                                    <CheckCircle className="h-4 w-4" />
                                  </Button>
                                  <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-500">
                                    <XCircle className="h-4 w-4" />
                                  </Button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="support" className="space-y-6">
                  <Card>
                    <CardHeader>
                      <div className="flex justify-between">
                        <div>
                          <CardTitle>Support Ticket Management</CardTitle>
                          <CardDescription>Manage and resolve customer support inquiries</CardDescription>
                        </div>
                        <div className="flex space-x-2">
                          <select className="bg-white dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-600 text-sm rounded-md px-2">
                            <option>All Tickets</option>
                            <option>Open</option>
                            <option>In Progress</option>
                            <option>Resolved</option>
                          </select>
                          <select className="bg-white dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-600 text-sm rounded-md px-2">
                            <option>All Priorities</option>
                            <option>High</option>
                            <option>Medium</option>
                            <option>Low</option>
                          </select>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-neutral-200 dark:divide-neutral-700">
                          <thead className="bg-neutral-50 dark:bg-neutral-800">
                            <tr>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
                                Ticket
                              </th>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
                                User
                              </th>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
                                Created
                              </th>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
                                Priority
                              </th>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
                                Status
                              </th>
                              <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
                                Actions
                              </th>
                            </tr>
                          </thead>
                          <tbody className="bg-white dark:bg-neutral-800 divide-y divide-neutral-200 dark:divide-neutral-700">
                            {supportTickets.map((ticket) => (
                              <tr key={ticket.id} className="hover:bg-neutral-50 dark:hover:bg-neutral-750">
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <div className="flex items-center">
                                    <div className={`p-2 rounded-full mr-3 ${
                                      ticket.priority === 'High' 
                                        ? 'bg-red-100 text-red-600'
                                        : ticket.priority === 'Medium'
                                        ? 'bg-amber-100 text-amber-600'
                                        : 'bg-blue-100 text-blue-600'
                                    }`}>
                                      <HelpCircle className="h-4 w-4" />
                                    </div>
                                    <div>
                                      <div className="text-sm font-medium text-neutral-900 dark:text-neutral-100">
                                        {ticket.subject}
                                      </div>
                                      <div className="text-xs text-neutral-500 dark:text-neutral-400">
                                        Ticket #{ticket.id}
                                      </div>
                                    </div>
                                  </div>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500 dark:text-neutral-400">
                                  {ticket.userName}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500 dark:text-neutral-400">
                                  {ticket.createdAt}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <Badge className={`${
                                    ticket.priority === 'High' 
                                      ? 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300'
                                      : ticket.priority === 'Medium'
                                      ? 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-300' 
                                      : 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300'
                                  }`}>
                                    {ticket.priority}
                                  </Badge>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300">
                                    {ticket.status}
                                  </Badge>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                  <Button variant="outline" size="sm" className="mr-2">View</Button>
                                  <Button size="sm" className="bg-blue-600 hover:bg-blue-700 mr-1">Assign</Button>
                                  <Button variant="ghost" size="sm" className="text-green-600 hover:text-green-500">
                                    <CheckCircle className="h-4 w-4" />
                                  </Button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}