import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import {
  FileText,
  Search,
  Filter,
  FileCheck,
  DownloadCloud,
  AlertTriangle,
  Lock,
  Shield,
  Users,
  PieChart,
  BarChart,
  Clock,
  Calendar,
  CheckCircle,
  X,
  Trash2,
  FileLock2,
  ShieldAlert,
  Download,
  ExternalLink
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import SecureDocumentViewer from "@/components/secure-document-viewer";
import { getKycDocumentUrl, getApplicationDocumentUrl, downloadDocument } from "@/lib/document-utils";

// Types for document management
type DocumentSecurityLevel = 'standard' | 'sensitive' | 'critical';
type DocumentStatus = 'active' | 'expired' | 'revoked' | 'pending_verification';
type DocumentCategory = 'kyc' | 'application' | 'statements' | 'agreements' | 'other';

interface BankDocument {
  id: string;
  fileName: string;
  documentType: string;
  category: DocumentCategory;
  uploadDate: string;
  expiryDate?: string;
  status: DocumentStatus;
  securityLevel: DocumentSecurityLevel;
  entityType: 'user' | 'application' | 'account';
  entityId: number;
  entityName: string;
  fileSize: number;
  mimeType: string;
  lastAccessed?: string;
  accessCount: number;
  verificationStatus?: string;
  hasFlags: boolean;
  tags: string[];
}

// Mock data for document types and tags
const DOCUMENT_TYPES = [
  'ID Card Front', 'ID Card Back', 'Passport', "Driver's License",
  'Proof of Address', 'Bank Statement', 'Utility Bill',
  'Employment Verification', 'Income Verification',
  'Account Agreement', 'Terms of Service', 'Privacy Policy',
  'Loan Application', 'Mortgage Document', 'Credit Application'
];

const DOCUMENT_TAGS = [
  'primary_id', 'secondary_id', 'address_verification',
  'financial', 'compliance', 'legal', 'onboarding',
  'high_risk', 'regulatory', 'expired', 'unverified'
];

export default function DocumentCenter() {
  const [activeTab, setActiveTab] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDocument, setSelectedDocument] = useState<BankDocument | null>(null);
  const [isDocumentDialogOpen, setIsDocumentDialogOpen] = useState(false);
  const [isAuditLogOpen, setIsAuditLogOpen] = useState(false);
  const { toast } = useToast();
  
  // Fetch documents from API
  const { data: documents = [], isLoading } = useQuery<BankDocument[]>({
    queryKey: ["/api/admin/documents"],
    refetchOnWindowFocus: false,
  });
  
  // Filter documents based on tab and search query
  const filteredDocuments = documents.filter(doc => {
    const matchesTab = 
      (activeTab === 'kyc' && doc.category === 'kyc') ||
      (activeTab === 'applications' && doc.category === 'application') ||
      (activeTab === 'flagged' && doc.hasFlags) ||
      (activeTab === 'critical' && doc.securityLevel === 'critical') ||
      activeTab === 'all';
    
    const matchesSearch = 
      searchQuery === '' || 
      doc.fileName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.documentType.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.entityName.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesTab && matchesSearch;
  });
  
  // Function to get document URL based on category and type
  const getDocumentUrl = (doc: BankDocument) => {
    if (doc.category === 'kyc') {
      return getKycDocumentUrl(doc.entityId, doc.documentType.toLowerCase().replace(' ', '-'));
    } else if (doc.category === 'application') {
      return getApplicationDocumentUrl(doc.entityId, doc.documentType.toLowerCase().replace(' ', '-')); 
    }
    return undefined;
  };
  
  // Function to format file size
  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };
  
  // Function to handle document download
  const handleDownload = async (doc: BankDocument) => {
    try {
      const url = getDocumentUrl(doc);
      if (!url) {
        toast({
          title: "Download Failed",
          description: "Document URL could not be generated",
          variant: "destructive"
        });
        return;
      }
      
      await downloadDocument(url, doc.fileName);
      
      toast({
        title: "Download Started",
        description: `${doc.fileName} is being downloaded`,
      });
      
      // Log download for audit in a real bank application
      console.log(`[AUDIT] Document download: ${doc.id} by admin user`);
    } catch (error) {
      console.error('Download error:', error);
      toast({
        title: "Download Failed",
        description: "There was an error downloading the document",
        variant: "destructive"
      });
    }
  };
  
  // Function to view document details
  const viewDocument = (doc: BankDocument) => {
    setSelectedDocument(doc);
    setIsDocumentDialogOpen(true);
    
    // Log document access for compliance in a real bank application
    console.log(`[COMPLIANCE] Document viewed: ${doc.id} by admin user`);
  };
  
  // Statuses and security levels with appropriate colors
  const getStatusBadge = (status: DocumentStatus) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-100 text-green-800">Active</Badge>;
      case 'expired':
        return <Badge className="bg-amber-100 text-amber-800">Expired</Badge>;
      case 'revoked':
        return <Badge className="bg-red-100 text-red-800">Revoked</Badge>;
      case 'pending_verification':
        return <Badge className="bg-blue-100 text-blue-800">Pending Verification</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };
  
  const getSecurityBadge = (level: DocumentSecurityLevel) => {
    switch (level) {
      case 'standard':
        return <Badge className="bg-gray-100 text-gray-800">Standard</Badge>;
      case 'sensitive':
        return <Badge className="bg-yellow-100 text-yellow-800">Sensitive</Badge>;
      case 'critical':
        return <Badge className="bg-red-100 text-red-800">Critical</Badge>;
      default:
        return <Badge>{level}</Badge>;
    }
  };
  
  // Mock audit log data
  const auditLogData = selectedDocument ? [
    { 
      timestamp: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
      action: 'view',
      user: 'Admin User',
      ipAddress: '192.168.1.1',
      details: 'Document viewed for compliance review'
    },
    { 
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
      action: 'download',
      user: 'System',
      ipAddress: '10.0.0.5',
      details: 'Automated document backup'
    },
    { 
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
      action: 'verify',
      user: 'Compliance Dept',
      ipAddress: '192.168.1.25',
      details: 'Document verified - passed all checks'
    },
    { 
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2).toISOString(),
      action: 'upload',
      user: selectedDocument.entityName,
      ipAddress: '73.125.22.16',
      details: 'Initial document upload'
    }
  ] : [];
  
  return (
    <div className="container mx-auto p-6">
      <div className="flex flex-col lg:flex-row justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold mb-2">Document Center</h1>
          <p className="text-muted-foreground">Manage and review all banking documents securely</p>
        </div>
        <div className="flex items-center mt-4 lg:mt-0 space-x-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search documents..."
              className="pl-9 w-[250px]"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button variant="outline" className="flex items-center">
            <Filter className="h-4 w-4 mr-2" />
            Filters
          </Button>
          <Button>
            <Shield className="h-4 w-4 mr-2" />
            Compliance Report
          </Button>
        </div>
      </div>
      
      <Card>
        <CardHeader className="pb-0">
          <Tabs defaultValue={activeTab} value={activeTab} onValueChange={setActiveTab}>
            <div className="flex justify-between items-center">
              <TabsList>
                <TabsTrigger value="all">All Documents</TabsTrigger>
                <TabsTrigger value="kyc">KYC Documents</TabsTrigger>
                <TabsTrigger value="applications">Applications</TabsTrigger>
                <TabsTrigger value="flagged">Flagged</TabsTrigger>
                <TabsTrigger value="critical">Critical</TabsTrigger>
              </TabsList>
              
              <div className="flex items-center text-sm text-muted-foreground">
                <Lock className="h-4 w-4 mr-1" />
                <span>Bank-grade encryption active</span>
              </div>
            </div>
          </Tabs>
        </CardHeader>
        
        <CardContent className="pt-6">
          {isLoading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
            </div>
          ) : filteredDocuments.length === 0 ? (
            <div className="text-center py-12">
              <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">No Documents Found</h3>
              <p className="text-muted-foreground mb-4">
                {searchQuery 
                  ? "Try adjusting your search parameters" 
                  : "There are no documents in this category"}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>File Name</TableHead>
                    <TableHead>User/Entity</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Upload Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Security</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredDocuments.map((doc) => (
                    <TableRow key={doc.id}>
                      <TableCell className="font-medium">
                        <div className="flex items-center">
                          <div className="h-8 w-8 rounded-md bg-neutral-100 flex items-center justify-center mr-2">
                            <FileText className="h-4 w-4 text-neutral-500" />
                          </div>
                          <div>
                            <div className="font-medium">{doc.fileName}</div>
                            <div className="text-xs text-muted-foreground">{formatFileSize(doc.fileSize)}</div>
                          </div>
                          {doc.hasFlags && (
                            <AlertTriangle className="h-4 w-4 text-amber-500 ml-2" />
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <div className="h-7 w-7 rounded-full bg-primary/10 flex items-center justify-center mr-2">
                            <Users className="h-3 w-3 text-primary" />
                          </div>
                          <span>{doc.entityName}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className="capitalize">{doc.documentType}</span>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <Calendar className="h-3 w-3 mr-1 text-muted-foreground" />
                          <span>{new Date(doc.uploadDate).toLocaleDateString()}</span>
                        </div>
                      </TableCell>
                      <TableCell>{getStatusBadge(doc.status)}</TableCell>
                      <TableCell>{getSecurityBadge(doc.securityLevel)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => viewDocument(doc)}
                          >
                            <FileCheck className="h-4 w-4 mr-1" />
                            View
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleDownload(doc)}
                          >
                            <DownloadCloud className="h-4 w-4 mr-1" />
                            Download
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
      
      {selectedDocument && (
        <Dialog open={isDocumentDialogOpen} onOpenChange={setIsDocumentDialogOpen}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Document Details</DialogTitle>
            </DialogHeader>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-4">
              {/* Document Preview */}
              <div className="md:col-span-2">
                <h3 className="text-lg font-medium mb-2">Document Preview</h3>
                <div className="rounded-md overflow-hidden border bg-neutral-50 dark:bg-neutral-900 min-h-[300px]">
                  <SecureDocumentViewer
                    documentUrl={getDocumentUrl(selectedDocument)}
                    documentType={selectedDocument.documentType.includes("Front") ? "id-front" : 
                                  selectedDocument.documentType.includes("Back") ? "id-back" : 
                                  selectedDocument.documentType.includes("Selfie") ? "selfie" : "other"}
                    fileName={selectedDocument.fileName}
                    height="h-[300px]"
                    metadata={{
                      documentType: selectedDocument.documentType
                    }}
                  />
                </div>
                
                <div className="mt-4 flex justify-between">
                  <Button 
                    variant="outline" 
                    onClick={() => setIsAuditLogOpen(true)}
                  >
                    <Clock className="h-4 w-4 mr-2" />
                    View Audit Log
                  </Button>
                  
                  <div className="space-x-2">
                    <Button 
                      variant="outline"
                      onClick={() => handleDownload(selectedDocument)}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                    <Button>
                      <FileCheck className="h-4 w-4 mr-2" />
                      Re-Verify Document
                    </Button>
                  </div>
                </div>
              </div>
              
              {/* Document Information */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Document Information</h3>
                
                <div className="space-y-3">
                  <div>
                    <p className="text-sm text-muted-foreground">File Name</p>
                    <p className="font-medium">{selectedDocument.fileName}</p>
                  </div>
                  
                  <div>
                    <p className="text-sm text-muted-foreground">Document Type</p>
                    <p className="font-medium">{selectedDocument.documentType}</p>
                  </div>
                  
                  <div>
                    <p className="text-sm text-muted-foreground">Category</p>
                    <p className="font-medium capitalize">{selectedDocument.category}</p>
                  </div>
                  
                  <div>
                    <p className="text-sm text-muted-foreground">Uploaded</p>
                    <p className="font-medium">{new Date(selectedDocument.uploadDate).toLocaleString()}</p>
                  </div>
                  
                  {selectedDocument.expiryDate && (
                    <div>
                      <p className="text-sm text-muted-foreground">Expires</p>
                      <p className="font-medium">{new Date(selectedDocument.expiryDate).toLocaleDateString()}</p>
                    </div>
                  )}
                  
                  <div>
                    <p className="text-sm text-muted-foreground">Status</p>
                    <div>{getStatusBadge(selectedDocument.status)}</div>
                  </div>
                  
                  <div>
                    <p className="text-sm text-muted-foreground">Security Level</p>
                    <div>{getSecurityBadge(selectedDocument.securityLevel)}</div>
                  </div>
                  
                  <div>
                    <p className="text-sm text-muted-foreground">Entity</p>
                    <p className="font-medium">
                      {selectedDocument.entityName} ({selectedDocument.entityType} #{selectedDocument.entityId})
                    </p>
                  </div>
                  
                  <div>
                    <p className="text-sm text-muted-foreground">File Size</p>
                    <p className="font-medium">{formatFileSize(selectedDocument.fileSize)}</p>
                  </div>
                  
                  {selectedDocument.lastAccessed && (
                    <div>
                      <p className="text-sm text-muted-foreground">Last Accessed</p>
                      <p className="font-medium">{new Date(selectedDocument.lastAccessed).toLocaleString()}</p>
                    </div>
                  )}
                  
                  <div>
                    <p className="text-sm text-muted-foreground">Access Count</p>
                    <p className="font-medium">{selectedDocument.accessCount} times</p>
                  </div>
                  
                  {selectedDocument.verificationStatus && (
                    <div>
                      <p className="text-sm text-muted-foreground">Verification</p>
                      <p className="font-medium">{selectedDocument.verificationStatus}</p>
                    </div>
                  )}
                  
                  {selectedDocument.tags && selectedDocument.tags.length > 0 && (
                    <div>
                      <p className="text-sm text-muted-foreground">Tags</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {selectedDocument.tags.map(tag => (
                          <Badge key={tag} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            <DialogFooter className="flex justify-between mt-6">
              <Button 
                variant="destructive" 
                className="flex items-center"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Remove Document
              </Button>
              
              <Button 
                onClick={() => setIsDocumentDialogOpen(false)}
              >
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
      
      {/* Audit Log Dialog */}
      <Dialog open={isAuditLogOpen} onOpenChange={setIsAuditLogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <FileLock2 className="h-5 w-5 mr-2" />
              Document Audit Log
            </DialogTitle>
          </DialogHeader>
          
          <div className="mt-4">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h4 className="font-medium">{selectedDocument?.fileName}</h4>
                <p className="text-sm text-muted-foreground">Security audit trail for document access and modifications</p>
              </div>
              
              <Button variant="outline" size="sm">
                <DownloadCloud className="h-4 w-4 mr-2" />
                Export Audit Log
              </Button>
            </div>
            
            <div className="border rounded-md">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Timestamp</TableHead>
                    <TableHead>Action</TableHead>
                    <TableHead>User</TableHead>
                    <TableHead>IP Address</TableHead>
                    <TableHead>Details</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {auditLogData.map((entry, index) => (
                    <TableRow key={index}>
                      <TableCell>
                        <div className="text-sm">{new Date(entry.timestamp).toLocaleDateString()}</div>
                        <div className="text-xs text-muted-foreground">{new Date(entry.timestamp).toLocaleTimeString()}</div>
                      </TableCell>
                      <TableCell>
                        <Badge className={
                          entry.action === 'view' ? 'bg-blue-100 text-blue-800' :
                          entry.action === 'download' ? 'bg-purple-100 text-purple-800' :
                          entry.action === 'verify' ? 'bg-green-100 text-green-800' :
                          entry.action === 'upload' ? 'bg-amber-100 text-amber-800' :
                          'bg-gray-100 text-gray-800'
                        }>
                          {entry.action.charAt(0).toUpperCase() + entry.action.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>{entry.user}</TableCell>
                      <TableCell>
                        <span className="font-mono text-xs">{entry.ipAddress}</span>
                      </TableCell>
                      <TableCell>{entry.details}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
          
          <DialogFooter className="mt-6">
            <Button 
              variant="outline" 
              onClick={() => setIsAuditLogOpen(false)}
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}