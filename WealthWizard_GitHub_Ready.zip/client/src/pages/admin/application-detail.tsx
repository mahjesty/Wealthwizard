import { useParams, Link, Route } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { 
  Loader2, ArrowLeft, Check, X, Shield, Clock, UserPlus, FileText, 
  AlertTriangle, User, MapPin, Phone, Calendar, DollarSign, Briefcase, 
  Eye, Mail, Landmark, CreditCard, Building, Award, Wallet, GraduationCap,
  Info, Globe, Flag, Banknote, Home, CreditCard as IdCard 
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAdminAuth } from "@/hooks/use-admin-auth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbSeparator } from "@/components/ui/breadcrumb";
import SecureDocumentViewer from "@/components/secure-document-viewer";
import { getKycDocumentUrl } from "@/lib/document-utils";

// Type definitions based on the backend response
interface ApplicationData {
  // Personal Information
  firstName: string;
  lastName: string;
  middleName?: string;
  dateOfBirth: string;
  ssn: string;
  citizenshipStatus: "usCitizen" | "usResident" | "nonResident" | string;
  
  // Contact Information
  phoneNumber: string;
  streetAddress: string;
  aptSuite?: string;
  city: string;
  state: string;
  zipCode: string;
  country?: string;
  
  // Employment Information
  employmentStatus: "employed" | "selfEmployed" | "retired" | "student" | "unemployed" | "other" | string;
  employerName?: string;
  industryType?: string;
  occupation?: string;
  annualIncome: string;
  sourceOfFunds?: string;
  
  // Banking Details
  accountType: string;
  accountPurpose: string;
  expectedMonthlyDeposits?: string;
  expectedMonthlyWithdrawals?: string;
  interestedInProducts?: string[] | string;
  digitalBankingPreference?: string;
  
  // Additional Information
  howDidYouHear?: string;
  
  // Catch-all for any other fields
  [key: string]: any;
}

interface AccessLog {
  id: number;
  accessId: string;
  documentPath: string;
  accessedAt: string;
  accessedBy: number;
  accessMethod: string;
  accessStatus: string;
  ipAddress: string;
  userAgent: string;
  browserInfo: string;
  purpose: string;
  isAdminAccess: boolean;
}

interface Application {
  id: number;
  applicationNumber: string;
  status: string;
  contactEmail: string;
  contactPhone: string | null;
  submittedAt: string;
  lastUpdatedAt: string;
  reviewedAt: string | null;
  reviewerId: number | null;
  reviewNotes: string | null;
  applicationData: ApplicationData;
  ipAddress: string;
  deviceInfo: string | null;
  reasonForDenial: string | null;
  userId: number | null;
  notifyViaEmail: boolean;
  notifyViaSms: boolean;
}

interface ApplicationDetailResponse {
  application: Application;
  accessLogs: AccessLog[];
  metadata: {
    accessedAt: string;
    accessedBy: {
      id: number;
      name: string;
    }
  }
}

// Status badge component
const StatusBadge = ({ status }: { status: string }) => {
  switch (status) {
    case "pending_review":
      return <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">Pending Review</Badge>;
    case "approved":
      return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Approved</Badge>;
    case "denied":
      return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Denied</Badge>;
    case "on_hold":
      return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">On Hold</Badge>;
    case "incomplete":
      return <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">Incomplete</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
};

// Field group component for consistent UI
const FieldGroup = ({ label, value, icon }: { label: string; value: string | null | undefined; icon?: React.ReactNode }) => (
  <div className="flex items-start mb-3">
    {icon && <div className="mt-0.5 mr-2 text-amber-700">{icon}</div>}
    <div>
      <div className="text-sm font-medium text-amber-900">{label}</div>
      <div className="text-sm">{value || "Not provided"}</div>
    </div>
  </div>
);

// Helper function to navigate to other pages without useNavigate
const navigateTo = (path: string) => {
  window.location.href = path;
};

export default function ApplicationDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { adminUser, isAuthenticated } = useAdminAuth();

  // Determine if this is an application number (starts with APP-) or a numeric ID
  const isApplicationNumber = id && id.startsWith('APP-');
  
  // Fetch application details based on ID type
  const {
    data,
    isLoading,
    isError,
    error,
    refetch
  } = useQuery<ApplicationDetailResponse>({
    queryKey: [isApplicationNumber ? `/api/admin/account-applications/by-number/${id}` : `/api/admin/account-applications/${id}`],
    queryFn: async () => {
      const res = await apiRequest(
        "GET",
        isApplicationNumber 
          ? `/api/admin/account-applications/by-number/${id}`
          : `/api/admin/account-applications/${id}`
      );
      return res.json();
    },
    enabled: !!id && !!adminUser?.id, // Only fetch if we have an ID and admin user is available
  });

  // Mutations for application actions
  const approveMutation = useMutation({
    mutationFn: async ({ notes }: { notes: string }) => {
      const res = await apiRequest(
        "POST",
        `/api/admin/account-applications/${id}/approve`,
        { notes }
      );
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Application Approved",
        description: "The application has been successfully approved.",
        variant: "success",
      });
      queryClient.invalidateQueries({
        queryKey: [`/api/admin/account-applications/${id}`],
      });
      queryClient.invalidateQueries({
        queryKey: ["/api/admin/account-applications"],
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to approve application: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const denyMutation = useMutation({
    mutationFn: async ({
      notes,
      reason,
    }: {
      notes: string;
      reason: string;
    }) => {
      const res = await apiRequest(
        "POST",
        `/api/admin/account-applications/${id}/deny`,
        { notes, reason }
      );
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Application Denied",
        description: "The application has been denied.",
        variant: "warning",
      });
      queryClient.invalidateQueries({
        queryKey: [`/api/admin/account-applications/${id}`],
      });
      queryClient.invalidateQueries({
        queryKey: ["/api/admin/account-applications"],
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to deny application: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const createUserMutation = useMutation({
    mutationFn: async ({
      username,
      password,
    }: {
      username: string;
      password: string;
    }) => {
      const res = await apiRequest(
        "POST",
        `/api/admin/account-applications/${id}/create-user`,
        { username, password }
      );
      return res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "User Created",
        description: `User ${data.user.username} has been successfully created.`,
        variant: "success",
      });
      queryClient.invalidateQueries({
        queryKey: [`/api/admin/account-applications/${id}`],
      });
      queryClient.invalidateQueries({
        queryKey: ["/api/admin/account-applications"],
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to create user: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // If not authenticated or loading, show loading spinner
  if (!isAuthenticated || !adminUser) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-amber-600" />
        <span className="ml-2">Verifying admin credentials...</span>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="container mx-auto py-6">
        <div className="flex justify-center items-center min-h-[50vh]">
          <Loader2 className="h-8 w-8 animate-spin text-amber-600" />
          <span className="ml-2 text-amber-800">Loading application details...</span>
        </div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="container mx-auto py-6">
        <div className="flex flex-col items-center justify-center min-h-[50vh]">
          <AlertTriangle className="h-12 w-12 text-red-500 mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Failed to load application</h2>
          <p className="text-gray-600 mb-4">{(error as Error)?.message || "An unknown error occurred"}</p>
          <div className="flex space-x-4">
            <Button
              variant="outline"
              onClick={() => refetch()}
              className="border-amber-200 hover:bg-amber-50"
            >
              Try Again
            </Button>
            <Button
              variant="outline"
              onClick={() => navigateTo("/admin/applications")}
              className="border-amber-200 hover:bg-amber-50"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Applications
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const application = data?.application;
  if (!application) {
    return (
      <div className="container mx-auto py-6">
        <div className="flex flex-col items-center justify-center min-h-[50vh]">
          <AlertTriangle className="h-12 w-12 text-red-500 mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Application not found</h2>
          <p className="text-gray-600 mb-4">The application you're looking for doesn't exist or has been removed.</p>
          <Button
            variant="outline"
            onClick={() => navigateTo("/admin/applications")}
            className="border-amber-200 hover:bg-amber-50"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Applications
          </Button>
        </div>
      </div>
    );
  }

  const appData = application.applicationData || {};
  const accessLogs = data?.accessLogs || [];
  
  // Helper function to format citizenship status
  const formatCitizenshipStatus = (status: string) => {
    switch (status) {
      case "usCitizen": return "US Citizen";
      case "usResident": return "US Permanent Resident";
      case "nonResident": return "Non-Resident";
      default: return status;
    }
  };

  // Helper function to format employment status
  const formatEmploymentStatus = (status: string) => {
    switch (status) {
      case "employed": return "Employed";
      case "selfEmployed": return "Self-Employed";
      case "student": return "Student";
      case "retired": return "Retired";
      case "unemployed": return "Unemployed";
      case "other": return "Other";
      default: return status;
    }
  };

  return (
    <div className="container mx-auto py-6 space-y-6">
      {/* Breadcrumb navigation */}
      <Breadcrumb className="mb-4">
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink href="/admin/dashboard" className="text-amber-700">Dashboard</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink href="/admin/applications" className="text-amber-700">Applications</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink className="text-amber-900 font-medium">
              {application.applicationNumber}
            </BreadcrumbLink>
          </BreadcrumbItem>
        </BreadcrumbList>
      </Breadcrumb>

      {/* Header section with application status */}
      <div className="flex flex-col lg:flex-row justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center">
            <FileText className="mr-2 h-6 w-6 text-amber-700" />
            Application {application.applicationNumber}
          </h1>
          <p className="text-gray-600">
            Submitted {format(new Date(application.submittedAt), "MMMM d, yyyy 'at' h:mm a")}
          </p>
        </div>

        <div className="flex items-center space-x-3">
          {/* Back button */}
          <Button
            variant="outline"
            onClick={() => navigateTo("/admin/applications")}
            className="border-amber-200 hover:bg-amber-50"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to List
          </Button>

          {/* Action buttons based on application status */}
          {application.status === "pending_review" && (
            <>
              <Button
                variant="outline"
                className="border-green-200 bg-green-50 hover:bg-green-100 text-green-700"
                onClick={() => {
                  const notes = prompt("Enter approval notes (optional):");
                  if (notes !== null) { // Only if not canceled
                    approveMutation.mutate({ notes });
                  }
                }}
              >
                <Check className="mr-2 h-4 w-4" />
                Approve
              </Button>
              <Button
                variant="outline"
                className="border-red-200 bg-red-50 hover:bg-red-100 text-red-700"
                onClick={() => {
                  const reason = prompt("Enter reason for denial (required):");
                  if (reason) {
                    const notes = prompt("Enter additional notes (optional):");
                    denyMutation.mutate({ reason, notes: notes || "" });
                  }
                }}
              >
                <X className="mr-2 h-4 w-4" />
                Deny
              </Button>
            </>
          )}

          {application.status === "approved" && !application.userId && (
            <Button
              variant="outline"
              className="border-blue-200 bg-blue-50 hover:bg-blue-100 text-blue-700"
              onClick={() => {
                const username = prompt("Enter username for the new user:");
                if (username) {
                  const password = prompt("Enter temporary password:");
                  if (password) {
                    createUserMutation.mutate({ username, password });
                  }
                }
              }}
            >
              <UserPlus className="mr-2 h-4 w-4" />
              Create User
            </Button>
          )}
        </div>
      </div>

      {/* Application details tabs */}
      <Tabs defaultValue="details" className="space-y-4">
        <TabsList className="bg-amber-50 border border-amber-200">
          <TabsTrigger value="details" className="data-[state=active]:bg-amber-100">
            Application Details
          </TabsTrigger>
          <TabsTrigger value="documents" className="data-[state=active]:bg-amber-100">
            Documents & KYC
          </TabsTrigger>
          <TabsTrigger value="logs" className="data-[state=active]:bg-amber-100">
            Access Logs
          </TabsTrigger>
        </TabsList>

        {/* Details Tab */}
        <TabsContent value="details" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Application Status Card */}
            <Card className="shadow-sm">
              <CardHeader className="bg-amber-50 border-b border-amber-100">
                <CardTitle className="text-amber-900">
                  <div className="flex items-center">
                    <Shield className="mr-2 h-5 w-5" />
                    Application Status
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="mb-4 flex items-center">
                  <StatusBadge status={application.status} />
                  <span className="ml-2 text-sm text-gray-600">
                    Last updated: {format(new Date(application.lastUpdatedAt), "MMM d, yyyy")}
                  </span>
                </div>

                {application.reviewedAt && (
                  <FieldGroup
                    label="Reviewed On"
                    value={format(new Date(application.reviewedAt), "MMMM d, yyyy 'at' h:mm a")}
                    icon={<Clock className="h-4 w-4" />}
                  />
                )}

                {application.reviewNotes && (
                  <FieldGroup
                    label="Review Notes"
                    value={application.reviewNotes}
                  />
                )}

                {application.reasonForDenial && (
                  <FieldGroup
                    label="Reason for Denial"
                    value={application.reasonForDenial}
                    icon={<AlertTriangle className="h-4 w-4" />}
                  />
                )}

                {application.userId && (
                  <FieldGroup
                    label="Linked User ID"
                    value={application.userId.toString()}
                    icon={<User className="h-4 w-4" />}
                  />
                )}
              </CardContent>
            </Card>

            {/* Personal Information Card */}
            <Card className="shadow-sm">
              <CardHeader className="bg-amber-50 border-b border-amber-100">
                <CardTitle className="text-amber-900">
                  <div className="flex items-center">
                    <User className="mr-2 h-5 w-5" />
                    Personal Information
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <FieldGroup
                  label="Full Name"
                  value={`${appData.firstName || ''} ${appData.middleName ? appData.middleName + ' ' : ''}${appData.lastName || ''}`}
                  icon={<User className="h-4 w-4" />}
                />

                <FieldGroup
                  label="Date of Birth"
                  value={appData.dateOfBirth ? format(new Date(appData.dateOfBirth), "MMMM d, yyyy") : null}
                  icon={<Calendar className="h-4 w-4" />}
                />

                <FieldGroup
                  label="Email Address"
                  value={application.contactEmail}
                  icon={<Mail className="h-4 w-4" />}
                />

                <FieldGroup
                  label="Phone Number"
                  value={application.contactPhone || appData.phoneNumber}
                  icon={<Phone className="h-4 w-4" />}
                />

                <FieldGroup
                  label="SSN (Last 4 Digits)"
                  value={appData.ssn ? `XXX-XX-${appData.ssn.slice(-4)}` : null}
                  icon={<IdCard className="h-4 w-4" />}
                />
                
                <FieldGroup
                  label="Citizenship Status"
                  value={appData.citizenshipStatus ? formatCitizenshipStatus(appData.citizenshipStatus) : null}
                  icon={<Flag className="h-4 w-4" />}
                />
              </CardContent>
            </Card>

            {/* Address Information Card */}
            <Card className="shadow-sm">
              <CardHeader className="bg-amber-50 border-b border-amber-100">
                <CardTitle className="text-amber-900">
                  <div className="flex items-center">
                    <MapPin className="mr-2 h-5 w-5" />
                    Address Information
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <FieldGroup
                  label="Street Address"
                  value={appData.streetAddress}
                  icon={<Home className="h-4 w-4" />}
                />

                {appData.aptSuite && (
                  <FieldGroup
                    label="Apartment/Suite"
                    value={appData.aptSuite}
                  />
                )}

                <FieldGroup
                  label="City"
                  value={appData.city}
                  icon={<Building className="h-4 w-4" />}
                />

                <FieldGroup
                  label="State"
                  value={appData.state}
                />

                <FieldGroup
                  label="ZIP Code"
                  value={appData.zipCode}
                />

                <FieldGroup
                  label="Country"
                  value={appData.country || "United States"}
                  icon={<Globe className="h-4 w-4" />}
                />
              </CardContent>
            </Card>

            {/* Employment Information Card */}
            <Card className="shadow-sm">
              <CardHeader className="bg-amber-50 border-b border-amber-100">
                <CardTitle className="text-amber-900">
                  <div className="flex items-center">
                    <Briefcase className="mr-2 h-5 w-5" />
                    Employment Information
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <FieldGroup
                  label="Employment Status"
                  value={appData.employmentStatus ? formatEmploymentStatus(appData.employmentStatus) : null}
                  icon={<Briefcase className="h-4 w-4" />}
                />

                {appData.employerName && (
                  <FieldGroup
                    label="Employer Name"
                    value={appData.employerName}
                    icon={<Building className="h-4 w-4" />}
                  />
                )}

                {appData.industryType && (
                  <FieldGroup
                    label="Industry"
                    value={appData.industryType}
                  />
                )}

                {appData.occupation && (
                  <FieldGroup
                    label="Occupation"
                    value={appData.occupation}
                    icon={<GraduationCap className="h-4 w-4" />}
                  />
                )}

                <FieldGroup
                  label="Annual Income"
                  value={appData.annualIncome ? `$${Number(appData.annualIncome).toLocaleString()}` : null}
                  icon={<DollarSign className="h-4 w-4" />}
                />

                {appData.sourceOfFunds && (
                  <FieldGroup
                    label="Source of Funds"
                    value={appData.sourceOfFunds}
                    icon={<Banknote className="h-4 w-4" />}
                  />
                )}
              </CardContent>
            </Card>
            
            {/* Banking Preferences Card */}
            <Card className="shadow-sm">
              <CardHeader className="bg-amber-50 border-b border-amber-100">
                <CardTitle className="text-amber-900">
                  <div className="flex items-center">
                    <Landmark className="mr-2 h-5 w-5" />
                    Banking Preferences
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <FieldGroup
                  label="Desired Account Type"
                  value={appData.accountType}
                  icon={<CreditCard className="h-4 w-4" />}
                />

                <FieldGroup
                  label="Account Purpose"
                  value={appData.accountPurpose || appData.purpose}
                  icon={<Wallet className="h-4 w-4" />}
                />

                {appData.expectedMonthlyDeposits && (
                  <FieldGroup
                    label="Expected Monthly Deposits"
                    value={appData.expectedMonthlyDeposits}
                    icon={<DollarSign className="h-4 w-4" />}
                  />
                )}

                {appData.expectedMonthlyWithdrawals && (
                  <FieldGroup
                    label="Expected Monthly Withdrawals"
                    value={appData.expectedMonthlyWithdrawals}
                    icon={<DollarSign className="h-4 w-4" />}
                  />
                )}

                {appData.interestedInProducts && (
                  <FieldGroup
                    label="Interested Products"
                    value={Array.isArray(appData.interestedInProducts) ? appData.interestedInProducts.join(", ") : appData.interestedInProducts}
                  />
                )}

                {appData.digitalBankingPreference && (
                  <FieldGroup
                    label="Digital Banking Preference"
                    value={appData.digitalBankingPreference}
                  />
                )}
              </CardContent>
            </Card>

            {/* Application Metadata Card */}
            <Card className="shadow-sm col-span-1 md:col-span-2">
              <CardHeader className="bg-amber-50 border-b border-amber-100">
                <CardTitle className="text-amber-900">
                  <div className="flex items-center">
                    <Shield className="mr-2 h-5 w-5" />
                    Application Metadata
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <FieldGroup
                      label="IP Address"
                      value={application.ipAddress}
                      icon={<Globe className="h-4 w-4" />}
                    />

                    <FieldGroup
                      label="Device Information"
                      value={application.deviceInfo}
                      icon={<Info className="h-4 w-4" />}
                    />

                    <FieldGroup
                      label="Email Notifications"
                      value={application.notifyViaEmail ? "Enabled" : "Disabled"}
                      icon={<Mail className="h-4 w-4" />}
                    />

                    <FieldGroup
                      label="SMS Notifications"
                      value={application.notifyViaSms ? "Enabled" : "Disabled"}
                      icon={<Phone className="h-4 w-4" />}
                    />
                    
                    {appData.howDidYouHear && (
                      <FieldGroup
                        label="How Applicant Heard About Us"
                        value={appData.howDidYouHear}
                        icon={<Info className="h-4 w-4" />}
                      />
                    )}
                  </div>

                  <div>
                    <FieldGroup
                      label="Application Number"
                      value={application.applicationNumber}
                      icon={<FileText className="h-4 w-4" />}
                    />

                    <FieldGroup
                      label="Submission Date/Time"
                      value={format(new Date(application.submittedAt), "MMMM d, yyyy 'at' h:mm a")}
                      icon={<Calendar className="h-4 w-4" />}
                    />

                    <FieldGroup
                      label="Last Updated"
                      value={format(new Date(application.lastUpdatedAt), "MMMM d, yyyy 'at' h:mm a")}
                      icon={<Clock className="h-4 w-4" />}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Documents Tab */}
        <TabsContent value="documents" className="space-y-4">
          <Card className="shadow-sm">
            <CardHeader className="bg-amber-50 border-b border-amber-100">
              <CardTitle className="text-amber-900">
                <div className="flex items-center">
                  <FileText className="mr-2 h-5 w-5" />
                  Verification Documents
                </div>
              </CardTitle>
              <CardDescription>
                View the documents submitted as part of this application. All document access is logged for compliance purposes.
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* ID Document (Front) */}
                <div className="border rounded-md p-4">
                  <h3 className="font-medium mb-2 flex items-center">
                    <Shield className="mr-2 h-4 w-4 text-amber-700" />
                    ID Document (Front)
                  </h3>
                  <div className="bg-gray-50 p-4 rounded-md mb-2 min-h-[200px] flex items-center justify-center">
                    {appData.idDocumentFront ? (
                      <SecureDocumentViewer
                        documentId={application.id.toString()}
                        documentType="id_front"
                        entityType="application"
                      />
                    ) : (
                      <div className="text-gray-500 text-center">No ID front document provided</div>
                    )}
                  </div>
                  {appData.idDocumentFront && (
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full border-amber-200 hover:bg-amber-50"
                      onClick={() => {
                        // Open document in a new tab
                        window.open(getKycDocumentUrl(application.id.toString(), "id_front"), "_blank");
                      }}
                    >
                      <Eye className="h-3.5 w-3.5 mr-1" />
                      View Full Size
                    </Button>
                  )}
                </div>

                {/* ID Document (Back) */}
                <div className="border rounded-md p-4">
                  <h3 className="font-medium mb-2 flex items-center">
                    <Shield className="mr-2 h-4 w-4 text-amber-700" />
                    ID Document (Back)
                  </h3>
                  <div className="bg-gray-50 p-4 rounded-md mb-2 min-h-[200px] flex items-center justify-center">
                    {appData.idDocumentBack ? (
                      <SecureDocumentViewer
                        documentId={application.id.toString()}
                        documentType="id_back"
                        entityType="application"
                      />
                    ) : (
                      <div className="text-gray-500 text-center">No ID back document provided</div>
                    )}
                  </div>
                  {appData.idDocumentBack && (
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full border-amber-200 hover:bg-amber-50"
                      onClick={() => {
                        // Open document in a new tab
                        window.open(getKycDocumentUrl(application.id.toString(), "id_back"), "_blank");
                      }}
                    >
                      <Eye className="h-3.5 w-3.5 mr-1" />
                      View Full Size
                    </Button>
                  )}
                </div>

                {/* Selfie / Live Photo */}
                <div className="border rounded-md p-4">
                  <h3 className="font-medium mb-2 flex items-center">
                    <User className="mr-2 h-4 w-4 text-amber-700" />
                    Selfie / Live Photo
                  </h3>
                  <div className="bg-gray-50 p-4 rounded-md mb-2 min-h-[200px] flex items-center justify-center">
                    {appData.selfiePhoto ? (
                      <SecureDocumentViewer
                        documentId={application.id.toString()}
                        documentType="selfie"
                        entityType="application"
                      />
                    ) : (
                      <div className="text-gray-500 text-center">No selfie provided</div>
                    )}
                  </div>
                  {appData.selfiePhoto && (
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full border-amber-200 hover:bg-amber-50"
                      onClick={() => {
                        // Open document in a new tab
                        window.open(getKycDocumentUrl(application.id.toString(), "selfie"), "_blank");
                      }}
                    >
                      <Eye className="h-3.5 w-3.5 mr-1" />
                      View Full Size
                    </Button>
                  )}
                </div>

                {/* Address Proof */}
                <div className="border rounded-md p-4">
                  <h3 className="font-medium mb-2 flex items-center">
                    <MapPin className="mr-2 h-4 w-4 text-amber-700" />
                    Proof of Address
                  </h3>
                  <div className="bg-gray-50 p-4 rounded-md mb-2 min-h-[200px] flex items-center justify-center">
                    {appData.addressProof ? (
                      <SecureDocumentViewer
                        documentId={application.id.toString()}
                        documentType="address_proof"
                        entityType="application"
                      />
                    ) : (
                      <div className="text-gray-500 text-center">No address proof provided</div>
                    )}
                  </div>
                  {appData.addressProof && (
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full border-amber-200 hover:bg-amber-50"
                      onClick={() => {
                        // Open document in a new tab
                        window.open(getKycDocumentUrl(application.id.toString(), "address_proof"), "_blank");
                      }}
                    >
                      <Eye className="h-3.5 w-3.5 mr-1" />
                      View Full Size
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Access Logs Tab */}
        <TabsContent value="logs" className="space-y-4">
          <Card className="shadow-sm">
            <CardHeader className="bg-amber-50 border-b border-amber-100">
              <CardTitle className="text-amber-900">
                <div className="flex items-center">
                  <Shield className="mr-2 h-5 w-5" />
                  Document Access Logs
                </div>
              </CardTitle>
              <CardDescription>
                Complete audit trail of all access to this application and its documents. This data is retained for compliance and security purposes.
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              {accessLogs.length === 0 ? (
                <div className="text-center py-8 border rounded-md border-dashed">
                  <p className="text-gray-500">No access logs found for this application</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader className="bg-amber-50">
                      <TableRow>
                        <TableHead>Timestamp</TableHead>
                        <TableHead>Access ID</TableHead>
                        <TableHead>User</TableHead>
                        <TableHead>Document</TableHead>
                        <TableHead>IP Address</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Purpose</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {accessLogs.map((log) => (
                        <TableRow key={log.id}>
                          <TableCell className="font-medium whitespace-nowrap">
                            {format(new Date(log.accessedAt), "yyyy-MM-dd HH:mm:ss")}
                          </TableCell>
                          <TableCell className="whitespace-nowrap">
                            {log.accessId}
                          </TableCell>
                          <TableCell>
                            {log.isAdminAccess ? <Badge variant="outline" className="bg-amber-50">Admin</Badge> : "User"}
                            {" "}#{log.accessedBy}
                          </TableCell>
                          <TableCell>
                            {log.documentPath.split('/').pop()}
                          </TableCell>
                          <TableCell className="whitespace-nowrap">
                            {log.ipAddress}
                          </TableCell>
                          <TableCell>
                            <Badge variant={log.accessStatus === "success" ? "outline" : "destructive"} className={
                              log.accessStatus === "success" ? "bg-green-50 text-green-700 border-green-200" : ""
                            }>
                              {log.accessStatus}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {log.purpose || "General review"}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
            <CardFooter className="bg-amber-50 border-t border-amber-100 text-sm text-amber-700">
              <Shield className="h-4 w-4 mr-2" />
              All actions are logged for security and regulatory compliance. Data logs are encrypted and tamper-proof.
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}