import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { Loader2, RefreshCw, Search, Check, X, Eye, UserPlus, Filter, ChevronDown, ChevronUp, AlertTriangle } from "lucide-react";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAdminAuth } from "@/hooks/use-admin-auth";

// Application status badges
const StatusBadge = ({ status }: { status: string }) => {
  switch (status) {
    case "pending_review":
      return <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">Pending Review</Badge>;
    case "approved":
      return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Approved</Badge>;
    case "denied":
      return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Denied</Badge>;
    case "on_hold":
      return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">On Hold</Badge>;
    case "incomplete":
      return <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">Incomplete</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
};

// Type definitions for application data structure
interface ApplicationData {
  firstName: string;
  lastName: string;
  middleName?: string;
  address: {
    street: string;
    city: string;
    state: string;
    zipCode: string;
    country: string;
  };
  dateOfBirth: string;
  ssn: string;
  phoneNumber: string;
  employmentStatus: string;
  annualIncome: string;
  [key: string]: any;
}

// Type for application object
interface Application {
  id: number;
  applicationNumber: string;
  status: string;
  contactEmail: string;
  contactPhone: string | null;
  submittedAt: string;
  reviewedAt: string | null;
  reviewerId: number | null;
  reviewNotes: string | null;
  applicationData: ApplicationData;
  ipAddress: string;
  deviceInfo: string | null;
  reasonForDenial: string | null;
  userId: number | null;
}

// Type for API response
interface ApplicationsResponse {
  applications: Application[];
  pagination: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
  };
  filters: {
    status: string;
    search: string;
  };
  sorting: {
    sortBy: string;
    sortOrder: string;
  };
}

// Type for access logs
interface AccessLog {
  id: number;
  accessId: string;
  accessedAt: string;
  accessedBy: number;
  accessMethod: string;
  accessStatus: string;
  ipAddress: string;
  userAgent: string;
  purpose: string | null;
  isAdminAccess: boolean;
}

// Main component
export default function ApplicationsManager() {
  const { user, adminToken } = useAdminAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // State for application number direct lookup
  const [applicationNumber, setApplicationNumber] = useState<string>("");
  
  // Mutation to handle direct application lookup
  const applicationLookupMutation = useMutation({
    mutationFn: async (appNumber: string) => {
      const res = await apiRequest(
        "GET",
        `/api/admin/account-applications/by-number/${appNumber}`
      );
      if (res.status === 404) {
        throw new Error("Application not found");
      }
      return await res.json();
    },
    onSuccess: (data) => {
      // Navigate to the application detail page
      navigate(`/admin/applications/${data.application.id}`);
    },
    onError: (error: Error) => {
      toast({
        title: "Application Not Found",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Handler for direct application lookup
  const handleApplicationLookup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!applicationNumber) {
      toast({
        title: "Missing Application Number",
        description: "Please enter an application number to search.",
        variant: "destructive",
      });
      return;
    }
    applicationLookupMutation.mutate(applicationNumber);
  };

  // State for filtering, pagination and sorting
  const [page, setPage] = useState<number>(1);
  const [limit, setLimit] = useState<number>(10);
  const [status, setStatus] = useState<string>("all");
  const [search, setSearch] = useState<string>("");
  const [sortBy, setSortBy] = useState<string>("submittedAt");
  const [sortOrder, setSortOrder] = useState<string>("desc");
  const [selectedTab, setSelectedTab] = useState<string>("all");

  // Handle tab changes
  const handleTabChange = (value: string) => {
    setSelectedTab(value);
    setStatus(value === "all" ? "all" : value);
    setPage(1); // Reset to first page when changing tabs
  };

  // Query to fetch applications with filters, pagination and sorting
  const {
    data,
    isLoading,
    isError,
    error,
    refetch
  } = useQuery<ApplicationsResponse>({
    queryKey: [
      "/api/admin/account-applications",
      page,
      limit,
      status,
      search,
      sortBy,
      sortOrder
    ],
    queryFn: () => {
      const queryParams = new URLSearchParams();
      queryParams.append("page", page.toString());
      queryParams.append("limit", limit.toString());
      if (status !== "all") queryParams.append("status", status);
      if (search) queryParams.append("search", search);
      queryParams.append("sortBy", sortBy);
      queryParams.append("sortOrder", sortOrder);

      return apiRequest(
        "GET",
        `/api/admin/account-applications?${queryParams.toString()}`
      )
        .then((res) => res.json());
    },
  });

  // Mutations for application actions
  const approveMutation = useMutation({
    mutationFn: async ({ id, notes }: { id: number; notes: string }) => {
      const res = await apiRequest(
        "POST",
        `/api/admin/account-applications/${id}/approve`,
        { notes }
      );
      return res.json();
    },
    onSuccess: (data) => {
      // Check if a user was automatically created during approval
      const userCreated = data.autoCreatedUser;
      
      toast({
        title: "Application Approved",
        description: userCreated 
          ? `The application has been approved and user account "${userCreated.username}" was created automatically.`
          : "The application has been successfully approved.",
        variant: "success",
      });
      
      // Invalidate both application and user queries to ensure all data is refreshed
      queryClient.invalidateQueries({
        queryKey: ["/api/admin/account-applications"],
      });
      
      // Important: Also invalidate the users query to show newly created users
      queryClient.invalidateQueries({
        queryKey: ["/api/admin/users"],
      });
      
      // Log the auto-created user details
      if (userCreated) {
        console.log("Auto-created user during application approval:", userCreated);
      }
      
      // Force refetch users data after a short delay
      setTimeout(() => {
        queryClient.refetchQueries({
          queryKey: ["/api/admin/users"],
          exact: true
        });
      }, 500);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to approve application: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const denyMutation = useMutation({
    mutationFn: async ({
      id,
      notes,
      reason,
    }: {
      id: number;
      notes: string;
      reason: string;
    }) => {
      const res = await apiRequest(
        "POST",
        `/api/admin/account-applications/${id}/deny`,
        { notes, reason }
      );
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Application Denied",
        description: "The application has been marked as denied.",
        variant: "warning",
      });
      queryClient.invalidateQueries({
        queryKey: ["/api/admin/account-applications"],
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to deny application: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const createUserMutation = useMutation({
    mutationFn: async ({
      id,
      username,
      password,
    }: {
      id: number;
      username: string;
      password: string;
    }) => {
      const res = await apiRequest(
        "POST",
        `/api/admin/account-applications/${id}/create-user`,
        { username, password }
      );
      return res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "User Created",
        description: `User ${data.user.username} has been successfully created.`,
        variant: "success",
      });
      queryClient.invalidateQueries({
        queryKey: ["/api/admin/account-applications"],
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to create user: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Handler for viewing application details
  const handleViewDetails = (id: number) => {
    navigate(`/admin/applications/${id}`);
  };

  // Handler for sorting columns
  const handleSort = (column: string) => {
    if (sortBy === column) {
      // Toggle sort order if same column is clicked
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      // Set new sort column and default to descending order
      setSortBy(column);
      setSortOrder("desc");
    }
  };

  // Helper to render sort direction indicator
  const renderSortIndicator = (column: string) => {
    if (sortBy !== column) return null;
    return sortOrder === "asc" ? (
      <ChevronUp className="ml-1 h-4 w-4 inline" />
    ) : (
      <ChevronDown className="ml-1 h-4 w-4 inline" />
    );
  };

  // Pagination component
  const renderPagination = () => {
    if (!data || !data.pagination) return null;

    const { total, page: currentPage, totalPages } = data.pagination;

    // No pagination needed if only 1 page
    if (totalPages <= 1) return null;

    return (
      <div className="flex flex-col items-center space-y-2 py-4">
        <div className="text-sm text-muted-foreground">
          Showing page {currentPage} of {totalPages} ({total} total applications)
        </div>
        <Pagination>
          <PaginationContent>
            <PaginationItem>
              <PaginationPrevious
                onClick={() => setPage(Math.max(1, currentPage - 1))}
                className={currentPage === 1 ? "pointer-events-none opacity-50" : "cursor-pointer"}
              />
            </PaginationItem>

            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
              let pageNum;
              
              // Always show first, last, and pages around current
              if (totalPages <= 5) {
                pageNum = i + 1;
              } else if (currentPage <= 3) {
                pageNum = i + 1;
                if (i === 4) pageNum = totalPages;
              } else if (currentPage >= totalPages - 2) {
                if (i === 0) pageNum = 1;
                else pageNum = totalPages - (4 - i);
              } else {
                if (i === 0) pageNum = 1;
                else if (i === 4) pageNum = totalPages;
                else pageNum = currentPage + (i - 2);
              }

              // Add ellipsis
              if ((i === 1 && pageNum > 2) || (i === 3 && pageNum < totalPages - 1)) {
                return (
                  <PaginationItem key={`ellipsis-${i}`}>
                    <PaginationEllipsis />
                  </PaginationItem>
                );
              }

              return (
                <PaginationItem key={pageNum}>
                  <PaginationLink
                    onClick={() => setPage(pageNum)}
                    isActive={currentPage === pageNum}
                  >
                    {pageNum}
                  </PaginationLink>
                </PaginationItem>
              );
            })}

            <PaginationItem>
              <PaginationNext
                onClick={() => setPage(Math.min(totalPages, currentPage + 1))}
                className={currentPage === totalPages ? "pointer-events-none opacity-50" : "cursor-pointer"}
              />
            </PaginationItem>
          </PaginationContent>
        </Pagination>
      </div>
    );
  };

  // If not authenticated, don't render anything (will redirect)
  if (!user) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-amber-600" />
      </div>
    );
  }

  return (
    <div className="container mx-auto py-6 space-y-6">
      <Card className="border-amber-200">
        <CardHeader className="bg-amber-50">
          <CardTitle className="text-amber-900 text-2xl flex items-center">
            <AlertTriangle className="mr-2 h-6 w-6" />
            Applications Manager
          </CardTitle>
          <CardDescription>
            Review, approve or deny account applications. All actions are logged for compliance and security purposes.
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          {/* Tabs for quick status filtering */}
          {/* Direct Application Lookup */}
          <div className="w-full bg-amber-50 border border-amber-200 rounded-md p-4 mb-6">
            <h3 className="text-amber-900 font-medium mb-2">Direct Application Lookup</h3>
            <form onSubmit={handleApplicationLookup} className="flex gap-2">
              <div className="flex-1">
                <Input
                  placeholder="Enter application number (e.g., APP-20250430-0001)"
                  value={applicationNumber}
                  onChange={(e) => setApplicationNumber(e.target.value)}
                  className="border-amber-200"
                />
              </div>
              <Button 
                type="submit" 
                className="bg-amber-600 hover:bg-amber-700 text-white"
                disabled={applicationLookupMutation.isPending}
              >
                {applicationLookupMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                ) : null}
                Lookup
              </Button>
            </form>
            <p className="text-xs text-amber-700 mt-2">
              Enter a complete application number to directly view the application details.
            </p>
          </div>

          <Tabs value={selectedTab} onValueChange={handleTabChange} className="w-full mb-6">
            <TabsList className="w-full justify-start bg-amber-50 border border-amber-200">
              <TabsTrigger value="all" className="data-[state=active]:bg-amber-100 data-[state=active]:text-amber-800">
                All Applications
              </TabsTrigger>
              <TabsTrigger value="pending_review" className="data-[state=active]:bg-amber-100 data-[state=active]:text-amber-800">
                Pending Review
              </TabsTrigger>
              <TabsTrigger value="approved" className="data-[state=active]:bg-amber-100 data-[state=active]:text-amber-800">
                Approved
              </TabsTrigger>
              <TabsTrigger value="denied" className="data-[state=active]:bg-amber-100 data-[state=active]:text-amber-800">
                Denied
              </TabsTrigger>
            </TabsList>
          </Tabs>

          {/* Search and filter controls */}
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by application number, email, or phone..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>

            <div className="flex flex-row gap-2">
              <Select
                value={limit.toString()}
                onValueChange={(value) => {
                  setLimit(parseInt(value));
                  setPage(1); // Reset to first page when changing limit
                }}
              >
                <SelectTrigger className="w-[130px]">
                  <SelectValue placeholder="Page size" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="5">5 per page</SelectItem>
                  <SelectItem value="10">10 per page</SelectItem>
                  <SelectItem value="25">25 per page</SelectItem>
                  <SelectItem value="50">50 per page</SelectItem>
                </SelectContent>
              </Select>

              <Button
                variant="outline"
                className="border-amber-200 hover:bg-amber-50"
                onClick={() => refetch()}
                title="Refresh data"
              >
                <RefreshCw className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Display loading state */}
          {isLoading && (
            <div className="flex justify-center items-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-amber-600" />
              <span className="ml-2 text-amber-800">Loading applications...</span>
            </div>
          )}

          {/* Display error state */}
          {isError && (
            <div className="bg-red-50 border border-red-200 rounded-md p-4 mb-6">
              <div className="flex">
                <div className="flex-shrink-0">
                  <AlertTriangle className="h-5 w-5 text-red-500" />
                </div>
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-red-800">
                    Error loading applications
                  </h3>
                  <div className="mt-2 text-sm text-red-700">
                    <p>{(error as Error).message || "Unknown error occurred. Please try again."}</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Display empty state */}
          {!isLoading && !isError && data?.applications.length === 0 && (
            <div className="text-center py-12 border rounded-md border-dashed border-gray-300 bg-gray-50">
              <h3 className="text-lg font-medium text-gray-900 mb-1">No applications found</h3>
              <p className="text-gray-500 max-w-md mx-auto">
                {search
                  ? `No applications match your search term "${search}". Try a different search term.`
                  : status !== "all"
                  ? `No applications with status "${status}" found.`
                  : "There are no applications in the system yet."}
              </p>
            </div>
          )}

          {/* Display applications table */}
          {!isLoading && !isError && data?.applications.length > 0 && (
            <div className="overflow-x-auto border rounded-md">
              <Table>
                <TableHeader className="bg-amber-50">
                  <TableRow className="hover:bg-amber-100">
                    <TableHead 
                      className="w-[200px] cursor-pointer" 
                      onClick={() => handleSort("applicationNumber")}
                    >
                      <span className="flex items-center">
                        App Number {renderSortIndicator("applicationNumber")}
                      </span>
                    </TableHead>
                    <TableHead 
                      className="cursor-pointer" 
                      onClick={() => handleSort("submittedAt")}
                    >
                      <span className="flex items-center">
                        Submitted {renderSortIndicator("submittedAt")}
                      </span>
                    </TableHead>
                    <TableHead>Applicant</TableHead>
                    <TableHead 
                      className="cursor-pointer"
                      onClick={() => handleSort("status")}
                    >
                      <span className="flex items-center">
                        Status {renderSortIndicator("status")}
                      </span>
                    </TableHead>
                    <TableHead>IP Address</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data?.applications.map((application) => (
                    <TableRow key={application.id} className="hover:bg-gray-50">
                      <TableCell className="font-medium">
                        {application.applicationNumber}
                      </TableCell>
                      <TableCell>
                        {application.submittedAt ? (
                          format(new Date(application.submittedAt), "MMM dd, yyyy HH:mm")
                        ) : (
                          "N/A"
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">
                          {application.applicationData?.firstName} {application.applicationData?.lastName}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {application.contactEmail}
                        </div>
                      </TableCell>
                      <TableCell>
                        <StatusBadge status={application.status} />
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {application.ipAddress || "Unknown"}
                      </TableCell>
                      <TableCell className="text-right space-x-1">
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-8 border-amber-200 hover:bg-amber-50"
                          onClick={() => handleViewDetails(application.id)}
                        >
                          <Eye className="h-3.5 w-3.5 mr-1" />
                          View
                        </Button>
                        
                        {application.status === "pending_review" && (
                          <>
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-8 border-green-200 hover:bg-green-50 text-green-700"
                              onClick={() => {
                                // In a real app, you would open a dialog for notes
                                // For this demo, we're using a simple prompt
                                const notes = prompt("Enter approval notes (optional):");
                                if (notes !== null) { // Only if not canceled
                                  approveMutation.mutate({ id: application.id, notes });
                                }
                              }}
                            >
                              <Check className="h-3.5 w-3.5 mr-1" />
                              Approve
                            </Button>
                            
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-8 border-red-200 hover:bg-red-50 text-red-700"
                              onClick={() => {
                                // In a real app, you would open a dialog for reason and notes
                                const reason = prompt("Enter reason for denial (required):");
                                if (reason) {
                                  const notes = prompt("Enter additional notes (optional):");
                                  denyMutation.mutate({ 
                                    id: application.id, 
                                    reason, 
                                    notes: notes || "" 
                                  });
                                }
                              }}
                            >
                              <X className="h-3.5 w-3.5 mr-1" />
                              Deny
                            </Button>
                          </>
                        )}
                        
                        {application.status === "approved" && !application.userId && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-8 border-blue-200 hover:bg-blue-50 text-blue-700"
                            onClick={() => {
                              // In a real app, you would open a dialog form
                              const username = prompt("Enter username for the new user:");
                              if (username) {
                                const password = prompt("Enter temporary password:");
                                if (password) {
                                  createUserMutation.mutate({ 
                                    id: application.id, 
                                    username, 
                                    password 
                                  });
                                }
                              }
                            }}
                          >
                            <UserPlus className="h-3.5 w-3.5 mr-1" />
                            Create User
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}

          {/* Pagination controls */}
          {renderPagination()}
        </CardContent>
      </Card>
    </div>
  );
}