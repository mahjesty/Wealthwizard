import { useState, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAdminAuth } from "@/hooks/use-admin-auth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Loader2, 
  User, 
  KeyRound, 
  Shield,
  Lock,
  AlertTriangle,
  Eye,
  EyeOff
} from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

const adminLoginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
  secureSession: z.boolean().optional(),
});

type AdminLoginFormValues = z.infer<typeof adminLoginSchema>;

export default function AdminLoginForm() {
  const { login } = useAdminAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [loginAttempts, setLoginAttempts] = useState(0);
  const [showPassword, setShowPassword] = useState(false);
  const adminKeyRef = useRef<string>("ADMIN_ACCESS_KEY");
  
  const form = useForm<AdminLoginFormValues>({
    resolver: zodResolver(adminLoginSchema),
    defaultValues: {
      username: "",
      password: "",
      secureSession: true,
    },
  });

  async function onSubmit(data: AdminLoginFormValues) {
    try {
      setIsLoading(true);
      
      // Extra security check for admin access
      // In a real system, this would validate against a secure whitelist
      // We're using a simple check for demo purposes - this would be more secure in production
      if (data.username !== "admin") {
        // Simulate a delay for security
        await new Promise(resolve => setTimeout(resolve, 1500));
        throw new Error("Invalid administrator credentials");
      }
      
      // Log the admin login attempt (this would go to a secure audit log in production)
      console.log(`Admin login attempt: ${new Date().toISOString()}`);
      
      // Perform the actual login
      await login(data.username, data.password);
      
      // After successful login, the useAuth hook will redirect to the appropriate page
    } catch (error) {
      // Increment failed login attempts
      setLoginAttempts(prev => prev + 1);
      
      // After 3 failed attempts show a stronger warning
      if (loginAttempts >= 2) {
        toast({
          title: "Access Restricted",
          description: "Multiple failed login attempts detected. This incident has been logged and reported to security.",
          variant: "destructive",
        });
        
        // In a real system, this would trigger a security alert
        console.error("SECURITY ALERT: Multiple failed admin login attempts");
        
        // Disable the form temporarily for additional security
        form.reset();
        setIsLoading(true);
        setTimeout(() => {
          setIsLoading(false);
        }, 5000); // Lock out for 5 seconds
      } else {
        toast({
          title: "Authentication Failed",
          description: "Invalid administrator credentials",
          variant: "destructive",
        });
      }
      
      console.error("Admin login error:", error);
    } finally {
      if (loginAttempts < 2) {
        setIsLoading(false);
      }
    }
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
        <div className="bg-amber-50 border-l-4 border-amber-400 p-4 mb-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <AlertTriangle className="h-5 w-5 text-amber-400" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-amber-700">
                You are accessing an administrative area. Unauthorized access attempts are logged and monitored.
              </p>
            </div>
          </div>
        </div>
        
        <FormField
          control={form.control}
          name="username"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="text-gray-700 flex items-center">
                Admin Username
                <span className="ml-2 px-1.5 py-0.5 text-xs bg-amber-100 text-amber-800 rounded-sm font-mono">
                  ADMIN ONLY
                </span>
              </FormLabel>
              <FormControl>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                    <User className="h-4 w-4" />
                  </div>
                  <Input
                    placeholder="Enter admin username"
                    className="pl-10 bg-gray-50 border-gray-200 focus:bg-white text-gray-900"
                    {...field}
                    disabled={isLoading}
                    autoComplete="username"
                    spellCheck={false}
                    autoCapitalize="none"
                  />
                </div>
              </FormControl>
              <div className="mt-1 text-xs text-gray-500">
                Regular user accounts cannot access this portal
              </div>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="password"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="text-gray-700">Admin Password</FormLabel>
              <FormControl>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                    <KeyRound className="h-4 w-4" />
                  </div>
                  <Input
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    className="pl-10 pr-10 bg-gray-50 border-gray-200 focus:bg-white text-gray-900"
                    {...field}
                    disabled={isLoading}
                    autoComplete="current-password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400 hover:text-gray-600"
                    tabIndex={-1}
                    disabled={isLoading}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </button>
                </div>
              </FormControl>
              <div className="mt-1 text-xs text-gray-500">
                <span className="flex items-center">
                  <Lock className="h-3 w-3 mr-1" />
                  Secure admin credentials required
                </span>
              </div>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <div className="flex justify-between items-center">
          <FormField
            control={form.control}
            name="secureSession"
            render={({ field }) => (
              <FormItem className="flex flex-row items-center space-x-2 space-y-0 mb-0">
                <FormControl>
                  <Checkbox
                    checked={field.value}
                    onCheckedChange={field.onChange}
                    disabled={isLoading}
                    className="text-primary border-gray-300"
                  />
                </FormControl>
                <div className="leading-none">
                  <FormLabel className="text-sm text-gray-600">Enhanced security session</FormLabel>
                </div>
              </FormItem>
            )}
          />
        </div>
        
        <Button 
          type="submit" 
          className="w-full py-6 text-base font-medium bg-amber-600 hover:bg-amber-700" 
          disabled={isLoading}
          size="lg"
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              Authenticating...
            </>
          ) : (
            <>
              <Shield className="mr-2 h-5 w-5" />
              Admin Access
            </>
          )}
        </Button>
        
        {/* No link back to user login page */}
      </form>
    </Form>
  );
}