import { useState, useEffect, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { 
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetFooter,
  SheetClose
} from "@/components/ui/sheet";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useToast } from "@/hooks/use-toast";
import { useAdminAuth } from "@/hooks/use-admin-auth";
import { apiRequest } from "@/lib/queryClient";
import { 
  Search, 
  Filter, 
  User,
  Menu,
  Shield,
  ShieldAlert,
  ShieldCheck,
  ChevronRight,
  PieChart,
  CreditCard,
  Clock,
  DollarSign,
  FileText,
  HelpCircle,
  AlertTriangle,
  Users,
  UserPlus,
  Download,
  Upload,
  MoreVertical,
  Edit,
  UserCheck,
  UserX,
  Lock,
  Unlock,
  Eye,
  KeyRound,
  Key,
  AlertCircle,
  Trash2,
  X,
  CheckCircle,
  LogOut,
  LogIn,
  TrendingUp,
  TrendingDown,
  BellRing,
  Settings,
  Activity,
  RefreshCcw,
  Loader2,
  ArrowUp,
  ArrowDown,
  ArrowLeftRight,
  ArrowDownToLine,
  ArrowUpFromLine
} from "lucide-react";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
} from "@/components/ui/dropdown-menu";
import { formatDate, formatCurrency } from "@/lib/utils";

interface User {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  username: string;
  role: string;
  isActive?: boolean;
  isVerified: boolean;
  isBlocked?: boolean;
  blockReason?: string;
  status?: string; // active, suspended, dormant, investigating
  securityLevel?: string; // standard, enhanced, high, maximum
  fraudAlert?: boolean;
  failedLoginAttempts?: number;
  lastPasswordChange?: string;
  createdAt: string;
  lastLogin?: string;
  accountCount?: number;
  balance?: string;
  kycStatus?: string;
  // Feature restriction fields
  loginRestricted?: boolean;
  loginRestrictionReason?: string;
  transferRestricted?: boolean;
  transferRestrictionReason?: string;
  depositRestricted?: boolean;
  depositRestrictionReason?: string;
  withdrawalRestricted?: boolean;
  withdrawalRestrictionReason?: string;
  cardRestricted?: boolean;
  cardRestrictionReason?: string;
}

interface UserDetails {
  accounts: Array<{
    id: number;
    accountType: string;
    accountNumber: string;
    balance: string;
    status: string;
  }>;
  transactions: Array<{
    id: number;
    amount: string;
    type: string;
    date: string;
    status: string;
    description: string;
  }>;
  cards: Array<{
    id: number;
    cardType: string;
    lastFour: string;
    expiryDate: string;
    status: string;
  }>;
  supportTickets: Array<{
    id: number;
    subject: string;
    status: string;
    date: string;
  }>;
}

export default function AdminUsers() {
  const { adminUser } = useAdminAuth();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [location, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive' | 'pending'>('all');
  const [verificationFilter, setVerificationFilter] = useState<'all' | 'verified' | 'unverified'>('all');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [showUserDetails, setShowUserDetails] = useState(false);
  const [showResetPasswordDialog, setShowResetPasswordDialog] = useState(false);
  const [showLoginRestrictionDialog, setShowLoginRestrictionDialog] = useState(false);
  const [showTransferRestrictionDialog, setShowTransferRestrictionDialog] = useState(false);
  const [showDepositRestrictionDialog, setShowDepositRestrictionDialog] = useState(false);
  const [showWithdrawalRestrictionDialog, setShowWithdrawalRestrictionDialog] = useState(false);
  const [showCardRestrictionDialog, setShowCardRestrictionDialog] = useState(false);
  const [confirmAction, setConfirmAction] = useState<{ action: string; userId: number | null }>({ action: '', userId: null });
  const [restrictionReason, setRestrictionReason] = useState('');
  
  // Transaction and Account management shared state
  const [amount, setAmount] = useState('');
  const [amountSliderValue, setAmountSliderValue] = useState(0);
  const maxSliderAmount = 5000;
  const [transactionDate, setTransactionDate] = useState(new Date().toISOString().split('T')[0]);
  const [reason, setReason] = useState('');
  
  // These transaction form fields are now moved to where the other account transactions are defined

  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch users
  const { 
    data: users = [], 
    isLoading, 
    error: usersError, 
    isFetching,
    refetch: refetchUsers 
  } = useQuery<User[]>({
    queryKey: ["/api/admin/users"],
    refetchOnWindowFocus: true,
    refetchInterval: 10000, // Refresh every 10 seconds to quickly show new users
    retry: 3, // Increase retry attempts
    staleTime: 5000, // Consider data stale after 5 seconds
    // Add timeout to avoid long-running requests
    gcTime: 10 * 60 * 1000, // 10 minutes
  });
  
  // Handle error effect
  useEffect(() => {
    if (usersError) {
      console.error("Error fetching admin users:", usersError);
      toast({
        title: "Error loading users",
        description: "Could not retrieve user data. Please try again later.",
        variant: "destructive",
      });
    }
  }, [usersError, toast]);
  
  // Add debug logging and handle response
  useEffect(() => {
    console.log("AdminUsersPage - Auth state:", { 
      isAdmin: !!adminUser, 
      adminUserId: adminUser?.id, 
      adminUserRole: adminUser?.role 
    });
    console.log("AdminUsersPage - Query state:", { 
      isLoading, 
      isFetching, 
      errorMessage: usersError?.message, 
      userCount: users?.length || 0 
    });
    
    // Add debug logging to inspect the users array
    if (users && users.length > 0) {
      console.log("AdminUsersPage - Users loaded:", users.length);
    }
    
    // Manually fetch users if query isn't working
    if (adminUser && ((!users || users.length === 0) && !isLoading && !isFetching)) {
      console.log("AdminUsersPage - Manually fetching users data");
      
      const fetchUsers = async () => {
        try {
          const response = await apiRequest("GET", "/api/admin/users");
          if (response.ok) {
            const fetchedUsers = await response.json();
            console.log("Manually fetched users:", fetchedUsers.length);
            
            // Force update React Query cache with new data
            queryClient.setQueryData(["/api/admin/users"], fetchedUsers);
          } else {
            console.error("Failed to fetch users manually:", response.statusText);
          }
        } catch (err) {
          console.error("Error in manual user fetch:", err);
        }
      };
      
      fetchUsers();
    }
  }, [adminUser, users, isLoading, isFetching, usersError, queryClient]);
  
  // Fetch real user details from database when a user is selected
  const { data: userDetails, isLoading: isLoadingDetails } = useQuery<UserDetails | null>({
    queryKey: ["/api/admin/users", selectedUser?.id, "details"],
    queryFn: async (): Promise<UserDetails> => {
      if (!selectedUser) {
        throw new Error("No user selected");
      }
      
      // Get user accounts
      const accountsRes = await apiRequest("GET", `/api/admin/users/${selectedUser.id}/accounts`);
      const accounts = await accountsRes.json();
      
      // Get user transactions
      const transactionsRes = await apiRequest("GET", `/api/admin/users/${selectedUser.id}/transactions`);
      const transactions = await transactionsRes.json();
      
      // Get user cards
      const cardsRes = await apiRequest("GET", `/api/admin/users/${selectedUser.id}/cards`);
      const cards = await cardsRes.json();
      
      // Get user support tickets
      const ticketsRes = await apiRequest("GET", `/api/admin/users/${selectedUser.id}/support-tickets`);
      const supportTickets = await ticketsRes.json();
      
      return {
        accounts,
        transactions,
        cards,
        supportTickets
      };
    },
    enabled: !!selectedUser,
    refetchOnWindowFocus: false,
  });
  
  // Mutation for toggling user active status
  const toggleUserStatusMutation = useMutation({
    mutationFn: async ({ userId, isActive }: { userId: number, isActive: boolean }) => {
      const res = await apiRequest("PATCH", `/api/admin/users/${userId}/status`, { isActive });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "User status updated",
        description: "User status has been successfully updated.",
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update user status",
        description: error.message || "An error occurred while updating user status.",
        variant: "destructive",
      });
    },
  });
  
  // Mutation for toggling user verification status
  const toggleUserVerificationMutation = useMutation({
    mutationFn: async ({ userId, isVerified }: { userId: number, isVerified: boolean }) => {
      const res = await apiRequest("PATCH", `/api/admin/users/${userId}/verification`, { isVerified });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "User verification updated",
        description: "User verification status has been successfully updated.",
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update verification status",
        description: error.message || "An error occurred while updating verification status.",
        variant: "destructive",
      });
    },
  });
  
  // Mutation for resetting user password
  const resetPasswordMutation = useMutation({
    mutationFn: async (userId: number) => {
      const res = await apiRequest("POST", `/api/admin/users/${userId}/reset-password`, {});
      return await res.json();
    },
    onSuccess: () => {
      setShowResetPasswordDialog(false);
      toast({
        title: "Password reset email sent",
        description: "A password reset link has been sent to the user's email.",
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to reset password",
        description: error.message || "An error occurred while resetting password.",
        variant: "destructive",
      });
    },
  });
  
  // Mutation for blocking a user
  const blockUserMutation = useMutation({
    mutationFn: async ({ userId, reason }: { userId: number; reason: string }) => {
      const res = await apiRequest("POST", `/api/admin/users/${userId}/block`, { reason });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "User blocked",
        description: "User has been successfully blocked.",
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to block user",
        description: error.message || "An error occurred while blocking the user.",
        variant: "destructive",
      });
    },
  });
  
  // Mutation for unblocking a user
  const unblockUserMutation = useMutation({
    mutationFn: async (userId: number) => {
      const res = await apiRequest("POST", `/api/admin/users/${userId}/unblock`, {});
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "User unblocked",
        description: "User has been successfully unblocked.",
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to unblock user",
        description: error.message || "An error occurred while unblocking the user.",
        variant: "destructive",
      });
    },
  });
  
  // Mutation for updating user status
  const updateUserStatusMutation = useMutation({
    mutationFn: async ({ userId, status }: { userId: number; status: string }) => {
      const res = await apiRequest("PATCH", `/api/admin/users/${userId}/user-status`, { status });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "User status updated",
        description: "User status has been successfully updated.",
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update user status",
        description: error.message || "An error occurred while updating user status.",
        variant: "destructive",
      });
    },
  });
  
  // Mutation for updating user security level
  const updateSecurityLevelMutation = useMutation({
    mutationFn: async ({ userId, level }: { userId: number; level: string }) => {
      const res = await apiRequest("PATCH", `/api/admin/users/${userId}/security-level`, { level });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "Security level updated",
        description: "User security level has been successfully updated.",
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update security level",
        description: error.message || "An error occurred while updating security level.",
        variant: "destructive",
      });
    },
  });
  
  // Mutation for setting fraud alert
  const updateFraudAlertMutation = useMutation({
    mutationFn: async ({ userId, hasAlert }: { userId: number; hasAlert: boolean }) => {
      const res = await apiRequest("PATCH", `/api/admin/users/${userId}/fraud-alert`, { hasAlert });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "Fraud alert status updated",
        description: "User fraud alert status has been successfully updated.",
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update fraud alert",
        description: error.message || "An error occurred while updating fraud alert status.",
        variant: "destructive",
      });
    },
  });

  // Mutation for topping up an account balance
  const topUpAccountMutation = useMutation({
    mutationFn: async ({ accountId, amount, reason, transactionDate }: { accountId: number; amount: string; reason: string; transactionDate: string }) => {
      const res = await apiRequest("POST", `/api/admin/accounts/${accountId}/top-up`, { 
        amount, 
        reason, 
        transactionDate 
      });
      return await res.json();
    },
    onSuccess: () => {
      // Close dialog and reset form
      setShowTopUpDialog(false);
      setAmount('');
      setReason('');
      setAmountSliderValue(0);
      setTransactionDate(new Date().toISOString().split('T')[0]); // Reset date
      
      // Refresh account and transaction data
      if (selectedUser) {
        queryClient.invalidateQueries({ queryKey: ["/api/admin/users", selectedUser.id, "details"] });
      }
      
      toast({
        title: "Account topped up",
        description: "Account balance has been successfully increased.",
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to top up account",
        description: error.message || "An error occurred while topping up the account.",
        variant: "destructive",
      });
    },
  });

  // Mutation for subtracting from account balance
  const subtractFromAccountMutation = useMutation({
    mutationFn: async ({ accountId, amount, reason, transactionDate }: { accountId: number; amount: string; reason: string; transactionDate: string }) => {
      const res = await apiRequest("POST", `/api/admin/accounts/${accountId}/subtract`, { 
        amount, 
        reason, 
        transactionDate 
      });
      return await res.json();
    },
    onSuccess: () => {
      // Close dialog and reset form
      setShowSubtractDialog(false);
      setAmount('');
      setReason('');
      setAmountSliderValue(0);
      setTransactionDate(new Date().toISOString().split('T')[0]); // Reset date
      
      // Refresh account and transaction data
      if (selectedUser) {
        queryClient.invalidateQueries({ queryKey: ["/api/admin/users", selectedUser.id, "details"] });
      }
      
      toast({
        title: "Amount subtracted",
        description: "Amount has been successfully subtracted from the account.",
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to subtract amount",
        description: error.message || "An error occurred while subtracting from the account.",
        variant: "destructive",
      });
    },
  });

  // Mutation for adding a transaction
  const addTransactionMutation = useMutation({
    mutationFn: async ({ 
      accountId, 
      amount, 
      transactionType,
      description,
      category,
      merchantName,
      transactionDate,
      transactionTime,
      method,
      status,
      referenceNumber,
      adminNotes
    }: { 
      accountId: number; 
      amount: string; 
      transactionType: string;
      description?: string;
      category?: string;
      merchantName?: string;
      transactionDate?: string;
      transactionTime?: string;
      method?: string;
      status?: string;
      referenceNumber?: string;
      adminNotes?: string;
    }) => {
      // Combine date and time if both are provided
      const fullDateTime = transactionDate && transactionTime
        ? `${transactionDate}T${transactionTime}:00`
        : transactionDate;
      
      const res = await apiRequest("POST", `/api/admin/accounts/${accountId}/transactions`, { 
        amount, 
        transactionType,
        description,
        category,
        merchantName,
        transactionDate: fullDateTime,
        method,
        status,
        referenceNumber,
        adminNotes
      });
      return await res.json();
    },
    onSuccess: () => {
      // Close dialog and reset form
      setShowAddTransactionDialog(false);
      setAmount('');
      setTransactionDescription('');
      setTransactionCategory('');
      setTransactionMerchant('');
      setTransactionMethod('');
      setTransactionStatus('completed');
      setReferenceNumber('');
      setAdminNotes('');
      setAmountSliderValue(0);
      setTransactionDate(new Date().toISOString().split('T')[0]); // Reset date
      setTransactionTime('12:00'); // Reset time
      
      // Refresh account and transaction data
      if (selectedUser) {
        queryClient.invalidateQueries({ queryKey: ["/api/admin/users", selectedUser.id, "details"] });
      }
      
      toast({
        title: "Transaction added",
        description: "Transaction has been successfully added to the account.",
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to add transaction",
        description: error.message || "An error occurred while adding the transaction.",
        variant: "destructive",
      });
    },
  });
  
  // Mutation for resetting failed login attempts
  const resetLoginAttemptsMutation = useMutation({
    mutationFn: async (userId: number) => {
      const res = await apiRequest("POST", `/api/admin/users/${userId}/reset-login-attempts`, {});
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "Login attempts reset",
        description: "User failed login attempts have been reset.",
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to reset login attempts",
        description: error.message || "An error occurred while resetting login attempts.",
        variant: "destructive",
      });
    },
  });
  
  // Filter users based on search query and filters
  const filteredUsers = useMemo(() => {
    // Log users data for debugging
    console.log("Filtering users:", {
      usersArray: Array.isArray(users),
      usersLength: users?.length || 0,
      firstItem: users?.[0] ? { id: users[0].id, name: users[0].firstName, isVerified: users[0].isVerified } : null
    });
    
    // Ensure users is an array and handle null/undefined
    if (!users || !Array.isArray(users)) {
      console.log("Users data is not a valid array");
      return [];
    }
    
    // Debug - Check for newly created verified users
    const verifiedUsers = users.filter(user => user.isVerified === true);
    console.log(`Found ${verifiedUsers.length} verified users:`, 
      verifiedUsers.map(u => ({id: u.id, username: u.username, isVerified: u.isVerified}))
    );
    
    return users.filter((user: User) => {
      // Skip undefined/null users (defensive)
      if (!user) {
        console.log("Found null/undefined user in array");
        return false;
      }
      
      // Safely check string properties with nullish coalescing
      const firstName = (user.firstName || "").toLowerCase();
      const lastName = (user.lastName || "").toLowerCase();
      const email = (user.email || "").toLowerCase();
      const username = (user.username || "").toLowerCase();
      const query = searchQuery.toLowerCase();
      
      const matchesSearch = 
        searchQuery === "" || 
        firstName.includes(query) ||
        lastName.includes(query) ||
        email.includes(query) ||
        username.includes(query);
      
      // Explicitly handle boolean comparisons to avoid type issues
      const isUserActive = user.isActive === true;
      const isUserInactive = user.isActive === false;
      const isPending = user.status === 'pending' || user.kycStatus === 'pending';
      
      const matchesStatus = 
        statusFilter === 'all' || 
        (statusFilter === 'active' && isUserActive) || 
        (statusFilter === 'inactive' && isUserInactive) ||
        (statusFilter === 'pending' && isPending);
      
      // Explicitly check verification status
      const isUserVerified = user.isVerified === true;
      const isUserUnverified = user.isVerified === false || user.isVerified === null || user.isVerified === undefined;
      
      const matchesVerification = 
        verificationFilter === 'all' || 
        (verificationFilter === 'verified' && isUserVerified) || 
        (verificationFilter === 'unverified' && isUserUnverified);
      
      // Debug problematic cases
      if (!matchesVerification && verificationFilter === 'verified' && user.isVerified !== true) {
        console.log(`User ${user.id} not matching verification filter. Value:`, user.isVerified);
      }
      
      return matchesSearch && matchesStatus && matchesVerification;
    });
  }, [users, searchQuery, statusFilter, verificationFilter]);
  
  // State for dialog management and form data
  const [showBlockDialog, setShowBlockDialog] = useState(false);
  const [blockReason, setBlockReason] = useState('');
  const [showStatusDialog, setShowStatusDialog] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState('');
  const [showSecurityLevelDialog, setShowSecurityLevelDialog] = useState(false);
  const [selectedSecurityLevel, setSelectedSecurityLevel] = useState('');
  
  // Account management states
  const [selectedAccount, setSelectedAccount] = useState<any>(null);
  const [showTopUpDialog, setShowTopUpDialog] = useState(false);
  const [showSubtractDialog, setShowSubtractDialog] = useState(false);
  const [showAddTransactionDialog, setShowAddTransactionDialog] = useState(false);
  const [transactionDescription, setTransactionDescription] = useState('');
  
  // Transaction form fields (consolidated)
  const [transactionType, setTransactionType] = useState<'credit' | 'debit'>('credit');
  const [transactionCategory, setTransactionCategory] = useState('');
  const [transactionMerchant, setTransactionMerchant] = useState('');
  const [transactionTime, setTransactionTime] = useState('12:00');
  const [transactionMethod, setTransactionMethod] = useState('');
  const [transactionStatus, setTransactionStatus] = useState('completed');
  const [referenceNumber, setReferenceNumber] = useState('');
  const [adminNotes, setAdminNotes] = useState('');
  // Using a shared maxSliderAmount constant
  
  // Constants for options
  const statusOptions = ['active', 'suspended', 'dormant', 'investigating'];
  const securityLevelOptions = ['standard', 'enhanced', 'high', 'maximum'];
  
  // Feature restriction mutations
  const toggleLoginRestrictionMutation = useMutation({
    mutationFn: async ({ userId, isRestricted, reason }: { userId: number; isRestricted: boolean; reason?: string }) => {
      // Using the correct endpoint that matches server/routes.ts
      const res = await apiRequest("POST", `/api/admin/users/${userId}/toggle-login-restriction`, { isRestricted, reason });
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to update login restriction");
      }
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      
      // More detailed user feedback with information about the restriction status
      const restrictionStatus = data.loginRestricted ? "restricted" : "allowed";
      toast({
        title: `Login access ${restrictionStatus}`,
        description: `User can ${data.loginRestricted ? "no longer" : "now"} log in to the platform.`,
        variant: data.loginRestricted ? "destructive" : "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update login access",
        description: error.message || "An error occurred while updating login access.",
        variant: "destructive",
      });
    },
  });
  
  const toggleTransferRestrictionMutation = useMutation({
    mutationFn: async ({ userId, isRestricted }: { userId: number; isRestricted: boolean }) => {
      // Using the correct endpoint that matches server/routes.ts
      const res = await apiRequest("POST", `/api/admin/users/${userId}/toggle-transfer-restriction`, { isRestricted });
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to update transfer restriction");
      }
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      
      // More detailed user feedback
      const restrictionStatus = data.transferRestricted ? "restricted" : "allowed";
      toast({
        title: `Transfer access ${restrictionStatus}`,
        description: `User can ${data.transferRestricted ? "no longer" : "now"} perform money transfers.`,
        variant: data.transferRestricted ? "destructive" : "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update transfer access",
        description: error.message || "An error occurred while updating transfer access.",
        variant: "destructive",
      });
    },
  });
  
  const toggleDepositRestrictionMutation = useMutation({
    mutationFn: async ({ userId, isRestricted }: { userId: number; isRestricted: boolean }) => {
      // Using the correct endpoint that matches server/routes.ts
      const res = await apiRequest("POST", `/api/admin/users/${userId}/toggle-deposit-restriction`, { isRestricted });
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to update deposit restriction");
      }
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      
      // More detailed user feedback
      const restrictionStatus = data.depositRestricted ? "restricted" : "allowed";
      toast({
        title: `Deposit access ${restrictionStatus}`,
        description: `User can ${data.depositRestricted ? "no longer" : "now"} make deposits to accounts.`,
        variant: data.depositRestricted ? "destructive" : "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update deposit access",
        description: error.message || "An error occurred while updating deposit access.",
        variant: "destructive",
      });
    },
  });
  
  const toggleWithdrawalRestrictionMutation = useMutation({
    mutationFn: async ({ userId, isRestricted }: { userId: number; isRestricted: boolean }) => {
      // Using the correct endpoint that matches server/routes.ts
      const res = await apiRequest("POST", `/api/admin/users/${userId}/toggle-withdrawal-restriction`, { isRestricted });
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to update withdrawal restriction");
      }
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      
      // More detailed user feedback
      const restrictionStatus = data.withdrawalRestricted ? "restricted" : "allowed";
      toast({
        title: `Withdrawal access ${restrictionStatus}`,
        description: `User can ${data.withdrawalRestricted ? "no longer" : "now"} make withdrawals from accounts.`,
        variant: data.withdrawalRestricted ? "destructive" : "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update withdrawal access",
        description: error.message || "An error occurred while updating withdrawal access.",
        variant: "destructive",
      });
    },
  });
  
  const toggleCardRestrictionMutation = useMutation({
    mutationFn: async ({ userId, isRestricted }: { userId: number; isRestricted: boolean }) => {
      // Using the correct endpoint that matches server/routes.ts
      const res = await apiRequest("POST", `/api/admin/users/${userId}/toggle-card-restriction`, { isRestricted });
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to update card restriction");
      }
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      
      // More detailed user feedback
      const restrictionStatus = data.cardRestricted ? "restricted" : "allowed";
      toast({
        title: `Card access ${restrictionStatus}`,
        description: `User can ${data.cardRestricted ? "no longer" : "now"} use their bank cards.`,
        variant: data.cardRestricted ? "destructive" : "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update card access",
        description: error.message || "An error occurred while updating card access.",
        variant: "destructive",
      });
    },
  });
  
  const removeAllRestrictionsMutation = useMutation({
    mutationFn: async (userId: number) => {
      // Using the correct endpoint that matches server/routes.ts
      const res = await apiRequest("POST", `/api/admin/users/${userId}/remove-all-restrictions`, {});
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to remove all restrictions");
      }
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "All restrictions removed",
        description: "All feature restrictions have been removed from the user.",
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to remove restrictions",
        description: error.message || "An error occurred while removing restrictions.",
        variant: "destructive",
      });
    },
  });
  
  // Handle user actions
  const handleUserAction = (action: string, user: User) => {
    switch(action) {
      case 'viewProfile':
        setSelectedUser(user);
        setShowUserDetails(true);
        break;
      case 'toggleActive':
        setConfirmAction({ action: user.isActive ? 'deactivate' : 'activate', userId: user.id });
        break;
      case 'toggleVerification':
        toggleUserVerificationMutation.mutate({ userId: user.id, isVerified: !user.isVerified });
        break;
      case 'resetPassword':
        setSelectedUser(user);
        setShowResetPasswordDialog(true);
        break;
      case 'blockUser':
        setSelectedUser(user);
        setShowBlockDialog(true);
        break;
      case 'unblockUser':
        unblockUserMutation.mutate(user.id);
        break;
      case 'updateStatus':
        setSelectedUser(user);
        setSelectedStatus(user.status || 'active');
        setShowStatusDialog(true);
        break;
      case 'updateSecurityLevel':
        setSelectedUser(user);
        setSelectedSecurityLevel(user.securityLevel || 'standard');
        setShowSecurityLevelDialog(true);
        break;
      case 'toggleFraudAlert':
        updateFraudAlertMutation.mutate({ 
          userId: user.id, 
          hasAlert: !(user.fraudAlert || false)
        });
        break;
      case 'resetLoginAttempts':
        resetLoginAttemptsMutation.mutate(user.id);
        break;
      // Feature restriction handlers
      case 'toggleLoginRestriction':
        // If enabling login restriction, show dialog to collect reason
        if (!(user.loginRestricted || false)) {
          setSelectedUser(user);
          setRestrictionReason('');
          setShowLoginRestrictionDialog(true);
        } else {
          // If removing restriction, just call API
          toggleLoginRestrictionMutation.mutate({
            userId: user.id,
            isRestricted: false
          });
        }
        break;
      case 'toggleTransferRestriction':
        // If enabling transfer restriction, show dialog to collect reason
        if (!(user.transferRestricted || false)) {
          setSelectedUser(user);
          setRestrictionReason('');
          setShowTransferRestrictionDialog(true);
        } else {
          // If removing restriction, just call API without a reason
          toggleTransferRestrictionMutation.mutate({
            userId: user.id,
            isRestricted: false
          });
        }
        break;
      case 'toggleDepositRestriction':
        // If enabling deposit restriction, show dialog to collect reason
        if (!(user.depositRestricted || false)) {
          setSelectedUser(user);
          setRestrictionReason('');
          setShowDepositRestrictionDialog(true);
        } else {
          // If removing restriction, just call API without a reason
          toggleDepositRestrictionMutation.mutate({
            userId: user.id,
            isRestricted: false
          });
        }
        break;
      case 'toggleWithdrawalRestriction':
        // If enabling withdrawal restriction, show dialog to collect reason
        if (!(user.withdrawalRestricted || false)) {
          setSelectedUser(user);
          setRestrictionReason('');
          setShowWithdrawalRestrictionDialog(true);
        } else {
          // If removing restriction, just call API without a reason
          toggleWithdrawalRestrictionMutation.mutate({
            userId: user.id,
            isRestricted: false
          });
        }
        break;
      case 'toggleCardRestriction':
        // If enabling card restriction, show dialog to collect reason
        if (!(user.cardRestricted || false)) {
          setSelectedUser(user);
          setRestrictionReason('');
          setShowCardRestrictionDialog(true);
        } else {
          // If removing restriction, just call API without a reason
          toggleCardRestrictionMutation.mutate({
            userId: user.id,
            isRestricted: false
          });
        }
        break;
      case 'removeAllRestrictions':
        removeAllRestrictionsMutation.mutate(user.id);
        break;
      default:
        break;
    }
  };
  
  // Handle confirm action
  const handleConfirmAction = () => {
    if (confirmAction.action === 'activate' || confirmAction.action === 'deactivate') {
      toggleUserStatusMutation.mutate({ 
        userId: confirmAction.userId!, 
        isActive: confirmAction.action === 'activate' 
      });
    }
    setConfirmAction({ action: '', userId: null });
  };
  
  // Handle blocking user
  const handleBlockUser = () => {
    if (selectedUser && blockReason) {
      blockUserMutation.mutate({ 
        userId: selectedUser.id, 
        reason: blockReason 
      });
      setShowBlockDialog(false);
      setBlockReason('');
    }
  };
  
  // Handle updating status
  const handleUpdateStatus = () => {
    if (selectedUser && selectedStatus) {
      updateUserStatusMutation.mutate({
        userId: selectedUser.id,
        status: selectedStatus
      });
      setShowStatusDialog(false);
    }
  };
  
  // Handle updating security level
  const handleUpdateSecurityLevel = () => {
    if (selectedUser && selectedSecurityLevel) {
      updateSecurityLevelMutation.mutate({
        userId: selectedUser.id,
        level: selectedSecurityLevel
      });
      setShowSecurityLevelDialog(false);
    }
  };
  
  const handleResetPassword = () => {
    if (selectedUser) {
      resetPasswordMutation.mutate(selectedUser.id);
    }
  };
  
  // Handle applying login restriction
  const handleApplyLoginRestriction = () => {
    if (selectedUser && restrictionReason.trim()) {
      toggleLoginRestrictionMutation.mutate({
        userId: selectedUser.id,
        isRestricted: true,
        reason: restrictionReason
      });
      setShowLoginRestrictionDialog(false);
      setRestrictionReason('');
    }
  };
  
  // Handle applying transfer restriction
  const handleApplyTransferRestriction = () => {
    if (selectedUser && restrictionReason.trim()) {
      toggleTransferRestrictionMutation.mutate({
        userId: selectedUser.id,
        isRestricted: true,
        reason: restrictionReason
      });
      setShowTransferRestrictionDialog(false);
      setRestrictionReason('');
    }
  };
  
  // Handle applying deposit restriction
  const handleApplyDepositRestriction = () => {
    if (selectedUser && restrictionReason.trim()) {
      toggleDepositRestrictionMutation.mutate({
        userId: selectedUser.id,
        isRestricted: true,
        reason: restrictionReason
      });
      setShowDepositRestrictionDialog(false);
      setRestrictionReason('');
    }
  };
  
  // Handle applying withdrawal restriction
  const handleApplyWithdrawalRestriction = () => {
    if (selectedUser && restrictionReason.trim()) {
      toggleWithdrawalRestrictionMutation.mutate({
        userId: selectedUser.id,
        isRestricted: true,
        reason: restrictionReason
      });
      setShowWithdrawalRestrictionDialog(false);
      setRestrictionReason('');
    }
  };
  
  // Handle applying card restriction
  const handleApplyCardRestriction = () => {
    if (selectedUser && restrictionReason.trim()) {
      toggleCardRestrictionMutation.mutate({
        userId: selectedUser.id,
        isRestricted: true,
        reason: restrictionReason
      });
      setShowCardRestrictionDialog(false);
      setRestrictionReason('');
    }
  };
  
  // Navigate to specific admin pages
  const navigateTo = (path: string) => {
    setLocation(path);
  };
  
  return (
    <div className="flex flex-col md:flex-row h-screen bg-amber-50 dark:bg-neutral-900 overflow-hidden">
      {/* Admin Sidebar - Hidden on mobile unless toggled */}
      <div className={`${sidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'} 
        ${sidebarOpen ? 'md:w-64' : 'md:w-20'} 
        fixed md:relative z-40 
        bg-amber-900 dark:bg-amber-950 text-white 
        transition-all duration-300 ease-in-out 
        flex flex-col h-full shrink-0
        w-3/4 sm:w-64 md:w-64`}>
        <div className="flex items-center justify-between p-4 border-b border-amber-700/50">
          <div className={`flex items-center ${!sidebarOpen && 'md:justify-center md:w-full'}`}>
            <Shield className="h-8 w-8 text-amber-400" />
            {sidebarOpen && <span className="ml-2 font-semibold text-xl">Admin Portal</span>}
          </div>
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="text-amber-400 hover:text-amber-300 block md:block">
            {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
        
        <div className="overflow-y-auto flex-grow">
          <div className="px-4 py-4">
            {sidebarOpen && <p className="text-xs font-semibold text-amber-500 uppercase tracking-wider mb-2">Main</p>}
            <nav className="space-y-1">
              <div 
                onClick={() => navigateTo("/admin/dashboard")}
                className={`flex items-center ${!sidebarOpen ? 'justify-center' : ''} py-2.5 px-2 rounded-md text-amber-300 hover:bg-amber-800/60 transition-colors duration-200 cursor-pointer`}
              >
                <PieChart className="h-5 w-5" />
                {sidebarOpen && <span className="ml-3">Dashboard</span>}
              </div>
              <div 
                onClick={() => navigateTo("/admin/users")}
                className={`flex items-center ${!sidebarOpen ? 'justify-center' : ''} py-2.5 px-2 rounded-md bg-amber-800 text-amber-300 transition-colors duration-200 cursor-pointer`}
              >
                <Users className="h-5 w-5" />
                {sidebarOpen && <span className="ml-3">Users</span>}
              </div>
              <div 
                onClick={() => navigateTo("/admin/accounts")}
                className={`flex items-center ${!sidebarOpen ? 'justify-center' : ''} py-2.5 px-2 rounded-md text-amber-300 hover:bg-amber-800/60 transition-colors duration-200 cursor-pointer`}
              >
                <CreditCard className="h-5 w-5" />
                {sidebarOpen && <span className="ml-3">Accounts</span>}
              </div>
              <div 
                onClick={() => navigateTo("/admin/transactions")}
                className={`flex items-center ${!sidebarOpen ? 'justify-center' : ''} py-2.5 px-2 rounded-md text-amber-300 hover:bg-amber-800/60 transition-colors duration-200 cursor-pointer`}
              >
                <DollarSign className="h-5 w-5" />
                {sidebarOpen && <span className="ml-3">Transactions</span>}
              </div>
              <div 
                onClick={() => navigateTo("/admin/kyc")}
                className={`flex items-center relative ${!sidebarOpen ? 'justify-center' : ''} py-2.5 px-2 rounded-md text-amber-300 hover:bg-amber-800/60 transition-colors duration-200 cursor-pointer`}
              >
                <FileText className="h-5 w-5" />
                {sidebarOpen && <span className="ml-3">KYC Verifications</span>}
              </div>
              <div 
                onClick={() => navigateTo("/admin/fraud")}
                className={`flex items-center relative ${!sidebarOpen ? 'justify-center' : ''} py-2.5 px-2 rounded-md text-amber-300 hover:bg-amber-800/60 transition-colors duration-200 cursor-pointer`}
              >
                <AlertTriangle className="h-5 w-5" />
                {sidebarOpen && <span className="ml-3">Fraud Alerts</span>}
              </div>
              <div 
                onClick={() => navigateTo("/admin/support")}
                className={`flex items-center ${!sidebarOpen ? 'justify-center' : ''} py-2.5 px-2 rounded-md text-amber-300 hover:bg-amber-800/60 transition-colors duration-200 cursor-pointer`}
              >
                <HelpCircle className="h-5 w-5" />
                {sidebarOpen && <span className="ml-3">Support Tickets</span>}
              </div>
            </nav>
          </div>
        </div>
        
        <div className="p-4 border-t border-amber-700/50">
          {sidebarOpen ? (
            <div className="flex items-center">
              <Avatar className="h-10 w-10 border-2 border-amber-400">
                <AvatarFallback className="bg-amber-700 text-amber-100">
                  {adminUser?.firstName?.charAt(0)}{adminUser?.lastName?.charAt(0)}
                </AvatarFallback>
              </Avatar>
              <div className="ml-3">
                <p className="text-sm font-medium text-amber-100">{adminUser?.firstName} {adminUser?.lastName}</p>
                <p className="text-xs text-amber-400">{adminUser?.role}</p>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center">
              <Avatar className="h-10 w-10 border-2 border-amber-400">
                <AvatarFallback className="bg-amber-700 text-amber-100">
                  {adminUser?.firstName?.charAt(0)}{adminUser?.lastName?.charAt(0)}
                </AvatarFallback>
              </Avatar>
            </div>
          )}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Header */}
        <header className="bg-white dark:bg-neutral-800 shadow-sm border-b border-neutral-200 dark:border-neutral-700">
          <div className="flex items-center justify-between px-6 py-4">
            <div className="flex items-center space-x-3">
              <h1 className="text-xl font-semibold text-neutral-800 dark:text-white">User Management</h1>
              <div className="hidden md:flex text-sm">
                <span className="text-neutral-500 dark:text-neutral-400">Admin /</span>
                <span className="text-neutral-900 dark:text-white ml-1">Users</span>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="outline" size="icon" className="relative">
                      <BellRing className="h-5 w-5 text-neutral-700 dark:text-neutral-300" />
                      <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-red-500"></span>
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Notifications</TooltipContent>
                </Tooltip>
              </TooltipProvider>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="gap-1">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="bg-amber-100 text-amber-800 text-sm">
                        {adminUser?.firstName?.charAt(0)}{adminUser?.lastName?.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <ChevronRight className="h-4 w-4 rotate-90" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium">{adminUser?.firstName} {adminUser?.lastName}</p>
                      <p className="text-xs text-neutral-500 dark:text-neutral-400">{adminUser?.email}</p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => navigateTo("/admin/settings")}>
                    <Settings className="mr-2 h-4 w-4" />
                    <span>Settings</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigateTo("/admin/logout")}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Logout</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </header>
        
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-neutral-100 dark:bg-neutral-800">
          <div className="container mx-auto px-6 py-8">
            <div className="mb-8 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <h2 className="text-2xl font-bold text-neutral-800 dark:text-white">Users</h2>
                <p className="text-neutral-500 dark:text-neutral-400 mt-1">
                  Manage user accounts, permissions, and view activity
                </p>
              </div>
              <div className="flex gap-3">
                <Button variant="outline" className="gap-2">
                  <Download className="h-4 w-4" />
                  Export
                </Button>
                <Button className="gap-2">
                  <UserPlus className="h-4 w-4" />
                  Add New User
                </Button>
              </div>
            </div>
            
            <Card className="mb-8">
              <CardHeader className="pb-2">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                  <div>
                    <CardTitle>User List</CardTitle>
                    <CardDescription>
                      View and manage all users in the system
                    </CardDescription>
                  </div>
                  <Tabs defaultValue="all" className="w-full md:w-auto">
                    <TabsList className="w-full md:w-auto">
                      <TabsTrigger 
                        value="all" 
                        onClick={() => setStatusFilter('all')}
                        className="flex-1 md:flex-none"
                      >
                        All
                      </TabsTrigger>
                      <TabsTrigger 
                        value="active" 
                        onClick={() => setStatusFilter('active')}
                        className="flex-1 md:flex-none"
                      >
                        Active
                      </TabsTrigger>
                      <TabsTrigger 
                        value="inactive" 
                        onClick={() => setStatusFilter('inactive')}
                        className="flex-1 md:flex-none"
                      >
                        Inactive
                      </TabsTrigger>
                      <TabsTrigger 
                        value="pending" 
                        onClick={() => setStatusFilter('pending')}
                        className="flex-1 md:flex-none"
                      >
                        Pending KYC
                      </TabsTrigger>
                    </TabsList>
                  </Tabs>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col md:flex-row justify-between mb-6 gap-4">
                  <div className="relative w-full md:w-96">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400" size={18} />
                    <Input 
                      placeholder="Search by name, email, username..." 
                      className="pl-10"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  
                  <div className="flex gap-4">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => {
                        // Force refresh of users data
                        queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
                        refetchUsers();
                        toast({
                          title: "Refreshing users list",
                          description: "Getting the latest user data from approved applications...",
                        });
                        
                        // Log action to console for debugging
                        console.log("Manually refreshing users list");
                      }}
                      className="h-10 w-10"
                      title="Refresh users list"
                    >
                      <RefreshCw className="h-4 w-4" />
                    </Button>
                    
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="outline" className="flex items-center gap-2">
                          <Filter className="h-4 w-4" />
                          Verification
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent>
                        <DropdownMenuLabel>Filter by Verification</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem 
                          onClick={() => setVerificationFilter('all')}
                          className={verificationFilter === 'all' ? 'bg-amber-50 text-amber-900' : ''}
                        >
                          <span className={verificationFilter === 'all' ? 'font-medium' : ''}>All</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => setVerificationFilter('verified')}
                          className={verificationFilter === 'verified' ? 'bg-amber-50 text-amber-900' : ''}
                        >
                          <span className={verificationFilter === 'verified' ? 'font-medium' : ''}>Verified</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => setVerificationFilter('unverified')}
                          className={verificationFilter === 'unverified' ? 'bg-amber-50 text-amber-900' : ''}
                        >
                          <span className={verificationFilter === 'unverified' ? 'font-medium' : ''}>Unverified</span>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
                
                {isLoading ? (
                  <div className="space-y-4">
                    {[...Array(5)].map((_, i) => (
                      <div key={i} className="flex items-center space-x-4 py-4">
                        <Skeleton className="h-12 w-12 rounded-full" />
                        <div className="space-y-2">
                          <Skeleton className="h-4 w-[200px]" />
                          <Skeleton className="h-4 w-[150px]" />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : filteredUsers.length === 0 ? (
                  <div className="text-center py-12 border rounded-md border-dashed border-neutral-300 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-900">
                    <div className="w-16 h-16 rounded-full bg-neutral-100 dark:bg-neutral-800 mx-auto flex items-center justify-center mb-4">
                      <Users className="h-8 w-8 text-neutral-500 dark:text-neutral-400" />
                    </div>
                    <h3 className="text-lg font-medium text-neutral-900 dark:text-neutral-100 mb-2">No users found</h3>
                    <p className="text-neutral-500 dark:text-neutral-400 mb-6 max-w-md mx-auto">
                      We couldn't find any users matching your search criteria. Try adjusting your filters or search terms.
                    </p>
                    <Button 
                      variant="outline" 
                      onClick={() => {
                        setSearchQuery("");
                        setStatusFilter("all");
                        setVerificationFilter("all");
                      }}
                    >
                      Clear Filters
                    </Button>
                  </div>
                ) : (
                  <div className="overflow-x-auto rounded-md border border-neutral-200 dark:border-neutral-700">
                    <Table>
                      <TableHeader className="bg-neutral-50 dark:bg-neutral-900">
                        <TableRow>
                          <TableHead className="whitespace-nowrap w-[50px]">ID</TableHead>
                          <TableHead className="whitespace-nowrap">User</TableHead>
                          <TableHead className="whitespace-nowrap">Email</TableHead>
                          <TableHead className="whitespace-nowrap">Status</TableHead>
                          <TableHead className="whitespace-nowrap">Verification</TableHead>
                          <TableHead className="whitespace-nowrap">Role</TableHead>
                          <TableHead className="whitespace-nowrap">Joined</TableHead>
                          <TableHead className="whitespace-nowrap text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredUsers.map(user => (
                          <TableRow key={user.id} className="hover:bg-neutral-50 dark:hover:bg-neutral-900">
                            <TableCell className="font-medium">{user.id}</TableCell>
                            <TableCell>
                              <div className="flex items-center">
                                <Avatar className="h-9 w-9 mr-3">
                                  <AvatarFallback className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200">
                                    {`${user.firstName?.[0] || ''}${user.lastName?.[0] || ''}`}
                                  </AvatarFallback>
                                </Avatar>
                                <div>
                                  <div className="font-medium text-neutral-900 dark:text-neutral-100">{user.firstName} {user.lastName}</div>
                                  <div className="text-xs text-neutral-500 dark:text-neutral-400">@{user.username}</div>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>{user.email}</TableCell>
                            <TableCell>
                              <Badge 
                                variant="outline"
                                className={`${
                                  user.isActive 
                                    ? "bg-green-50 text-green-700 border-green-200 dark:bg-green-950 dark:text-green-300 dark:border-green-800" 
                                    : "bg-red-50 text-red-700 border-red-200 dark:bg-red-950 dark:text-red-300 dark:border-red-800"
                                }`}
                              >
                                <div className="flex items-center gap-1">
                                  <div className={`h-1.5 w-1.5 rounded-full ${user.isActive ? "bg-green-500" : "bg-red-500"}`}></div>
                                  {user.isActive ? "Active" : "Inactive"}
                                </div>
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Badge 
                                variant="outline"
                                className={`${
                                  user.isVerified 
                                    ? "bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950 dark:text-blue-300 dark:border-blue-800" 
                                    : user.kycStatus === 'pending'
                                      ? "bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-950 dark:text-yellow-300 dark:border-yellow-800"
                                      : "bg-neutral-50 text-neutral-700 border-neutral-200 dark:bg-neutral-950 dark:text-neutral-300 dark:border-neutral-800"
                                }`}
                              >
                                {user.isVerified ? "Verified" : user.kycStatus === 'pending' ? "Pending KYC" : "Unverified"}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Badge 
                                variant="outline"
                                className={`${
                                  user.role === 'admin' 
                                    ? "bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-950 dark:text-purple-300 dark:border-purple-800" 
                                    : "bg-neutral-50 text-neutral-700 border-neutral-200 dark:bg-neutral-950 dark:text-neutral-300 dark:border-neutral-800"
                                }`}
                              >
                                {user.role}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <TooltipProvider>
                                <Tooltip>
                                  <TooltipTrigger>
                                    <span className="text-neutral-500 dark:text-neutral-400 text-sm">
                                      {formatDate(user.createdAt)}
                                    </span>
                                  </TooltipTrigger>
                                  <TooltipContent>
                                    <div className="text-xs">
                                      <div>Joined: {new Date(user.createdAt).toLocaleString()}</div>
                                      {user.lastLogin && (
                                        <div>Last active: {new Date(user.lastLogin).toLocaleString()}</div>
                                      )}
                                    </div>
                                  </TooltipContent>
                                </Tooltip>
                              </TooltipProvider>
                            </TableCell>
                            <TableCell className="text-right">
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                    <MoreVertical className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end" className="w-64">
                                  {/* SECTION 1: Primary Actions */}
                                  <DropdownMenuLabel className="text-sm font-bold text-neutral-600 dark:text-neutral-300">
                                    Profile Management
                                  </DropdownMenuLabel>
                                  <DropdownMenuItem onClick={() => handleUserAction('viewProfile', user)} className="focus:bg-blue-50 dark:focus:bg-blue-900/20">
                                    <Eye className="h-4 w-4 mr-2.5 text-blue-600 dark:text-blue-400" />
                                    <span className="font-medium">View Full Profile</span>
                                  </DropdownMenuItem>
                                  <DropdownMenuItem className="focus:bg-blue-50 dark:focus:bg-blue-900/20">
                                    <Edit className="h-4 w-4 mr-2.5 text-blue-600 dark:text-blue-400" />
                                    <span className="font-medium">Edit User Details</span>
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator className="my-1.5" />
                                  
                                  {/* SECTION 2: Account Control */}
                                  <DropdownMenuLabel className="text-sm font-bold text-neutral-600 dark:text-neutral-300 pt-1.5">
                                    Account Control
                                  </DropdownMenuLabel>
                                  <DropdownMenuItem 
                                    onClick={() => handleUserAction('updateStatus', user)}
                                    className="focus:bg-amber-50 dark:focus:bg-amber-900/20"
                                  >
                                    <Activity className="h-4 w-4 mr-2.5 text-amber-600 dark:text-amber-400" />
                                    <span className="font-medium">Modify Status</span>
                                    <span className="ml-auto text-xs px-1.5 py-0.5 rounded-full bg-neutral-100 dark:bg-neutral-800 capitalize">
                                      {user.status || 'active'}
                                    </span>
                                  </DropdownMenuItem>
                                  <DropdownMenuItem 
                                    onClick={() => handleUserAction('toggleVerification', user)}
                                    className={user.isVerified ? "focus:bg-red-50 dark:focus:bg-red-900/20" : "focus:bg-green-50 dark:focus:bg-green-900/20"} 
                                  >
                                    {user.isVerified ? (
                                      <>
                                        <UserX className="h-4 w-4 mr-2.5 text-red-600 dark:text-red-400" />
                                        <span className="font-medium">Remove Verification</span>
                                      </>
                                    ) : (
                                      <>
                                        <UserCheck className="h-4 w-4 mr-2.5 text-green-600 dark:text-green-400" />
                                        <span className="font-medium">Verify Account</span>
                                      </>
                                    )}
                                  </DropdownMenuItem>
                                  <DropdownMenuItem 
                                    onClick={() => handleUserAction('toggleActive', user)}
                                    className={user.isActive ? "focus:bg-red-50 dark:focus:bg-red-900/20" : "focus:bg-green-50 dark:focus:bg-green-900/20"}
                                  >
                                    {user.isActive ? (
                                      <>
                                        <Lock className="h-4 w-4 mr-2.5 text-red-600 dark:text-red-400" />
                                        <span className="font-medium">Deactivate Account</span>
                                      </>
                                    ) : (
                                      <>
                                        <UserCheck className="h-4 w-4 mr-2.5 text-green-600 dark:text-green-400" />
                                        <span className="font-medium">Activate Account</span>
                                      </>
                                    )}
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator className="my-1.5" />
                                  
                                  {/* SECTION 3: Security Management */}
                                  <DropdownMenuLabel className="text-sm font-bold text-neutral-600 dark:text-neutral-300 pt-1.5">
                                    Security Management
                                  </DropdownMenuLabel>
                                  <DropdownMenuItem 
                                    onClick={() => handleUserAction('resetPassword', user)}
                                    className="focus:bg-purple-50 dark:focus:bg-purple-900/20"
                                  >
                                    <KeyRound className="h-4 w-4 mr-2.5 text-purple-600 dark:text-purple-400" />
                                    <span className="font-medium">Reset Password</span>
                                  </DropdownMenuItem>
                                  <DropdownMenuItem 
                                    onClick={() => handleUserAction('updateSecurityLevel', user)}
                                    className="focus:bg-purple-50 dark:focus:bg-purple-900/20"
                                  >
                                    <Shield className="h-4 w-4 mr-2.5 text-purple-600 dark:text-purple-400" />
                                    <span className="font-medium">Security Level</span>
                                    <span className="ml-auto text-xs px-1.5 py-0.5 rounded-full bg-neutral-100 dark:bg-neutral-800 capitalize">
                                      {user.securityLevel || 'standard'}
                                    </span>
                                  </DropdownMenuItem>
                                  <DropdownMenuItem 
                                    onClick={() => handleUserAction('resetLoginAttempts', user)} 
                                    disabled={!user.failedLoginAttempts || user.failedLoginAttempts === 0}
                                    className="focus:bg-purple-50 dark:focus:bg-purple-900/20"
                                  >
                                    <RefreshCcw className={`h-4 w-4 mr-2.5 ${(user.failedLoginAttempts || 0) > 0 ? 'text-red-600 dark:text-red-400' : 'text-purple-600 dark:text-purple-400'}`} />
                                    <span className="font-medium">Reset Login Attempts</span>
                                    {(user.failedLoginAttempts || 0) > 0 && (
                                      <span className="ml-auto text-xs px-1.5 py-0.5 rounded-full bg-red-100 dark:bg-red-900/40 text-red-800 dark:text-red-300">
                                        {user.failedLoginAttempts}
                                      </span>
                                    )}
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator className="my-1.5" />
                                  
                                  {/* SECTION 4: Restrictions & Risk Management */}
                                  <DropdownMenuLabel className="text-sm font-bold text-neutral-600 dark:text-neutral-300 pt-1.5">
                                    Restrictions & Risk
                                  </DropdownMenuLabel>
                                  <DropdownMenuSub>
                                    <DropdownMenuSubTrigger className="focus:bg-blue-50 dark:focus:bg-blue-900/20">
                                      <ShieldAlert className="h-4 w-4 mr-2.5 text-blue-600 dark:text-blue-400" />
                                      <span className="font-medium">Feature Restrictions</span>
                                      {(user.loginRestricted || user.transferRestricted || user.depositRestricted || 
                                        user.withdrawalRestricted || user.cardRestricted) && (
                                        <span className="ml-auto text-xs px-1.5 py-0.5 rounded-full bg-red-100 dark:bg-red-900/40 text-red-800 dark:text-red-300">
                                          Active
                                        </span>
                                      )}
                                    </DropdownMenuSubTrigger>
                                    <DropdownMenuSubContent className="w-64">
                                      <DropdownMenuItem onClick={() => handleUserAction('toggleLoginRestriction', user)}>
                                        <LogIn className={`h-4 w-4 mr-2.5 ${user.loginRestricted ? 'text-red-600' : 'text-blue-600'}`} />
                                        <span className="font-medium">{user.loginRestricted ? 'Allow Login' : 'Restrict Login'}</span>
                                        {user.loginRestricted && (
                                          <span className="ml-auto text-xs px-1.5 py-0.5 rounded-full bg-red-100 text-red-800">
                                            Blocked
                                          </span>
                                        )}
                                      </DropdownMenuItem>
                                      <DropdownMenuItem onClick={() => handleUserAction('toggleTransferRestriction', user)}>
                                        <ArrowLeftRight className={`h-4 w-4 mr-2.5 ${user.transferRestricted ? 'text-red-600' : 'text-blue-600'}`} />
                                        <span className="font-medium">{user.transferRestricted ? 'Allow Transfers' : 'Restrict Transfers'}</span>
                                        {user.transferRestricted && (
                                          <span className="ml-auto text-xs px-1.5 py-0.5 rounded-full bg-red-100 text-red-800">
                                            Blocked
                                          </span>
                                        )}
                                      </DropdownMenuItem>
                                      <DropdownMenuItem onClick={() => handleUserAction('toggleDepositRestriction', user)}>
                                        <ArrowDownToLine className={`h-4 w-4 mr-2.5 ${user.depositRestricted ? 'text-red-600' : 'text-blue-600'}`} />
                                        <span className="font-medium">{user.depositRestricted ? 'Allow Deposits' : 'Restrict Deposits'}</span>
                                        {user.depositRestricted && (
                                          <span className="ml-auto text-xs px-1.5 py-0.5 rounded-full bg-red-100 text-red-800">
                                            Blocked
                                          </span>
                                        )}
                                      </DropdownMenuItem>
                                      <DropdownMenuItem onClick={() => handleUserAction('toggleWithdrawalRestriction', user)}>
                                        <ArrowUpFromLine className={`h-4 w-4 mr-2.5 ${user.withdrawalRestricted ? 'text-red-600' : 'text-blue-600'}`} />
                                        <span className="font-medium">{user.withdrawalRestricted ? 'Allow Withdrawals' : 'Restrict Withdrawals'}</span>
                                        {user.withdrawalRestricted && (
                                          <span className="ml-auto text-xs px-1.5 py-0.5 rounded-full bg-red-100 text-red-800">
                                            Blocked
                                          </span>
                                        )}
                                      </DropdownMenuItem>
                                      <DropdownMenuItem onClick={() => handleUserAction('toggleCardRestriction', user)}>
                                        <CreditCard className={`h-4 w-4 mr-2.5 ${user.cardRestricted ? 'text-red-600' : 'text-blue-600'}`} />
                                        <span className="font-medium">{user.cardRestricted ? 'Allow Card Usage' : 'Restrict Card Usage'}</span>
                                        {user.cardRestricted && (
                                          <span className="ml-auto text-xs px-1.5 py-0.5 rounded-full bg-red-100 text-red-800">
                                            Blocked
                                          </span>
                                        )}
                                      </DropdownMenuItem>
                                      <DropdownMenuSeparator />
                                      <DropdownMenuItem onClick={() => handleUserAction('removeAllRestrictions', user)} className="focus:bg-green-50 dark:focus:bg-green-900/20">
                                        <ShieldCheck className="h-4 w-4 mr-2.5 text-green-600 dark:text-green-400" />
                                        <span className="font-medium">Remove All Restrictions</span>
                                      </DropdownMenuItem>
                                    </DropdownMenuSubContent>
                                  </DropdownMenuSub>
                                  
                                  <DropdownMenuItem 
                                    onClick={() => handleUserAction('toggleFraudAlert', user)}
                                    className={user.fraudAlert ? "focus:bg-amber-50 dark:focus:bg-amber-900/20" : "focus:bg-blue-50 dark:focus:bg-blue-900/20"}
                                  >
                                    <AlertTriangle className={`h-4 w-4 mr-2.5 ${user.fraudAlert ? 'text-amber-600 dark:text-amber-400' : 'text-blue-600 dark:text-blue-400'}`} />
                                    <span className="font-medium">{user.fraudAlert ? 'Remove Fraud Alert' : 'Set Fraud Alert'}</span>
                                    {user.fraudAlert && (
                                      <span className="ml-auto text-xs px-1.5 py-0.5 rounded-full bg-amber-100 dark:bg-amber-900/40 text-amber-800 dark:text-amber-300">
                                        Active
                                      </span>
                                    )}
                                  </DropdownMenuItem>
                                  
                                  {/* SECTION 5: Critical Actions */}
                                  <DropdownMenuSeparator className="my-1.5" />
                                  <DropdownMenuLabel className="text-sm font-bold text-neutral-600 dark:text-neutral-300 pt-1.5">
                                    Critical Actions
                                  </DropdownMenuLabel>
                                  {!user.isBlocked ? (
                                    <DropdownMenuItem 
                                      onClick={() => handleUserAction('blockUser', user)}
                                      className="text-red-600 focus:bg-red-50 dark:focus:bg-red-900/20 dark:text-red-400"
                                    >
                                      <Lock className="h-4 w-4 mr-2.5 text-red-600 dark:text-red-400" />
                                      <span className="font-medium">Block Account</span>
                                    </DropdownMenuItem>
                                  ) : (
                                    <DropdownMenuItem 
                                      onClick={() => handleUserAction('unblockUser', user)}
                                      className="text-green-600 focus:bg-green-50 dark:focus:bg-green-900/20 dark:text-green-400"
                                    >
                                      <Unlock className="h-4 w-4 mr-2.5 text-green-600 dark:text-green-400" />
                                      <span className="font-medium">Unblock Account</span>
                                      {user.blockReason && (
                                        <span className="ml-auto text-xs px-1.5 py-0.5 rounded-full bg-red-100 dark:bg-red-900/40 text-red-800 dark:text-red-300">
                                          Blocked
                                        </span>
                                      )}
                                    </DropdownMenuItem>
                                  )}
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
                
                <div className="flex justify-between items-center mt-6">
                  <div className="text-sm text-neutral-500 dark:text-neutral-400">
                    Showing {filteredUsers.length} of {users.length} users
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" disabled>Previous</Button>
                    <Button variant="outline" size="sm" disabled>Next</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
      
      {/* User Details Side Panel */}
      <Sheet open={showUserDetails} onOpenChange={setShowUserDetails}>
        <SheetContent className="w-full sm:max-w-md overflow-y-auto">
          <SheetHeader className="pb-4">
            <SheetTitle>User Profile</SheetTitle>
            <SheetDescription>View complete user information and account details</SheetDescription>
          </SheetHeader>
          
          {selectedUser && (
            <div className="mt-6 space-y-6">
              <div className="flex flex-col items-center text-center">
                <Avatar className="h-20 w-20 mb-3">
                  <AvatarFallback className="text-lg bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200">
                    {selectedUser.firstName[0]}{selectedUser.lastName[0]}
                  </AvatarFallback>
                </Avatar>
                <h3 className="text-xl font-semibold">{selectedUser.firstName} {selectedUser.lastName}</h3>
                <p className="text-neutral-500 dark:text-neutral-400">@{selectedUser.username}</p>
                <div className="flex gap-2 mt-2">
                  <Badge 
                    variant="outline"
                    className={`${
                      selectedUser.isActive 
                        ? "bg-green-50 text-green-700 border-green-200 dark:bg-green-950 dark:text-green-300 dark:border-green-800" 
                        : "bg-red-50 text-red-700 border-red-200 dark:bg-red-950 dark:text-red-300 dark:border-red-800"
                    }`}
                  >
                    {selectedUser.isActive ? "Active" : "Inactive"}
                  </Badge>
                  <Badge 
                    variant="outline"
                    className={`${
                      selectedUser.isVerified 
                        ? "bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950 dark:text-blue-300 dark:border-blue-800" 
                        : selectedUser.kycStatus === 'pending'
                          ? "bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-950 dark:text-yellow-300 dark:border-yellow-800"
                          : "bg-neutral-50 text-neutral-700 border-neutral-200 dark:bg-neutral-950 dark:text-neutral-300 dark:border-neutral-800"
                    }`}
                  >
                    {selectedUser.isVerified ? "Verified" : selectedUser.kycStatus === 'pending' ? "Pending KYC" : "Unverified"}
                  </Badge>
                  <Badge 
                    variant="outline"
                    className="bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-950 dark:text-purple-300 dark:border-purple-800"
                  >
                    {selectedUser.role}
                  </Badge>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h4 className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Personal Information</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Email</p>
                    <p className="text-neutral-900 dark:text-neutral-100">{selectedUser.email}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Joined</p>
                    <p className="text-neutral-900 dark:text-neutral-100">{formatDate(selectedUser.createdAt)}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Last Login</p>
                    <p className="text-neutral-900 dark:text-neutral-100">{selectedUser.lastLogin ? formatDate(selectedUser.lastLogin) : "Never"}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Total Balance</p>
                    <p className="text-neutral-900 dark:text-neutral-100 font-medium">
                      ${selectedUser.balance || "0.00"}
                    </p>
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h4 className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Accounts</h4>
                {userDetails?.accounts && userDetails.accounts.length > 0 ? (
                  <div className="space-y-3">
                    {userDetails.accounts.map(account => (
                      <div key={account.id} className="bg-neutral-50 dark:bg-neutral-900 p-3 rounded-md border border-neutral-200 dark:border-neutral-700">
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="font-medium">{account.accountType}</p>
                            <p className="text-sm text-neutral-500 dark:text-neutral-400">{account.accountNumber}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-medium">${account.balance}</p>
                            <Badge variant="outline" className="bg-green-50 text-green-700 mt-1">
                              {account.status}
                            </Badge>
                          </div>
                        </div>
                        <div className="flex gap-2 mt-3 justify-end">
                          <Button 
                            variant="outline" 
                            size="sm"
                            className="flex items-center gap-1 text-green-600 border-green-200 hover:bg-green-50"
                            onClick={() => {
                              setSelectedAccount(account);
                              setShowTopUpDialog(true);
                            }}
                          >
                            <TrendingUp className="h-3.5 w-3.5" />
                            <span>Top-up</span>
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                            className="flex items-center gap-1 text-red-600 border-red-200 hover:bg-red-50"
                            onClick={() => {
                              setSelectedAccount(account);
                              setShowSubtractDialog(true);
                            }}
                          >
                            <TrendingDown className="h-3.5 w-3.5" />
                            <span>Subtract</span>
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                            className="flex items-center gap-1 border-amber-200 hover:bg-amber-50"
                            onClick={() => {
                              setSelectedAccount(account);
                              setShowAddTransactionDialog(true);
                            }}
                          >
                            <DollarSign className="h-3.5 w-3.5" />
                            <span>Add Transaction</span>
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-neutral-500 dark:text-neutral-400">No accounts found</p>
                )}
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h4 className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Recent Transactions</h4>
                {userDetails?.transactions && userDetails.transactions.length > 0 ? (
                  <div className="space-y-3">
                    {userDetails.transactions.map(transaction => (
                      <div key={transaction.id} className="bg-neutral-50 dark:bg-neutral-900 p-3 rounded-md border border-neutral-200 dark:border-neutral-700">
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="font-medium">{transaction.description}</p>
                            <p className="text-xs text-neutral-500 dark:text-neutral-400">{formatDate(transaction.date)}</p>
                          </div>
                          <div className="text-right">
                            <p className={`font-medium ${
                              transaction.type === 'deposit' 
                                ? 'text-green-600 dark:text-green-400' 
                                : 'text-red-600 dark:text-red-400'
                            }`}>
                              {transaction.type === 'deposit' ? '+' : '-'}${transaction.amount}
                            </p>
                            <Badge variant="outline" className="bg-blue-50 text-blue-700 mt-1 text-xs">
                              {transaction.status}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-neutral-500 dark:text-neutral-400">No recent transactions</p>
                )}
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h4 className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Actions</h4>
                <div className="flex flex-col gap-3">
                  <Button variant="outline" className="justify-start">
                    <Edit className="mr-2 h-4 w-4" />
                    Edit User Profile
                  </Button>
                  <Button 
                    variant="outline" 
                    className="justify-start"
                    onClick={() => handleUserAction('toggleActive', selectedUser)}
                  >
                    {selectedUser.isActive ? (
                      <>
                        <Lock className="mr-2 h-4 w-4" />
                        Deactivate Account
                      </>
                    ) : (
                      <>
                        <UserCheck className="mr-2 h-4 w-4" />
                        Activate Account
                      </>
                    )}
                  </Button>
                  <Button 
                    variant="outline" 
                    className="justify-start"
                    onClick={() => handleUserAction('toggleVerification', selectedUser)}
                  >
                    {selectedUser.isVerified ? (
                      <>
                        <UserX className="mr-2 h-4 w-4" />
                        Remove Verification
                      </>
                    ) : (
                      <>
                        <UserCheck className="mr-2 h-4 w-4" />
                        Mark as Verified
                      </>
                    )}
                  </Button>
                  <Button 
                    variant="outline" 
                    className="justify-start text-red-600 dark:text-red-400"
                    onClick={() => {
                      setShowUserDetails(false);
                      setShowResetPasswordDialog(true);
                    }}
                  >
                    <KeyRound className="mr-2 h-4 w-4" />
                    Reset Password
                  </Button>
                </div>
              </div>
            </div>
          )}
          
          <SheetFooter className="mt-6">
            <SheetClose asChild>
              <Button variant="outline">Close</Button>
            </SheetClose>
          </SheetFooter>
        </SheetContent>
      </Sheet>
      
      {/* Reset Password Dialog */}
      <Dialog open={showResetPasswordDialog} onOpenChange={setShowResetPasswordDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reset User Password</DialogTitle>
            <DialogDescription>
              This will send a password reset link to the user's email address.
              They'll be able to set a new password using this link.
            </DialogDescription>
          </DialogHeader>
          
          {selectedUser && (
            <div className="py-4">
              <div className="flex items-center gap-4 p-3 rounded-md bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800">
                <AlertCircle className="h-10 w-10 text-amber-600" />
                <div>
                  <p className="font-medium text-amber-800 dark:text-amber-300">
                    Confirm Password Reset
                  </p>
                  <p className="text-sm text-amber-700 dark:text-amber-400">
                    You are about to reset the password for {selectedUser.firstName} {selectedUser.lastName} ({selectedUser.email}).
                  </p>
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowResetPasswordDialog(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleResetPassword}
              disabled={resetPasswordMutation.isPending}
            >
              {resetPasswordMutation.isPending ? (
                <>
                  <span className="animate-spin mr-2">⟳</span>
                  Sending...
                </>
              ) : (
                "Send Reset Link"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Confirm Action Dialog */}
      <Dialog open={!!confirmAction.action} onOpenChange={() => setConfirmAction({ action: '', userId: null })}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {confirmAction.action === 'activate' 
                ? "Activate User Account" 
                : confirmAction.action === 'deactivate' 
                  ? "Deactivate User Account" 
                  : "Confirm Action"
              }
            </DialogTitle>
            <DialogDescription>
              {confirmAction.action === 'activate' 
                ? "This will re-enable the user's access to the platform and all its features."
                : confirmAction.action === 'deactivate'
                  ? "This will temporarily disable the user's access to the platform. They will not be able to log in until reactivated."
                  : "Please confirm this action."
              }
            </DialogDescription>
          </DialogHeader>
          
          <div className="flex items-start gap-4 p-4 rounded-md bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700">
            {confirmAction.action === 'activate' ? (
              <CheckCircle className="h-10 w-10 text-green-600" />
            ) : confirmAction.action === 'deactivate' ? (
              <AlertCircle className="h-10 w-10 text-amber-600" />
            ) : (
              <AlertCircle className="h-10 w-10 text-blue-600" />
            )}
            <div>
              <p className="font-medium">
                {confirmAction.action === 'activate' 
                  ? "User will regain access to their account"
                  : confirmAction.action === 'deactivate'
                    ? "User will temporarily lose access to their account"
                    : "Confirm this action"
                }
              </p>
              <p className="text-sm text-neutral-500 dark:text-neutral-400">
                {confirmAction.action === 'activate' 
                  ? "The user will be notified via email about this change."
                  : confirmAction.action === 'deactivate'
                    ? "Any active sessions for this user will be terminated."
                    : "This action cannot be undone."
                }
              </p>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirmAction({ action: '', userId: null })}>
              Cancel
            </Button>
            <Button 
              onClick={handleConfirmAction}
              variant={confirmAction.action === 'activate' ? "default" : "destructive"}
              disabled={toggleUserStatusMutation.isPending}
            >
              {toggleUserStatusMutation.isPending ? (
                <>
                  <span className="animate-spin mr-2">⟳</span>
                  Processing...
                </>
              ) : (
                confirmAction.action === 'activate' 
                  ? "Activate User" 
                  : confirmAction.action === 'deactivate'
                    ? "Deactivate User"
                    : "Confirm"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Block User Dialog */}
      <Dialog open={showBlockDialog} onOpenChange={setShowBlockDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Block User Account</DialogTitle>
            <DialogDescription>
              This will block the user account and prevent any access to the banking platform.
              <p className="mt-2 font-medium">
                User: {selectedUser?.firstName} {selectedUser?.lastName} ({selectedUser?.username})
              </p>
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="blockReason">Block Reason <span className="text-red-500">*</span></Label>
                <Textarea 
                  id="blockReason" 
                  value={blockReason} 
                  onChange={(e) => setBlockReason(e.target.value)}
                  placeholder="Please provide a detailed reason for blocking this account"
                  className="min-h-[100px]"
                />
                {blockReason.length === 0 && (
                  <p className="text-sm text-red-500">Block reason is required</p>
                )}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setShowBlockDialog(false);
              setBlockReason('');
            }}>Cancel</Button>
            <Button 
              variant="destructive" 
              onClick={handleBlockUser} 
              disabled={blockUserMutation.isPending || blockReason.length === 0}
            >
              {blockUserMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Blocking...
                </>
              ) : "Block Account"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Update Status Dialog */}
      <Dialog open={showStatusDialog} onOpenChange={setShowStatusDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update User Status</DialogTitle>
            <DialogDescription>
              Set the account status for {selectedUser?.firstName} {selectedUser?.lastName}.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="space-y-4">
              <RadioGroup 
                value={selectedStatus} 
                onValueChange={setSelectedStatus}
                className="space-y-2"
              >
                <div className="grid grid-cols-1 gap-2">
                  {statusOptions.map((status) => (
                    <div key={status} className="flex items-center space-x-2">
                      <RadioGroupItem value={status} id={`status-${status}`} />
                      <Label htmlFor={`status-${status}`} className="capitalize">
                        {status}
                        <span className="text-xs text-neutral-500 ml-2 block">
                          {status === 'active' && 'Full account access'}
                          {status === 'suspended' && 'Temporary account restriction'}
                          {status === 'dormant' && 'Inactive account with limited access'}
                          {status === 'investigating' && 'Under investigation by compliance team'}
                        </span>
                      </Label>
                    </div>
                  ))}
                </div>
              </RadioGroup>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowStatusDialog(false)}>Cancel</Button>
            <Button 
              onClick={handleUpdateStatus} 
              disabled={updateUserStatusMutation.isPending || !selectedStatus}
            >
              {updateUserStatusMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Updating...
                </>
              ) : "Update Status"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Update Security Level Dialog */}
      <Dialog open={showSecurityLevelDialog} onOpenChange={setShowSecurityLevelDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Set Security Level</DialogTitle>
            <DialogDescription>
              Update security level for {selectedUser?.firstName} {selectedUser?.lastName}.
              This affects authentication requirements and transaction limits.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="space-y-4">
              <RadioGroup 
                value={selectedSecurityLevel} 
                onValueChange={setSelectedSecurityLevel}
                className="space-y-2"
              >
                <div className="grid grid-cols-1 gap-2">
                  {securityLevelOptions.map((level) => (
                    <div key={level} className="flex items-center space-x-2">
                      <RadioGroupItem value={level} id={`level-${level}`} />
                      <Label htmlFor={`level-${level}`} className="capitalize">
                        {level}
                        <span className="text-xs text-neutral-500 ml-2 block">
                          {level === 'standard' && 'Basic authentication and transaction limits'}
                          {level === 'enhanced' && 'Additional verification steps for sensitive operations'}
                          {level === 'high' && 'Multi-factor authentication for all transactions'}
                          {level === 'maximum' && 'Strictest limits and verification requirements'}
                        </span>
                      </Label>
                    </div>
                  ))}
                </div>
              </RadioGroup>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSecurityLevelDialog(false)}>Cancel</Button>
            <Button 
              onClick={handleUpdateSecurityLevel} 
              disabled={updateSecurityLevelMutation.isPending || !selectedSecurityLevel}
            >
              {updateSecurityLevelMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Updating...
                </>
              ) : "Update Security Level"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Block User Dialog */}
      <Dialog open={showBlockDialog} onOpenChange={setShowBlockDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Block User Account</DialogTitle>
            <DialogDescription>
              This will prevent the user from accessing their account. Please provide a reason for blocking.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="blockReason" className="text-left">Reason for blocking</Label>
              <Textarea
                id="blockReason"
                value={blockReason}
                onChange={(e) => setBlockReason(e.target.value)}
                placeholder="Enter the reason for blocking this user..."
                className="resize-none"
                rows={4}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowBlockDialog(false)}>Cancel</Button>
            <Button 
              variant="destructive"
              onClick={handleBlockUser} 
              disabled={blockUserMutation.isPending || !blockReason.trim()}
            >
              {blockUserMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Blocking User...
                </>
              ) : "Block User"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Update User Status Dialog */}
      <Dialog open={showStatusDialog} onOpenChange={setShowStatusDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update User Status</DialogTitle>
            <DialogDescription>
              Select the appropriate status for this user account.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label className="text-left">Account Status</Label>
              <RadioGroup 
                value={selectedStatus} 
                onValueChange={setSelectedStatus}
                className="flex flex-col space-y-1"
              >
                {statusOptions.map(status => (
                  <div key={status} className="flex items-center space-x-2">
                    <RadioGroupItem value={status} id={`status-${status}`} />
                    <Label htmlFor={`status-${status}`} className="capitalize font-normal flex items-center">
                      {status === 'active' && <CheckCircle className="h-4 w-4 mr-2 text-green-500" />}
                      {status === 'suspended' && <AlertCircle className="h-4 w-4 mr-2 text-red-500" />}
                      {status === 'dormant' && <Clock className="h-4 w-4 mr-2 text-amber-500" />}
                      {status === 'investigating' && <HelpCircle className="h-4 w-4 mr-2 text-blue-500" />}
                      {status}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowStatusDialog(false)}>Cancel</Button>
            <Button 
              onClick={handleUpdateStatus} 
              disabled={updateUserStatusMutation.isPending || !selectedStatus}
            >
              {updateUserStatusMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Updating...
                </>
              ) : "Update Status"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Top-up Account Balance Dialog */}
      <Dialog open={showTopUpDialog} onOpenChange={setShowTopUpDialog}>
        <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-blue-600 dark:text-blue-400">Top-up Account Balance</DialogTitle>
            <DialogDescription>
              Add funds to the selected account. The amount will be credited immediately.
            </DialogDescription>
          </DialogHeader>
          
          {selectedAccount && (
            <div className="space-y-5 py-4">
              {/* Account Info Card */}
              <div className="bg-blue-50 dark:bg-blue-900/30 border border-blue-200 dark:border-blue-800 p-4 rounded-lg shadow-sm">
                <div className="flex items-center gap-3">
                  <div className="bg-blue-100 dark:bg-blue-800 p-2 rounded-full">
                    <CreditCard className="h-8 w-8 text-blue-600 dark:text-blue-300" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-blue-700 dark:text-blue-300">
                      {selectedAccount.accountType} Account
                    </h3>
                    <p className="text-sm text-blue-600 dark:text-blue-400">
                      Account Number: <span className="font-mono">{selectedAccount.accountNumber}</span>
                    </p>
                    <div className="mt-1.5 flex items-center gap-1.5">
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-300">Current Balance:</p>
                      <p className="text-sm font-semibold text-green-600 dark:text-green-400">
                        ${parseFloat(selectedAccount.balance || "0").toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Amount Field */}
              <div className="space-y-2.5">
                <div className="flex justify-between items-center">
                  <Label htmlFor="topup-amount" className="text-left font-medium">Amount (USD)</Label>
                  <span className="text-xs text-gray-500">Enter the amount to credit</span>
                </div>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 font-medium">$</span>
                  <Input
                    id="topup-amount"
                    className="pl-8 h-12 text-lg font-medium"
                    type="number"
                    step="0.01"
                    min="0.01"
                    placeholder="0.00"
                    value={amount}
                    onChange={(e) => {
                      setAmount(e.target.value);
                      setAmountSliderValue(parseFloat(e.target.value) || 0);
                    }}
                  />
                </div>
                
                {/* Amount Slider */}
                <div className="space-y-2 py-2">
                  <div className="flex justify-between items-center">
                    <Label htmlFor="topup-slider" className="text-left text-sm text-gray-600">Slide to adjust</Label>
                    <span className="text-sm font-medium text-blue-600">${amountSliderValue.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
                  </div>
                  <div className="relative py-2 touch-none">
                    <Slider 
                      id="topup-slider"
                      min={0} 
                      max={maxSliderAmount} 
                      step={10}
                      value={[amountSliderValue]} 
                      onValueChange={(value) => {
                        setAmountSliderValue(value[0]);
                        setAmount(value[0].toString());
                      }}
                      className="touch-none"
                    />
                  </div>
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>$0</span>
                    <span>${maxSliderAmount}</span>
                  </div>
                </div>
                
                {/* Quick Amount Buttons */}
                <div className="flex flex-wrap gap-2 mt-2">
                  {[50, 100, 500, 1000, 5000].map((quickAmount) => (
                    <Button 
                      key={quickAmount} 
                      type="button" 
                      variant={parseFloat(amount) === quickAmount ? "default" : "outline"} 
                      size="sm"
                      onClick={() => {
                        setAmount(quickAmount.toString());
                        setAmountSliderValue(quickAmount);
                      }}
                      className={`flex-1 min-w-20 ${parseFloat(amount) === quickAmount ? "bg-blue-600 hover:bg-blue-700" : ""}`}
                    >
                      ${quickAmount}
                    </Button>
                  ))}
                </div>
              </div>
              
              {/* Reason Field */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <Label htmlFor="topup-reason" className="text-left font-medium">Reason <span className="text-red-500">*</span></Label>
                  <span className="text-xs text-gray-500">Required</span>
                </div>
                <Input
                  id="topup-reason"
                  placeholder="Deposit reason"
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                />
                <p className="text-xs text-gray-500">This will appear in the transaction history.</p>
              </div>
              
              {/* Transaction Date */}
              <div className="space-y-2">
                <Label htmlFor="topup-date" className="text-left font-medium">Transaction Date</Label>
                <Input
                  id="topup-date"
                  type="date"
                  value={transactionDate}
                  onChange={(e) => setTransactionDate(e.target.value)}
                  max={new Date().toISOString().split('T')[0]}
                />
                <p className="text-xs text-gray-500">The date this transaction will be recorded with.</p>
              </div>
              
              {/* Effect Preview */}
              <div className="bg-gray-50 dark:bg-gray-800/50 p-3 rounded-md border border-gray-200 dark:border-gray-700">
                <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Transaction Preview</h4>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600 dark:text-gray-400">Current Balance:</span>
                  <span className="font-medium">${parseFloat(selectedAccount.balance || "0").toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600 dark:text-gray-400">Amount to Add:</span>
                  <span className="font-medium text-green-600">+${parseFloat(amount || "0").toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
                </div>
                <div className="flex justify-between text-sm font-semibold mt-2 pt-2 border-t border-gray-200 dark:border-gray-700">
                  <span className="text-gray-700 dark:text-gray-300">New Balance:</span>
                  <span>${(parseFloat(selectedAccount.balance || "0") + parseFloat(amount || "0")).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter className="flex-col sm:flex-row gap-3 sm:gap-0">
            <Button variant="outline" size="lg" onClick={() => setShowTopUpDialog(false)} className="w-full sm:w-auto">
              Cancel
            </Button>
            <Button 
              onClick={() => topUpAccountMutation.mutate({ 
                accountId: selectedAccount.id, 
                amount: amount,
                reason: reason,
                transactionDate: transactionDate
              })} 
              disabled={topUpAccountMutation.isPending || !amount || parseFloat(amount) <= 0 || !reason}
              size="lg"
              className="w-full sm:w-auto bg-green-600 hover:bg-green-700 text-white"
            >
              {topUpAccountMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Processing Transaction...
                </>
              ) : (
                <>
                  <ArrowUp className="mr-2 h-5 w-5" />
                  Confirm Top-Up
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Subtract from Account Balance Dialog */}
      <Dialog open={showSubtractDialog} onOpenChange={setShowSubtractDialog}>
        <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-amber-600 dark:text-amber-400">Subtract from Account Balance</DialogTitle>
            <DialogDescription>
              Deduct funds from the selected account. The amount will be withdrawn immediately.
            </DialogDescription>
          </DialogHeader>
          
          {selectedAccount && (
            <div className="space-y-5 py-4">
              {/* Account Info Card */}
              <div className="bg-amber-50 dark:bg-amber-900/30 border border-amber-200 dark:border-amber-800 p-4 rounded-lg shadow-sm">
                <div className="flex items-center gap-3">
                  <div className="bg-amber-100 dark:bg-amber-800 p-2 rounded-full">
                    <CreditCard className="h-8 w-8 text-amber-600 dark:text-amber-300" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-amber-700 dark:text-amber-300">
                      {selectedAccount.accountType} Account
                    </h3>
                    <p className="text-sm text-amber-600 dark:text-amber-400">
                      Account Number: <span className="font-mono">{selectedAccount.accountNumber}</span>
                    </p>
                    <div className="mt-1.5 flex items-center gap-1.5">
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-300">Current Balance:</p>
                      <p className="text-sm font-semibold text-green-600 dark:text-green-400">
                        ${parseFloat(selectedAccount.balance || "0").toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Amount Field */}
              <div className="space-y-2.5">
                <div className="flex justify-between items-center">
                  <Label htmlFor="subtract-amount" className="text-left font-medium">Amount (USD)</Label>
                  <span className="text-xs text-gray-500">Enter the amount to deduct</span>
                </div>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 font-medium">$</span>
                  <Input
                    id="subtract-amount"
                    className="pl-8 h-12 text-lg font-medium"
                    type="number"
                    step="0.01"
                    min="0.01"
                    max={selectedAccount.balance}
                    placeholder="0.00"
                    value={amount}
                    onChange={(e) => {
                      setAmount(e.target.value);
                      setAmountSliderValue(parseFloat(e.target.value) || 0);
                    }}
                  />
                </div>
                
                {/* Amount Slider */}
                <div className="space-y-2 py-2">
                  <div className="flex justify-between items-center">
                    <Label htmlFor="subtract-slider" className="text-left text-sm text-gray-600">Slide to adjust</Label>
                    <span className="text-sm font-medium text-amber-600">${amountSliderValue.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
                  </div>
                  <div className="relative py-2 touch-none">
                    <Slider 
                      id="subtract-slider"
                      min={0} 
                      max={parseFloat(selectedAccount.balance || maxSliderAmount)} 
                      step={10}
                      value={[amountSliderValue]} 
                      onValueChange={(value) => {
                        setAmountSliderValue(value[0]);
                        setAmount(value[0].toString());
                      }}
                      className="touch-none"
                    />
                  </div>
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>$0</span>
                    <span>${parseFloat(selectedAccount.balance || "0").toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
                  </div>
                </div>
                
                {/* Quick Amount Buttons */}
                <div className="flex flex-wrap gap-2 mt-2">
                  {[50, 100, 250, 500, 1000].map((quickAmount) => (
                    <Button 
                      key={quickAmount} 
                      type="button" 
                      variant={parseFloat(amount) === quickAmount ? "default" : "outline"} 
                      size="sm"
                      onClick={() => {
                        setAmount(quickAmount.toString());
                        setAmountSliderValue(quickAmount);
                      }}
                      className={`flex-1 min-w-20 ${parseFloat(amount) === quickAmount ? "bg-amber-600 hover:bg-amber-700" : ""}`}
                      disabled={quickAmount > parseFloat(selectedAccount.balance || "0")}
                    >
                      ${quickAmount}
                    </Button>
                  ))}
                </div>
              </div>
              
              {/* Transaction Date */}
              <div className="space-y-2">
                <Label htmlFor="subtract-date" className="text-left font-medium">Transaction Date</Label>
                <Input
                  id="subtract-date"
                  type="date"
                  value={transactionDate}
                  onChange={(e) => setTransactionDate(e.target.value)}
                  max={new Date().toISOString().split('T')[0]}
                />
                <p className="text-xs text-gray-500">The date this transaction will be recorded with.</p>
              </div>
              
              {/* Reason Field */}
              <div className="space-y-2.5">
                <div className="flex justify-between items-center">
                  <Label htmlFor="subtract-reason" className="text-left font-medium">Reason <span className="text-red-500">*</span></Label>
                  <span className="text-xs text-gray-500">Provide a detailed reason for this deduction</span>
                </div>
                <Textarea
                  id="subtract-reason"
                  placeholder="Reason for deduction (required)"
                  className="min-h-[80px]"
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                />
                <p className="text-xs text-gray-500">This reason will be recorded in the transaction history and may be visible to the account holder.</p>
              </div>
              
              {/* Effect Preview */}
              <div className="bg-gray-50 dark:bg-gray-800/50 p-3 rounded-md border border-gray-200 dark:border-gray-700">
                <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Transaction Preview</h4>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600 dark:text-gray-400">Current Balance:</span>
                  <span className="font-medium">${parseFloat(selectedAccount.balance || "0").toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600 dark:text-gray-400">Amount to Deduct:</span>
                  <span className="font-medium text-red-600">-${parseFloat(amount || "0").toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
                </div>
                <div className="flex justify-between text-sm font-semibold mt-2 pt-2 border-t border-gray-200 dark:border-gray-700">
                  <span className="text-gray-700 dark:text-gray-300">New Balance:</span>
                  <span>${Math.max(0, parseFloat(selectedAccount.balance || "0") - parseFloat(amount || "0")).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter className="flex-col sm:flex-row gap-3 sm:gap-0">
            <Button variant="outline" size="lg" onClick={() => setShowSubtractDialog(false)} className="w-full sm:w-auto">
              Cancel
            </Button>
            <Button 
              onClick={() => subtractFromAccountMutation.mutate({ 
                accountId: selectedAccount.id, 
                amount: amount,
                reason: reason,
                transactionDate: transactionDate
              })} 
              disabled={
                subtractFromAccountMutation.isPending || 
                !amount || 
                parseFloat(amount) <= 0 || 
                parseFloat(amount) > parseFloat(selectedAccount.balance || "0") ||
                !reason
              }
              size="lg"
              className="w-full sm:w-auto bg-red-600 hover:bg-red-700 text-white"
            >
              {subtractFromAccountMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Processing Transaction...
                </>
              ) : (
                <>
                  <ArrowDown className="mr-2 h-5 w-5" />
                  Confirm Subtraction
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Transaction Dialog */}
      <Dialog open={showAddTransactionDialog} onOpenChange={setShowAddTransactionDialog}>
        <DialogContent className="sm:max-w-[550px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-indigo-600 dark:text-indigo-400">Add New Transaction</DialogTitle>
            <DialogDescription>
              Create a new transaction for this account. This will affect the account balance.
            </DialogDescription>
          </DialogHeader>
          
          {selectedAccount && (
            <div className="space-y-5 py-4">
              {/* Account Info Card */}
              <div className="bg-indigo-50 dark:bg-indigo-900/30 border border-indigo-200 dark:border-indigo-800 p-4 rounded-lg shadow-sm">
                <div className="flex items-center gap-3">
                  <div className="bg-indigo-100 dark:bg-indigo-800 p-2 rounded-full">
                    <CreditCard className="h-8 w-8 text-indigo-600 dark:text-indigo-300" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-indigo-700 dark:text-indigo-300">
                      {selectedAccount.accountType} Account
                    </h3>
                    <p className="text-sm text-indigo-600 dark:text-indigo-400">
                      Account Number: <span className="font-mono">{selectedAccount.accountNumber}</span>
                    </p>
                    <div className="mt-1.5 flex items-center gap-1.5">
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-300">Current Balance:</p>
                      <p className="text-sm font-semibold text-green-600 dark:text-green-400">
                        ${parseFloat(selectedAccount.balance || "0").toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Transaction Type */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <Label className="text-left font-medium">Transaction Type</Label>
                  <span className="text-xs text-gray-500">Select the transaction direction</span>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div
                    className={`flex items-center gap-3 p-3 rounded-lg border-2 cursor-pointer transition-all ${
                      transactionType === 'credit'
                        ? 'border-green-500 bg-green-50 dark:bg-green-900/20'
                        : 'border-gray-200 dark:border-gray-700 hover:border-green-200 dark:hover:border-green-800/50'
                    }`}
                    onClick={() => setTransactionType('credit')}
                  >
                    <div className="bg-green-100 dark:bg-green-800/30 p-2 rounded-full">
                      <ArrowDown className="h-5 w-5 text-green-600 dark:text-green-400" />
                    </div>
                    <div>
                      <p className="font-medium text-green-700 dark:text-green-300">Credit</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">Money coming in</p>
                    </div>
                  </div>
                  
                  <div
                    className={`flex items-center gap-3 p-3 rounded-lg border-2 cursor-pointer transition-all ${
                      transactionType === 'debit'
                        ? 'border-red-500 bg-red-50 dark:bg-red-900/20'
                        : 'border-gray-200 dark:border-gray-700 hover:border-red-200 dark:hover:border-red-800/50'
                    }`}
                    onClick={() => setTransactionType('debit')}
                  >
                    <div className="bg-red-100 dark:bg-red-800/30 p-2 rounded-full">
                      <ArrowUp className="h-5 w-5 text-red-600 dark:text-red-400" />
                    </div>
                    <div>
                      <p className="font-medium text-red-700 dark:text-red-300">Debit</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">Money going out</p>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Amount Field */}
              <div className="space-y-2.5">
                <div className="flex justify-between items-center">
                  <Label htmlFor="transaction-amount" className="text-left font-medium">Amount (USD)</Label>
                  <span className="text-xs text-gray-500">Enter the transaction amount</span>
                </div>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 font-medium">$</span>
                  <Input
                    id="transaction-amount"
                    className="pl-8 h-12 text-lg font-medium"
                    type="number"
                    step="0.01"
                    min="0.01"
                    placeholder="0.00"
                    value={amount}
                    onChange={(e) => {
                      setAmount(e.target.value);
                      setAmountSliderValue(parseFloat(e.target.value) || 0);
                    }}
                  />
                </div>
                
                {/* Amount Slider */}
                <div className="space-y-2 py-2">
                  <div className="flex justify-between items-center">
                    <Label htmlFor="transaction-slider" className="text-left text-sm text-gray-600">Slide to adjust</Label>
                    <span className="text-sm font-medium text-indigo-600">${amountSliderValue.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
                  </div>
                  <div className="relative py-2 touch-none">
                    <Slider 
                      id="transaction-slider"
                      min={0} 
                      max={transactionType === 'debit' ? parseFloat(selectedAccount.balance || maxSliderAmount) : maxSliderAmount}
                      step={10}
                      value={[amountSliderValue]} 
                      onValueChange={(value) => {
                        setAmountSliderValue(value[0]);
                        setAmount(value[0].toString());
                      }}
                      className="touch-none"
                    />
                  </div>
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>$0</span>
                    <span>${transactionType === 'debit' 
                      ? parseFloat(selectedAccount.balance || "0").toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})
                      : maxSliderAmount.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})
                    }</span>
                  </div>
                </div>
                
                {/* Quick Amount Buttons */}
                <div className="flex flex-wrap gap-2 mt-2">
                  {[50, 100, 250, 500, 1000].map((quickAmount) => (
                    <Button 
                      key={quickAmount} 
                      type="button" 
                      variant={parseFloat(amount) === quickAmount ? "default" : "outline"} 
                      size="sm"
                      onClick={() => {
                        setAmount(quickAmount.toString());
                        setAmountSliderValue(quickAmount);
                      }}
                      className={`flex-1 min-w-20 ${parseFloat(amount) === quickAmount 
                        ? transactionType === 'debit' 
                          ? "bg-red-600 hover:bg-red-700" 
                          : "bg-indigo-600 hover:bg-indigo-700" 
                        : ""}`}
                      disabled={transactionType === 'debit' && quickAmount > parseFloat(selectedAccount.balance || "0")}
                    >
                      ${quickAmount}
                    </Button>
                  ))}
                </div>
              </div>
              
              {/* Transaction Date and Time */}
              <div className="space-y-2.5">
                <div className="flex justify-between items-center">
                  <Label htmlFor="transaction-date" className="text-left font-medium">Transaction Date & Time</Label>
                  <span className="text-xs text-gray-500">When the transaction occurred</span>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Input
                      id="transaction-date"
                      type="date"
                      value={transactionDate}
                      onChange={(e) => setTransactionDate(e.target.value)}
                      max={new Date().toISOString().split('T')[0]}
                      className="font-medium"
                    />
                  </div>
                  <div>
                    <Input
                      id="transaction-time"
                      type="time"
                      value={transactionTime}
                      onChange={(e) => setTransactionTime(e.target.value)}
                      className="font-medium"
                    />
                  </div>
                </div>
                <p className="text-xs text-gray-500">Admin can backdate or set precise transaction times for record-keeping.</p>
              </div>

              {/* Description Field */}
              <div className="space-y-2.5">
                <div className="flex justify-between items-center">
                  <Label htmlFor="transaction-description" className="text-left font-medium">Description <span className="text-red-500">*</span></Label>
                  <span className="text-xs text-gray-500">Provide a description for this transaction</span>
                </div>
                <Input
                  id="transaction-description"
                  placeholder="Transaction description (required)"
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                />
                <p className="text-xs text-gray-500">This description will appear in the transaction history.</p>
              </div>
              
              {/* Additional Details */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="transaction-category" className="text-left font-medium">Category <span className="text-red-500">*</span></Label>
                  <Select 
                    value={transactionCategory}
                    onValueChange={setTransactionCategory}
                  >
                    <SelectTrigger id="transaction-category">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="deposit">Deposit</SelectItem>
                      <SelectItem value="withdrawal">Withdrawal</SelectItem>
                      <SelectItem value="transfer">Transfer</SelectItem>
                      <SelectItem value="payment">Bill Payment</SelectItem>
                      <SelectItem value="fee">Fee/Service Charge</SelectItem>
                      <SelectItem value="interest">Interest</SelectItem>
                      <SelectItem value="adjustment">Adjustment</SelectItem>
                      <SelectItem value="shopping">Shopping</SelectItem>
                      <SelectItem value="dining">Dining/Restaurant</SelectItem>
                      <SelectItem value="entertainment">Entertainment</SelectItem>
                      <SelectItem value="travel">Travel</SelectItem>
                      <SelectItem value="healthcare">Healthcare</SelectItem>
                      <SelectItem value="utilities">Utilities</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="transaction-merchant" className="text-left font-medium">Merchant Name</Label>
                  <Input
                    id="transaction-merchant"
                    placeholder="e.g., Amazon, Starbucks"
                    value={transactionMerchant}
                    onChange={(e) => setTransactionMerchant(e.target.value)}
                  />
                </div>
              </div>
              
              {/* Processing Details */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="transaction-method" className="text-left font-medium">Payment Method</Label>
                  <Select 
                    value={transactionMethod} 
                    onValueChange={setTransactionMethod}
                  >
                    <SelectTrigger id="transaction-method">
                      <SelectValue placeholder="Select method" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="card">Card Transaction</SelectItem>
                      <SelectItem value="ach">ACH Transfer</SelectItem>
                      <SelectItem value="wire">Wire Transfer</SelectItem>
                      <SelectItem value="check">Check</SelectItem>
                      <SelectItem value="cash">Cash</SelectItem>
                      <SelectItem value="internal">Internal Transfer</SelectItem>
                      <SelectItem value="electronic">Electronic Payment</SelectItem>
                      <SelectItem value="auto">Automated Transaction</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="transaction-status" className="text-left font-medium">Status</Label>
                  <Select 
                    value={transactionStatus} 
                    onValueChange={setTransactionStatus}
                  >
                    <SelectTrigger id="transaction-status">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="processing">Processing</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="failed">Failed</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                      <SelectItem value="on_hold">On Hold</SelectItem>
                      <SelectItem value="disputed">Disputed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              {/* Reference Numbers */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="reference-number" className="text-left font-medium">Reference Number</Label>
                  <Input
                    id="reference-number"
                    placeholder="e.g., TXN-123456789"
                    value={referenceNumber}
                    onChange={(e) => setReferenceNumber(e.target.value)}
                  />
                  <p className="text-xs text-gray-500">Auto-generated if left blank</p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="transaction-notes" className="text-left font-medium">Admin Notes</Label>
                  <Input
                    id="transaction-notes"
                    placeholder="Internal admin notes"
                    value={adminNotes}
                    onChange={(e) => setAdminNotes(e.target.value)}
                  />
                  <p className="text-xs text-gray-500">Not visible to customers</p>
                </div>
              </div>
              
              {/* Effect Preview */}
              <div className="bg-gray-50 dark:bg-gray-800/50 p-3 rounded-md border border-gray-200 dark:border-gray-700">
                <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Balance Preview</h4>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600 dark:text-gray-400">Current Balance:</span>
                  <span className="font-medium">${parseFloat(selectedAccount.balance || "0").toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600 dark:text-gray-400">{transactionType === 'credit' ? 'Amount to Add:' : 'Amount to Deduct:'}</span>
                  <span className={`font-medium ${transactionType === 'credit' ? 'text-green-600' : 'text-red-600'}`}>
                    {transactionType === 'credit' ? '+' : '-'}${parseFloat(amount || "0").toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                  </span>
                </div>
                <div className="flex justify-between text-sm font-semibold mt-2 pt-2 border-t border-gray-200 dark:border-gray-700">
                  <span className="text-gray-700 dark:text-gray-300">New Balance:</span>
                  <span>
                    ${(transactionType === 'credit' 
                      ? parseFloat(selectedAccount.balance || "0") + parseFloat(amount || "0") 
                      : Math.max(0, parseFloat(selectedAccount.balance || "0") - parseFloat(amount || "0")))
                      .toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                  </span>
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter className="flex-col sm:flex-row gap-3 sm:gap-0">
            <Button variant="outline" size="lg" onClick={() => setShowAddTransactionDialog(false)} className="w-full sm:w-auto">
              Cancel
            </Button>
            <Button 
              onClick={() => addTransactionMutation.mutate({ 
                accountId: selectedAccount.id, 
                amount: amount,
                transactionType,
                description: reason,
                category: transactionCategory || undefined,
                merchantName: transactionMerchant || undefined,
                transactionDate: transactionDate || undefined,
                transactionTime: transactionTime || undefined,
                method: transactionMethod || undefined,
                status: transactionStatus || undefined,
                referenceNumber: referenceNumber || undefined,
                adminNotes: adminNotes || undefined
              })} 
              disabled={
                addTransactionMutation.isPending || 
                !amount || 
                parseFloat(amount) <= 0 ||
                !reason ||
                !transactionCategory
              }
              size="lg"
              className={`w-full sm:w-auto ${
                transactionType === 'credit' 
                  ? "bg-green-600 hover:bg-green-700" 
                  : "bg-red-600 hover:bg-red-700"
              } text-white`}
            >
              {addTransactionMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Processing Transaction...
                </>
              ) : (
                <>
                  {transactionType === 'credit' 
                    ? <ArrowDown className="mr-2 h-5 w-5" />
                    : <ArrowUp className="mr-2 h-5 w-5" />
                  }
                  Create Transaction
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Login Restriction Dialog */}
      <Dialog open={showLoginRestrictionDialog} onOpenChange={setShowLoginRestrictionDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Restrict Login Access</DialogTitle>
            <DialogDescription>
              This will prevent the user from logging into their account. Please provide a reason for this restriction.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="restrictionReason" className="text-left">Reason for login restriction</Label>
              <Textarea
                id="restrictionReason"
                value={restrictionReason}
                onChange={(e) => setRestrictionReason(e.target.value)}
                placeholder="Enter the reason for restricting this user's login ability..."
                className="resize-none"
                rows={4}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowLoginRestrictionDialog(false)}>Cancel</Button>
            <Button 
              variant="destructive"
              onClick={handleApplyLoginRestriction} 
              disabled={toggleLoginRestrictionMutation.isPending || !restrictionReason.trim()}
            >
              {toggleLoginRestrictionMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Restricting Login...
                </>
              ) : "Restrict Login"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Transfer Restriction Dialog */}
      <Dialog open={showTransferRestrictionDialog} onOpenChange={setShowTransferRestrictionDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Restrict Transfer Access</DialogTitle>
            <DialogDescription>
              This will prevent the user from making transfers. Please provide a reason for this restriction.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="restrictionReason" className="text-left">Reason for transfer restriction</Label>
              <Textarea
                id="restrictionReason"
                value={restrictionReason}
                onChange={(e) => setRestrictionReason(e.target.value)}
                placeholder="Enter the reason for restricting this user's transfer ability..."
                className="resize-none"
                rows={4}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowTransferRestrictionDialog(false)}>Cancel</Button>
            <Button 
              variant="destructive"
              onClick={handleApplyTransferRestriction} 
              disabled={toggleTransferRestrictionMutation.isPending || !restrictionReason.trim()}
            >
              {toggleTransferRestrictionMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Restricting Transfers...
                </>
              ) : "Restrict Transfers"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Deposit Restriction Dialog */}
      <Dialog open={showDepositRestrictionDialog} onOpenChange={setShowDepositRestrictionDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Restrict Deposit Access</DialogTitle>
            <DialogDescription>
              This will prevent the user from making deposits. Please provide a reason for this restriction.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="restrictionReason" className="text-left">Reason for deposit restriction</Label>
              <Textarea
                id="restrictionReason"
                value={restrictionReason}
                onChange={(e) => setRestrictionReason(e.target.value)}
                placeholder="Enter the reason for restricting this user's deposit ability..."
                className="resize-none"
                rows={4}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDepositRestrictionDialog(false)}>Cancel</Button>
            <Button 
              variant="destructive"
              onClick={handleApplyDepositRestriction} 
              disabled={toggleDepositRestrictionMutation.isPending || !restrictionReason.trim()}
            >
              {toggleDepositRestrictionMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Restricting Deposits...
                </>
              ) : "Restrict Deposits"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Withdrawal Restriction Dialog */}
      <Dialog open={showWithdrawalRestrictionDialog} onOpenChange={setShowWithdrawalRestrictionDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Restrict Withdrawal Access</DialogTitle>
            <DialogDescription>
              This will prevent the user from making withdrawals. Please provide a reason for this restriction.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="restrictionReason" className="text-left">Reason for withdrawal restriction</Label>
              <Textarea
                id="restrictionReason"
                value={restrictionReason}
                onChange={(e) => setRestrictionReason(e.target.value)}
                placeholder="Enter the reason for restricting this user's withdrawal ability..."
                className="resize-none"
                rows={4}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowWithdrawalRestrictionDialog(false)}>Cancel</Button>
            <Button 
              variant="destructive"
              onClick={handleApplyWithdrawalRestriction} 
              disabled={toggleWithdrawalRestrictionMutation.isPending || !restrictionReason.trim()}
            >
              {toggleWithdrawalRestrictionMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Restricting Withdrawals...
                </>
              ) : "Restrict Withdrawals"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Card Restriction Dialog */}
      <Dialog open={showCardRestrictionDialog} onOpenChange={setShowCardRestrictionDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Restrict Card Access</DialogTitle>
            <DialogDescription>
              This will prevent the user from using their cards. Please provide a reason for this restriction.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="restrictionReason" className="text-left">Reason for card restriction</Label>
              <Textarea
                id="restrictionReason"
                value={restrictionReason}
                onChange={(e) => setRestrictionReason(e.target.value)}
                placeholder="Enter the reason for restricting this user's card access..."
                className="resize-none"
                rows={4}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCardRestrictionDialog(false)}>Cancel</Button>
            <Button 
              variant="destructive"
              onClick={handleApplyCardRestriction} 
              disabled={toggleCardRestrictionMutation.isPending || !restrictionReason.trim()}
            >
              {toggleCardRestrictionMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Restricting Cards...
                </>
              ) : "Restrict Cards"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}