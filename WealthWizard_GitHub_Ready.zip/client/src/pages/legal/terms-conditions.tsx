import { Button } from "@/components/ui/button";
import { Link, useLocation } from "wouter";
import { ArrowLeft, FileText, Shield, BookOpen, ChevronLeft } from "lucide-react";
import { Separator } from "@/components/ui/separator";

export default function TermsConditionsPage() {
  const [location, navigate] = useLocation();
  const isFromRegister = location.includes('from=register');
  
  const goBack = () => {
    // Always navigate directly to auth with register tab - more reliable than window.history.back()
    navigate('/auth?tab=register');
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8 flex items-center justify-between">
          <div className="flex items-center">
            <Button
              variant="outline"
              size="sm"
              className="mr-4"
              onClick={goBack}
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            
            <h1 className="text-2xl font-bold text-gray-900">Terms and Conditions</h1>
          </div>
          
          <div className="flex items-center">
            <FileText className="h-5 w-5 text-primary mr-2" />
            <span className="text-sm text-gray-600">Last updated: April 1, 2025</span>
          </div>
        </div>
        
        <div className="bg-white shadow-sm rounded-lg p-6 sm:p-8">
          <div className="prose prose-blue max-w-none">
            <div className="flex items-center mb-4">
              <Shield className="h-5 w-5 text-primary mr-2" />
              <h2 className="text-xl font-semibold mt-0 mb-0">Fortis Capital Account Agreement</h2>
            </div>
            
            <p className="text-sm text-gray-500 mb-6">
              This Terms and Conditions agreement ("Agreement") is between you and Fortis Capital ("Bank," "we," "our," or "us") 
              and governs your use of all accounts and services provided by Fortis Capital.
            </p>
            
            <h3 className="text-lg font-medium">1. Agreement Acceptance</h3>
            <p>
              By opening or maintaining an account with Fortis Capital, you agree to be bound by this Agreement, along with any
              other agreements, disclosures, rules, or notices relating to your accounts as Fortis Capital may provide from time to time.
              This Agreement may be amended at any time with notice provided to you as required by law.
            </p>
            
            <h3 className="text-lg font-medium">2. Account Ownership</h3>
            <p>
              Accounts may be owned in various forms, including individual accounts, joint accounts, trust accounts, or business accounts.
              The form of ownership for your account is designated on the signature card or electronic account opening documentation.
            </p>
            
            <h4 className="text-base font-medium">2.1 Individual Accounts</h4>
            <p>
              An individual account is owned by one person who is solely entitled to all funds in the account and who may withdraw funds
              and give us instructions regarding the account.
            </p>
            
            <h4 className="text-base font-medium">2.2 Joint Accounts</h4>
            <p>
              A joint account is owned by two or more persons. Each owner of a joint account possesses equal withdrawal rights and
              equal rights to give us instructions regarding the account. Each owner authorizes all other joint owners to act on
              his/her behalf with respect to the account and consents to any transaction involving the account made by another
              joint owner.
            </p>
            
            <h3 className="text-lg font-medium">3. Deposits</h3>
            <p>
              We may accept deposits to your account from any source and need not question the authority of the person making the
              deposit. We may refuse to accept a deposit for any reason or impose conditions on a deposit prior to accepting it.
              We are not responsible for deposits until a bank employee physically receives them. Deposits are subject to verification.
            </p>
            
            <h3 className="text-lg font-medium">4. Withdrawals</h3>
            <p>
              We may refuse to permit a withdrawal from your account in certain cases, including, but not limited to:
            </p>
            <ul>
              <li>If there is a dispute about the account;</li>
              <li>If a legal garnishment, attachment, or levy is served on the account;</li>
              <li>If the account is pledged as collateral for a debt;</li>
              <li>If any required documentation has not been presented; or</li>
              <li>If you are delinquent on any obligation to us.</li>
            </ul>
            
            <h3 className="text-lg font-medium">5. Fees and Charges</h3>
            <p>
              Your account is subject to the fees described in the Fee Schedule provided to you. We may deduct these fees and charges
              directly from your account balance. We may change our fees and charges at any time, and will provide notice as required
              by applicable law.
            </p>
            
            <h3 className="text-lg font-medium">6. Electronic Banking Services</h3>
            <p>
              We offer a variety of electronic banking services for use with your account, including but not limited to ATM and debit cards,
              online banking, mobile banking, and electronic fund transfers. These services are subject to additional terms and conditions
              provided at the time you enroll or activate these services.
            </p>
            
            <h3 className="text-lg font-medium">7. Statements</h3>
            <p>
              We will make account statements available to you as required by law. Statements may be delivered electronically if
              you have consented to electronic delivery. You agree to promptly examine your statements and report any errors or
              unauthorized transactions within 60 days from when the statement is first made available.
            </p>
            
            <h3 className="text-lg font-medium">8. Dispute Resolution</h3>
            <p>
              Any dispute, claim, or controversy arising out of or relating to this Agreement shall be settled by binding arbitration
              in accordance with the Commercial Arbitration Rules of the American Arbitration Association. Judgment upon the award
              rendered by the arbitrator may be entered in any court having jurisdiction.
            </p>
            
            <h3 className="text-lg font-medium">9. Governing Law</h3>
            <p>
              This Agreement is governed by federal law and, to the extent not preempted by federal law, the laws of the state
              where your account is established, without regard to conflict of law principles.
            </p>
            
            <h3 className="text-lg font-medium">10. Contact Information</h3>
            <p>
              For questions regarding your account or this Agreement, please contact our Customer Service at 1-800-555-1234 or
              visit any of our branch locations.
            </p>
            
            <div className="bg-gray-50 p-4 rounded-lg mt-8 mb-4">
              <p className="text-sm text-gray-700">
                <strong>Note:</strong> This is a simplified version of a bank account agreement provided for demonstration purposes only. 
                Actual bank terms and conditions are typically more comprehensive and address additional requirements under 
                applicable federal and state laws.
              </p>
            </div>
          </div>
        </div>
        
        <div className="mt-6 flex justify-between">
          <Link to="/legal/privacy-policy?from=register">
            <Button variant="outline" size="sm">
              <BookOpen className="h-4 w-4 mr-2" />
              Privacy Policy
            </Button>
          </Link>
          
          <Button 
            variant="outline" 
            size="sm" 
            onClick={goBack}
          >
            <ChevronLeft className="h-4 w-4 mr-2" />
            Go Back
          </Button>
        </div>
      </div>
    </div>
  );
}