import { Button } from "@/components/ui/button";
import { Link, useLocation } from "wouter";
import { ArrowLeft, FileText, Shield, BookOpen, Lock, ChevronLeft } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

export default function PrivacyPolicyPage() {
  const [location, navigate] = useLocation();
  const isFromRegister = location.includes('from=register');
  
  const goBack = () => {
    // Always navigate directly to auth with register tab - more reliable than window.history.back()
    navigate('/auth?tab=register');
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8 flex items-center justify-between">
          <div className="flex items-center">
            <Button
              variant="outline"
              size="sm"
              className="mr-4"
              onClick={goBack}
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            
            <h1 className="text-2xl font-bold text-gray-900">Privacy Policy</h1>
          </div>
          
          <div className="flex items-center">
            <FileText className="h-5 w-5 text-primary mr-2" />
            <span className="text-sm text-gray-600">Last updated: April 1, 2025</span>
          </div>
        </div>
        
        <div className="bg-white shadow-sm rounded-lg p-6 sm:p-8">
          <div className="prose prose-blue max-w-none">
            <div className="flex items-center mb-4">
              <Lock className="h-5 w-5 text-primary mr-2" />
              <h2 className="text-xl font-semibold mt-0 mb-0">Fortis Capital Privacy Notice</h2>
            </div>
            
            <div className="text-sm text-gray-500 space-y-2 mb-6">
              <p>
                At Fortis Capital, we respect your privacy and are committed to protecting your personal information.
                This Privacy Notice explains how we collect, use, disclose, and safeguard your information.
              </p>
              <p>
                Please review this Privacy Notice carefully. By using our services or opening an account with us,
                you consent to the practices described in this notice.
              </p>
            </div>
            
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="information-collected">
                <AccordionTrigger className="text-lg font-medium">
                  Information We Collect
                </AccordionTrigger>
                <AccordionContent>
                  <p className="my-2">We collect various types of information, including:</p>
                  <ul className="list-disc pl-6 space-y-1">
                    <li>
                      <strong>Personal Information:</strong> Name, address, email address, phone number, date of birth,
                      Social Security number or Tax Identification Number.
                    </li>
                    <li>
                      <strong>Financial Information:</strong> Account balances, transaction history, credit history,
                      income, and assets.
                    </li>
                    <li>
                      <strong>Online Information:</strong> IP address, device information, browsing history on our
                      website, and information collected through cookies and other tracking technologies.
                    </li>
                    <li>
                      <strong>Authentication Information:</strong> Username, password, security questions and answers.
                    </li>
                  </ul>
                  <p className="mt-4">
                    We collect information directly from you, from your transactions with us, from third parties
                    (such as credit reporting agencies), and through your use of our website and mobile applications.
                  </p>
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="information-use">
                <AccordionTrigger className="text-lg font-medium">
                  How We Use Your Information
                </AccordionTrigger>
                <AccordionContent>
                  <p className="my-2">We use your information for various purposes, including to:</p>
                  <ul className="list-disc pl-6 space-y-1">
                    <li>Process transactions and provide you with requested products and services</li>
                    <li>Verify your identity and prevent fraud or unauthorized activity</li>
                    <li>Assess your eligibility for products and services</li>
                    <li>Respond to your inquiries and provide customer support</li>
                    <li>Send you important information about your accounts, products, and services</li>
                    <li>Send you marketing communications about products and services that may interest you</li>
                    <li>Improve our website, products, and services</li>
                    <li>Comply with legal and regulatory requirements</li>
                    <li>Conduct risk management and business operations</li>
                  </ul>
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="information-sharing">
                <AccordionTrigger className="text-lg font-medium">
                  How We Share Your Information
                </AccordionTrigger>
                <AccordionContent>
                  <p className="my-2">
                    We may share your information with the following categories of third parties:
                  </p>
                  <ul className="list-disc pl-6 space-y-1">
                    <li>
                      <strong>Service Providers:</strong> Companies that perform services on our behalf,
                      such as processing transactions, maintaining accounts, and providing customer service.
                    </li>
                    <li>
                      <strong>Financial Companies:</strong> Credit bureaus, other financial institutions,
                      and payment processors to process your transactions.
                    </li>
                    <li>
                      <strong>Government Agencies:</strong> In response to lawful requests, such as court orders,
                      subpoenas, or as required by applicable laws and regulations.
                    </li>
                    <li>
                      <strong>Other Third Parties:</strong> With your consent or as otherwise permitted by law.
                    </li>
                  </ul>
                  <div className="bg-blue-50 p-4 rounded mt-4">
                    <h4 className="text-sm font-medium text-blue-800 mb-1">Important Privacy Rights Notice:</h4>
                    <p className="text-sm text-blue-700">
                      Federal law gives you the right to limit some types of information sharing.
                      For details on your rights and how to exercise them, see our full Privacy Notice or
                      call us at 1-800-555-1234.
                    </p>
                  </div>
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="security">
                <AccordionTrigger className="text-lg font-medium">
                  How We Protect Your Information
                </AccordionTrigger>
                <AccordionContent>
                  <p className="my-2">
                    We maintain administrative, technical, and physical safeguards designed to protect
                    your personal information against accidental, unlawful, or unauthorized access,
                    disclosure, alteration, or destruction. These safeguards include:
                  </p>
                  <ul className="list-disc pl-6 space-y-1">
                    <li>Encryption of sensitive information</li>
                    <li>Firewalls and network security measures</li>
                    <li>Secure access controls to our systems and facilities</li>
                    <li>Regular security assessments and testing</li>
                    <li>Employee training on privacy and information security</li>
                  </ul>
                  <p className="mt-4">
                    Despite our efforts, no security system is completely impenetrable. We cannot guarantee
                    the security of our databases, nor can we guarantee that information you provide won't
                    be intercepted while being transmitted to us over the Internet.
                  </p>
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="cookies">
                <AccordionTrigger className="text-lg font-medium">
                  Cookies and Tracking Technologies
                </AccordionTrigger>
                <AccordionContent>
                  <p className="my-2">
                    We use cookies and similar technologies to enhance your experience on our website, analyze
                    usage patterns, tailor our content and offers, and enable certain functionality.
                  </p>
                  <p className="my-2">The types of cookies we use include:</p>
                  <ul className="list-disc pl-6 space-y-1">
                    <li><strong>Essential cookies:</strong> Required for basic website functionality</li>
                    <li><strong>Functional cookies:</strong> Enable enhanced features and personalization</li>
                    <li><strong>Analytics cookies:</strong> Help us understand how visitors use our website</li>
                    <li><strong>Advertising cookies:</strong> Used to deliver relevant advertisements</li>
                  </ul>
                  <p className="mt-4">
                    You can manage your cookie preferences through your browser settings. However,
                    disabling certain cookies may limit your ability to use some features of our website.
                  </p>
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="your-rights">
                <AccordionTrigger className="text-lg font-medium">
                  Your Rights and Choices
                </AccordionTrigger>
                <AccordionContent>
                  <p className="my-2">
                    Depending on your location and applicable laws, you may have certain rights regarding
                    your personal information, including:
                  </p>
                  <ul className="list-disc pl-6 space-y-1">
                    <li>The right to access and receive a copy of your personal information</li>
                    <li>The right to correct inaccurate or incomplete information</li>
                    <li>The right to request deletion of your personal information</li>
                    <li>The right to restrict or object to processing of your information</li>
                    <li>The right to opt-out of certain types of communications</li>
                    <li>The right to withdraw consent where processing is based on consent</li>
                  </ul>
                  <p className="mt-4">
                    To exercise these rights or for questions about our privacy practices,
                    please contact us using the information provided at the end of this notice.
                  </p>
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="updates">
                <AccordionTrigger className="text-lg font-medium">
                  Updates to This Privacy Notice
                </AccordionTrigger>
                <AccordionContent>
                  <p className="my-2">
                    We may update this Privacy Notice from time to time to reflect changes in our practices,
                    technologies, legal requirements, or other factors. We will notify you of any material
                    changes as required by applicable law, including by posting the updated Privacy Notice
                    on our website with a new effective date.
                  </p>
                  <p className="my-2">
                    We encourage you to periodically review this Privacy Notice to stay informed about
                    how we collect, use, and protect your information.
                  </p>
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="contact">
                <AccordionTrigger className="text-lg font-medium">
                  Contact Us
                </AccordionTrigger>
                <AccordionContent>
                  <p className="my-2">
                    If you have questions, concerns, or requests regarding this Privacy Notice or our
                    privacy practices, please contact us at:
                  </p>
                  <div className="my-4 p-4 bg-gray-50 rounded-lg">
                    <p className="font-medium">Fortis Capital</p>
                    <p>Privacy Office</p>
                    <p>123 Financial Street</p>
                    <p>New York, NY 10001</p>
                    <p className="mt-2">Phone: 1-800-555-1234</p>
                    <p>Email: privacy@fortiscapital.com</p>
                  </div>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
            
            <div className="bg-gray-50 p-4 rounded-lg mt-8 mb-4">
              <p className="text-sm text-gray-700">
                <strong>Note:</strong> This is a simplified version of a privacy policy provided for demonstration purposes only. 
                Actual bank privacy notices are typically more comprehensive and must comply with various laws including 
                the Gramm-Leach-Bliley Act, the California Consumer Privacy Act, and other applicable regulations.
              </p>
            </div>
          </div>
        </div>
        
        <div className="mt-6 flex justify-between">
          <Link to="/legal/terms-conditions?from=register">
            <Button variant="outline" size="sm">
              <BookOpen className="h-4 w-4 mr-2" />
              Terms and Conditions
            </Button>
          </Link>
          
          <Button 
            variant="outline" 
            size="sm" 
            onClick={goBack}
          >
            <ChevronLeft className="h-4 w-4 mr-2" />
            Go Back
          </Button>
        </div>
      </div>
    </div>
  );
}