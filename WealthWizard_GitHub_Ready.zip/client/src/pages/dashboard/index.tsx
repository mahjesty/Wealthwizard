import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import AccountCard from "@/components/dashboard/account-card";
import TransactionItem from "@/components/dashboard/transaction-item";
import SpendingChart from "@/components/dashboard/spending-chart";
import TransferModal from "@/components/modals/transfer-modal";
import { BiometricPrompt } from "@/components/auth/biometric-prompt";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  AddCard, 
  AccountBalance,
  VerifiedUser,
  CreditScore,
  InsertChart,
  NotificationsActive,
  StarRate,
  ArrowForward
} from "@mui/icons-material";
import { formatCurrency } from "@/lib/utils";

export default function Dashboard() {
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [lastActivity, setLastActivity] = useState("");
  const [securityScore, setSecurityScore] = useState(85);
  const [showBiometricPrompt, setShowBiometricPrompt] = useState(false);
  
  // Calculate time of day and last activity on component mount
  useEffect(() => {
    // Set last activity time for realistic appearance
    const now = new Date();
    setLastActivity(`${now.toLocaleDateString()} at ${now.toLocaleTimeString()}`);
  }, []);
  
  // Fetch user data
  const { data: user } = useQuery({
    queryKey: ["/api/auth/me"],
  });
  
  // Fetch accounts
  const { data: accounts = [] } = useQuery({
    queryKey: ["/api/accounts"],
  });
  
  // Fetch recent transactions
  const { data: transactions = [] } = useQuery({
    queryKey: ["/api/transactions/recent"],
  });
  
  // Calculate total balance across all accounts
  const totalBalance = accounts.reduce((sum, account) => {
    const balanceNum = parseFloat(account.balance || "0");
    // For credit cards, don't add to total balance
    return account.accountType === "credit_card" ? sum : sum + balanceNum;
  }, 0);
  
  // Calculate spending by category from transactions
  const totalSpending = transactions.reduce((sum, transaction) => {
    if (transaction.transactionType === "purchase" || transaction.transactionType === "payment") {
      return sum + parseFloat(transaction.amount);
    }
    return sum;
  }, 0);
  
  // Wouter navigation hook
  const [, navigate] = useLocation();

  // Handle security alerts - redirect to settings page
  const handleSecurityAlert = () => {
    navigate("/settings");
  };
  

  
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      {/* Biometric registration prompt */}
      {user && showBiometricPrompt && (
        <BiometricPrompt 
          onSuccess={() => setShowBiometricPrompt(false)}
          onCancel={() => setShowBiometricPrompt(false)}
        />
      )}
      
      <main className="flex-grow bg-neutral-50 dark:bg-neutral-900">
        <div className="container mx-auto px-4 py-6">
          {/* Dashboard Header with Security Status */}
          <div className="mb-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
              <div>
                <h1 className="text-2xl md:text-3xl font-bold text-neutral-900 dark:text-white">
                  Good {getTimeOfDay()}, {user?.firstName || "User"}
                </h1>
                <p className="text-neutral-600 dark:text-neutral-400 mt-1">
                  Last login: {lastActivity}
                </p>
              </div>
              <div className="mt-4 md:mt-0 flex items-center">
                <Badge variant="outline" className="flex items-center bg-blue-50 text-blue-700 dark:bg-blue-900 dark:text-blue-300 mr-3 px-3 py-1">
                  <VerifiedUser className="w-4 h-4 mr-1" />
                  <span>Secure Connection</span>
                </Badge>
                <Button variant="outline" size="sm" onClick={handleSecurityAlert}>
                  <NotificationsActive className="w-4 h-4 mr-1" />
                  <span>Security Center</span>
                </Button>
              </div>
            </div>
          </div>
          
          {/* Tabs for different banking sections */}
          <Tabs defaultValue="overview" className="mb-6">
            <TabsList className="mb-4">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="accounts">Accounts</TabsTrigger>
              <TabsTrigger value="transactions">Transactions</TabsTrigger>
              <TabsTrigger value="insights">Insights</TabsTrigger>
            </TabsList>
            
            {/* Overview Tab */}
            <TabsContent value="overview">
              {/* Financial Summary Card */}
              <Card className="p-6 mb-8 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900 dark:to-indigo-900 border-none shadow-md">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <h3 className="text-sm font-medium text-neutral-600 dark:text-neutral-400 mb-1">
                      Total Balance
                    </h3>
                    <div className="text-3xl font-bold text-neutral-900 dark:text-white">
                      {formatCurrency(totalBalance)}
                    </div>
                    <p className="text-sm text-neutral-600 dark:text-neutral-400 mt-2">
                      Across {accounts.filter(a => a.accountType !== "credit_card").length} accounts
                    </p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-neutral-600 dark:text-neutral-400 mb-1">
                      Security Score
                    </h3>
                    <div className="flex items-center">
                      <span className="text-3xl font-bold text-neutral-900 dark:text-white mr-2">
                        {securityScore}%
                      </span>
                      <VerifiedUser className="text-green-600 dark:text-green-400" />
                    </div>
                    <Progress value={securityScore} className="h-2 mt-2" />
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-neutral-600 dark:text-neutral-400 mb-1">
                      Credit Score
                    </h3>
                    <div className="flex items-center">
                      <span className="text-3xl font-bold text-neutral-900 dark:text-white mr-2">
                        Excellent
                      </span>
                      <CreditScore className="text-green-600 dark:text-green-400" />
                    </div>
                    <div className="flex items-center mt-2">
                      <Button variant="link" className="p-0 h-auto text-primary">
                        View Credit Report
                        <ArrowForward className="w-4 h-4 ml-1" />
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
              
              {/* Account Overview Cards */}
              <div className="mb-8">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-semibold text-neutral-900 dark:text-white">
                    Your Accounts
                  </h2>
                  <Button variant="outline" size="sm" asChild>
                    <Link href="/accounts">View All</Link>
                  </Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {accounts.map((account) => (
                    <AccountCard 
                      key={account.id}
                      id={account.id}
                      type={account.accountType}
                      name={account.accountName}
                      accountNumber={account.accountNumber}
                      balance={account.balance}
                      availableBalance={account.availableBalance}
                    />
                  ))}
                </div>
              </div>
              

              
              {/* Recent Transactions and Analysis */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
                {/* Recent Transactions */}
                <Card className="lg:col-span-2 p-6">
                  <div className="flex justify-between items-center mb-6">
                    <h2 className="text-xl font-bold text-neutral-900 dark:text-white">Recent Transactions</h2>
                    <Button variant="ghost" size="sm" asChild>
                      <Link href="/accounts">View All</Link>
                    </Button>
                  </div>
                  
                  <div className="space-y-4">
                    {transactions.length === 0 ? (
                      <p className="text-neutral-500 dark:text-neutral-400 text-center py-4">
                        No recent transactions found
                      </p>
                    ) : (
                      transactions.slice(0, 5).map((transaction) => (
                        <TransactionItem 
                          key={transaction.id}
                          id={transaction.id}
                          type={transaction.transactionType}
                          amount={transaction.amount}
                          description={transaction.description}
                          merchantName={transaction.merchantName || "Unknown Merchant"}
                          category={transaction.category || "other"}
                          date={transaction.transactionDate}
                          status={transaction.status}
                        />
                      ))
                    )}
                  </div>
                </Card>
                
                {/* Spending Analysis */}
                <Card className="p-6">
                  <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-bold text-neutral-900 dark:text-white">Spending</h2>
                  </div>
                  <SpendingChart />
                </Card>
              </div>
              
              {/* Financial Insights */}
              <div className="mb-6">
                <h2 className="text-xl font-bold text-neutral-900 dark:text-white mb-4">
                  Financial Insights
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="p-5 border-l-4 border-l-blue-500">
                    <div className="flex items-start">
                      <InsertChart className="text-blue-500 mr-3" />
                      <div>
                        <h3 className="font-medium mb-1">Budget Analysis</h3>
                        <p className="text-sm text-neutral-600 dark:text-neutral-400">You're spending 15% less on dining compared to last month.</p>
                      </div>
                    </div>
                  </Card>
                  
                  <Card className="p-5 border-l-4 border-l-green-500">
                    <div className="flex items-start">
                      <AccountBalance className="text-green-500 mr-3" />
                      <div>
                        <h3 className="font-medium mb-1">Savings Opportunity</h3>
                        <p className="text-sm text-neutral-600 dark:text-neutral-400">Transfer unused checking funds to your high-yield savings account.</p>
                      </div>
                    </div>
                  </Card>
                  
                  <Card className="p-5 border-l-4 border-l-amber-500">
                    <div className="flex items-start">
                      <StarRate className="text-amber-500 mr-3" />
                      <div>
                        <h3 className="font-medium mb-1">Loyalty Rewards</h3>
                        <p className="text-sm text-neutral-600 dark:text-neutral-400">You have 12,500 points available. Consider redeeming them.</p>
                      </div>
                    </div>
                  </Card>
                </div>
              </div>
            </TabsContent>
            
            {/* Accounts Tab */}
            <TabsContent value="accounts">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold text-neutral-900 dark:text-white">
                  All Your Accounts
                </h2>
                <Button>
                  <AddCard className="w-4 h-4 mr-2" />
                  Open New Account
                </Button>
              </div>
              
              <div className="space-y-6">
                {accounts.map((account) => (
                  <AccountCard 
                    key={account.id}
                    id={account.id}
                    type={account.accountType}
                    name={account.accountName}
                    accountNumber={account.accountNumber}
                    balance={account.balance}
                    availableBalance={account.availableBalance}
                  />
                ))}
              </div>
            </TabsContent>
            
            {/* Transactions Tab */}
            <TabsContent value="transactions">
              <Card className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-bold text-neutral-900 dark:text-white">
                    Recent Transactions
                  </h2>
                  
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm">
                      Filter
                    </Button>
                    <Button variant="outline" size="sm">
                      Export
                    </Button>
                  </div>
                </div>
                
                <div className="space-y-4">
                  {transactions.length === 0 ? (
                    <p className="text-neutral-500 dark:text-neutral-400 text-center py-4">
                      No recent transactions found
                    </p>
                  ) : (
                    transactions.map((transaction) => (
                      <TransactionItem 
                        key={transaction.id}
                        id={transaction.id}
                        type={transaction.transactionType}
                        amount={transaction.amount}
                        description={transaction.description}
                        merchantName={transaction.merchantName || "Unknown Merchant"}
                        category={transaction.category || "other"}
                        date={transaction.transactionDate}
                        status={transaction.status}
                      />
                    ))
                  )}
                </div>
              </Card>
            </TabsContent>
            
            {/* Insights Tab */}
            <TabsContent value="insights">
              <Card className="p-6 mb-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-bold text-neutral-900 dark:text-white">
                    Spending Breakdown
                  </h2>
                  <div className="flex items-center">
                    <span className="text-neutral-600 dark:text-neutral-400 mr-3">
                      Total Spending: {formatCurrency(totalSpending)}
                    </span>
                    <Button variant="outline" size="sm">Monthly</Button>
                  </div>
                </div>
                <SpendingChart />
              </Card>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="p-6">
                  <h3 className="text-lg font-bold text-neutral-900 dark:text-white mb-4">
                    Income vs Expenses
                  </h3>
                  <div className="flex items-center justify-between mb-6">
                    <div className="text-center">
                      <div className="text-sm text-neutral-600 dark:text-neutral-400">Income</div>
                      <div className="text-2xl font-bold text-green-600">{formatCurrency(8500)}</div>
                    </div>
                    <div className="h-10 w-0.5 bg-neutral-200 dark:bg-neutral-700"></div>
                    <div className="text-center">
                      <div className="text-sm text-neutral-600 dark:text-neutral-400">Expenses</div>
                      <div className="text-2xl font-bold text-red-600">{formatCurrency(5750)}</div>
                    </div>
                    <div className="h-10 w-0.5 bg-neutral-200 dark:bg-neutral-700"></div>
                    <div className="text-center">
                      <div className="text-sm text-neutral-600 dark:text-neutral-400">Savings</div>
                      <div className="text-2xl font-bold text-blue-600">{formatCurrency(2750)}</div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Income Utilization</span>
                        <span className="text-sm font-medium">67%</span>
                      </div>
                      <Progress value={67} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Savings Rate</span>
                        <span className="text-sm font-medium">32%</span>
                      </div>
                      <Progress value={32} className="h-2" />
                    </div>
                  </div>
                </Card>
                
                <Card className="p-6">
                  <h3 className="text-lg font-bold text-neutral-900 dark:text-white mb-4">
                    Financial Health Score
                  </h3>
                  <div className="mb-6 text-center">
                    <div className="inline-flex items-center justify-center w-32 h-32 rounded-full bg-gradient-to-r from-green-400 to-emerald-500 text-white">
                      <div>
                        <div className="text-3xl font-bold">92</div>
                        <div className="text-sm">Excellent</div>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Emergency Fund</span>
                        <span className="text-sm font-medium">100%</span>
                      </div>
                      <Progress value={100} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Debt Management</span>
                        <span className="text-sm font-medium">85%</span>
                      </div>
                      <Progress value={85} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Retirement Planning</span>
                        <span className="text-sm font-medium">78%</span>
                      </div>
                      <Progress value={78} className="h-2" />
                    </div>
                  </div>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      <Footer />
      
      {/* Transfer Modal */}
      <TransferModal 
        isOpen={isTransferModalOpen} 
        onClose={() => setIsTransferModalOpen(false)} 
      />
    </div>
  );
}

// Helper function to get time of day greeting
function getTimeOfDay() {
  const hour = new Date().getHours();
  if (hour < 12) return "morning";
  if (hour < 18) return "afternoon";
  return "evening";
}
