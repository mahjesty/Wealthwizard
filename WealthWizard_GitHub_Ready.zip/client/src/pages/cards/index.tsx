import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage,
  FormDescription
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { 
  CreditCard, 
  Lock, 
  LockOpen, 
  Eye, 
  EyeOff, 
  ChevronRight, 
  Plus, 
  History,
  Receipt,
  ShoppingCart, 
  Utensils,
  Book,
  CheckIcon,
  Copy,
  AlertCircle, 
  RefreshCw, 
  ShieldAlert, 
  ShieldCheck, 
  AlertTriangle,
  RefreshCcw, 
  Key, 
  Download, 
  Building, 
  Building2, 
  SlidersHorizontal as SliderHorizontal, 
  Info
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { FortisLogo } from "@/components/ui/fortis-logo";

interface CardDetails {
  id: number;
  accountId: number;
  cardNumber: string;
  cardType: string;
  expiryDate: string;
  cvv: string;
  cardholderName: string;
  isActive: boolean;
  isLocked: boolean;
  cardNetwork?: string; // Card network (Visa, Mastercard, etc)
  cardBrand?: string;   // Card tier (Standard, Gold, Platinum)
  cardVariant?: string; // Physical or virtual card
  purpose?: string;     // Purpose for virtual cards
  last4?: string;       // Last 4 digits of card number
  contactlessEnabled?: boolean; // NFC contactless payments enabled
  internationalEnabled?: boolean; // International transactions enabled
  onlinePurchasesEnabled?: boolean; // Online purchases enabled
}

export default function Cards() {
  const [activeTab, setActiveTab] = useState("physical");
  const [isAddCardOpen, setIsAddCardOpen] = useState(false);
  const [selectedCard, setSelectedCard] = useState<CardDetails | null>(null);
  const [isCardDetailsOpen, setIsCardDetailsOpen] = useState(false);
  const [showCardDetails, setShowCardDetails] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch cards
  const { data: cards = [], isLoading: isLoadingCards } = useQuery({
    queryKey: ["/api/cards"],
  });
  
  // Fetch accounts for adding new cards
  const { data: accounts = [], isLoading: isLoadingAccounts } = useQuery({
    queryKey: ["/api/accounts"],
  });
  
  // Fetch user data
  const { data: userData } = useQuery({
    queryKey: ["/api/auth/me"],
  });
  
  // Filter cards to show only virtual cards
  const virtualCards = cards.filter((card: CardDetails) => card.cardVariant === "virtual");
  
  // Card lock/unlock mutation
  const toggleLockMutation = useMutation({
    mutationFn: ({ id, isLocked }: { id: number; isLocked: boolean }) => {
      return apiRequest("PATCH", `/api/cards/${id}`, { isLocked });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cards"] });
      toast({
        title: "Card updated",
        description: "Card status has been updated successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Update failed",
        description: error.message || "There was an error updating the card.",
        variant: "destructive",
      });
    }
  });
  
  // Card settings mutation
  const updateCardSettingsMutation = useMutation({
    mutationFn: ({ id, settings }: { id: number; settings: Partial<CardDetails> }) => {
      return apiRequest("PATCH", `/api/cards/${id}`, settings);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cards"] });
      toast({
        title: "Settings updated",
        description: "Your card settings have been updated successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Settings update failed",
        description: error.message || "There was an error updating your card settings.",
        variant: "destructive",
      });
    }
  });
  
  // New card schema
  const newCardSchema = z.object({
    accountId: z.string().min(1, { message: "Account is required" }),
    cardType: z.string().min(1, { message: "Card type is required" }),
    cardholderName: z.string().min(1, { message: "Cardholder name is required" }),
    cardVariant: z.string().default("physical"),
    cardBrand: z.string().default("standard"),
    cardNetwork: z.string().default("visa"),
    purpose: z.string().optional(),
    spendingLimit: z.string().optional(),
    expirationDays: z.string().optional(),
    contactlessEnabled: z.boolean().default(true),
    internationalEnabled: z.boolean().default(false),
    onlinePurchasesEnabled: z.boolean().default(true),
  });
  
  const cardForm = useForm<z.infer<typeof newCardSchema>>({
    resolver: zodResolver(newCardSchema),
    defaultValues: {
      accountId: "",
      cardType: "debit",
      cardholderName: "",
      cardVariant: "virtual", // Always use virtual card variant
      cardBrand: "standard",
      cardNetwork: "visa",
      purpose: "",
      spendingLimit: "",
      expirationDays: "90",
      contactlessEnabled: true,
      internationalEnabled: false,
      onlinePurchasesEnabled: true
    }
  });

  // Card creation mutation
  const createCardMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/cards", data);
      return response.json(); // Parse JSON here directly
    },
    onSuccess: (cardData, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/cards"] });
      
      // Close card application dialog
      setIsAddCardOpen(false);
      
      // Show the newly created card details
      setSelectedCard(cardData);
      setIsCardDetailsOpen(true);
      // Card created successfully
      
      // Show success toast
      toast({
        title: variables.cardVariant === "virtual" ? "Virtual Card Created" : "Card Application Approved",
        description: variables.cardVariant === "virtual" 
          ? "Your virtual card is ready to use for online purchases." 
          : "Your physical card has been approved and will arrive in 7-10 business days.",
      });
      
      cardForm.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Card request failed",
        description: error.message || "There was an error processing your card request.",
        variant: "destructive",
      });
    }
  });
  
  const viewCardDetails = (card: CardDetails) => {
    setSelectedCard(card);
    setIsCardDetailsOpen(true);
  };
  
  const toggleCardLock = (card: CardDetails) => {
    toggleLockMutation.mutate({
      id: card.id,
      isLocked: !card.isLocked
    });
  };
  
  const handleAddCard = (values: z.infer<typeof newCardSchema>) => {
    // Generate random card details
    const generateCardNumber = () => {
      const prefix = values.cardNetwork === 'visa' ? '4' : 
                    values.cardNetwork === 'mastercard' ? '5' : 
                    values.cardNetwork === 'amex' ? '3' : '4';
      const randomNumbers = Array.from({length: 15}, () => Math.floor(Math.random() * 10)).join('');
      return prefix + randomNumbers.substring(0, prefix === '3' ? 14 : 15);
    };
    
    const generateCVV = () => {
      return Array.from({length: 3}, () => Math.floor(Math.random() * 10)).join('');
    };
    
    const generateExpiryDate = () => {
      const today = new Date();
      const expiryYears = values.cardVariant === 'virtual' ? 
        (parseInt(values.expirationDays || '90') / 365) : 3;
      const expiryMonth = today.getMonth() + 1;
      const expiryYear = today.getFullYear() + Math.floor(expiryYears);
      return `${expiryMonth.toString().padStart(2, '0')}/${(expiryYear % 100).toString().padStart(2, '0')}`;
    };
    
    const cardNumber = generateCardNumber();
    
    const data = {
      ...values,
      accountId: parseInt(values.accountId),
      cardNumber: cardNumber,
      last4: cardNumber.slice(-4),
      cvv: generateCVV(),
      expiryDate: generateExpiryDate(),
      spendingLimit: values.spendingLimit ? parseFloat(values.spendingLimit) : null,
    };
    
    createCardMutation.mutate(data);
  };
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow bg-neutral-50 dark:bg-neutral-900">
        <div className="container mx-auto px-4 py-6">
          {/* Page Header */}
          <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-neutral-900 dark:text-white">Cards</h1>
              <p className="text-neutral-600 dark:text-neutral-400 mt-1">
                Manage your debit and credit cards
              </p>
            </div>
            <Button onClick={() => setIsAddCardOpen(true)} className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Card
            </Button>
          </div>
          
          {/* Virtual Cards Section */}
          <div className="mb-6">
            <div className="bg-white dark:bg-neutral-900 shadow-sm rounded-lg">
              <div className="border-b border-neutral-200 dark:border-neutral-800">
                <div className="flex justify-between items-center px-6 py-4">
                  <h2 className="text-xl font-semibold text-neutral-900 dark:text-white">My Virtual Cards</h2>
                </div>
              </div>
              
              <div className="p-6">
                {isLoadingCards ? (
                  <div className="flex justify-center py-12">
                    <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                  </div>
                ) : virtualCards.length === 0 ? (
                  <div className="text-center py-16 px-6">
                    <div className="w-20 h-20 rounded-full bg-neutral-100 dark:bg-neutral-800 mx-auto flex items-center justify-center mb-4">
                      <CreditCard className="h-10 w-10 text-neutral-400" />
                    </div>
                    <h3 className="text-lg font-medium text-neutral-900 dark:text-white mb-2">No Virtual Cards</h3>
                    <p className="text-neutral-500 dark:text-neutral-400 max-w-md mx-auto mb-6">
                      You don't have any virtual cards yet. Create a virtual card for online shopping or subscriptions.
                    </p>
                    <Button onClick={() => {
                      setIsAddCardOpen(true);
                      cardForm.setValue("cardVariant", "virtual");
                    }} className="px-6">
                      Create a Virtual Card
                    </Button>
                  </div>
                ) : (
                  <div className="grid gap-6 md:grid-cols-2">
                    {virtualCards.map((card: CardDetails) => (
                      <div 
                        key={card.id} 
                        className="relative group overflow-hidden rounded-xl border border-neutral-200 dark:border-neutral-800 hover:shadow-lg transition-all duration-300"
                      >
                        {/* Card preview */}
                        <div className="p-4">
                          <div className="flex justify-between items-center mb-3">
                            <h3 className="font-medium text-neutral-900 dark:text-white">{card.cardBrand || 'Standard'} {card.cardType}</h3>
                            <Badge variant={card.isLocked ? "destructive" : "outline"}>
                              {card.isLocked ? "Locked" : "Active"}
                            </Badge>
                          </div>
                          
                          {/* Card representation */}
                          <div className="mb-3 cursor-pointer" onClick={() => viewCardDetails(card)}>
                            <div className="card-wrapper scale-75 md:scale-90 origin-top-left mx-auto md:mx-0">
                              <div className="card">
                                <div className="face front">
                                  <div className="bank-name flex items-center gap-1">
                                    <FortisLogo width={20} height={20} className="text-white" />
                                    <span>Fortis Capital {card.cardBrand || "Platinum"}</span>
                                  </div>
                                  <div className="chip">
                                    <div></div><div></div><div></div>
                                    <div></div><div></div><div></div>
                                  </div>
                                  <div className="number">{card.cardNumber || '•••• •••• •••• ' + (card.last4 || '••••')}</div>
                                  <div className="details">
                                    <span>
                                      <small>Card Holder</small>
                                      <strong>{card.cardholderName}</strong>
                                    </span>
                                    <span>
                                      <small>Expires</small>
                                      <strong>{card.expiryDate}</strong>
                                    </span>
                                  </div>
                                  <img 
                                    src="https://upload.wikimedia.org/wikipedia/commons/4/41/Visa_Logo.png" 
                                    alt="Visa" 
                                    className="visa-logo"
                                  />
                                </div>
                              </div>
                            </div>
                          </div>
                          
                          {/* Card actions */}
                          <div className="flex gap-2">
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="flex-1"
                              onClick={() => viewCardDetails(card)}
                            >
                              <Eye className="h-4 w-4 mr-1" />
                              Details
                            </Button>
                            <Button 
                              variant={card.isLocked ? "outline" : "secondary"} 
                              size="sm" 
                              className="flex-1"
                              onClick={() => toggleCardLock(card)}
                            >
                              {card.isLocked ? <LockOpen className="h-4 w-4 mr-1" /> : <Lock className="h-4 w-4 mr-1" />}
                              {card.isLocked ? "Unlock" : "Lock"}
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
      
      {/* Card Application Dialog - Chipper Cash Style */}
      <Dialog open={isAddCardOpen} onOpenChange={setIsAddCardOpen}>
        <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Apply for Fortis Capital Card</DialogTitle>
            <DialogDescription>
              Complete your application for a new Fortis Capital card.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            {/* Card eligibility information */}
            <div className="mb-6 border border-neutral-200 dark:border-neutral-700 rounded-md p-4 bg-neutral-50 dark:bg-neutral-800">
              <div className="flex items-start gap-3">
                <svg className="w-5 h-5 text-green-500 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                <div>
                  <h3 className="text-sm font-medium mb-1">You're eligible for a Fortis Capital Card</h3>
                  <p className="text-sm text-neutral-600 dark:text-neutral-400">
                    Our system has determined you qualify for a card based on your account history.
                  </p>
                </div>
              </div>
            </div>
            
            <Form {...cardForm}>
              <form onSubmit={cardForm.handleSubmit(handleAddCard)} className="space-y-5">
                <FormField
                  control={cardForm.control}
                  name="accountId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Link to Account</FormLabel>
                      <Select 
                        onValueChange={(value) => {
                          field.onChange(value);
                          // When account is selected, auto-populate the cardholder name
                          if (userData) {
                            cardForm.setValue("cardholderName", `${userData.firstName} ${userData.lastName}`);
                          }
                        }} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select account" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {accounts.map((account: any) => (
                            <SelectItem key={account.id} value={account.id.toString()}>
                              {account.accountName} ({account.accountType}) - {account.accountNumber}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        Select the account you want to link to your new card
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
          
                <FormField
                  control={cardForm.control}
                  name="cardholderName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Cardholder Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter name as it will appear on card" {...field} />
                      </FormControl>
                      <FormDescription>
                        Name must match your identification documents
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
          
                {/* Hidden field for cardVariant (always virtual) */}
                <input type="hidden" {...cardForm.register("cardVariant")} value="virtual" />
                
                {/* Virtual Card Info */}
                <div className="rounded-lg border p-4 bg-green-50 dark:bg-green-950 mb-4">
                  <div className="flex items-start space-x-3">
                    <div className="bg-green-100 dark:bg-green-900 rounded-full p-1.5">
                      <svg className="w-5 h-5 text-green-600 dark:text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium flex items-center text-green-800 dark:text-green-300 mb-1">
                        Virtual Card
                        <span className="ml-2 text-xs font-normal bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300 px-2 py-0.5 rounded">Instant Issue</span>
                      </h3>
                      <p className="text-xs text-green-700 dark:text-green-400">
                        Your virtual card will be created instantly and can be used immediately for online purchases.
                      </p>
                    </div>
                  </div>
                </div>
                              
                {/* Hidden fields - system determined values */}
                <input type="hidden" {...cardForm.register("cardType")} value="debit" />
                <input type="hidden" {...cardForm.register("cardNetwork")} value="visa" />
                <input type="hidden" {...cardForm.register("cardBrand")} value="standard" />
                <input type="hidden" {...cardForm.register("contactlessEnabled")} value="true" />
                
                {/* Card preview */}
                <div className="rounded-lg border border-neutral-200 dark:border-neutral-700 p-4 bg-white dark:bg-neutral-900">
                  <h3 className="text-sm font-medium mb-3">Your Card Preview</h3>
                  
                  <div className="card-wrapper mx-auto transform hover:rotate-0 rotate-3 hover:-translate-y-1 hover:shadow-2xl transition-all">
                    <div className="card">
                      <div className="face front">
                        <div className="bank-name flex items-center gap-1">
                          <FortisLogo width={20} height={20} className="text-white" />
                          <span>Fortis Capital {cardForm.watch("cardBrand") || "Platinum"}</span>
                        </div>
                        <div className="chip">
                          <div></div><div></div><div></div>
                          <div></div><div></div><div></div>
                        </div>
                        <div className="number">
                          {cardForm.watch("cardholderName") ? '5424 0000 1234 5678' : '•••• •••• •••• ••••'}
                        </div>
                        <div className="details">
                          <span>
                            <small>Card Holder</small>
                            <strong>{cardForm.watch("cardholderName") || "YOUR NAME"}</strong>
                          </span>
                          <span>
                            <small>Expires</small>
                            <strong>12/28</strong>
                          </span>
                        </div>
                        <img 
                          src="https://upload.wikimedia.org/wikipedia/commons/4/41/Visa_Logo.png" 
                          alt="Visa" 
                          className="visa-logo"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Card features and info message */}
                <div className="border border-neutral-200 dark:border-neutral-700 rounded-md p-4 bg-neutral-50 dark:bg-neutral-800">
                  <h3 className="text-sm font-medium mb-2">Card Features & Benefits</h3>
                  <ul className="space-y-2 text-sm text-neutral-600 dark:text-neutral-400">
                    <li className="flex items-start gap-2">
                      <svg className="w-4 h-4 text-green-500 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                      </svg>
                      <span>No monthly maintenance fees</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <svg className="w-4 h-4 text-green-500 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                      </svg>
                      <span>{cardForm.watch("cardVariant") === "virtual" ? 
                        "Use immediately for online purchases" : 
                        "Tap-to-pay contactless technology"}</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <svg className="w-4 h-4 text-green-500 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                      </svg>
                      <span>Real-time transaction notifications</span>
                    </li>
                  </ul>
                </div>
                
                <div className="border-t pt-4 mt-4">
                  <p className="text-sm text-neutral-500 dark:text-neutral-400 mb-4">
                    By applying for this card, you agree to the <a href="#" className="text-primary underline">Terms & Conditions</a> and <a href="#" className="text-primary underline">Cardholder Agreement</a>.
                  </p>
                </div>
          
                <DialogFooter>
                  <Button 
                    variant="outline" 
                    type="button" 
                    onClick={() => setIsAddCardOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" className="gap-2">
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                    {cardForm.watch("cardVariant") === "virtual" ? "Get Virtual Card" : "Apply for Card"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Card Details Dialog */}
      {selectedCard && (
        <Dialog open={isCardDetailsOpen} onOpenChange={setIsCardDetailsOpen}>
          <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center">
                <span>
                  {selectedCard.cardBrand || 'Standard'} {selectedCard.cardType.charAt(0).toUpperCase() + selectedCard.cardType.slice(1)} Card 
                </span>
                <Badge className="ml-2" variant={selectedCard.isLocked ? "destructive" : "outline"}>
                  {selectedCard.isLocked ? "Locked" : "Active"}
                </Badge>
              </DialogTitle>
              <DialogDescription>
                {selectedCard.purpose ? `Purpose: ${selectedCard.purpose}` : 'Manage your card settings and view details'}
              </DialogDescription>
            </DialogHeader>
            
            <div className="py-4">
              {/* Card display */}
              <div className="mb-6">
                <div className="card-wrapper">
                  <div className="card">
                    <div className="face front">
                      <div className="bank-name flex items-center gap-1">
                        <FortisLogo width={20} height={20} className="text-white" />
                        <span>Fortis Capital {selectedCard.cardBrand}</span>
                      </div>
                      <div className="chip">
                        <div></div><div></div><div></div>
                        <div></div><div></div><div></div>
                      </div>
                      <div className="number">{selectedCard.cardNumber || '•••• •••• •••• ••••'}</div>
                      <div className="details">
                        <span>
                          <small>Card Holder</small>
                          <strong>{selectedCard.cardholderName}</strong>
                        </span>
                        <span>
                          <small>Expires</small>
                          <strong>{selectedCard.expiryDate}</strong>
                        </span>
                      </div>
                      <img 
                        src="https://upload.wikimedia.org/wikipedia/commons/4/41/Visa_Logo.png" 
                        alt="Visa" 
                        className="visa-logo"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="space-y-6">
                <div className="flex gap-4 flex-wrap md:flex-nowrap">
                  {/* Left section with main details */}
                  <div className="w-full md:w-1/2 space-y-5">
                    {/* Main details */}
                    <div className="bg-neutral-50 dark:bg-neutral-800 rounded-lg p-4 border border-neutral-200 dark:border-neutral-700">
                      <h3 className="text-sm font-medium mb-3">Card Information</h3>
                      <dl className="space-y-3 text-sm">
                        <div className="flex justify-between">
                          <dt className="text-neutral-500 dark:text-neutral-400">Card Status</dt>
                          <dd className="font-medium">
                            {selectedCard.isLocked 
                              ? <Badge variant="destructive">Locked</Badge>
                              : <Badge variant="outline" className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">Active</Badge>
                            }
                          </dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-neutral-500 dark:text-neutral-400">Card Type</dt>
                          <dd className="font-medium capitalize">{selectedCard.cardBrand || 'Platinum'} {selectedCard.cardType}</dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-neutral-500 dark:text-neutral-400">Network</dt>
                          <dd className="font-medium capitalize">{selectedCard.cardNetwork || "Visa"}</dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-neutral-500 dark:text-neutral-400">Type</dt>
                          <dd className="font-medium">
                            <Badge variant="outline" className="capitalize bg-blue-50 text-blue-800 dark:bg-blue-900 dark:text-blue-300 border-blue-200 dark:border-blue-800">
                              {selectedCard.cardVariant || "Virtual"}
                            </Badge>
                          </dd>
                        </div>
                        {selectedCard.purpose && (
                          <div className="flex justify-between">
                            <dt className="text-neutral-500 dark:text-neutral-400">Purpose</dt>
                            <dd className="font-medium">{selectedCard.purpose}</dd>
                          </div>
                        )}
                      </dl>
                    </div>
                    
                    {/* Security details */}
                    <div className="bg-neutral-50 dark:bg-neutral-800 rounded-lg p-4 border border-neutral-200 dark:border-neutral-700">
                      <h3 className="text-sm font-medium mb-3 flex justify-between">
                        <span>Security Details</span>
                        <button 
                          onClick={() => setShowCardDetails(!showCardDetails)}
                          className="text-xs text-primary hover:text-primary/80 flex items-center gap-1"
                        >
                          {showCardDetails ? (
                            <>
                              <EyeOff className="h-3 w-3" />
                              Hide Details
                            </>
                          ) : (
                            <>
                              <Eye className="h-3 w-3" />
                              Show Details
                            </>
                          )}
                        </button>
                      </h3>
                      <dl className="space-y-3 text-sm">
                        <div className="flex justify-between items-center">
                          <dt className="text-neutral-500 dark:text-neutral-400">Card Number</dt>
                          <dd className="font-medium font-mono flex items-center gap-2">
                            {showCardDetails ? (
                              selectedCard.cardNumber
                            ) : (
                              `•••• •••• •••• ${selectedCard.last4 || "••••"}`
                            )}
                            <button 
                              onClick={() => {
                                navigator.clipboard.writeText(selectedCard.cardNumber);
                                toast({
                                  title: "Card number copied",
                                  description: "Card number has been copied to your clipboard",
                                });
                              }}
                              className="text-neutral-400 hover:text-primary"
                            >
                              <svg className="h-3 w-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
                              </svg>
                            </button>
                          </dd>
                        </div>
                        <div className="flex justify-between items-center">
                          <dt className="text-neutral-500 dark:text-neutral-400">CVV Code</dt>
                          <dd className="font-medium font-mono flex items-center gap-2">
                            {showCardDetails ? (
                              selectedCard.cvv
                            ) : (
                              "•••"
                            )}
                            <button 
                              onClick={() => {
                                navigator.clipboard.writeText(selectedCard.cvv);
                                toast({
                                  title: "CVV copied",
                                  description: "CVV has been copied to your clipboard",
                                });
                              }}
                              className="text-neutral-400 hover:text-primary"
                            >
                              <svg className="h-3 w-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
                              </svg>
                            </button>
                          </dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-neutral-500 dark:text-neutral-400">Expiry Date</dt>
                          <dd className="font-medium">{selectedCard.expiryDate}</dd>
                        </div>
                      </dl>
                    </div>
                  </div>
                
                  {/* Right section with controls and settings */}
                  <div className="w-full md:w-1/2 space-y-5">
                    {/* Card Settings */}
                    <div className="bg-neutral-50 dark:bg-neutral-800 rounded-lg p-4 border border-neutral-200 dark:border-neutral-700">
                      <h3 className="text-sm font-medium mb-3">Card Settings</h3>
                      <div className="space-y-3">
                        {/* Contactless toggle */}
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="text-sm font-medium">Contactless Payments</span>
                            <p className="text-xs text-neutral-500 dark:text-neutral-400">
                              Allow tap to pay transactions
                            </p>
                          </div>
                          <Switch 
                            checked={selectedCard.contactlessEnabled} 
                            id="contactless-toggle"
                            disabled={selectedCard.isLocked}
                            onCheckedChange={(checked) => {
                              updateCardSettingsMutation.mutate({
                                id: selectedCard.id,
                                settings: { contactlessEnabled: checked }
                              });
                            }}
                          />
                        </div>
                        
                        {/* International toggle */}
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="text-sm font-medium">International Transactions</span>
                            <p className="text-xs text-neutral-500 dark:text-neutral-400">
                              Allow card use outside your country
                            </p>
                          </div>
                          <Switch 
                            checked={selectedCard.internationalEnabled} 
                            id="international-toggle"
                            disabled={selectedCard.isLocked}
                            onCheckedChange={(checked) => {
                              updateCardSettingsMutation.mutate({
                                id: selectedCard.id,
                                settings: { internationalEnabled: checked }
                              });
                            }}
                          />
                        </div>
                        
                        {/* Online transactions toggle */}
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="text-sm font-medium">Online Purchases</span>
                            <p className="text-xs text-neutral-500 dark:text-neutral-400">
                              Allow online and e-commerce purchases
                            </p>
                          </div>
                          <Switch 
                            checked={selectedCard.onlinePurchasesEnabled !== false} 
                            id="online-toggle"
                            disabled={selectedCard.isLocked}
                            onCheckedChange={(checked) => {
                              updateCardSettingsMutation.mutate({
                                id: selectedCard.id,
                                settings: { onlinePurchasesEnabled: checked }
                              });
                            }}
                          />
                        </div>
                      </div>
                    </div>
                    
                    {/* Card management actions */}
                    <div className="space-y-3">
                      <Button 
                        variant={selectedCard.isLocked ? "outline" : "destructive"} 
                        className="w-full"
                        onClick={() => toggleCardLock(selectedCard)}
                      >
                        {selectedCard.isLocked ? <LockOpen className="mr-2 h-4 w-4" /> : <Lock className="mr-2 h-4 w-4" />}
                        {selectedCard.isLocked ? "Unlock Card" : "Lock Card"}
                      </Button>
                      
                      {selectedCard.cardVariant === 'virtual' && (
                        <Button 
                          variant="outline" 
                          className="w-full"
                          onClick={() => {
                            navigator.clipboard.writeText(selectedCard.cardNumber);
                            toast({
                              title: "Card number copied",
                              description: "Card number has been copied to your clipboard",
                            });
                          }}
                        >
                          <svg className="mr-2 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
                          </svg>
                          Copy Card Details
                        </Button>
                      )}
                      
                      <Button 
                        variant="secondary" 
                        className="w-full"
                      >
                        <Receipt className="mr-2 h-4 w-4" />
                        View Transactions
                      </Button>
                    </div>
                  </div>
                </div>
                
                {/* Recent Transactions */}
                <div className="bg-neutral-50 dark:bg-neutral-800 rounded-lg p-4 border border-neutral-200 dark:border-neutral-700">
                  <h3 className="text-sm font-medium mb-3">Recent Transactions</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between py-2 border-b border-neutral-200 dark:border-neutral-700">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-neutral-100 dark:bg-neutral-700 rounded-full flex items-center justify-center">
                          <ShoppingCart className="h-4 w-4" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">Amazon</p>
                          <p className="text-xs text-neutral-500 dark:text-neutral-400">Apr 27, 2025</p>
                        </div>
                      </div>
                      <p className="text-sm font-medium">-$49.99</p>
                    </div>
                    <div className="flex items-center justify-between py-2 border-b border-neutral-200 dark:border-neutral-700">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-neutral-100 dark:bg-neutral-700 rounded-full flex items-center justify-center">
                          <Utensils className="h-4 w-4" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">Starbucks</p>
                          <p className="text-xs text-neutral-500 dark:text-neutral-400">Apr 26, 2025</p>
                        </div>
                      </div>
                      <p className="text-sm font-medium">-$5.75</p>
                    </div>
                    <div className="flex items-center justify-between py-2">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-neutral-100 dark:bg-neutral-700 rounded-full flex items-center justify-center">
                          <Book className="h-4 w-4" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">Audible</p>
                          <p className="text-xs text-neutral-500 dark:text-neutral-400">Apr 24, 2025</p>
                        </div>
                      </div>
                      <p className="text-sm font-medium">-$14.95</p>
                    </div>
                  </div>
                  <div className="mt-3 text-center">
                    <Button variant="link" size="sm" className="text-xs">
                      View All Transactions
                    </Button>
                  </div>
                </div>
                
                {/* Info note */}
                <div className="text-xs text-neutral-500 dark:text-neutral-400 mt-6">
                  <p>For security reasons, please keep your card details confidential. If you suspect any unauthorized activity, lock your card immediately and contact customer support.</p>
                </div>
              </div>
            </div>
            
            <DialogFooter>
              <Button onClick={() => {
                setIsCardDetailsOpen(false);
              }}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}