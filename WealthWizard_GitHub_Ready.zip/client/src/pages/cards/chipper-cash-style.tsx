import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage,
  FormDescription
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { 
  CreditCard, 
  Lock, 
  LockOpen, 
  Visibility, 
  VisibilityOff, 
  ChevronRight, 
  AddCircleOutline, 
  History 
} from "@mui/icons-material";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";

interface CardDetails {
  id: number;
  accountId: number;
  cardNumber: string;
  cardType: string;
  expiryDate: string;
  cvv: string;
  cardholderName: string;
  isActive: boolean;
  isLocked: boolean;
  cardNetwork?: string; // Card network (Visa, Mastercard, etc)
  cardBrand?: string;   // Card tier (Standard, Gold, Platinum)
  cardVariant?: string; // Physical or virtual card
  purpose?: string;     // Purpose for virtual cards
}

export default function Cards() {
  const [activeTab, setActiveTab] = useState("physical");
  const [isAddCardOpen, setIsAddCardOpen] = useState(false);
  const [selectedCard, setSelectedCard] = useState<CardDetails | null>(null);
  const [isCardDetailsOpen, setIsCardDetailsOpen] = useState(false);
  const [showCardDetails, setShowCardDetails] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch cards
  const { data: cards = [], isLoading: isLoadingCards } = useQuery({
    queryKey: ["/api/cards"],
  });
  
  // Fetch accounts for adding new cards
  const { data: accounts = [] } = useQuery({
    queryKey: ["/api/accounts"],
  });
  
  // Filter cards based on active tab
  const physicalCards = cards.filter((card: CardDetails) => card.cardType !== "virtual");
  const virtualCards = cards.filter((card: CardDetails) => card.cardType === "virtual");
  
  // Card lock/unlock mutation
  const toggleLockMutation = useMutation({
    mutationFn: ({ id, isLocked }: { id: number; isLocked: boolean }) => {
      return apiRequest("PATCH", `/api/cards/${id}`, { isLocked });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cards"] });
      toast({
        title: "Card updated",
        description: "Card status has been updated successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Update failed",
        description: error.message || "There was an error updating the card.",
        variant: "destructive",
      });
    }
  });
  
  // New card schema
  const newCardSchema = z.object({
    accountId: z.string().min(1, { message: "Account is required" }),
    cardType: z.string().min(1, { message: "Card type is required" }),
    cardholderName: z.string().min(1, { message: "Cardholder name is required" }),
    cardVariant: z.string().default("physical"),
    cardBrand: z.string().default("standard"),
    cardNetwork: z.string().default("visa"),
    purpose: z.string().optional(),
    spendingLimit: z.string().optional(),
    expirationDays: z.string().optional(),
    contactlessEnabled: z.boolean().default(true),
    internationalEnabled: z.boolean().default(false),
  });
  
  const cardForm = useForm<z.infer<typeof newCardSchema>>({
    resolver: zodResolver(newCardSchema),
    defaultValues: {
      accountId: "",
      cardType: "debit",
      cardholderName: "",
      cardVariant: "physical",
      cardBrand: "standard",
      cardNetwork: "visa",
      purpose: "",
      spendingLimit: "",
      expirationDays: "90",
      contactlessEnabled: true,
      internationalEnabled: false
    }
  });

  // Card creation mutation
  const createCardMutation = useMutation({
    mutationFn: (data: any) => {
      return apiRequest("POST", "/api/cards", data);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/cards"] });
      toast({
        title: "Card request submitted",
        description: variables.cardVariant === "virtual" 
          ? "Your virtual card has been created successfully." 
          : "Your physical card request has been submitted for processing.",
      });
      setIsAddCardOpen(false);
      cardForm.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Card request failed",
        description: error.message || "There was an error processing your card request.",
        variant: "destructive",
      });
    }
  });
  
  const viewCardDetails = (card: CardDetails) => {
    setSelectedCard(card);
    setIsCardDetailsOpen(true);
  };
  
  const toggleCardLock = (card: CardDetails) => {
    toggleLockMutation.mutate({
      id: card.id,
      isLocked: !card.isLocked
    });
  };
  
  const handleAddCard = (values: z.infer<typeof newCardSchema>) => {
    // Generate random card details
    const generateCardNumber = () => {
      const prefix = values.cardNetwork === 'visa' ? '4' : 
                    values.cardNetwork === 'mastercard' ? '5' : 
                    values.cardNetwork === 'amex' ? '3' : '4';
      const randomNumbers = Array.from({length: 15}, () => Math.floor(Math.random() * 10)).join('');
      return prefix + randomNumbers.substring(0, prefix === '3' ? 14 : 15);
    };
    
    const generateCVV = () => {
      return Array.from({length: 3}, () => Math.floor(Math.random() * 10)).join('');
    };
    
    const generateExpiryDate = () => {
      const today = new Date();
      const expiryYears = values.cardVariant === 'virtual' ? 
        (parseInt(values.expirationDays || '90') / 365) : 3;
      const expiryMonth = today.getMonth() + 1;
      const expiryYear = today.getFullYear() + Math.floor(expiryYears);
      return `${expiryMonth.toString().padStart(2, '0')}/${(expiryYear % 100).toString().padStart(2, '0')}`;
    };
    
    const cardNumber = generateCardNumber();
    
    const data = {
      ...values,
      accountId: parseInt(values.accountId),
      cardNumber: cardNumber,
      last4: cardNumber.slice(-4),
      cvv: generateCVV(),
      expiryDate: generateExpiryDate(),
      spendingLimit: values.spendingLimit ? parseFloat(values.spendingLimit) : null,
    };
    
    createCardMutation.mutate(data);
  };
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow bg-neutral-50 dark:bg-neutral-900">
        <div className="container mx-auto px-4 py-6">
          {/* Page Header */}
          <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-neutral-900 dark:text-white">Cards</h1>
              <p className="text-neutral-600 dark:text-neutral-400 mt-1">
                Manage your debit and credit cards
              </p>
            </div>
            <Button onClick={() => setIsAddCardOpen(true)} className="flex items-center gap-2">
              <AddCircleOutline className="h-4 w-4" />
              Card
            </Button>
          </div>
          
          {/* Card Tabs */}
          <div className="mb-6">
            <div className="bg-white dark:bg-neutral-900 shadow-sm rounded-lg">
              <Tabs defaultValue={activeTab} value={activeTab} onValueChange={setActiveTab}>
                <div className="border-b border-neutral-200 dark:border-neutral-800">
                  <div className="flex justify-between items-center px-6 py-4">
                    <h2 className="text-xl font-semibold text-neutral-900 dark:text-white">My Cards</h2>
                    <TabsList className="h-9 p-1 bg-neutral-100 dark:bg-neutral-800">
                      <TabsTrigger className="rounded px-3 py-1.5 text-sm" value="physical">Physical Cards</TabsTrigger>
                      <TabsTrigger className="rounded px-3 py-1.5 text-sm" value="virtual">Virtual Cards</TabsTrigger>
                    </TabsList>
                  </div>
                </div>
                
                <div className="p-6">
                  <TabsContent value="physical">
                    {isLoadingCards ? (
                      <div className="flex justify-center py-12">
                        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                      </div>
                    ) : physicalCards.length === 0 ? (
                      <div className="text-center py-16 px-6">
                        <div className="w-20 h-20 rounded-full bg-neutral-100 dark:bg-neutral-800 mx-auto flex items-center justify-center mb-4">
                          <CreditCard className="h-10 w-10 text-neutral-400" />
                        </div>
                        <h3 className="text-lg font-medium text-neutral-900 dark:text-white mb-2">No Physical Cards</h3>
                        <p className="text-neutral-500 dark:text-neutral-400 max-w-md mx-auto mb-6">
                          You don't have any physical cards yet. Request a physical card to make purchases in stores and ATM withdrawals.
                        </p>
                        <Button onClick={() => {
                          setIsAddCardOpen(true);
                          cardForm.setValue("cardVariant", "physical");
                        }} className="px-6">
                          Request a Physical Card
                        </Button>
                      </div>
                    ) : (
                      <div className="grid gap-6 md:grid-cols-2">
                        {physicalCards.map((card: CardDetails) => (
                          <div 
                            key={card.id} 
                            className="relative group overflow-hidden rounded-xl border border-neutral-200 dark:border-neutral-800 hover:shadow-lg transition-all duration-300"
                          >
                            {/* Card content here */}
                          </div>
                        ))}
                      </div>
                    )}
                  </TabsContent>
                  
                  <TabsContent value="virtual">
                    {isLoadingCards ? (
                      <div className="flex justify-center py-12">
                        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                      </div>
                    ) : virtualCards.length === 0 ? (
                      <div className="text-center py-16 px-6">
                        <div className="w-20 h-20 rounded-full bg-neutral-100 dark:bg-neutral-800 mx-auto flex items-center justify-center mb-4">
                          <CreditCard className="h-10 w-10 text-neutral-400" />
                        </div>
                        <h3 className="text-lg font-medium text-neutral-900 dark:text-white mb-2">No Virtual Cards</h3>
                        <p className="text-neutral-500 dark:text-neutral-400 max-w-md mx-auto mb-6">
                          You don't have any virtual cards yet. Create a virtual card for online shopping or subscriptions.
                        </p>
                        <Button onClick={() => {
                          setIsAddCardOpen(true);
                          cardForm.setValue("cardVariant", "virtual");
                        }} className="px-6">
                          Create a Virtual Card
                        </Button>
                      </div>
                    ) : (
                      <div className="grid gap-6 md:grid-cols-2">
                        {virtualCards.map((card: CardDetails) => (
                          <div 
                            key={card.id} 
                            className="relative group overflow-hidden rounded-xl border border-neutral-200 dark:border-neutral-800 hover:shadow-lg transition-all duration-300"
                          >
                            {/* Card content here */}
                          </div>
                        ))}
                      </div>
                    )}
                  </TabsContent>
                </div>
              </Tabs>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
      
      {/* Card Application Dialog - Chipper Cash Style */}
      <Dialog open={isAddCardOpen} onOpenChange={setIsAddCardOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Apply for Fortis Capital Card</DialogTitle>
            <DialogDescription>
              Complete your application for a new Fortis Capital card.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            {/* Card eligibility information */}
            <div className="mb-6 border border-neutral-200 dark:border-neutral-700 rounded-md p-4 bg-neutral-50 dark:bg-neutral-800">
              <div className="flex items-start gap-3">
                <svg className="w-5 h-5 text-green-500 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                <div>
                  <h3 className="text-sm font-medium mb-1">You're eligible for a Fortis Capital Card</h3>
                  <p className="text-sm text-neutral-600 dark:text-neutral-400">
                    Our system has determined you qualify for a card based on your account history.
                  </p>
                </div>
              </div>
            </div>
            
            <Form {...cardForm}>
              <form onSubmit={cardForm.handleSubmit(handleAddCard)} className="space-y-5">
                <FormField
                  control={cardForm.control}
                  name="accountId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Link to Account</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select account" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {accounts.map((account: any) => (
                            <SelectItem key={account.id} value={account.id.toString()}>
                              {account.accountName} ({account.accountType}) - {account.accountNumber}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        Select the account you want to link to your new card
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
          
                <FormField
                  control={cardForm.control}
                  name="cardholderName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Cardholder Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter name as it will appear on card" {...field} />
                      </FormControl>
                      <FormDescription>
                        Name must match your identification documents
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
          
                <FormField
                  control={cardForm.control}
                  name="cardVariant"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Card Delivery Method</FormLabel>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="flex flex-col space-y-2"
                      >
                        <FormItem className="flex items-center space-x-3 space-y-0 rounded-lg border p-4 cursor-pointer data-[state=checked]:border-primary">
                          <FormControl>
                            <RadioGroupItem value="virtual" />
                          </FormControl>
                          <div className="space-y-0.5 flex-1">
                            <FormLabel className="text-base font-medium flex items-center justify-between cursor-pointer">
                              Virtual Card
                              <span className="text-xs font-normal bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300 px-2 py-0.5 rounded">Instant Issue</span>
                            </FormLabel>
                            <FormDescription>
                              Get your card details immediately for online purchases
                            </FormDescription>
                          </div>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0 rounded-lg border p-4 cursor-pointer data-[state=checked]:border-primary">
                          <FormControl>
                            <RadioGroupItem value="physical" />
                          </FormControl>
                          <div className="space-y-0.5 flex-1">
                            <FormLabel className="text-base font-medium flex items-center justify-between cursor-pointer">
                              Physical Card
                              <span className="text-xs font-normal bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300 px-2 py-0.5 rounded">7-10 days</span>
                            </FormLabel>
                            <FormDescription>
                              Receive a plastic card by mail with contactless capability
                            </FormDescription>
                          </div>
                        </FormItem>
                      </RadioGroup>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                              
                {/* Hidden fields - system determined values */}
                <input type="hidden" {...cardForm.register("cardType")} value="debit" />
                <input type="hidden" {...cardForm.register("cardNetwork")} value="visa" />
                <input type="hidden" {...cardForm.register("cardBrand")} value="standard" />
                <input type="hidden" {...cardForm.register("contactlessEnabled")} value="true" />
                
                {/* Card preview */}
                <div className="rounded-lg border border-neutral-200 dark:border-neutral-700 p-4 bg-white dark:bg-neutral-900">
                  <h3 className="text-sm font-medium mb-3">Your Card Preview</h3>
                  
                  <div className="w-full max-w-[320px] mx-auto aspect-[1.6/1] rounded-xl bg-gradient-to-br from-neutral-800 to-neutral-900 text-white p-4 shadow-md relative">
                    {/* Network logo */}
                    <div className="absolute top-3 right-3">
                      <svg className="w-10 h-6" viewBox="0 0 48 16" fill="white">
                        <path d="M44 0H4C1.8 0 0 1.8 0 4v8c0 2.2 1.8 4 4 4h40c2.2 0 4-1.8 4-4V4c0-2.2-1.8-4-4-4zm-23.4 12.9h-3.2L14.9 3.1h3.5l2.5 9.8zm15.2 0h-3l.8-2.2h-4.8l-.8 2.2h-3.4l4.6-9.8h3.8l2.8 9.8zm-6.3-4.4h3l-1.5-4.2-1.5 4.2zM19.6 6c0-.8-.5-1.5-1.6-1.5h-4.5v7.4h2.4V9.2h.4l2.1 2.7h3L19 8.9c1-.2 1.6-1.1 1.6-2.3v-.6zm-2.6.8h-1V6h1c.4 0 .7.2.7.4 0 .3-.3.4-.7.4zm21.7-3.7h-6.6v9.8h6.6v-2.1h-4.1V8.7h4V6.7h-4V5.1h4.1V3.1z"/>
                      </svg>
                    </div>
                  
                    <div className="mt-2">
                      <p className="text-xs opacity-70 uppercase tracking-wider">
                        Fortis Capital
                      </p>
                      <p className="font-medium text-sm">
                        {cardForm.watch("cardVariant") === "virtual" ? "Virtual Debit" : "Debit Card"}
                      </p>
                    </div>
                    
                    <div className="mt-4">
                      <p className="font-mono text-lg tracking-wider">••••  ••••  ••••  ••••</p>
                    </div>
                    
                    <div className="flex justify-between mt-4 items-end">
                      <div>
                        <p className="text-xs opacity-70 uppercase">Cardholder</p>
                        <p className="font-medium truncate max-w-[120px] text-sm">
                          {cardForm.watch("cardholderName") || "YOUR NAME"}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs opacity-70 uppercase">Expires</p>
                        <p className="font-medium text-sm">••/••</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Card features and info message */}
                <div className="border border-neutral-200 dark:border-neutral-700 rounded-md p-4 bg-neutral-50 dark:bg-neutral-800">
                  <h3 className="text-sm font-medium mb-2">Card Features & Benefits</h3>
                  <ul className="space-y-2 text-sm text-neutral-600 dark:text-neutral-400">
                    <li className="flex items-start gap-2">
                      <svg className="w-4 h-4 text-green-500 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                      </svg>
                      <span>No monthly maintenance fees</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <svg className="w-4 h-4 text-green-500 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                      </svg>
                      <span>{cardForm.watch("cardVariant") === "virtual" ? 
                        "Use immediately for online purchases" : 
                        "Tap-to-pay contactless technology"}</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <svg className="w-4 h-4 text-green-500 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                      </svg>
                      <span>Real-time transaction notifications</span>
                    </li>
                  </ul>
                </div>
                
                <div className="border-t pt-4 mt-4">
                  <p className="text-sm text-neutral-500 dark:text-neutral-400 mb-4">
                    By applying for this card, you agree to the <a href="#" className="text-primary underline">Terms & Conditions</a> and <a href="#" className="text-primary underline">Cardholder Agreement</a>.
                  </p>
                </div>
          
                <DialogFooter>
                  <Button 
                    variant="outline" 
                    type="button" 
                    onClick={() => setIsAddCardOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" className="gap-2">
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                    {cardForm.watch("cardVariant") === "virtual" ? "Get Virtual Card" : "Apply for Card"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Card details dialog - Details of selected card */}
      {selectedCard && (
        <Dialog open={isCardDetailsOpen} onOpenChange={setIsCardDetailsOpen}>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Card Details</DialogTitle>
            </DialogHeader>
            
            {/* Card details content here */}
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}