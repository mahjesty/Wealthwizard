import { useState, useEffect } from "react";
import { useAdminAuth } from "@/hooks/use-admin-auth";
import { useToast } from "@/hooks/use-toast";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { FortisLogo } from "@/components/ui/fortis-logo";
import { 
  LockKeyhole,
  Shield, 
  Database,
  UserCog,
  Clock,
  AlertOctagon
} from "lucide-react";
import AdminLoginForm from "./admin/auth/components/admin-login-form";

export default function AdminLoginPage() {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [location, setLocation] = useLocation();
  const { isAuthenticated } = useAdminAuth();
  const { toast } = useToast();
  
  // Add special flag to mark this as the admin login page
  // This will prevent interference from regular auth redirects
  const [isAdminLoginPage] = useState(true);
  
  // Update current time for the clock display
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => {
      clearInterval(timer);
    };
  }, []);

  // Only redirect if already logged in as admin
  useEffect(() => {
    if (isAuthenticated) {
      console.log("Already authenticated as admin, redirecting to dashboard");
      setLocation("/admin");
    }
  }, [isAuthenticated, setLocation]);

  // Format time
  const formattedTime = currentTime.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit'
  });
  
  const formattedDate = currentTime.toLocaleDateString([], {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric'
  });

  return (
    <div className="flex flex-col md:flex-row h-screen bg-neutral-50 dark:bg-neutral-900">
      {/* Left Section - Admin Auth Form */}
      <div className="flex-1 flex flex-col items-center justify-center px-4 sm:px-6 py-8 bg-white dark:bg-neutral-900">
        <div className="flex flex-col items-center justify-center max-w-md w-full mx-auto space-y-8">
          <div className="flex flex-col items-center space-y-2 text-center">
            <div className="flex justify-center mb-4">
              <FortisLogo width={80} height={80} className="text-amber-600" />
            </div>
            <h1 className="text-3xl font-bold text-amber-600">Fortis Admin</h1>
            <div className="flex items-center justify-center space-x-2 bg-amber-50 px-3 py-1.5 rounded-full">
              <LockKeyhole className="h-4 w-4 text-amber-600" />
              <p className="text-xs font-medium text-amber-700">Restricted Area</p>
            </div>
            <p className="text-muted-foreground text-sm max-w-xs mt-2">
              Banking system administration portal
            </p>
          </div>

          <Card className="w-full p-6 shadow-lg border-t-4 border-t-amber-500">
            <AdminLoginForm />
          </Card>
          
          <div className="w-full text-center text-xs text-neutral-500 dark:text-neutral-400">
            <p>This is a secure banking system. Unauthorized access is prohibited.</p>
            <p className="mt-1">{formattedDate} • {formattedTime}</p>
          </div>
        </div>
      </div>

      {/* Right Section - Admin Information */}
      <div className="hidden md:flex md:w-1/2 bg-gradient-to-br from-amber-700 to-amber-900 text-white p-8">
        <div className="flex flex-col w-full max-w-lg mx-auto justify-center space-y-12">
          <div>
            <h2 className="text-3xl font-bold mb-6">Bank Administration Portal</h2>
            <p className="mb-8 text-amber-100">
              Access management tools and administrative functions for Fortis Capital banking operations.
            </p>
            
            <div className="space-y-6">
              <div className="flex items-start">
                <div className="flex-shrink-0 p-1 bg-amber-600 rounded-lg mr-4">
                  <Shield className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="font-medium">Security Controls</h3>
                  <p className="text-sm text-amber-100">Manage bank security protocols and compliance settings</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="flex-shrink-0 p-1 bg-amber-600 rounded-lg mr-4">
                  <Database className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="font-medium">Data Management</h3>
                  <p className="text-sm text-amber-100">Access transaction records and financial database</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="flex-shrink-0 p-1 bg-amber-600 rounded-lg mr-4">
                  <UserCog className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="font-medium">User Administration</h3>
                  <p className="text-sm text-amber-100">Manage user accounts and access permissions</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="flex-shrink-0 p-1 bg-amber-600 rounded-lg mr-4">
                  <AlertOctagon className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="font-medium">Risk Management</h3>
                  <p className="text-sm text-amber-100">Review flagged transactions and security alerts</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="border-t border-amber-600 pt-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <Clock className="h-5 w-5 text-amber-300" />
                <span className="text-sm text-amber-300">System Status</span>
              </div>
              <div className="bg-green-100 px-2 py-0.5 rounded-full">
                <span className="text-xs font-medium text-green-800">Operational</span>
              </div>
            </div>
            <div className="text-xs text-amber-300">
              <p>Last security scan: Today at 8:15 AM</p>
              <p>Database backup: Complete (4 hours ago)</p>
              <p>System updates: Up to date</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}