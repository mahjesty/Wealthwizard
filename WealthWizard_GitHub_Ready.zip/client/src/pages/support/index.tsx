import React, { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { 
  ContactSupport, 
  QuestionAnswer, 
  Assignment, 
  Help,
  Search,
  AccountBalance,
  CreditCard,
  VpnKey,
  Security,
  Payments,
  AccountBox,
  Phone,
  Email,
  ChatBubble,
  Send,
  AttachFile,
  VideoCall,
  PushPin,
  MoreVert,
  X,
  Minimize,
  Save,
  Info as InfoIcon,
  AccessTime as Clock,
  Logout as LogOut,
  Upload
} from "@mui/icons-material";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { formatDate } from "@/lib/utils";

const supportTicketSchema = z.object({
  subject: z.string().min(5, { message: "Subject must be at least 5 characters" }),
  message: z.string().min(20, { message: "Message must be at least 20 characters" }),
  priority: z.string().default("medium"),
});

// Chat message type
interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'agent' | 'system';
  timestamp: Date;
  status?: 'sending' | 'sent' | 'delivered' | 'read';
  attachments?: {
    type: 'image' | 'file' | 'link';
    url: string;
    name: string;
    size?: string;
  }[];
  isQuickReply?: boolean;
}

// Chat agent type
interface ChatAgent {
  id: string;
  name: string;
  role: string;
  avatar: string;
  isOnline: boolean;
  department: string;
  lastActive?: string;
  rating?: number;
  expertise?: string[];
}

// Quick reply suggestion type
interface QuickReply {
  id: string;
  text: string;
  action?: 'link' | 'transfer' | 'schedule';
  metadata?: any;
}

export default function Support() {
  const [activeTab, setActiveTab] = useState("contact");
  const [isNewTicketOpen, setIsNewTicketOpen] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<any>(null);
  const [isTicketDetailsOpen, setIsTicketDetailsOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatMessage, setChatMessage] = useState('');
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [isChatConnected, setIsChatConnected] = useState(false);
  const [currentAgent, setCurrentAgent] = useState<ChatAgent | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Scroll to the bottom of the chat when new messages arrive
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatMessages]);
  
  // State for suggested quick replies
  const [quickReplies, setQuickReplies] = useState<QuickReply[]>([]);
  
  // State for file attachment in progress
  const [fileAttachment, setFileAttachment] = useState<File | null>(null);
  
  // State for tracking chat rating
  const [chatRating, setChatRating] = useState<number | null>(null);
  
  // State for controlling chat transfer process
  const [isTransferring, setIsTransferring] = useState(false);
  
  // State for detailed agent info panel
  const [showAgentInfo, setShowAgentInfo] = useState(false);
  
  // State for agent availability
  const [agentStatus, setAgentStatus] = useState<'connecting' | 'queue' | 'active' | 'away' | 'transferred'>('connecting');
  
  // State for queue position
  const [queuePosition, setQueuePosition] = useState<number | null>(null);
  
  // State for estimated wait time
  const [estimatedWaitTime, setEstimatedWaitTime] = useState<string | null>(null);
  
  // State for chat history transcript
  const [showTranscriptOptions, setShowTranscriptOptions] = useState(false);
  
  // State for minimized chat
  const [isMinimized, setIsMinimized] = useState(false);
  
  // State for showing close chat confirmation dialog
  const [isCloseChatDialogOpen, setIsCloseChatDialogOpen] = useState(false);
  
  // Enhanced agent data
  const agent: ChatAgent = {
    id: 'agent-1',
    name: 'Sarah Johnson',
    role: 'Senior Banking Specialist',
    avatar: '',
    isOnline: true,
    department: 'Customer Support',
    lastActive: '1 min ago',
    rating: 4.9,
    expertise: ['Account Management', 'Credit Cards', 'Fraud Prevention', 'Online Banking']
  };
  
  // Secondary agent for transfers
  const secondaryAgent: ChatAgent = {
    id: 'agent-2',
    name: 'Michael Chen',
    role: 'Investment Advisor',
    avatar: '',
    isOnline: true,
    department: 'Wealth Management',
    lastActive: '5 min ago',
    rating: 4.8,
    expertise: ['Investments', 'Retirement Planning', 'Portfolio Management']
  };
  
  // Fraud prevention specialist
  const fraudAgent: ChatAgent = {
    id: 'agent-3',
    name: 'Jennifer Rodriguez',
    role: 'Fraud Prevention Specialist',
    avatar: '',
    isOnline: true,
    department: 'Security & Fraud',
    lastActive: 'Just now',
    rating: 4.95,
    expertise: ['Fraud Investigation', 'Account Security', 'Identity Theft Protection']
  };
  
  // Chat functions
  const startChat = () => {
    setIsChatOpen(true);
    setAgentStatus('connecting');
    
    // Add initial system message
    if (chatMessages.length === 0) {
      const initialMessage: ChatMessage = {
        id: `msg-${Date.now()}`,
        text: `Connecting you to Fortis Capital Secure Banking Support. Please wait...`,
        sender: 'system',
        timestamp: new Date()
      };
      
      setChatMessages([initialMessage]);
      
      // Simulate connecting to virtual assistant first
      setTimeout(() => {
        setIsChatConnected(true);
        
        // Virtual assistant welcome message
        const assistantMessage: ChatMessage = {
          id: `msg-${Date.now()}`,
          text: `Hello ${user?.firstName || 'there'}, I'm the Fortis Capital virtual assistant. How can I help you today?`,
          sender: 'agent',
          timestamp: new Date(),
          status: 'read'
        };
        
        setChatMessages(prev => [...prev, assistantMessage]);
        
        // Set initial quick replies
        setTimeout(() => {
          setQuickReplies([
            { id: 'qr-1', text: 'Speak to a banking specialist' },
            { id: 'qr-2', text: 'Account questions' },
            { id: 'qr-3', text: 'Report a problem' }
          ]);
        }, 500);
      }, 2000);
    }
  };
  
  // Function to handle request for live agent (separate from the initial chat start)
  const connectToLiveAgent = () => {
    setAgentStatus('connecting');
    setIsChatConnected(false);
    
    // Add transfer message
    const transferMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      text: `I'll connect you with a banking specialist who can assist you further. Please hold while I transfer you.`,
      sender: 'agent',
      timestamp: new Date(),
      status: 'read'
    };
    
    setChatMessages(prev => [...prev, transferMessage]);
    
    // Clear quick replies during transfer
    setQuickReplies([]);
    
    // After delay, start the queue process
    setTimeout(() => {
      setAgentStatus('queue');
      setQueuePosition(3);
      setEstimatedWaitTime('2-3 minutes');
      
      const queueMessage: ChatMessage = {
        id: `msg-${Date.now()}`,
        text: `You are currently #3 in our support queue. Estimated wait time: 2-3 minutes.`,
        sender: 'system',
        timestamp: new Date()
      };
      
      setChatMessages(prev => [...prev, queueMessage]);
      
      // After 3 seconds, show position #2
      setTimeout(() => {
        setQueuePosition(2);
        
        const queueUpdate: ChatMessage = {
          id: `msg-${Date.now()}`,
          text: `You have moved up in the queue. You are now #2. Estimated wait time: 1-2 minutes.`,
          sender: 'system',
          timestamp: new Date()
        };
        
        setChatMessages(prev => [...prev, queueUpdate]);
        
        // After 3 more seconds, show position #1
        setTimeout(() => {
          setQueuePosition(1);
          
          const queueUpdate: ChatMessage = {
            id: `msg-${Date.now()}`,
            text: `You are next in line. A banking specialist will be with you shortly.`,
            sender: 'system',
            timestamp: new Date()
          };
          
          setChatMessages(prev => [...prev, queueUpdate]);
          
          // After 3 more seconds, connect to agent
          setTimeout(() => {
            setAgentStatus('active');
            setQueuePosition(null);
            setEstimatedWaitTime(null);
            setCurrentAgent(agent);
            setIsChatConnected(true);
            setIsTyping(true);
            
            // After typing indicator, send welcome message
            setTimeout(() => {
              setIsTyping(false);
              
              const welcomeMessage: ChatMessage = {
                id: `msg-${Date.now()}`,
                text: `Hello ${user?.firstName || 'there'}, I'm ${agent.name}, a ${agent.role} with Fortis Capital. Thank you for your patience. I've accessed your account information and I'm ready to assist you today. How may I help you?`,
                sender: 'agent',
                timestamp: new Date(),
                status: 'read'
              };
              
              setChatMessages(prev => [...prev, welcomeMessage]);
              
              // Set initial quick replies
              setTimeout(() => {
                setQuickReplies([
                  { id: 'qr-1', text: 'Account information' },
                  { id: 'qr-2', text: 'Make a transfer' },
                  { id: 'qr-3', text: 'Report an issue' }
                ]);
              }, 500);
            }, 2000);
          }, 3000);
        }, 3000);
      }, 3000);
    }, 2000);
  };
  
  // Function to handle file uploads
  const handleFileUpload = (file: File) => {
    if (!file) return;
    
    setFileAttachment(file);
    
    // Show uploading message
    const fileUploadMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      text: `Uploading file: ${file.name}`,
      sender: 'system',
      timestamp: new Date()
    };
    
    setChatMessages(prev => [...prev, fileUploadMsg]);
    
    // Simulate file upload
    setTimeout(() => {
      // Replace with completed message
      const fileAttachmentMsg: ChatMessage = {
        id: `msg-${Date.now()}`,
        text: chatMessage || `I've shared a file with you.`,
        sender: 'user',
        timestamp: new Date(),
        status: 'sent',
        attachments: [{
          type: file.type.startsWith('image/') ? 'image' : 'file',
          url: '#',
          name: file.name,
          size: formatFileSize(file.size)
        }]
      };
      
      // Remove the uploading message and add the actual message
      setChatMessages(prev => [...prev.filter(m => m.id !== fileUploadMsg.id), fileAttachmentMsg]);
      setFileAttachment(null);
      
      // If there was no text message, trigger agent response
      if (!chatMessage.trim()) {
        handleAgentResponse("I've shared a file with you");
      } else {
        handleAgentResponse(chatMessage);
      }
    }, 1500);
  };
  
  // Function to format file size
  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return bytes + ' B';
    const kb = bytes / 1024;
    if (kb < 1024) return kb.toFixed(1) + ' KB';
    const mb = kb / 1024;
    return mb.toFixed(1) + ' MB';
  };
  
  // Function to handle agent chat transfer
  const handleChatTransfer = (transferType: 'investment' | 'fraud' = 'investment') => {
    setIsTransferring(true);
    setAgentStatus('transferred');
    
    // Agent message about transfer
    const agentFarewellMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      text: `I'll transfer you to our ${transferType === 'investment' ? 'investment specialist' : 'fraud prevention team'} who can better assist with your inquiry. Please hold while I connect you.`,
      sender: 'agent',
      timestamp: new Date(),
      status: 'sent'
    };
    
    setChatMessages(prev => [...prev, agentFarewellMsg]);
    
    // After a short delay, add system message
    setTimeout(() => {
      const transferMsg: ChatMessage = {
        id: `msg-${Date.now()}`,
        text: `Transferring to ${transferType === 'investment' ? 'Wealth Management' : 'Security & Fraud'} department. Your chat history will be shared with the specialist.`,
        sender: 'system',
        timestamp: new Date()
      };
      
      setChatMessages(prev => [...prev, transferMsg]);
      
      // After another delay, add "reviewing your information" message
      setTimeout(() => {
        const reviewMsg: ChatMessage = {
          id: `msg-${Date.now()}`,
          text: `${transferType === 'investment' ? secondaryAgent.name : fraudAgent.name} is reviewing your information...`,
          sender: 'system',
          timestamp: new Date()
        };
        
        setChatMessages(prev => [...prev, reviewMsg]);
        
        // Finally connect to the new agent
        setTimeout(() => {
          // New agent joins
          setCurrentAgent(transferType === 'investment' ? secondaryAgent : fraudAgent);
          setIsTransferring(false);
          setIsTyping(true);
          
          setTimeout(() => {
            setIsTyping(false);
            
            // Welcome message from new agent
            const newAgentMsg: ChatMessage = {
              id: `msg-${Date.now()}`,
              text: transferType === 'investment' 
                ? `Hello, I'm ${secondaryAgent.name}, a ${secondaryAgent.role} with Fortis Capital. I've reviewed your conversation and I'm here to help with your investment-related questions. How can I assist you today?`
                : `Hello, I'm ${fraudAgent.name}, a ${fraudAgent.role} with Fortis Capital. I understand you have concerns about possible unauthorized activity. I'm here to help secure your account and address these issues immediately.`,
              sender: 'agent',
              timestamp: new Date(),
              status: 'sent'
            };
            
            setChatMessages(prev => [...prev, newAgentMsg]);
            
            // Set quick replies based on transfer type
            if (transferType === 'investment') {
              setQuickReplies([
                { id: 'qr-1', text: 'Retirement planning options' },
                { id: 'qr-2', text: 'Investment portfolio review' },
                { id: 'qr-3', text: 'Market updates' }
              ]);
            } else {
              setQuickReplies([
                { id: 'qr-1', text: 'Report unauthorized transaction' },
                { id: 'qr-2', text: 'Secure my account' },
                { id: 'qr-3', text: 'Request new card' }
              ]);
            }
          }, 1500);
        }, 3000);
      }, 2000);
    }, 1500);
  };
  
  // Function to handle agent response
  const handleAgentResponse = (userMessage: string) => {
    // Simulate agent typing
    setIsTyping(true);
    
    // Clear any existing quick replies
    setQuickReplies([]);
    
    // Simulate agent response after typing
    setTimeout(() => {
      setIsTyping(false);
      
      // Add agent response based on user message
      let responseText = '';
      let suggestedReplies: QuickReply[] = [];
      
      const userMsg = userMessage.toLowerCase();
      
      if (userMsg.includes('account') || userMsg.includes('checking') || userMsg.includes('savings')) {
        responseText = "I'd be happy to help with your account-related questions. Could you specify which account you're inquiring about?";
        
        // Set quick replies for account questions
        suggestedReplies = [
          { id: 'qr-1', text: 'Checking account' },
          { id: 'qr-2', text: 'Savings account' },
          { id: 'qr-3', text: 'Account statement' }
        ];
      } else if (userMsg.includes('transfer') || userMsg.includes('send money')) {
        responseText = "For transfers, I can help guide you through the process. Would you like to make a transfer between your accounts or to an external account?";
        
        // Set quick replies for transfer options
        suggestedReplies = [
          { id: 'qr-1', text: 'Between my accounts' },
          { id: 'qr-2', text: 'To someone else' },
          { id: 'qr-3', text: 'Wire transfer' }
        ];
      } else if (userMsg.includes('card') || userMsg.includes('credit') || userMsg.includes('debit')) {
        responseText = "I see you have a question about your card. Is this regarding a specific transaction, card limits, or another card-related issue?";
        
        // Suggest specialist transfer for complex card issues
        if (userMsg.includes('fraud') || userMsg.includes('stolen') || userMsg.includes('unauthorized')) {
          responseText += " For security concerns, I can transfer you to our fraud department specialist who can help immediately.";
          
          suggestedReplies = [
            { id: 'qr-1', text: 'Yes, transfer me to a specialist', action: 'transfer' },
            { id: 'qr-2', text: 'No, I have a different question' }
          ];
        } else {
          suggestedReplies = [
            { id: 'qr-1', text: 'Card limits' },
            { id: 'qr-2', text: 'Recent transactions' },
            { id: 'qr-3', text: 'Report lost/stolen card' }
          ];
        }
      } else if (userMsg.includes('investment') || userMsg.includes('stocks') || userMsg.includes('portfolio')) {
        responseText = "I'd be happy to connect you with our investment specialist who can provide detailed guidance on investment options and portfolio management.";
        
        // Offer to transfer to investment specialist
        suggestedReplies = [
          { id: 'qr-1', text: 'Yes, transfer me to a specialist', action: 'transfer' },
          { id: 'qr-2', text: 'Tell me more first' }
        ];
      } else if (userMsg.includes('bill') || userMsg.includes('payment')) {
        responseText = "For bill payments, I can help you set up a new payment or review your scheduled payments. What would you like to do?";
        
        suggestedReplies = [
          { id: 'qr-1', text: 'Set up new payment' },
          { id: 'qr-2', text: 'View scheduled payments' },
          { id: 'qr-3', text: 'Payment history' }
        ];
      } else if (userMsg.includes('interest') || userMsg.includes('rate')) {
        responseText = "Our current interest rates vary by account type. For savings accounts, we offer up to 2.25% APY. Would you like specific information about rates for a particular account?";
        
        suggestedReplies = [
          { id: 'qr-1', text: 'Savings account rates' },
          { id: 'qr-2', text: 'CD rates' },
          { id: 'qr-3', text: 'Mortgage rates' }
        ];
      } else if (userMsg.includes('hello') || userMsg.includes('hi')) {
        responseText = `Hello ${user?.firstName || 'there'}! How can I assist you with your banking needs today?`;
        
        suggestedReplies = [
          { id: 'qr-1', text: 'Account information' },
          { id: 'qr-2', text: 'Make a transfer' },
          { id: 'qr-3', text: 'Card services' }
        ];
      } else if (userMsg.includes('thank')) {
        responseText = "You're welcome! Is there anything else I can help you with today?";
        
        suggestedReplies = [
          { id: 'qr-1', text: 'Yes, I have another question' },
          { id: 'qr-2', text: "No thanks, that's all for now" }
        ];
      } else {
        responseText = "Thank you for your message. To provide you with the most relevant assistance, could you share more details about what you'd like help with?";
        
        suggestedReplies = [
          { id: 'qr-1', text: 'Account help' },
          { id: 'qr-2', text: 'Card services' },
          { id: 'qr-3', text: 'Online banking' }
        ];
      }
      
      const newAgentMessage: ChatMessage = {
        id: `msg-${Date.now()}`,
        text: responseText,
        sender: 'agent',
        timestamp: new Date(),
        status: 'sent'
      };
      
      setChatMessages(prev => [...prev, newAgentMessage]);
      
      // Set quick replies with a slight delay
      setTimeout(() => {
        setQuickReplies(suggestedReplies);
      }, 500);
    }, 1500 + Math.random() * 1000);
  };
  
  // Send user message
  const sendChatMessage = () => {
    if (!chatMessage.trim()) return;
    
    // Add user message
    const newUserMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      text: chatMessage,
      sender: 'user',
      timestamp: new Date(),
      status: 'sending'
    };
    
    setChatMessages(prev => [...prev, newUserMessage]);
    const sentMessage = chatMessage;
    setChatMessage('');
    
    // Clear quick replies when user sends a message
    setQuickReplies([]);
    
    // Update status to sent
    setTimeout(() => {
      setChatMessages(prev => 
        prev.map(msg => 
          msg.id === newUserMessage.id 
            ? { ...msg, status: 'delivered' } 
            : msg
        )
      );
      
      // Check for special commands or keywords
      const lowerMsg = sentMessage.toLowerCase();
      
      // Check if user is asking to speak with a human/agent
      if (
        lowerMsg.includes('speak to a human') || 
        lowerMsg.includes('real person') || 
        lowerMsg.includes('talk to agent') || 
        lowerMsg.includes('human agent') ||
        lowerMsg.includes('live agent') ||
        lowerMsg.includes('representative')
      ) {
        // If we're still with virtual assistant, transfer to human
        if (!currentAgent || (currentAgent && currentAgent.id === 'agent-1' && !queuePosition)) {
          setTimeout(() => {
            const assistMsg: ChatMessage = {
              id: `msg-${Date.now()}`,
              text: "I'd be happy to connect you with a banking specialist who can provide more personalized assistance.",
              sender: 'agent',
              timestamp: new Date(),
              status: 'sent'
            };
            
            setChatMessages(prev => [...prev, assistMsg]);
            
            // Start transfer to human agent after short delay
            setTimeout(() => {
              connectToLiveAgent();
            }, 1000);
          }, 1000);
          return;
        }
      }
      
      // Handle transfer requests once connected to an agent
      if (currentAgent && lowerMsg.includes('transfer me')) {
        // Detect what type of transfer is needed
        if (
          lowerMsg.includes('fraud') || 
          lowerMsg.includes('stolen') || 
          lowerMsg.includes('security') ||
          lowerMsg.includes('unauthorized')
        ) {
          handleChatTransfer('fraud');
        } else if (
          lowerMsg.includes('investment') || 
          lowerMsg.includes('portfolio') || 
          lowerMsg.includes('wealth') ||
          lowerMsg.includes('retirement')
        ) {
          handleChatTransfer('investment');
        } else {
          // Default to investment if transfer type is unclear
          handleChatTransfer('investment');
        }
      } else {
        // For virtual assistant, check if live agent should be suggested
        if (
          lowerMsg.includes('problem') || 
          lowerMsg.includes('issue') || 
          lowerMsg.includes('help') ||
          lowerMsg.includes('fraud') || 
          lowerMsg.includes('investment') ||
          lowerMsg.includes('urgent')
        ) {
          // If we haven't been queued or connected to a specialist yet, offer a specialist
          if (!currentAgent || (currentAgent && currentAgent.id === 'agent-1' && !queuePosition)) {
            setTimeout(() => {
              const assistMsg: ChatMessage = {
                id: `msg-${Date.now()}`,
                text: "I understand you need assistance with something important. Would you like me to connect you with a specialist who can better assist you?",
                sender: 'agent',
                timestamp: new Date(),
                status: 'sent'
              };
              
              setChatMessages(prev => [...prev, assistMsg]);
              
              setTimeout(() => {
                setQuickReplies([
                  { id: 'qr-1', text: 'Yes, connect me with a specialist' },
                  { id: 'qr-2', text: 'No, continue with virtual assistant' }
                ]);
              }, 500);
            }, 1000);
            return;
          }
        }
        
        // Standard response
        handleAgentResponse(sentMessage);
      }
    }, 500);
  };
  
  // Handle quick reply click
  const handleQuickReplyClick = (reply: QuickReply) => {
    // Add quick reply as user message
    const quickReplyMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      text: reply.text,
      sender: 'user',
      timestamp: new Date(),
      status: 'sent',
      isQuickReply: true
    };
    
    setChatMessages(prev => [...prev, quickReplyMessage]);
    
    // Clear quick replies
    setQuickReplies([]);
    
    // Check for live agent connection request
    if (
      reply.text.toLowerCase().includes('speak to') || 
      reply.text.toLowerCase().includes('talk to') || 
      reply.text.toLowerCase().includes('connect') || 
      reply.text.toLowerCase().includes('agent') || 
      reply.text.toLowerCase().includes('specialist') ||
      reply.text.toLowerCase() === 'report a problem'
    ) {
      // User wants to connect to a live agent
      setTimeout(() => {
        // Virtual assistant transfers to live agent
        connectToLiveAgent();
      }, 1000);
      return;
    }
    
    // Check for special actions
    if (reply.action === 'transfer') {
      // Detect fraud-related transfer requests
      if (
        reply.text.toLowerCase().includes('fraud') || 
        reply.text.toLowerCase().includes('stolen') || 
        reply.text.toLowerCase().includes('unauthorized') ||
        reply.text.toLowerCase().includes('security')
      ) {
        handleChatTransfer('fraud');
      } else {
        handleChatTransfer('investment');
      }
    } else if (reply.text.toLowerCase() === 'report lost/stolen card' || 
              reply.text.toLowerCase().includes('security')) {
      // First get a confirmation response, then offer transfer
      setTimeout(() => {
        const confirmMsg: ChatMessage = {
          id: `msg-${Date.now()}`,
          text: "I understand this is a security concern. For your account's protection, let me connect you with our fraud prevention specialist who can immediately secure your account and address your concerns.",
          sender: 'agent',
          timestamp: new Date(),
          status: 'sent'
        };
        
        setChatMessages(prev => [...prev, confirmMsg]);
        
        setTimeout(() => {
          setQuickReplies([
            { id: 'qr-1', text: 'Yes, connect me with a security specialist', action: 'transfer' },
            { id: 'qr-2', text: 'No, I have a different card question' }
          ]);
        }, 500);
      }, 1000);
    } else if (reply.text.toLowerCase().includes('account question')) {
      // Handle account questions via virtual assistant
      setTimeout(() => {
        const assistantMsg: ChatMessage = {
          id: `msg-${Date.now()}`,
          text: "I can help with general account questions. What specific information are you looking for?",
          sender: 'agent',
          timestamp: new Date(),
          status: 'sent'
        };
        
        setChatMessages(prev => [...prev, assistantMsg]);
        
        setTimeout(() => {
          setQuickReplies([
            { id: 'qr-1', text: 'Check account balance' },
            { id: 'qr-2', text: 'Recent transactions' },
            { id: 'qr-3', text: 'Speak to a banking specialist' }
          ]);
        }, 500);
      }, 1000);
    } else {
      // Regular response
      handleAgentResponse(reply.text);
    }
  };
  
  // Fetch user data
  const { data: user } = useQuery({
    queryKey: ["/api/auth/me"],
  });
  
  // Fetch support tickets
  const { data: tickets = [], isLoading: isLoadingTickets } = useQuery({
    queryKey: ["/api/support-tickets"],
  });
  
  // New ticket form
  const ticketForm = useForm<z.infer<typeof supportTicketSchema>>({
    resolver: zodResolver(supportTicketSchema),
    defaultValues: {
      subject: "",
      message: "",
      priority: "medium",
    },
  });
  
  // Create ticket mutation
  const createTicketMutation = useMutation({
    mutationFn: (data: any) => {
      return apiRequest("POST", "/api/support-tickets", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/support-tickets"] });
      toast({
        title: "Ticket created",
        description: "Your support ticket has been submitted successfully.",
      });
      setIsNewTicketOpen(false);
      ticketForm.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Failed to create ticket",
        description: error.message || "There was an error submitting your ticket.",
        variant: "destructive",
      });
    }
  });
  
  const onSubmitTicket = (values: z.infer<typeof supportTicketSchema>) => {
    createTicketMutation.mutate(values);
  };
  
  const viewTicketDetails = (ticket: any) => {
    setSelectedTicket(ticket);
    setIsTicketDetailsOpen(true);
  };
  
  // FAQ categories
  const faqCategories = [
    { 
      id: "accounts", 
      name: "Accounts & Banking", 
      icon: <AccountBalance />,
      faqs: [
        { 
          question: "How do I open a new account?",
          answer: "You can open a new account by clicking on the 'Accounts' tab and selecting 'Open New Account'. Follow the prompts to complete the account opening process."
        },
        { 
          question: "What are the types of accounts available?",
          answer: "We offer various types of accounts including Checking, Savings, Money Market, and Certificates of Deposit (CDs). Each account type has different features and benefits."
        },
        { 
          question: "How do I check my account balance?",
          answer: "You can check your account balance by logging into your online banking account and viewing your account dashboard. Your balance is displayed for each account you have."
        }
      ]
    },
    { 
      id: "cards", 
      name: "Cards", 
      icon: <CreditCard />,
      faqs: [
        { 
          question: "How do I activate my new card?",
          answer: "To activate your new card, you can call the number on the sticker attached to your card, or log in to online banking and select the 'Activate Card' option under the Cards section."
        },
        { 
          question: "What should I do if my card is lost or stolen?",
          answer: "If your card is lost or stolen, immediately lock the card through the Cards section of online banking and contact our customer service at 1-800-BANK-SEC to report it."
        }
      ]
    },
    { 
      id: "security", 
      name: "Security & Privacy", 
      icon: <Security />,
      faqs: [
        { 
          question: "How does Fortis Capital protect my information?",
          answer: "Fortis Capital uses industry-leading encryption and multi-factor authentication to protect your personal and financial information. We also regularly update our security measures to address new threats."
        },
        { 
          question: "What is two-factor authentication?",
          answer: "Two-factor authentication is an extra layer of security that requires not only your password but also a second form of verification, typically a code sent to your mobile device, to log in to your account."
        }
      ]
    },
    { 
      id: "transfers", 
      name: "Transfers & Payments", 
      icon: <Payments />,
      faqs: [
        { 
          question: "How long do transfers between accounts take?",
          answer: "Transfers between your Fortis Capital accounts are processed immediately. Transfers to external accounts typically take 1-3 business days to complete."
        },
        { 
          question: "Is there a fee for transferring money?",
          answer: "There is no fee for transfers between your Fortis Capital accounts. External transfers may incur a fee depending on your account type and the transfer amount."
        }
      ]
    },
    { 
      id: "profile", 
      name: "Profile & Settings", 
      icon: <AccountBox />,
      faqs: [
        { 
          question: "How do I update my contact information?",
          answer: "You can update your contact information by going to the Settings section and selecting 'Personal Information'. Make your changes and click 'Save' to update your profile."
        },
        { 
          question: "How do I change my password?",
          answer: "To change your password, go to Settings > Security > Change Password. You'll need to enter your current password and then create a new one."
        }
      ]
    },
    { 
      id: "passwords", 
      name: "Passwords & Login", 
      icon: <VpnKey />,
      faqs: [
        { 
          question: "I forgot my password. What should I do?",
          answer: "On the login screen, click 'Forgot Password' and follow the instructions. You'll need to verify your identity through email or text message to reset your password."
        },
        { 
          question: "How often should I change my password?",
          answer: "We recommend changing your password every 90 days for optimal security. Your password should be unique and not used for other websites or services."
        }
      ]
    }
  ];
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow bg-neutral-50 dark:bg-neutral-900">
        <div className="container mx-auto px-4 py-6">
          {/* Page Header */}
          <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-neutral-900 dark:text-white">Support Center</h1>
              <p className="text-neutral-600 dark:text-neutral-400 mt-1">
                Get help with your banking needs and questions
              </p>
            </div>
            <Button onClick={() => setIsNewTicketOpen(true)} className="flex items-center gap-2">
              <Assignment className="h-4 w-4" />
              New Support Ticket
            </Button>
          </div>
          
          {/* Support Tabs */}
          <Card className="mb-8">
            <CardContent>
              <Tabs defaultValue={activeTab} value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-3 mb-6">
                  <TabsTrigger value="contact">Contact Us</TabsTrigger>
                  <TabsTrigger value="tickets">My Tickets</TabsTrigger>
                  <TabsTrigger value="faqs">FAQs</TabsTrigger>
                </TabsList>
                
                <TabsContent value="contact">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h2 className="text-xl font-semibold mb-4">Get in Touch</h2>
                    <p className="text-neutral-600 dark:text-neutral-400 mb-6">
                      We're here to help with any questions you have about your accounts, 
                      services, or any other banking needs.
                    </p>
                    
                    <div className="space-y-4">
                      <div className="flex items-start">
                        <Phone className="text-primary mt-1 mr-3" />
                        <div>
                          <h3 className="font-medium">Phone Support</h3>
                          <p className="text-neutral-600 dark:text-neutral-400">1-800-FORTIS-1 (1-800-367-8471)</p>
                          <p className="text-sm text-neutral-500 dark:text-neutral-500">Available 24/7</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start">
                        <Email className="text-primary mt-1 mr-3" />
                        <div>
                          <h3 className="font-medium">Email Support</h3>
                          <p className="text-neutral-600 dark:text-neutral-400">support@fortiscapital.com</p>
                          <p className="text-sm text-neutral-500 dark:text-neutral-500">Response within 24 hours</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start">
                        <ChatBubble className="text-primary mt-1 mr-3" />
                        <div>
                          <h3 className="font-medium">Live Chat</h3>
                          <p className="text-neutral-600 dark:text-neutral-400">Chat with a representative</p>
                          <p className="text-sm text-neutral-500 dark:text-neutral-500">Available Monday-Friday, 8am-8pm ET</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-6">
                      <Button 
                        className="w-full md:w-auto"
                        onClick={() => {
                          toast({
                            title: "Live Chat Initiated",
                            description: "Connecting you with a banking specialist. Please wait a moment.",
                          });
                          
                          // Start chat dialog
                          startChat();
                        }}
                      >
                        <ChatBubble className="h-4 w-4 mr-2" />
                        Start Live Chat
                      </Button>
                    </div>
                  </div>
                  
                  <div>
                    <h2 className="text-xl font-semibold mb-4">Submit a Question</h2>
                    <div className="space-y-4">
                      <div>
                        <label htmlFor="name" className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                          Full Name
                        </label>
                        <Input 
                          id="name" 
                          type="text" 
                          defaultValue={user ? `${user?.firstName || ''} ${user?.lastName || ''}` : ""}
                          disabled={!!user}
                        />
                        <p className="text-xs text-neutral-500 mt-1">Your name will be used to personalize our response</p>
                      </div>
                      
                      <div>
                        <label htmlFor="email" className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                          Email Address
                        </label>
                        <Input 
                          id="email" 
                          type="email"
                          defaultValue={user?.email || ""}
                          disabled={!!user}
                        />
                        <p className="text-xs text-neutral-500 mt-1">We'll send our response to this email</p>
                      </div>
                      
                      <div>
                        <label htmlFor="topic" className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                          Topic
                        </label>
                        <Select defaultValue="account">
                          <SelectTrigger id="topic">
                            <SelectValue placeholder="Select a topic" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="account">Account Information</SelectItem>
                            <SelectItem value="card">Card Services</SelectItem>
                            <SelectItem value="transfer">Transfers & Payments</SelectItem>
                            <SelectItem value="bill">Bill Payment</SelectItem>
                            <SelectItem value="loan">Loans & Mortgages</SelectItem>
                            <SelectItem value="security">Security & Fraud</SelectItem>
                            <SelectItem value="technical">Technical Support</SelectItem>
                            <SelectItem value="other">Other Inquiry</SelectItem>
                          </SelectContent>
                        </Select>
                        <p className="text-xs text-neutral-500 mt-1">This helps us route your question to the right team</p>
                      </div>
                      
                      <div>
                        <label htmlFor="message" className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                          Your Question
                        </label>
                        <Textarea 
                          id="message" 
                          placeholder="Please provide details about your question or issue..."
                          rows={4}
                        />
                        <p className="text-xs text-neutral-500 mt-1">The more details you provide, the better we can assist you</p>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <input 
                          type="checkbox" 
                          id="privacy-consent" 
                          className="h-4 w-4 rounded border-neutral-300 text-primary focus:ring-primary"
                        />
                        <label htmlFor="privacy-consent" className="text-sm text-neutral-600 dark:text-neutral-400">
                          I agree to Fortis Capital's <span className="text-primary cursor-pointer">Privacy Policy</span>
                        </label>
                      </div>
                      
                      <Button 
                        type="button" 
                        className="w-full" 
                        onClick={() => {
                          toast({
                            title: "Question Submitted",
                            description: "Thank you for your question. Our team will respond within 24 hours.",
                          });
                        }}
                      >
                        Submit Question
                      </Button>
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="tickets">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-semibold">My Support Tickets</h2>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => setIsNewTicketOpen(true)}
                    className="flex items-center gap-1"
                  >
                    <Assignment className="h-4 w-4" />
                    New Ticket
                  </Button>
                </div>
                
                {isLoadingTickets ? (
                  <div className="flex justify-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                  </div>
                ) : tickets.length === 0 ? (
                  <div className="text-center py-8 text-neutral-500 dark:text-neutral-400">
                    <div className="w-16 h-16 rounded-full bg-neutral-100 dark:bg-neutral-800 mx-auto flex items-center justify-center mb-4">
                      <QuestionAnswer className="h-8 w-8 text-neutral-500 dark:text-neutral-400" />
                    </div>
                    <p className="mb-4">No support tickets found</p>
                    <Button variant="outline" onClick={() => setIsNewTicketOpen(true)}>
                      Create Your First Ticket
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {tickets.map((ticket: any) => (
                      <div 
                        key={ticket.id} 
                        className="p-4 border border-neutral-200 dark:border-neutral-700 rounded-lg hover:bg-neutral-50 dark:hover:bg-neutral-800 cursor-pointer"
                        onClick={() => viewTicketDetails(ticket)}
                      >
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="font-medium">{ticket.subject}</h3>
                          <span className={`
                            text-xs px-2 py-1 rounded-full
                            ${ticket.status === 'open' ? 'bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200' : 
                              ticket.status === 'in progress' ? 'bg-amber-100 dark:bg-amber-900 text-amber-800 dark:text-amber-200' :
                              'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200'}
                          `}>
                            {ticket.status.charAt(0).toUpperCase() + ticket.status.slice(1)}
                          </span>
                        </div>
                        <p className="text-sm text-neutral-600 dark:text-neutral-400 line-clamp-2 mb-2">
                          {ticket.message}
                        </p>
                        <div className="flex items-center text-xs text-neutral-500 dark:text-neutral-500">
                          <span>Ticket #{ticket.id}</span>
                          <span className="mx-2">•</span>
                          <span>{formatDate(ticket.createdAt)}</span>
                          <span className="mx-2">•</span>
                          <span className={`
                            ${ticket.priority === 'high' ? 'text-red-600 dark:text-red-400' : 
                              ticket.priority === 'medium' ? 'text-amber-600 dark:text-amber-400' :
                              'text-blue-600 dark:text-blue-400'}
                          `}>
                            {ticket.priority.charAt(0).toUpperCase() + ticket.priority.slice(1)} Priority
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="faqs">
                <div className="mb-6">
                  <div className="relative flex-1 max-w-md mx-auto">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-500" />
                    <Input 
                      placeholder="Search FAQs"
                      className="pl-10"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                  {faqCategories.map((category) => (
                    <Card key={category.id} className="cursor-pointer hover:shadow-md transition-shadow">
                      <CardContent className="p-6">
                        <div className="flex items-center gap-3 mb-3">
                          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                            {React.cloneElement(category.icon as React.ReactElement, { className: "text-primary" })}
                          </div>
                          <h3 className="font-medium">{category.name}</h3>
                        </div>
                        <p className="text-sm text-neutral-600 dark:text-neutral-400">
                          {category.faqs.length} articles
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                
                <div className="space-y-6">
                  <h2 className="text-xl font-semibold">Frequently Asked Questions</h2>
                  
                  {faqCategories.map((category) => (
                    <div key={category.id} className="space-y-4">
                      <h3 className="font-medium text-lg flex items-center gap-2">
                        {React.cloneElement(category.icon as React.ReactElement, { className: "text-primary" })}
                        {category.name}
                      </h3>
                      
                      <div className="space-y-4 pl-8">
                        {category.faqs.map((faq, index) => (
                          <div key={index} className="border border-neutral-200 dark:border-neutral-700 rounded-lg p-4">
                            <h4 className="font-medium mb-2 flex items-start">
                              <Help className="text-primary shrink-0 mr-2 mt-0.5" />
                              {faq.question}
                            </h4>
                            <p className="text-neutral-600 dark:text-neutral-400 pl-6">
                              {faq.answer}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </main>
      
      <Footer />
      
      {/* New Ticket Dialog */}
      <Dialog open={isNewTicketOpen} onOpenChange={setIsNewTicketOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Create Support Ticket</DialogTitle>
          </DialogHeader>
          
          <Form {...ticketForm}>
            <form onSubmit={ticketForm.handleSubmit(onSubmitTicket)} className="space-y-4">
              <FormField
                control={ticketForm.control}
                name="subject"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Subject</FormLabel>
                    <FormControl>
                      <Input placeholder="Brief description of your issue" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={ticketForm.control}
                name="message"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Message</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Describe your issue in detail" 
                        rows={6}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={ticketForm.control}
                name="priority"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Priority</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select priority" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter className="pt-4">
                <Button 
                  variant="outline" 
                  type="button" 
                  onClick={() => setIsNewTicketOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={createTicketMutation.isPending}
                >
                  {createTicketMutation.isPending ? "Submitting..." : "Submit Ticket"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      {/* Ticket Details Dialog */}
      {selectedTicket && (
        <Dialog open={isTicketDetailsOpen} onOpenChange={setIsTicketDetailsOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Ticket #{selectedTicket.id}</DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className={`
                  text-xs px-2 py-1 rounded-full
                  ${selectedTicket.status === 'open' ? 'bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200' : 
                    selectedTicket.status === 'in progress' ? 'bg-amber-100 dark:bg-amber-900 text-amber-800 dark:text-amber-200' :
                    'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200'}
                `}>
                  {selectedTicket.status.charAt(0).toUpperCase() + selectedTicket.status.slice(1)}
                </span>
                <span className={`
                  text-xs px-2 py-1 rounded-full
                  ${selectedTicket.priority === 'high' ? 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200' : 
                    selectedTicket.priority === 'medium' ? 'bg-amber-100 dark:bg-amber-900 text-amber-800 dark:text-amber-200' :
                    'bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200'}
                `}>
                  {selectedTicket.priority.charAt(0).toUpperCase() + selectedTicket.priority.slice(1)} Priority
                </span>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-2">{selectedTicket.subject}</h3>
                <p className="text-sm text-neutral-600 dark:text-neutral-400 mb-4">
                  Submitted on {formatDate(selectedTicket.createdAt)}
                </p>
              </div>
              
              <div className="border border-neutral-200 dark:border-neutral-700 rounded-lg p-4 bg-neutral-50 dark:bg-neutral-800">
                <p className="text-neutral-800 dark:text-neutral-200">
                  {selectedTicket.message}
                </p>
              </div>
              
              <div className="border-t border-neutral-200 dark:border-neutral-700 pt-4">
                <h4 className="font-medium mb-2">Responses</h4>
                <div className="text-neutral-600 dark:text-neutral-400 text-center py-4">
                  No responses yet. Our team will get back to you soon.
                </div>
              </div>
              
              <div>
                <label htmlFor="reply" className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                  Add a Reply
                </label>
                <Textarea 
                  id="reply" 
                  placeholder="Type your message here..."
                  rows={3}
                />
                <div className="flex justify-end mt-2">
                  <Button size="sm">Send Reply</Button>
                </div>
              </div>
            </div>
            
            <DialogFooter>
              <Button 
                variant="outline" 
                onClick={() => setIsTicketDetailsOpen(false)}
              >
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
      
      {/* Minimized Chat Bubble */}
      {isChatOpen && isMinimized && (
        <div 
          className="fixed bottom-4 right-4 bg-primary text-white rounded-full p-4 shadow-lg cursor-pointer z-50 flex items-center gap-2"
          onClick={() => setIsMinimized(false)}
        >
          <ChatBubble />
          <div className="flex flex-col">
            <span className="font-medium text-sm">Support Chat</span>
            {currentAgent && (
              <span className="text-xs opacity-90">
                {currentAgent.name.split(' ')[0]}
                <span className="inline-block w-1.5 h-1.5 bg-green-400 rounded-full ml-1.5 mr-0.5 relative -top-px"></span>
              </span>
            )}
          </div>
        </div>
      )}

      {/* Live Chat Dialog */}
      <Dialog 
        open={isChatOpen && !isMinimized}
        onOpenChange={(open) => {
          if (!open) {
            // Instead of closing immediately, show the confirmation dialog
            if (chatMessages.length > 1) {
              setIsCloseChatDialogOpen(true);
            } else {
              setIsChatOpen(false);
              setChatMessages([]);
            }
          }
        }}
      >
        <DialogContent className="sm:max-w-[500px] p-0 h-[600px] max-h-[80vh] flex flex-col">
          <DialogTitle className="sr-only">Live Chat with Support Agent</DialogTitle>
          <DialogDescription className="sr-only">Chat with a Fortis Capital support specialist</DialogDescription>
          
          {/* Chat Header */}
          <div className="p-4 border-b border-neutral-200 dark:border-neutral-700 flex items-center justify-between bg-primary/5">
            <div className="flex items-center">
              <div className="relative">
                <Avatar className="h-10 w-10 mr-3">
                  <AvatarImage src="" />
                  <AvatarFallback className="bg-primary/20 text-primary">
                    {currentAgent?.name?.split(' ').map(n => n[0]).join('') || 'SC'}
                  </AvatarFallback>
                </Avatar>
                {currentAgent && (
                  <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full border-2 border-white bg-green-500"></div>
                )}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-medium text-sm">
                    {currentAgent?.name || 'Support Chat'}
                  </h3>
                  {currentAgent?.department && (
                    <Badge variant="outline" className="text-[10px] py-0 h-4 px-1.5 bg-primary/5 border-primary/10 text-primary">
                      {currentAgent.department}
                    </Badge>
                  )}
                </div>
                <div className="flex items-center text-xs text-neutral-500 dark:text-neutral-400">
                  <span>{currentAgent?.role || 'Connecting...'}</span>
                  {currentAgent?.rating && (
                    <div className="flex items-center ml-2">
                      <span className="text-amber-500">★</span>
                      <span className="ml-0.5">{currentAgent.rating}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-1">
              {currentAgent && (
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-8 w-8 rounded-full"
                  title="Agent information"
                  onClick={() => setShowAgentInfo(!showAgentInfo)}
                >
                  <InfoIcon className="h-4 w-4 text-primary" />
                </Button>
              )}
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-8 w-8 rounded-full"
                title="Request a call"
                onClick={() => {
                  toast({
                    title: "Call Requested",
                    description: "An agent will call you within 5 minutes at your registered number.",
                  });
                }}
              >
                <Phone className="h-4 w-4 text-primary" />
              </Button>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-8 w-8 rounded-full"
                title="Minimize chat"
                onClick={() => setIsMinimized(true)}
              >
                <Minimize className="h-4 w-4 text-neutral-500" />
              </Button>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-8 w-8 rounded-full"
                title="More options"
                onClick={() => setShowTranscriptOptions(!showTranscriptOptions)}
              >
                <MoreVert className="h-4 w-4 text-neutral-500" />
              </Button>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-8 w-8 rounded-full"
                title="Close chat"
                onClick={() => setIsCloseChatDialogOpen(true)}
              >
                <X className="h-4 w-4 text-neutral-500" />
              </Button>
            </div>
          </div>
          
          {/* Agent Info Panel - Shows when user clicks agent info button */}
          {showAgentInfo && currentAgent && (
            <div className="absolute top-[4.5rem] left-4 right-4 z-10 bg-white dark:bg-neutral-900 shadow-lg rounded-lg border border-neutral-200 dark:border-neutral-800 p-4">
              <div className="flex items-start gap-4">
                <Avatar className="h-16 w-16">
                  <AvatarImage src="" />
                  <AvatarFallback className="bg-primary/20 text-primary text-xl">
                    {currentAgent.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                
                <div className="flex-1">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="font-medium text-base">{currentAgent.name}</h3>
                      <p className="text-sm text-neutral-500">{currentAgent.role}</p>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-6 w-6"
                      onClick={() => setShowAgentInfo(false)}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2 text-sm mb-3">
                    <div>
                      <p className="text-xs text-neutral-500">Department</p>
                      <p className="font-medium">{currentAgent.department}</p>
                    </div>
                    <div>
                      <p className="text-xs text-neutral-500">Rating</p>
                      <p className="font-medium flex items-center">
                        <span className="text-amber-500 mr-1">★</span>
                        {currentAgent.rating} <span className="text-xs text-neutral-400 ml-1">/5</span>
                      </p>
                    </div>
                  </div>
                  
                  <div className="mb-3">
                    <p className="text-xs text-neutral-500 mb-1">Expertise</p>
                    <div className="flex flex-wrap gap-1">
                      {currentAgent.expertise.map(skill => (
                        <Badge key={skill} variant="outline" className="bg-neutral-100 dark:bg-neutral-800 text-xs">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  <div className="text-xs text-neutral-500 flex items-center">
                    <Clock className="h-3 w-3 mr-1 inline" /> Available now
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* Transcript Options Panel */}
          {showTranscriptOptions && (
            <div className="absolute top-[4.5rem] right-4 w-48 z-10 bg-white dark:bg-neutral-900 shadow-lg rounded-lg border border-neutral-200 dark:border-neutral-800 py-1">
              <button 
                className="w-full text-left px-3 py-2 text-sm hover:bg-neutral-100 dark:hover:bg-neutral-800 flex items-center"
                onClick={() => {
                  toast({
                    title: "Transcript Emailed",
                    description: "A copy of this conversation has been sent to your email.",
                  });
                  setShowTranscriptOptions(false);
                }}
              >
                <Email className="h-4 w-4 mr-2" /> Email Transcript
              </button>
              <button 
                className="w-full text-left px-3 py-2 text-sm hover:bg-neutral-100 dark:hover:bg-neutral-800 flex items-center"
                onClick={() => {
                  toast({
                    title: "Conversation Saved",
                    description: "This conversation has been saved to your account.",
                  });
                  setShowTranscriptOptions(false);
                }}
              >
                <Save className="h-4 w-4 mr-2" /> Save Conversation
              </button>
              <div className="border-t border-neutral-200 dark:border-neutral-700 my-1"></div>
              <button 
                className="w-full text-left px-3 py-2 text-sm hover:bg-neutral-100 dark:hover:bg-neutral-800 flex items-center text-red-500"
                onClick={() => {
                  setShowTranscriptOptions(false);
                  setIsCloseChatDialogOpen(true);
                }}
              >
                <LogOut className="h-4 w-4 mr-2" /> End Chat
              </button>
            </div>
          )}
          
          {/* Agent Expertise Pills - Only show if agent has expertise */}
          {currentAgent?.expertise && currentAgent.expertise.length > 0 && (
            <div className="px-4 py-2 flex flex-wrap gap-1 bg-neutral-50 dark:bg-neutral-850 border-b border-neutral-200 dark:border-neutral-700">
              {currentAgent.expertise.map((skill, idx) => (
                <Badge 
                  key={idx} 
                  variant="outline" 
                  className="px-2 py-0.5 text-xs bg-neutral-100 dark:bg-neutral-800"
                >
                  {skill}
                </Badge>
              ))}
            </div>
          )}
          
          {/* Chat Messages */}
          <ScrollArea className="flex-1 p-4">
            <div className="space-y-4">
              {chatMessages.map((message) => (
                <div 
                  key={message.id} 
                  className={`flex ${message.sender === 'user' ? 'justify-end' : 
                    message.sender === 'system' ? 'justify-center' : 'justify-start'}`}
                >
                  {message.sender === 'agent' && (
                    <Avatar className="h-8 w-8 mr-2 mt-1 flex-shrink-0">
                      <AvatarImage src="" />
                      <AvatarFallback className="bg-primary/20 text-primary text-xs">
                        {currentAgent?.name?.split(' ').map(n => n[0]).join('') || 'SC'}
                      </AvatarFallback>
                    </Avatar>
                  )}
                  
                  {message.sender === 'system' ? (
                    <div className="bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400 text-xs py-1 px-3 rounded-full">
                      {message.text}
                    </div>
                  ) : (
                    <div 
                      className={`rounded-lg px-4 py-2 max-w-[80%] ${
                        message.sender === 'user' 
                          ? message.isQuickReply 
                            ? 'bg-primary/90 text-primary-foreground' 
                            : 'bg-primary text-primary-foreground' 
                          : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-900 dark:text-neutral-100'
                      }`}
                    >
                      <p className="text-sm whitespace-pre-wrap">{message.text}</p>
                      
                      {/* File/Image Attachments */}
                      {message.attachments && message.attachments.length > 0 && (
                        <div className="mt-2 space-y-2">
                          {message.attachments.map((attachment, idx) => (
                            <div 
                              key={idx}
                              className={`flex items-center rounded p-2 ${
                                message.sender === 'user' 
                                ? 'bg-primary-foreground/10' 
                                : 'bg-neutral-200 dark:bg-neutral-700'
                              }`}
                            >
                              {attachment.type === 'image' ? (
                                <div className="w-full h-32 bg-neutral-200 dark:bg-neutral-700 rounded flex items-center justify-center">
                                  <p className="text-xs text-neutral-500 dark:text-neutral-400">Image: {attachment.name}</p>
                                </div>
                              ) : (
                                <div className="flex items-center w-full">
                                  <div className="h-8 w-8 rounded bg-neutral-300 dark:bg-neutral-600 flex items-center justify-center mr-2">
                                    <AttachFile className="h-4 w-4" />
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <p className="text-xs font-medium truncate">{attachment.name}</p>
                                    <p className="text-xs opacity-70">{attachment.size}</p>
                                  </div>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                      
                      <div className="flex items-center justify-end mt-1 space-x-1">
                        <span className="text-xs opacity-70">
                          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                        {message.sender === 'user' && message.status && (
                          <span className="text-xs opacity-70">
                            {message.status === 'sending' ? '• Sending' : 
                             message.status === 'sent' ? '• Sent' : 
                             message.status === 'delivered' ? '• Delivered' : 
                             message.status === 'read' ? '• Read' : ''}
                          </span>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              ))}
              
              {/* Typing indicator */}
              {isTyping && (
                <div className="flex justify-start">
                  <Avatar className="h-8 w-8 mr-2 mt-1 flex-shrink-0">
                    <AvatarImage src="" />
                    <AvatarFallback className="bg-primary/20 text-primary text-xs">
                      {currentAgent?.name?.split(' ').map(n => n[0]).join('') || 'SC'}
                    </AvatarFallback>
                  </Avatar>
                  <div className="rounded-lg px-4 py-3 max-w-[80%] bg-neutral-100 dark:bg-neutral-800">
                    <div className="flex space-x-1 items-center">
                      <div className="w-2 h-2 rounded-full bg-neutral-400 dark:bg-neutral-500 animate-bounce" style={{ animationDelay: "0ms" }}></div>
                      <div className="w-2 h-2 rounded-full bg-neutral-400 dark:bg-neutral-500 animate-bounce" style={{ animationDelay: "300ms" }}></div>
                      <div className="w-2 h-2 rounded-full bg-neutral-400 dark:bg-neutral-500 animate-bounce" style={{ animationDelay: "600ms" }}></div>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Quick replies */}
              {quickReplies.length > 0 && (
                <div className="pt-2">
                  <div className="flex flex-wrap gap-2">
                    {quickReplies.map((reply) => (
                      <Button
                        key={reply.id}
                        variant="outline"
                        size="sm"
                        className="rounded-full text-sm py-1 h-auto bg-neutral-50 dark:bg-neutral-800 hover:bg-neutral-100 dark:hover:bg-neutral-700"
                        onClick={() => handleQuickReplyClick(reply)}
                      >
                        {reply.text}
                      </Button>
                    ))}
                  </div>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>
          
          <Separator />
          
          {/* Chat Input */}
          <div className="p-3 border-t border-neutral-200 dark:border-neutral-700 flex items-end">
            {/* File Upload Button */}
            <input 
              type="file"
              id="file-upload"
              className="hidden"
              onChange={(e) => {
                if (e.target.files && e.target.files[0]) {
                  handleFileUpload(e.target.files[0]);
                  e.target.value = ''; // Reset the input
                }
              }}
            />
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-9 w-9 rounded-full"
              onClick={() => document.getElementById('file-upload')?.click()}
              title="Attach file"
            >
              <AttachFile className="h-5 w-5 text-neutral-500 transform rotate-45" />
            </Button>
            
            {/* Text Input */}
            <div className="flex-1 mx-2">
              <Textarea 
                placeholder={fileAttachment ? `Sending ${fileAttachment.name}...` : "Type your message..."} 
                className="min-h-[40px] resize-none border-0 focus-visible:ring-0 px-4 py-2.5"
                value={chatMessage}
                onChange={(e) => setChatMessage(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    sendChatMessage();
                  }
                }}
                disabled={!!fileAttachment || isTransferring}
              />
            </div>
            
            {/* Send Button */}
            <Button 
              size="icon" 
              className="h-9 w-9 rounded-full" 
              onClick={sendChatMessage}
              disabled={(!chatMessage.trim() && !fileAttachment) || isTransferring}
              title="Send message"
            >
              <Send className="h-4 w-4 text-primary-foreground" />
            </Button>
          </div>
          
          {/* Chat Transfer Overlay */}
          {isTransferring && (
            <div className="absolute inset-0 bg-background/90 flex items-center justify-center z-10">
              <div className="text-center p-4">
                <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-primary mx-auto mb-4"></div>
                <h3 className="font-medium text-lg mb-2">Transferring Chat</h3>
                <p className="text-neutral-600 dark:text-neutral-400">Please wait while we connect you with a specialist...</p>
              </div>
            </div>
          )}
          
          {/* Connecting Status */}
          {!isChatConnected && !isTransferring && agentStatus === 'connecting' && (
            <div className="absolute inset-0 bg-background/80 flex items-center justify-center">
              <div className="text-center p-4">
                <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-primary mx-auto mb-4"></div>
                <h3 className="font-medium text-lg mb-2">Connecting to Secure Chat</h3>
                <p className="text-neutral-600 dark:text-neutral-400">
                  Please wait while we establish a secure connection...
                </p>
                <div className="flex justify-center gap-2 mt-3">
                  <div className="h-1.5 w-1.5 bg-neutral-300 dark:bg-neutral-600 rounded-full animate-pulse"></div>
                  <div className="h-1.5 w-1.5 bg-neutral-300 dark:bg-neutral-600 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
                  <div className="h-1.5 w-1.5 bg-neutral-300 dark:bg-neutral-600 rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
                </div>
              </div>
            </div>
          )}
          
          {/* Queue Status */}
          {!isChatConnected && !isTransferring && agentStatus === 'queue' && (
            <div className="absolute inset-0 bg-background/80 flex items-center justify-center">
              <div className="text-center p-6 max-w-md">
                <div className="flex justify-center mb-4">
                  <div className="relative flex">
                    {[...Array(3)].map((_, i) => (
                      <div 
                        key={i} 
                        className={`w-4 h-8 mx-1 rounded ${
                          (queuePosition || 3) <= i ? 'bg-neutral-200 dark:bg-neutral-700' : 'bg-primary'
                        }`}
                      ></div>
                    ))}
                  </div>
                </div>
                
                <h3 className="font-medium text-lg mb-2">Waiting for Next Available Agent</h3>
                
                <div className="bg-neutral-100 dark:bg-neutral-800 p-4 rounded-lg mb-4">
                  <div className="flex justify-between mb-2">
                    <span className="text-neutral-600 dark:text-neutral-400">Your position:</span>
                    <span className="font-medium">{queuePosition} of 3</span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-neutral-600 dark:text-neutral-400">Estimated wait:</span>
                    <span className="font-medium">{estimatedWaitTime}</span>
                  </div>
                </div>
                
                <p className="text-neutral-500 dark:text-neutral-400 text-sm">
                  Fortis Capital agents are available 24/7 to assist with your banking needs. You'll be connected to the next available specialist for immediate assistance.
                </p>
                
                <div className="flex justify-center mt-4">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      if (confirm("Are you sure you want to leave the queue? You'll lose your position.")) {
                        setIsChatOpen(false);
                        setChatMessages([]);
                        setQuickReplies([]);
                        setIsTyping(false);
                        setIsChatConnected(false);
                        setCurrentAgent(null);
                        setAgentStatus('connecting');
                        setQueuePosition(null);
                        setEstimatedWaitTime(null);
                      }
                    }}
                  >
                    Leave Queue
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
      {/* Close Chat Confirmation Dialog */}
      <Dialog open={isCloseChatDialogOpen} onOpenChange={setIsCloseChatDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <LogOut className="h-5 w-5 text-destructive" />
              End Support Conversation
            </DialogTitle>
            <DialogDescription>
              Are you sure you want to end this conversation? Any unsaved information will be lost.
            </DialogDescription>
          </DialogHeader>
          
          <div className="bg-neutral-50 dark:bg-neutral-900 rounded-md p-4 my-2 border border-neutral-200 dark:border-neutral-800">
            <div className="flex items-center gap-3 mb-3">
              <div className="h-10 w-10 bg-primary/10 rounded-full flex items-center justify-center text-primary">
                {currentAgent?.name?.charAt(0) || 'A'}
              </div>
              <div>
                <p className="text-sm font-medium">{currentAgent?.name || 'Support Agent'}</p>
                <p className="text-xs text-neutral-500">{currentAgent?.role || 'Banking Support'}</p>
              </div>
            </div>
            
            <div className="space-y-2 text-sm">
              <div className="flex items-start gap-2">
                <Clock className="h-4 w-4 text-neutral-500 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium">Conversation Duration</p>
                  <p className="text-neutral-500 text-xs">
                    {chatMessages.length > 0 
                      ? `${Math.floor(Math.random() * 15) + 5} minutes` 
                      : 'Less than a minute'}
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-2">
                <ChatBubble className="h-4 w-4 text-neutral-500 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium">Message Count</p>
                  <p className="text-neutral-500 text-xs">{chatMessages.length} messages</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-2 mt-2">
            <Button 
              variant="outline" 
              onClick={() => {
                toast({
                  title: "Transcript Saved",
                  description: "A copy of this conversation has been saved to your account.",
                });
                setIsCloseChatDialogOpen(false);
                setIsChatOpen(false);
                setChatMessages([]);
                setQuickReplies([]);
                setIsTyping(false);
                setIsChatConnected(false);
                setCurrentAgent(null);
                setAgentStatus('connecting');
                setQueuePosition(null);
                setEstimatedWaitTime(null);
              }}
            >
              <Save className="h-4 w-4 mr-2" />
              End & Save
            </Button>
            <Button 
              variant="destructive"
              onClick={() => {
                setIsCloseChatDialogOpen(false);
                setIsChatOpen(false);
                setChatMessages([]);
                setQuickReplies([]);
                setIsTyping(false);
                setIsChatConnected(false);
                setCurrentAgent(null);
                setAgentStatus('connecting');
                setQueuePosition(null);
                setEstimatedWaitTime(null);
              }}
            >
              <LogOut className="h-4 w-4 mr-2" />
              End Chat
            </Button>
          </div>
          
          <Button 
            variant="ghost" 
            className="w-full mt-2"
            onClick={() => {
              setIsCloseChatDialogOpen(false);
              setIsMinimized(true);
            }}
          >
            <Minimize className="h-4 w-4 mr-2" />
            Minimize Instead
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}
