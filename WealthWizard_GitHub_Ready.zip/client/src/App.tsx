import { Switch, Route, useLocation, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/lib/theme-provider";
import { AuthProvider } from "@/hooks/use-auth";
import { AdminAuthProvider } from "@/hooks/use-admin-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import { AdminProtectedRoute } from "@/lib/admin-protected-route";
import NotFound from "@/pages/not-found";

// Auth Pages
import TwoFactor from "@/pages/auth/two-factor";
import ForgotPassword from "@/pages/auth/forgot-password";
import ResetPassword from "@/pages/auth/reset-password";
import AuthPage from "@/pages/auth/index";
import VerificationPage from "@/pages/auth/verification-page";
import ApplicationStatusPage from "@/pages/application-status";

// User Pages
import Dashboard from "@/pages/dashboard";
import Accounts from "@/pages/accounts";
import AccountDetails from "@/pages/accounts/details";
import NewAccount from "@/pages/accounts/new";
import Transfers from "@/pages/transfers";
import Bills from "@/pages/bills";
import Cards from "@/pages/cards";
import Support from "@/pages/support";
import Settings from "@/pages/settings";

// Legal Pages
import TermsAndConditions from "@/pages/legal/terms-conditions";
import PrivacyPolicy from "@/pages/legal/privacy-policy";

// Admin Pages
import AdminDashboard from "@/pages/admin/dashboard";
import AdminUsers from "@/pages/admin/users";
import AdminKyc from "@/pages/admin/kyc";
import AdminTransactions from "@/pages/admin/transactions";
import AdminBills from "@/pages/admin/bills";
import AdminDocumentCenter from "@/pages/admin/document-center";
import SimpleApplications from "@/pages/admin/simple-applications";
import AdminLoginPage from "@/pages/admin-login";

// Router function is now replaced by AdminRouter and UserRouter
// They are managed separately and conditionally rendered based on path

// AdminRouter handles all admin-specific routes
function AdminRouter() {
  const [location] = useLocation();
  const isAdminRoute = location.startsWith('/admin');
  const isAdminLoginPath = location === '/admin-login'; // Check for alternate admin login path
  
  // Only render AdminRouter for admin routes to avoid conflicts with user routes
  if (!isAdminRoute && !isAdminLoginPath) {
    return null;
  }
  
  return (
    <AdminAuthProvider>
      <Switch>
        {/* Admin login page - support both URL patterns */}
        <Route path="/admin/login">
          {() => {
            console.log("Admin portal login page loaded via AdminRouter");
            return <AdminLoginPage />;
          }}
        </Route>
        
        {/* Alternative admin login path for easier access */}
        <Route path="/admin-login">
          {() => {
            console.log("Redirecting from /admin-login to /admin/login");
            return <Redirect to="/admin/login" />;
          }}
        </Route>
        
        {/* Protected admin routes */}
        <AdminProtectedRoute path="/admin/dashboard" component={AdminDashboard} />
        <AdminProtectedRoute path="/admin/users" component={AdminUsers} />
        <AdminProtectedRoute path="/admin/kyc" component={AdminKyc} />
        <AdminProtectedRoute path="/admin/transactions" component={AdminTransactions} />
        <AdminProtectedRoute path="/admin/bills" component={AdminBills} />
        <AdminProtectedRoute path="/admin/documents" component={AdminDocumentCenter} />
        <AdminProtectedRoute path="/admin/simple-applications" component={SimpleApplications} />
        <AdminProtectedRoute path="/admin" component={AdminDashboard} />
        
        {/* Fallback for unknown admin routes */}
        <Route path="/admin/*">
          {() => <Redirect to="/admin/dashboard" />}
        </Route>
      </Switch>
    </AdminAuthProvider>
  );
}

// UserRouter handles all user/regular routes
function UserRouter() {
  const [location] = useLocation();
  const isAdminRoute = location.startsWith('/admin');
  const isAdminLoginPath = location === '/admin-login';
  
  // Only don't render user routes when on admin routes 
  // This allows concurrent user and admin sessions
  if (isAdminRoute || isAdminLoginPath) {
    return null;
  }
  
  return (
    <AuthProvider>
      <Switch>
        {/* Legal Routes - Public */}
        <Route path="/legal/terms-conditions" component={TermsAndConditions} />
        <Route path="/legal/privacy-policy" component={PrivacyPolicy} />
        
        {/* Public Auth Routes */}
        <Route path="/verification/:step">
          {(params) => <VerificationPage params={params} />}
        </Route>
        <Route path="/verification">
          {(params) => <VerificationPage params={params} />}
        </Route>
        <Route path="/forgot-password" component={ForgotPassword} />
        <Route path="/reset-password" component={ResetPassword} />
        <Route path="/two-factor" component={TwoFactor} />
        <Route path="/application-status" component={ApplicationStatusPage} />
        
        {/* Auth page variations */}
        <Route path="/auth">
          {() => {
            console.log("Auth page loaded via /auth route");
            return <AuthPage />;
          }}
        </Route>
        <Route path="/login">
          {() => {
            console.log("Auth page loaded via /login route");
            return <AuthPage />;
          }}
        </Route>
        <Route path="/register">
          {() => {
            console.log("Auth page loaded via /register route");
            return <AuthPage />;
          }}
        </Route>
        <Route path="/user-login">
          {() => {
            // Special route to clear admin session and redirect to regular login
            console.log("User login route clearing admin session");
            localStorage.removeItem('fortis_admin_token');
            return <Redirect to="/login" />;
          }}
        </Route>
        
        {/* Protected User Routes */}
        <ProtectedRoute path="/accounts/new" component={NewAccount} />
        <ProtectedRoute path="/accounts/:id" component={AccountDetails} />
        <ProtectedRoute path="/accounts" component={Accounts} />
        <ProtectedRoute path="/dashboard" component={Dashboard} />
        <ProtectedRoute path="/transfers" component={Transfers} />
        <ProtectedRoute path="/bills" component={Bills} />
        <ProtectedRoute path="/cards" component={Cards} />
        <ProtectedRoute path="/support" component={Support} />
        <ProtectedRoute path="/settings" component={Settings} />
        
        {/* Root path redirect */}
        <Route path="/">
          {() => {
            console.log("Root path hit, redirecting to /auth");
            return <Redirect to="/auth" />;
          }}
        </Route>
        
        {/* Fallback to 404 for any unknown routes */}
        <Route component={NotFound} />
      </Switch>
    </AuthProvider>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          {/* For debugging - will help track page loads */}
          <div className="hidden">App loaded successfully</div>
          
          {/* Two completely separate router systems */}
          <AdminRouter />
          <UserRouter />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
