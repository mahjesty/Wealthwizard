import { useEffect } from "react";
import { Redirect, Route, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";

interface ProtectedRouteProps {
  path: string;
  component: React.ComponentType<any>;
  adminOnly?: boolean;
}

/**
 * ProtectedRoute component that handles authentication and authorization
 * Will redirect to /auth if user is not authenticated
 * Will redirect to /dashboard if adminOnly is true and the user is not an admin
 */
export function ProtectedRoute({ 
  path, 
  component: Component, 
  adminOnly = false 
}: ProtectedRouteProps) {
  const { user, isLoading, isAuthenticated, isAdmin } = useAuth();
  const [, navigate] = useLocation();

  // Log authentication status for debugging
  useEffect(() => {
    // Don't show debug messages on admin login page
    if (path !== '/admin/login' && !isLoading) {
      if (!isAuthenticated) {
        console.log("Not authenticated, redirecting to auth page");
      } else if (adminOnly && !isAdmin) {
        console.log("Not authorized as admin, redirecting to dashboard");
      }
    }
  }, [isLoading, isAuthenticated, isAdmin, adminOnly, path]);

  return (
    <Route path={path}>
      {() => {
        // Don't handle admin login page here - it has its own logic
        if (path === '/admin/login') {
          return <Component />;
        }
        
        // Show loading spinner while checking authentication
        if (isLoading) {
          return (
            <div className="flex items-center justify-center min-h-screen">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          );
        }

        // Redirect to auth page if not authenticated
        if (!isAuthenticated) {
          return <Redirect to="/auth" />;
        }

        // Redirect to dashboard if trying to access admin page without admin privileges
        if (adminOnly && !isAdmin) {
          return <Redirect to="/dashboard" />;
        }

        // User is authenticated (and has admin rights if required)
        return <Component />;
      }}
    </Route>
  );
}