import { useAdminAuth } from "@/hooks/use-admin-auth";
import { Loader2, Shield } from "lucide-react";
import { Redirect, Route, useLocation } from "wouter";
import { useEffect } from "react";

interface AdminProtectedRouteProps {
  path: string;
  component: React.ComponentType<any>;
}

/**
 * AdminProtectedRoute component specifically for admin routes
 * Uses the AdminAuthProvider instead of the regular AuthProvider
 * Will redirect to /admin/login if not authenticated as admin
 */
export function AdminProtectedRoute({ 
  path,
  component: Component,
}: AdminProtectedRouteProps) {
  const { isAuthenticated, isLoading } = useAdminAuth();

  if (isLoading) {
    return (
      <Route path={path}>
        <div className="flex items-center justify-center min-h-screen bg-amber-50">
          <div className="flex flex-col items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-amber-600 mb-2" />
            <p className="text-amber-800">Loading admin portal...</p>
          </div>
        </div>
      </Route>
    );
  }

  if (!isAuthenticated) {
    console.log("Not authenticated as admin, redirecting to admin login");
    return (
      <Route path={path}>
        <Redirect to="/admin/login" />
      </Route>
    );
  }

  // If we're on an admin route and authenticated, render the component
  return <Route path={path} component={Component} />;
}