/**
 * WebAuthn service for handling biometric authentication
 */

// Convert base64 string to ArrayBuffer
function base64ToArrayBuffer(base64: string): ArrayBuffer {
  const binaryString = window.atob(base64.replace(/-/g, '+').replace(/_/g, '/'));
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes.buffer;
}

// Convert ArrayBuffer to base64 string
function arrayBufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return window.btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}

/**
 * Check if WebAuthn is supported by the browser
 */
export function isWebAuthnSupported(): boolean {
  return window.PublicKeyCredential !== undefined && 
         typeof window.PublicKeyCredential === 'function';
}

/**
 * Check if the platform authenticator is available (e.g., Touch ID, Face ID, Windows Hello)
 */
export async function isPlatformAuthenticatorAvailable(): Promise<boolean> {
  if (!isWebAuthnSupported()) {
    return false;
  }
  
  return await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
}

/**
 * Register a new credential (enroll biometrics)
 */
export async function registerCredential(username: string, userId: string): Promise<{ 
  credential: string; 
  credentialId: string;
}> {
  try {
    // Get auth token from localStorage if available for header-based auth
    const authToken = localStorage.getItem('fortis_auth_token');
    
    // Build headers with content type and auth token if available
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    
    if (authToken) {
      headers['Authorization'] = `Bearer ${authToken}`;
    }
    
    console.log("Sending WebAuthn register options request with headers:", headers);
    
    // Get challenge from server
    const response = await fetch('/api/webauthn/register-options', {
      method: 'POST',
      headers,
      body: JSON.stringify({ username, userId }),
      credentials: 'include', // Include session cookies
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error(`WebAuthn register options error: Status ${response.status}, ${errorText}`);
      throw new Error(`Server error (${response.status}): ${errorText}`);
    }
    
    const options = await response.json();
    
    console.log("Received options:", options);
    
    // Convert challenge and user.id from base64 to ArrayBuffer
    options.challenge = base64ToArrayBuffer(options.challenge);
    if (options.user && options.user.id) {
      options.user.id = base64ToArrayBuffer(options.user.id);
    }
    
    // If exclude credentials exist, process them
    if (options.excludeCredentials) {
      options.excludeCredentials = options.excludeCredentials.map((credential: any) => {
        return {
          ...credential,
          id: base64ToArrayBuffer(credential.id)
        };
      });
    }
    
    // Set authenticator selection criteria - but don't override if already set by server
    if (!options.authenticatorSelection) {
      options.authenticatorSelection = {
        authenticatorAttachment: 'platform', // Use platform authenticator (like TouchID, FaceID)
        userVerification: 'required', // Require biometric verification
        requireResidentKey: false
      };
    }
    
    // Create credentials with device biometrics
    const credential = await navigator.credentials.create({
      publicKey: options
    }) as PublicKeyCredential;
    
    // Get attestation response
    const attestationResponse = credential.response as AuthenticatorAttestationResponse;
    
    // Prepare data for server
    const credentialData = {
      id: credential.id,
      rawId: arrayBufferToBase64(credential.rawId),
      response: {
        clientDataJSON: arrayBufferToBase64(attestationResponse.clientDataJSON),
        attestationObject: arrayBufferToBase64(attestationResponse.attestationObject),
      },
      type: credential.type,
    };
    
    // Build headers with content type and auth token if available
    const verificationHeaders: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    
    // Reuse the authToken we already retrieved earlier
    if (authToken) {
      verificationHeaders['Authorization'] = `Bearer ${authToken}`;
    }
    
    console.log("Sending WebAuthn verification request with headers:", verificationHeaders);
    
    // Send to server for verification
    const verificationResponse = await fetch('/api/webauthn/register-verification', {
      method: 'POST',
      headers: verificationHeaders,
      body: JSON.stringify(credentialData),
      credentials: 'include', // Include session cookies
    });
    
    if (!verificationResponse.ok) {
      const error = await verificationResponse.text();
      throw new Error(`Server verification error: ${error}`);
    }
    
    const verificationResult = await verificationResponse.json();
    
    return {
      credential: JSON.stringify(credentialData),
      credentialId: credential.id
    };
    
  } catch (error) {
    console.error('Error during credential registration:', error);
    throw error;
  }
}

/**
 * Authenticate with a registered biometric credential
 */
export async function authenticateWithBiometrics(): Promise<{
  credentialId: string;
  username: string;
}> {
  try {
    // Get auth token from localStorage if available for header-based auth
    const authToken = localStorage.getItem('fortis_auth_token');
    
    // Build headers with content type and auth token if available
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    
    if (authToken) {
      headers['Authorization'] = `Bearer ${authToken}`;
    }
    
    console.log("Sending WebAuthn login options request with headers:", headers);
    
    // Get challenge from server
    const response = await fetch('/api/webauthn/login-options', {
      method: 'POST',
      headers,
      credentials: 'include', // Include session cookies
    });
    
    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Server error: ${error}`);
    }
    
    const options = await response.json();
    
    // Convert challenge from base64 to ArrayBuffer
    options.challenge = base64ToArrayBuffer(options.challenge);
    
    // Convert allowed credentials if they exist
    if (options.allowCredentials) {
      options.allowCredentials = options.allowCredentials.map((credential: any) => {
        return {
          ...credential,
          id: base64ToArrayBuffer(credential.id),
        };
      });
    }
    
    // Get credential with device biometrics
    const credential = await navigator.credentials.get({
      publicKey: options
    }) as PublicKeyCredential;
    
    // Get assertion response
    const assertionResponse = credential.response as AuthenticatorAssertionResponse;
    
    // Prepare data for server
    const assertionData = {
      id: credential.id,
      rawId: arrayBufferToBase64(credential.rawId),
      response: {
        clientDataJSON: arrayBufferToBase64(assertionResponse.clientDataJSON),
        authenticatorData: arrayBufferToBase64(assertionResponse.authenticatorData),
        signature: arrayBufferToBase64(assertionResponse.signature),
        userHandle: assertionResponse.userHandle 
          ? arrayBufferToBase64(assertionResponse.userHandle) 
          : null,
      },
      type: credential.type,
    };
    
    // Build headers for verification with auth token if available
    const verificationHeaders: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    
    if (authToken) {
      verificationHeaders['Authorization'] = `Bearer ${authToken}`;
    }
    
    console.log("Sending WebAuthn login verification request with headers:", verificationHeaders);
    
    // Send to server for verification
    const verificationResponse = await fetch('/api/webauthn/login-verification', {
      method: 'POST',
      headers: verificationHeaders,
      body: JSON.stringify(assertionData),
      credentials: 'include', // Include session cookies
    });
    
    if (!verificationResponse.ok) {
      const error = await verificationResponse.text();
      throw new Error(`Server verification error: ${error}`);
    }
    
    const { username } = await verificationResponse.json();
    
    return {
      credentialId: credential.id,
      username
    };
    
  } catch (error) {
    console.error('Error during authentication:', error);
    throw error;
  }
}

/**
 * Remove a biometric credential
 */
export async function removeCredential(credentialId: string): Promise<boolean> {
  try {
    // Get auth token from localStorage if available for header-based auth
    const authToken = localStorage.getItem('fortis_auth_token');
    
    // Build headers with content type and auth token if available
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    
    if (authToken) {
      headers['Authorization'] = `Bearer ${authToken}`;
    }
    
    console.log("Sending WebAuthn credential removal request with headers:", headers);
    
    const response = await fetch('/api/webauthn/remove-credential', {
      method: 'POST',
      headers,
      body: JSON.stringify({ credentialId }),
      credentials: 'include', // Include session cookies
    });
    
    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Server error: ${error}`);
    }
    
    return true;
  } catch (error) {
    console.error('Error removing credential:', error);
    throw error;
  }
}