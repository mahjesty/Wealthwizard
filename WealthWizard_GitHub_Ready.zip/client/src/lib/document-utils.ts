import { apiRequest } from "./queryClient";
import { getDeviceInfo } from "./utils";

interface DocumentAccessLogParams {
  accessId?: string;
  documentType: string;
  documentPath: string;
  entityType: string;
  entityId: number;
  accessedBy?: number;
  isAdminAccess?: boolean;
  browserInfo?: string;
  accessMethod?: string;
  accessReason?: string;
  sessionId?: string;
  encryptionStatus?: string;
  purpose?: string;
  additionalInfo?: string;
}

/**
 * Log document access for security and compliance
 * 
 * @param params Document access parameters
 * @returns Promise with the logging response
 */
export async function logDocumentAccess(params: DocumentAccessLogParams): Promise<{ 
  success: boolean; 
  logId?: number; 
  accessId?: string; 
  message?: string; 
  error?: string;
}> {
  try {
    // Get browser information if not provided
    const browserInfo = params.browserInfo || navigator.userAgent;
    
    // Generate accessId if not provided (using UUID v4 pattern)
    const accessId = params.accessId || crypto.randomUUID();
    
    // Create payload with required fields
    const payload = {
      ...params,
      accessId,
      browserInfo,
      additionalInfo: params.additionalInfo || JSON.stringify({
        method: "GET",
        referrer: document.referrer || null,
        deviceInfo: getDeviceInfo(),
        timestamp: new Date().toISOString()
      })
    };

    // Call the API endpoint
    const response = await apiRequest("POST", "/api/documents/access-log", payload);
    const data = await response.json();
    
    if (response.ok) {
      console.log(`Document access logged successfully: ${accessId}`);
      return {
        success: true,
        logId: data.logId,
        accessId: data.accessId,
        message: data.message
      };
    } else {
      console.error("Error logging document access:", data);
      return {
        success: false,
        message: data.message,
        error: data.errorCode || "UNKNOWN_ERROR"
      };
    }
  } catch (error) {
    console.error("Document access logging failed:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error occurred"
    };
  }
}

/**
 * Create a secure URL for document access with tracking parameters
 * 
 * @param documentPath Base path to the document
 * @param entityType Type of entity (user, application, account)
 * @param entityId ID of the entity
 * @param options Additional options for the URL
 * @returns Secure document URL with tracking parameters
 */
export function createSecureDocumentUrl(
  documentPath: string,
  entityType: string,
  entityId: number,
  options?: {
    accessId?: string;
    isAdmin?: boolean;
    purpose?: string;
    encryptionStatus?: string;
  }
): string {
  // Generate access ID for tracking
  const accessId = options?.accessId || crypto.randomUUID();
  
  // Create URL with tracking parameters
  const url = new URL(documentPath, window.location.origin);
  
  // Add tracking parameters
  url.searchParams.append("accessId", accessId);
  url.searchParams.append("entityType", entityType);
  url.searchParams.append("entityId", entityId.toString());
  
  // Add optional parameters if provided
  if (options?.isAdmin) {
    url.searchParams.append("admin", "true");
  }
  
  if (options?.purpose) {
    url.searchParams.append("purpose", options.purpose);
  }
  
  if (options?.encryptionStatus) {
    url.searchParams.append("encryption", options.encryptionStatus);
  }
  
  return url.toString();
}

/**
 * Track document view event with automatic logging
 * 
 * @param documentInfo Document information for tracking
 * @returns Promise that resolves when tracking is complete
 */
export async function trackDocumentView(documentInfo: {
  documentPath: string;
  documentType: string;
  entityType: string;
  entityId: number;
  purpose?: string;
  accessReason?: string;
  isAdminAccess?: boolean;
}): Promise<void> {
  try {
    // First create a unique access ID
    const accessId = crypto.randomUUID();
    
    // Log the access
    await logDocumentAccess({
      accessId,
      documentPath: documentInfo.documentPath,
      documentType: documentInfo.documentType,
      entityType: documentInfo.entityType,
      entityId: documentInfo.entityId,
      accessMethod: "view",
      purpose: documentInfo.purpose || "Viewing",
      accessReason: documentInfo.accessReason,
      isAdminAccess: documentInfo.isAdminAccess
    });
    
    // Could also send analytics event here in a real application
    
  } catch (error) {
    console.error("Error tracking document view:", error);
    // Don't throw errors from tracking functions to avoid disrupting the user experience
  }
}

/**
 * Generate a URL for accessing KYC verification documents with proper tracking
 * This implementation is deprecated, use the enhanced version below
 * (keeping this as a reference for now)
 * 
 * @param verificationId ID of the KYC verification
 * @param documentType Type of document (id-front, id-back, selfie, etc.)
 * @param isAdmin Whether the request is coming from an admin
 * @returns URL string for accessing the document
 */
function getKycDocumentUrlLegacy(
  verificationId: number,
  documentType: string,
  isAdmin: boolean = false
): string {
  const basePath = `/api/documents/kyc/${verificationId}/${documentType}`;
  return createSecureDocumentUrl(
    basePath,
    'kyc',
    verificationId,
    {
      isAdmin,
      purpose: 'Verification',
      encryptionStatus: 'encrypted'
    }
  );
}

/**
 * Download a document and automatically log the access
 * 
 * @param url Document URL
 * @param documentInfo Document metadata for logging
 * @returns Promise that resolves when the download is complete
 */
export async function downloadDocument(
  url: string,
  documentInfo: {
    documentType: string;
    entityType: string;
    entityId: number;
    purpose?: string;
  }
): Promise<void> {
  try {
    // Generate tracking ID for this download
    const accessId = crypto.randomUUID();
    
    // Log the document access first
    await logDocumentAccess({
      accessId,
      documentPath: url,
      documentType: documentInfo.documentType,
      entityType: documentInfo.entityType,
      entityId: documentInfo.entityId,
      accessMethod: 'download',
      purpose: documentInfo.purpose || 'Downloading',
    });
    
    // Create a URL with the access tracking ID
    const downloadUrl = new URL(url, window.location.origin);
    downloadUrl.searchParams.append('accessId', accessId);
    downloadUrl.searchParams.append('download', 'true');
    
    // Start the download
    window.open(downloadUrl.toString(), '_blank');
    
  } catch (error) {
    console.error('Error downloading document:', error);
    // Don't block the UI with errors
  }
}

/**
 * Fetch document metadata from the server
 * 
 * @param documentId Document identifier
 * @param entityType Type of entity (user, application, account, kyc)
 * @param entityId ID of the related entity
 * @returns Promise resolving to document metadata
 */
export async function getDocumentMetadata(
  documentId: string,
  entityType: string = 'document',
  entityId: number = 0
): Promise<{
  accessId: string;
  documentType: string;
  fileName: string;
  fileSize: number;
  uploadDate: Date;
  mimeType: string;
  securityLevel: string;
  isEncrypted: boolean;
  lastViewed?: Date;
  viewCount?: number;
  metadata?: Record<string, any>;
}> {
  try {
    // Create a request URL with proper tracking
    const url = new URL(`/api/documents/metadata/${documentId}`, window.location.origin);
    url.searchParams.append('docType', documentId);
    
    if (entityType) url.searchParams.append('entityType', entityType);
    if (entityId) url.searchParams.append('entityId', entityId.toString());
    
    // Generate a tracking ID for this metadata request
    const accessId = crypto.randomUUID();
    url.searchParams.append('accessId', accessId);
    
    // Log the access attempt (even before we get the data)
    await logDocumentAccess({
      accessId,
      documentPath: `/api/documents/metadata/${documentId}`,
      documentType: documentId,
      entityType,
      entityId,
      accessMethod: 'metadata',
      purpose: 'Retrieving metadata',
    });
    
    // Fetch metadata
    const response = await fetch(url.toString());
    
    if (!response.ok) {
      throw new Error(`Failed to get document metadata: ${response.status} ${response.statusText}`);
    }
    
    const data = await response.json();
    
    // Return the structured metadata
    return {
      accessId: data.accessId || accessId,
      documentType: data.documentType || documentId,
      fileName: data.fileName || `${documentId}.pdf`,
      fileSize: data.fileSize || 0,
      uploadDate: new Date(data.uploadDate || Date.now()),
      mimeType: data.mimeType || 'application/pdf',
      securityLevel: data.securityLevel || 'standard',
      isEncrypted: data.securityDetails?.isEncrypted || false,
      lastViewed: data.lastViewed ? new Date(data.lastViewed) : undefined,
      viewCount: data.viewCount,
      metadata: data.metadata || {}
    };
  } catch (error) {
    console.error('Error fetching document metadata:', error);
    
    // Return default metadata with error state
    return {
      accessId: crypto.randomUUID(),
      documentType: documentId,
      fileName: `${documentId}.pdf`,
      fileSize: 0,
      uploadDate: new Date(),
      mimeType: 'application/pdf',
      securityLevel: 'unknown',
      isEncrypted: true
    };
  }
}

/**
 * Generate a URL for accessing an application document with proper tracking
 * 
 * @param applicationId ID of the application
 * @param documentType Type of document (application-form, id-verification, etc.)
 * @param isAdmin Whether the request is coming from an admin
 * @returns URL string for accessing the document
 */
export function getApplicationDocumentUrl(
  applicationId: number,
  documentType: string = 'application-form',
  isAdmin: boolean = false
): string {
  // Create a URL with the proper path and parameters
  const url = new URL(`/api/documents/application/${applicationId}/${documentType}`, window.location.origin);
  
  // Add tracking and security parameters
  url.searchParams.append('accessId', crypto.randomUUID());
  url.searchParams.append('entityType', 'application');
  url.searchParams.append('entityId', applicationId.toString());
  
  // Add timestamp for cache busting and audit trail
  url.searchParams.append('timestamp', Date.now().toString());
  
  // Add admin flag if applicable (will be checked against server-side session)
  if (isAdmin) {
    url.searchParams.append('admin', 'true');
  }
  
  // Add purpose for compliance logging
  url.searchParams.append('purpose', isAdmin ? 'admin_review' : 'applicant_viewing');
  
  return url.toString();
}

/**
 * Generate a URL for accessing a KYC verification document with proper tracking
 * 
 * @param verificationId ID of the KYC verification
 * @param documentType Type of document (id-front, id-back, selfie, etc.)
 * @param isAdmin Whether the request is coming from an admin
 * @returns URL string for accessing the document
 */
export function getKycDocumentUrl(
  verificationId: number,
  documentType: string = 'id-front',
  isAdmin: boolean = false
): string {
  // Create a URL with the proper path and parameters
  const url = new URL(`/api/documents/kyc/${verificationId}/${documentType}`, window.location.origin);
  
  // Add tracking and security parameters
  url.searchParams.append('accessId', crypto.randomUUID());
  url.searchParams.append('entityType', 'kyc');
  url.searchParams.append('entityId', verificationId.toString());
  
  // Add timestamp for cache busting and audit trail
  url.searchParams.append('timestamp', Date.now().toString());
  
  // Add admin flag if applicable (will be checked against server-side session)
  if (isAdmin) {
    url.searchParams.append('admin', 'true');
  }
  
  // Add purpose for compliance logging
  url.searchParams.append('purpose', isAdmin ? 'kyc_verification' : 'user_verification');
  
  return url.toString();
}