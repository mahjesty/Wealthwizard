import { QueryClient, QueryFunction } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    
    // If authentication failed, clear the token and trigger automatic logout
    if (res.status === 401) {
      // Remove auth token to prevent further authenticated requests
      localStorage.removeItem('fortis_auth_token');
      
      // We'll let the calling function handle this error appropriately
      // For API calls, we'll throw normally
      // For queries, we'll handle based on the unauthorized behavior option
    }
    
    throw new Error(`${res.status}: ${text}`);
  }
}

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
): Promise<Response> {
  try {
    // Determine which token to use based on the URL
    // For admin endpoints, use the admin token; otherwise, use the user token
    const isAdminEndpoint = url.startsWith('/api/admin');
    const authToken = isAdminEndpoint 
      ? localStorage.getItem('fortis_admin_token')
      : localStorage.getItem('fortis_auth_token');
    
    // Prepare headers with cache control
    const headers: Record<string, string> = {
      'Cache-Control': 'no-cache',
      'Pragma': 'no-cache'
    };
    
    // Add Content-Type header if we have data
    if (data) {
      headers['Content-Type'] = 'application/json';
    }
    
    // Add Authorization header if we have a token
    if (authToken) {
      headers['Authorization'] = `Bearer ${authToken}`;
    }
    
    console.log(`API Request to ${url} with ${isAdminEndpoint ? 'admin' : 'user'} auth`);
    
    const res = await fetch(url, {
      method,
      headers,
      body: data ? JSON.stringify(data) : undefined,
      credentials: "include",
      cache: "no-cache", // Prevent caching issues with authentication
    });

    // Special handling for 401 errors
    if (res.status === 401) {
      // Always clear invalid token
      localStorage.removeItem('fortis_auth_token');
      
      // For logout requests, consider 401 as success and return the response
      if (method === 'POST' && url === '/api/auth/logout') {
        return res;
      }
      
      // Trigger auth expiration event for global handling
      const event = new CustomEvent('auth:token_expired', {
        detail: { reason: 'token_expired', url }
      });
      window.dispatchEvent(event);
      
      // Otherwise, throw an error 
      const errorText = await res.text();
      throw new Error(`Authentication required: ${errorText || res.statusText}`);
    }
    
    // For other errors, process normally
    await throwIfResNotOk(res);
    return res;
  } catch (error) {
    // Log non-auth errors for debugging
    if (!(error instanceof Error) || !error.message.includes('Authentication required')) {
      console.error(`API error (${method} ${url}):`, error);
    }
    throw error;
  }
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    try {
      const url = queryKey[0] as string;
      
      // Determine which token to use based on the URL
      // For admin endpoints, use the admin token; otherwise, use the user token
      const isAdminEndpoint = url.startsWith('/api/admin');
      const authToken = isAdminEndpoint 
        ? localStorage.getItem('fortis_admin_token')
        : localStorage.getItem('fortis_auth_token');
      
      // Prepare headers with cache control
      const headers: Record<string, string> = {
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache'
      };
      
      // Add Authorization header if we have a token
      if (authToken) {
        headers['Authorization'] = `Bearer ${authToken}`;
        console.log(`Query to ${url} with ${isAdminEndpoint ? 'admin' : 'user'} auth token`);
      }
      
      const res = await fetch(url, {
        credentials: "include",
        cache: "no-cache", // Prevent caching issues with authentication
        headers
      });
  
      // Handle 401 Unauthorized errors specially
      if (res.status === 401) {
        // Clear the appropriate token based on the URL
        if (isAdminEndpoint) {
          console.log("Admin authentication failure, clearing admin token");
          localStorage.removeItem('fortis_admin_token');
          
          // Trigger admin auth expiration event (except for admin auth endpoints)
          if (!url.includes('/api/admin/me') && unauthorizedBehavior !== "returnNull") {
            const event = new CustomEvent('admin:token_expired', {
              detail: { reason: 'token_expired', url }
            });
            window.dispatchEvent(event);
          }
        } else {
          console.log("User authentication failure, clearing user token");
          localStorage.removeItem('fortis_auth_token');
          
          // Trigger user auth expiration event (except for auth endpoints)
          if (!url.includes('/api/auth/me') && unauthorizedBehavior !== "returnNull") {
            const event = new CustomEvent('auth:token_expired', {
              detail: { reason: 'token_expired', url }
            });
            window.dispatchEvent(event);
          }
        }
        
        // Either return null (for auth checks) or throw (for protected resources)
        if (unauthorizedBehavior === "returnNull") {
          return null;
        } else {
          const errorText = await res.text();
          throw new Error(`Authentication required: ${errorText || res.statusText}`);
        }
      }
  
      // For other errors, throw normally
      await throwIfResNotOk(res);
      
      // Parse and return JSON response
      return await res.json();
    } catch (error) {
      // Log the error for debugging but rethrow it
      console.error(`Query error for ${queryKey[0]}:`, error);
      throw error;
    }
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
