import { createContext, useContext, useEffect, ReactNode, useState } from "react";
import { useLocation } from "wouter";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest, getQueryFn } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";

interface User {
  id: number;
  username: string;
  firstName: string;
  lastName: string;
  email: string;
  role: string;
  isVerified: boolean;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  isAdmin: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  register: (userData: any) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [hasInitialized, setHasInitialized] = useState(false);
  
  // Initialize auth state by adding auth token to axios headers if it exists
  useEffect(() => {
    const initializeAuth = async () => {
      const authToken = localStorage.getItem('fortis_auth_token');
      
      if (authToken) {
        // Force a refresh of auth status with the token
        try {
          await queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
          const result = await queryClient.fetchQuery<User | null>({ 
            queryKey: ["/api/auth/me"],
            retry: false
          }).catch(error => {
            console.log("Auth token validation failed, removing token", error);
            localStorage.removeItem('fortis_auth_token');
            return null;
          });
          
          // If we didn't get a valid user back, clear the token
          if (!result) {
            localStorage.removeItem('fortis_auth_token');
          }
        } catch (error) {
          console.error("Error initializing auth state, removing token:", error);
          localStorage.removeItem('fortis_auth_token');
        }
      }
      setHasInitialized(true);
    };
    
    initializeAuth();
  }, [queryClient]);
  
  // Global listener for token expiration events
  useEffect(() => {
    const handleTokenExpired = (event: Event) => {
      console.log("Auth token expired, redirecting to login page");
      
      // Add a toast notification about session expiration
      toast({
        title: "Session Expired",
        description: "Your session has expired. Please log in again to continue.",
        variant: "destructive",
      });
      
      // Redirect to login page
      navigate("/auth");
    };
    
    // Add event listener for token expiration
    window.addEventListener('auth:token_expired', handleTokenExpired);
    
    // Clean up event listener on unmount
    return () => {
      window.removeEventListener('auth:token_expired', handleTokenExpired);
    };
  }, [navigate, toast]);
  
  const { 
    data: userData, 
    isLoading: isLoadingUser,
    error 
  } = useQuery<User | null>({
    queryKey: ["/api/auth/me"],
    // Custom query function to handle authentication errors gracefully
    queryFn: async ({ queryKey }) => {
      try {
        const authToken = localStorage.getItem('fortis_auth_token');
        const headers: Record<string, string> = {
          'Cache-Control': 'no-cache',
        };
        
        if (authToken) {
          headers['Authorization'] = `Bearer ${authToken}`;
        }
        
        const res = await fetch(queryKey[0] as string, {
          credentials: "include",
          headers
        });
        
        if (res.status === 401) {
          // Clear invalid token
          localStorage.removeItem('fortis_auth_token');
          // Return null instead of throwing for auth checks
          return null;
        }
        
        if (!res.ok) {
          throw new Error(`API error: ${res.status}`);
        }
        
        return await res.json();
      } catch (error) {
        console.error("Auth query error:", error);
        return null;
      }
    },
    retry: false,
    // Use more aggressive refetch settings for authentication
    refetchInterval: 60000,
    refetchOnWindowFocus: true,
    refetchIntervalInBackground: false
  });
  
  // TypeScript safety - ensure user is the correct type
  const user = userData as User | null;
  
  const isLoading = isLoadingUser || !hasInitialized;
  const isAuthenticated = !!user;
  const isAdmin = isAuthenticated && user?.role === "admin";
  
  // Login function
  const login = async (username: string, password: string) => {
    try {
      // Check if this is a WebAuthn/biometric login (empty password is the signal)
      const isBiometricLogin = password === '';
      
      let data;
      
      if (isBiometricLogin) {
        console.log("Handling biometric authentication login flow");
        
        // For biometric login, WebAuthn has already authenticated the user and set the session
        // We just need to fetch the current user data
        await queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
        const userData = await queryClient.fetchQuery<User>({ 
          queryKey: ["/api/auth/me"],
        });
        
        // Check if we got valid user data
        if (!userData || !userData.id) {
          throw new Error("Failed to get user information after biometric login");
        }
        
        data = { user: userData };
      } else {
        // Regular username/password login
        try {
          const response = await apiRequest("POST", "/api/auth/login", { username, password });
          data = await response.json();
          
          // Store auth token in localStorage for use in future requests
          if (data.token) {
            localStorage.setItem('fortis_auth_token', data.token);
          }
          
          // Refresh the user data
          await queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
          await queryClient.refetchQueries({ queryKey: ["/api/auth/me"] });
        } catch (loginError: any) {
          // Check if this is a login restriction error (403 with special fields)
          if (loginError.status === 403) {
            // Try to parse the response body for more details
            try {
              const errorBody = await loginError.json();
              
              if (errorBody?.restricted) {
                // This is a login restriction, handle it specially
                const errorWithDetails = new Error("Account access restricted");
                // Add custom properties to the error
                (errorWithDetails as any).restricted = true;
                (errorWithDetails as any).restrictionReason = errorBody.restrictionReason;
                throw errorWithDetails;
              }
            } catch (parseError) {
              // If we can't parse the JSON, just use the original error
              console.error("Error parsing login error response:", parseError);
            }
          }
          
          // If not a special case, rethrow the original error
          throw loginError;
        }
      }
      
      // Navigate to dashboard - use direct location change for more reliable navigation
      setTimeout(() => {
        console.log("Redirecting to dashboard after successful login");
        window.location.href = "/dashboard";
      }, 500); // Longer delay to ensure state updates and session is fully established
      
      // Show success toast with user's name
      toast({
        title: "Login successful",
        description: `Welcome back, ${data.user.firstName}!`,
      });
      
      // Also refresh other initial data the user might need
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions/recent"] });
      
      return data;
    } catch (error: any) {
      // Handle different types of errors differently
      if (error.restricted) {
        // Let the login form handle the display of the restriction modal
        // Don't show toast notification as it would be redundant with the modal
      } else {
        // Generic login error
        toast({
          title: "Authentication Failed",
          description: error.message || "Invalid credentials. Please verify your username and password.",
          variant: "destructive",
          duration: 5000, // 5 seconds instead of the default 3
        });
      }
      throw error;
    }
  };
  
  // Logout function
  const logout = async () => {
    try {
      // First remove the token to prevent any further authenticated requests
      localStorage.removeItem('fortis_auth_token');
      
      // Clear authorization header for all future requests
      try {
        // Make the logout request to clear server-side session
        await apiRequest("POST", "/api/auth/logout");
      } catch (error) {
        console.error("Error during logout API call:", error);
        // Continue with client-side logout even if server call fails
      }
      
      // Reset client state completely by resetting the query cache
      queryClient.setQueryData(["/api/auth/me"], null);
      queryClient.removeQueries();
      queryClient.clear();
      
      // Show success message
      toast({
        title: "Logged out",
        description: "You have been successfully logged out.",
      });
      
      // Hard refresh to completely reload the app and show the auth page
      // This is the most reliable way to ensure a clean slate
      window.location.replace('/auth');
    } catch (error: any) {
      console.error("Logout error:", error);
      
      // Make sure token is definitely removed even in case of any error
      localStorage.removeItem('fortis_auth_token');
      
      // Still reset client state
      queryClient.setQueryData(["/api/auth/me"], null);
      queryClient.removeQueries();
      queryClient.clear();
      
      toast({
        title: "Logged out",
        description: "You have been logged out.",
      });
      
      // Hard refresh to completely reload the app and show the auth page
      window.location.replace('/auth');
    }
  };
  
  // Register function
  const register = async (userData: any) => {
    try {
      // Display a processing message
      toast({
        title: "Processing Registration",
        description: "Your information is being verified. Please wait...",
      });
      
      // Submit the registration request
      const response = await apiRequest("POST", "/api/auth/register", userData);
      const data = await response.json();
      
      // Clear any existing auth state to ensure a clean login
      localStorage.removeItem('fortis_auth_token');
      queryClient.setQueryData(["/api/auth/me"], null);
      
      console.log("Starting 10-second verification process...");
      
      // Silent 10-second processing period with no visible timer
      await new Promise(resolve => setTimeout(resolve, 10000));
      
      console.log("Verification process complete, redirecting...");
      
      // Redirect to verification page
      navigate('/verification');
      
      toast({
        title: "Registration Complete",
        description: "Your account has been verified and is now ready for use.",
      });
      
      return data;
    } catch (error: any) {
      toast({
        title: "Registration Failed",
        description: error.message || "We couldn't process your registration. Please try again.",
        variant: "destructive",
      });
      throw error;
    }
  };
  
  // Redirect to login if not authenticated on protected routes
  useEffect(() => {
    const currentPath = window.location.pathname;
    // Updated auth paths list - make sure it includes all possible auth-related pages
    const authPaths = ['/login', '/register', '/two-factor', '/auth', '/forgot-password', '/reset-password', '/verification'];
    const legalPaths = ['/legal/terms-conditions', '/legal/privacy-policy'];
    
    // Allow access to auth, verification, and legal pages without authentication
    const isPublicPage = authPaths.some(path => currentPath.startsWith(path) || path === currentPath) ||
                         legalPaths.some(path => currentPath.startsWith(path) || path === currentPath);
    const isAuthPage = authPaths.some(path => currentPath.startsWith(path) || path === currentPath);
    
    if (!isLoading) {
      // If not authenticated and not on a public page, redirect to login
      if (!isAuthenticated && !isPublicPage) {
        console.log("Not authenticated, redirecting to auth page");
        navigate("/auth");
        return;
      }
      
      // If authenticated and on an auth page (but not verification), redirect to dashboard
      if (isAuthenticated && isAuthPage && !currentPath.startsWith('/verification')) {
        console.log("Already authenticated, redirecting to dashboard");
        navigate("/dashboard");
        return;
      }
      
      // If trying to access admin pages without admin role
      if (isAuthenticated && currentPath.startsWith('/admin') && !isAdmin) {
        console.log("Access denied - not an admin");
        navigate("/dashboard");
        toast({
          title: "Access denied",
          description: "You do not have permission to access this area.",
          variant: "destructive",
        });
        return;
      }
    }
  }, [isLoading, isAuthenticated, isAdmin, navigate, toast]);
  
  // Ensure we always provide the correct type (User | null) to satisfy TypeScript
  const safeUser: User | null = user || null;
  
  return (
    <AuthContext.Provider
      value={{
        user: safeUser,
        isLoading,
        isAuthenticated,
        isAdmin,
        login,
        logout,
        register,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
