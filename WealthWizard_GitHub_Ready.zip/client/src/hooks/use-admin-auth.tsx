import { createContext, useContext, useEffect, ReactNode, useState } from "react";
import { useLocation } from "wouter";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest, getQueryFn } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface AdminUser {
  id: number;
  username: string;
  firstName: string;
  lastName: string;
  email: string;
  role: string;
}

interface AdminAuthContextType {
  adminUser: AdminUser | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  clearAdminSession: () => void;
}

const AdminAuthContext = createContext<AdminAuthContextType | undefined>(undefined);

export function AdminAuthProvider({ children }: { children: ReactNode }) {
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [hasInitialized, setHasInitialized] = useState(false);
  
  // Get admin user data
  const { 
    data: adminUser = null,
    isLoading,
    refetch,
  } = useQuery<AdminUser | null>({
    queryKey: ['/api/admin/me'],
    queryFn: getQueryFn({ on401: "returnNull" }),
    enabled: hasInitialized,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const isAuthenticated = !!adminUser;
  
  // Initialize admin auth state
  useEffect(() => {
    const initializeAuth = async () => {
      const adminAuthToken = localStorage.getItem('fortis_admin_token');
      
      if (adminAuthToken) {
        try {
          // Verify token validity by making a request
          const response = await apiRequest('GET', '/api/admin/me');
          
          if (response.status === 401) {
            // If token is invalid, remove it
            console.log("Invalid admin token found, removing");
            localStorage.removeItem('fortis_admin_token');
          }
        } catch (error) {
          console.error("Error initializing admin auth state, removing token:", error);
          localStorage.removeItem('fortis_admin_token');
        }
      }
      setHasInitialized(true);
    };
    
    initializeAuth();
  }, []);

  // Admin login function
  const login = async (username: string, password: string) => {
    try {
      // First completely clear any existing user auth to prevent conflicts
      localStorage.removeItem('fortis_auth_token');
      
      const response = await apiRequest('POST', '/api/admin/login', { username, password });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Login failed');
      }
      
      const data = await response.json();
      console.log("Admin login successful, data received:", Object.keys(data));
      
      // Store admin token
      if (data.token) {
        localStorage.setItem('fortis_admin_token', data.token);
      }
      
      // First set the admin user data directly
      if (data.user) {
        queryClient.setQueryData(['/api/admin/me'], data.user);
      }
      
      // Then refetch to ensure full synchronization
      await refetch();
      
      // Show success message
      toast({
        title: "Admin Login Successful",
        description: "Welcome to the Fortis Admin Portal",
      });
      
      // Force the navigation to the admin dashboard using window.location
      // to ensure a complete refresh and avoid any stale state issues
      window.location.href = '/admin';
      
    } catch (error: any) {
      toast({
        title: "Admin Login Failed",
        description: error.message || "Invalid administrator credentials",
        variant: "destructive",
      });
      throw error;
    }
  };

  // Admin logout function
  const logout = async () => {
    try {
      await apiRequest('POST', '/api/admin/logout');
    } catch (error) {
      console.error("Error during admin logout:", error);
    } finally {
      // Clear the admin token from local storage
      localStorage.removeItem('fortis_admin_token');
      
      // Reset admin user data in the query cache
      queryClient.setQueryData(['/api/admin/me'], null);
      queryClient.invalidateQueries({ queryKey: ['/api/admin/me'] });
      
      toast({
        title: "Admin Logout Successful",
        description: "You have been logged out of the admin portal",
      });
      
      // Force navigation to login page with a complete page refresh
      window.location.href = '/admin/login';
    }
  };
  
  // Public method to clear admin sessions specifically for switching to user interface
  const clearAdminSession = () => {
    localStorage.removeItem('fortis_admin_token');
    queryClient.setQueryData(['/api/admin/me'], null);
    queryClient.invalidateQueries({ queryKey: ['/api/admin/me'] });
    console.log("Admin session cleared for user login");
  };

  return (
    <AdminAuthContext.Provider
      value={{
        adminUser,
        isLoading,
        isAuthenticated,
        login,
        logout,
        clearAdminSession,
      }}
    >
      {children}
    </AdminAuthContext.Provider>
  );
}

export function useAdminAuth() {
  const context = useContext(AdminAuthContext);
  
  if (context === undefined) {
    throw new Error("useAdminAuth must be used within an AdminAuthProvider");
  }
  
  return context;
}