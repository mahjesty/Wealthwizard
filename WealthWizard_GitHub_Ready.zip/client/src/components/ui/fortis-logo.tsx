import React from 'react';

interface FortisLogoProps {
  className?: string;
  width?: number;
  height?: number;
  showText?: boolean;
}

export function FortisLogo({ className, width = 48, height = 48, showText = false }: FortisLogoProps) {
  return (
    <svg 
      width={showText ? width * 4 : width} 
      height={height}
      viewBox={showText ? "0 0 200 50" : "0 0 50 50"}
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Gradient background for logo */}
      <defs>
        <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#0A4DA6" />
          <stop offset="100%" stopColor="#0F7DD1" />
        </linearGradient>
        <filter id="shadow" x="-5%" y="-5%" width="110%" height="120%">
          <feDropShadow dx="0" dy="2" stdDeviation="1" floodOpacity="0.3"/>
        </filter>
      </defs>
      
      {/* Main shield shape */}
      <path d="M25 5L45 15V30C45 37.1797 33.9844 44 25 44C16.0156 44 5 37.1797 5 30V15L25 5Z" fill="url(#logoGradient)" filter="url(#shadow)"/>
      
      {/* Inner decorative elements */}
      <path d="M25 9L39 16.5V28.5C39 33.8564 30.5234 39 25 39C19.4766 39 11 33.8564 11 28.5V16.5L25 9Z" fill="#0D5EB9" opacity="0.7"/>
      <path d="M25 13L35 18.5V27.5C35 31.6423 28.7112 35.5 25 35.5C21.2888 35.5 15 31.6423 15 27.5V18.5L25 13Z" fill="#0F7DD1" opacity="0.9"/>
      
      {/* Capital F letter in the shield */}
      <path d="M21 19H29V22H25V25H28V28H25V33H21V19Z" fill="white"/>
      
      {showText && (
        <>
          {/* Text "FORTIS CAPITAL" */}
          <text x="55" y="23" fontFamily="Arial, sans-serif" fontWeight="700" fontSize="16" fill="#0D5EB9">FORTIS</text>
          <text x="55" y="38" fontFamily="Arial, sans-serif" fontWeight="500" fontSize="14" fill="#444444">CAPITAL</text>
          
          {/* Decorative dots at the bottom */}
          <circle cx="132" cy="30" r="1.5" fill="#0D5EB9"/>
          <circle cx="137" cy="30" r="1.5" fill="#0D5EB9"/>
          <circle cx="142" cy="30" r="1.5" fill="#0D5EB9"/>
          
          {/* Decorative line */}
          <line x1="55" y1="25" x2="120" y2="25" stroke="#DDDDDD" strokeWidth="1"/>
        </>
      )}
    </svg>
  );
}