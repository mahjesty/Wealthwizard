import { ReactNode } from "react";

interface QuickActionProps {
  icon: ReactNode;
  label: string;
  bgColor: string;
  iconColor: string;
  onClick: () => void;
}

export default function QuickAction({
  icon,
  label,
  bgColor,
  iconColor,
  onClick,
}: QuickActionProps) {
  return (
    <button
      className="flex flex-col items-center justify-center p-4 bg-white dark:bg-neutral-800 rounded-lg shadow-sm hover:shadow transition duration-150"
      onClick={onClick}
    >
      <div
        className={`w-10 h-10 rounded-full ${bgColor} flex items-center justify-center mb-2`}
      >
        <span className={iconColor}>{icon}</span>
      </div>
      <span className="text-sm font-medium text-neutral-800 dark:text-neutral-200">
        {label}
      </span>
    </button>
  );
}
