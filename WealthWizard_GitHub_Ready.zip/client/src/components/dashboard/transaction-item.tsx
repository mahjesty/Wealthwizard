import { 
  ShoppingBag, 
  AttachMoney, 
  ElectricBolt, 
  LocalCafe, 
  Movie, 
  Payment,
  SwapHoriz,
  Home,
  DirectionsCar,
  LocalHospital,
  School,
  FlightTakeoff,
  Info,
  AccountBalance,
  ArrowUpward,
  ArrowDownward,
  CheckCircleOutline
} from "@mui/icons-material";
import { cn, formatCurrency, formatDate } from "@/lib/utils";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";

interface TransactionItemProps {
  id: number;
  type: string;
  amount: string;
  description: string;
  merchantName: string;
  category: string;
  date: string;
  status?: string;
  onClick?: () => void;
}

export default function TransactionItem({
  id,
  type,
  amount,
  description,
  merchantName,
  category,
  date,
  status = "completed",
  onClick,
}: TransactionItemProps) {
  const getTypeDetails = () => {
    switch(type) {
      case "deposit":
        return {
          icon: <ArrowDownward className="text-green-600 dark:text-green-400" />,
          bgColor: "bg-green-100 dark:bg-green-900",
          textColor: "text-green-600 dark:text-green-400",
          prefix: "+",
          label: "Deposit"
        };
      case "withdrawal":
        return {
          icon: <ArrowUpward className="text-amber-600 dark:text-amber-400" />,
          bgColor: "bg-amber-100 dark:bg-amber-900",
          textColor: "text-amber-600 dark:text-amber-400",
          prefix: "-",
          label: "Withdrawal"
        };
      case "transfer":
        return {
          icon: <SwapHoriz className="text-blue-600 dark:text-blue-400" />,
          bgColor: "bg-blue-100 dark:bg-blue-900",
          textColor: "text-blue-600 dark:text-blue-400",
          prefix: "-",
          label: "Transfer"
        };
      case "payment":
        return {
          icon: <Payment className="text-red-600 dark:text-red-400" />,
          bgColor: "bg-red-100 dark:bg-red-900",
          textColor: "text-red-600 dark:text-red-400",
          prefix: "-",
          label: "Payment"
        };
      case "purchase":
        return {
          icon: getCategoryIcon(),
          bgColor: getCategoryBgColor(),
          textColor: getCategoryTextColor(),
          prefix: "-",
          label: "Purchase"
        };
      case "refund":
        return {
          icon: <CheckCircleOutline className="text-green-600 dark:text-green-400" />,
          bgColor: "bg-green-100 dark:bg-green-900",
          textColor: "text-green-600 dark:text-green-400",
          prefix: "+",
          label: "Refund"
        };
      case "interest":
        return {
          icon: <AttachMoney className="text-blue-600 dark:text-blue-400" />,
          bgColor: "bg-blue-100 dark:bg-blue-900",
          textColor: "text-blue-600 dark:text-blue-400",
          prefix: "+",
          label: "Interest"
        };
      default:
        return {
          icon: <AccountBalance className="text-neutral-600 dark:text-neutral-400" />,
          bgColor: "bg-neutral-100 dark:bg-neutral-800",
          textColor: "text-neutral-600 dark:text-neutral-400",
          prefix: type.includes("deposit") || type.includes("refund") ? "+" : "-",
          label: "Transaction"
        };
    }
  };
  
  const getCategoryIcon = () => {
    switch(category.toLowerCase()) {
      case "groceries":
        return <ShoppingBag className="text-blue-600 dark:text-blue-400" />;
      case "utilities":
        return <ElectricBolt className="text-purple-600 dark:text-purple-400" />;
      case "dining":
      case "restaurants":
        return <LocalCafe className="text-amber-600 dark:text-amber-400" />;
      case "entertainment":
        return <Movie className="text-red-600 dark:text-red-400" />;
      case "housing":
      case "mortgage":
      case "rent":
        return <Home className="text-indigo-600 dark:text-indigo-400" />;
      case "transportation":
      case "auto":
        return <DirectionsCar className="text-emerald-600 dark:text-emerald-400" />;
      case "healthcare":
      case "medical":
        return <LocalHospital className="text-pink-600 dark:text-pink-400" />;
      case "education":
        return <School className="text-orange-600 dark:text-orange-400" />;
      case "travel":
        return <FlightTakeoff className="text-cyan-600 dark:text-cyan-400" />;
      default:
        return <Payment className="text-neutral-600 dark:text-neutral-400" />;
    }
  };
  
  const getCategoryBgColor = () => {
    switch(category.toLowerCase()) {
      case "groceries":
        return "bg-blue-100 dark:bg-blue-900";
      case "utilities":
        return "bg-purple-100 dark:bg-purple-900";
      case "dining":
      case "restaurants":
        return "bg-amber-100 dark:bg-amber-900";
      case "entertainment":
        return "bg-red-100 dark:bg-red-900";
      case "housing":
      case "mortgage":
      case "rent":
        return "bg-indigo-100 dark:bg-indigo-900";
      case "transportation":
      case "auto":
        return "bg-emerald-100 dark:bg-emerald-900";
      case "healthcare":
      case "medical":
        return "bg-pink-100 dark:bg-pink-900";
      case "education":
        return "bg-orange-100 dark:bg-orange-900";
      case "travel":
        return "bg-cyan-100 dark:bg-cyan-900";
      default:
        return "bg-neutral-100 dark:bg-neutral-800";
    }
  };
  
  const getCategoryTextColor = () => {
    switch(category.toLowerCase()) {
      case "groceries":
        return "text-blue-600 dark:text-blue-400";
      case "utilities":
        return "text-purple-600 dark:text-purple-400";
      case "dining":
      case "restaurants":
        return "text-amber-600 dark:text-amber-400";
      case "entertainment":
        return "text-red-600 dark:text-red-400";
      case "housing":
      case "mortgage":
      case "rent":
        return "text-indigo-600 dark:text-indigo-400";
      case "transportation":
      case "auto":
        return "text-emerald-600 dark:text-emerald-400";
      case "healthcare":
      case "medical":
        return "text-pink-600 dark:text-pink-400";
      case "education":
        return "text-orange-600 dark:text-orange-400";
      case "travel":
        return "text-cyan-600 dark:text-cyan-400";
      default:
        return "text-neutral-600 dark:text-neutral-400";
    }
  };
  
  const typeDetails = getTypeDetails();
  const formattedDate = formatDate(date);
  const formattedAmount = formatCurrency(amount);
  const formattedCategory = category ? category.charAt(0).toUpperCase() + category.slice(1) : '';
  
  // Format the description to be more readable
  const getFormattedDescription = () => {
    if (!description) return '';
    
    // If it's very long, truncate it
    if (description.length > 50) {
      return description.substring(0, 50) + '...';
    }
    return description;
  };
  
  // Get the status badge based on transaction status
  const getStatusBadge = () => {
    switch (status) {
      case "completed":
        return (
          <Badge className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 hover:bg-green-100 dark:hover:bg-green-900 ml-2 text-xs">
            Completed
          </Badge>
        );
      case "pending":
        return (
          <Badge className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 hover:bg-yellow-100 dark:hover:bg-yellow-900 ml-2 text-xs">
            Pending
          </Badge>
        );
      case "processing":
        return (
          <Badge className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 hover:bg-blue-100 dark:hover:bg-blue-900 ml-2 text-xs">
            Processing
          </Badge>
        );
      case "cancelled":
        return (
          <Badge className="bg-neutral-100 dark:bg-neutral-700 text-neutral-800 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-700 ml-2 text-xs">
            Cancelled
          </Badge>
        );
      case "failed":
        return (
          <Badge className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 hover:bg-red-100 dark:hover:bg-red-900 ml-2 text-xs">
            Failed
          </Badge>
        );
      default:
        return null;
    }
  };
  
  return (
    <div 
      className="flex items-center justify-between p-3 border border-transparent hover:border-neutral-200 dark:hover:border-neutral-700 rounded-lg cursor-pointer hover:bg-neutral-50 dark:hover:bg-neutral-800/50 transition-all shadow-sm hover:shadow"
      onClick={onClick}
    >
      <div className="flex items-center">
        <div className={`w-10 h-10 rounded-full ${typeDetails.bgColor} flex items-center justify-center mr-3 shrink-0`}>
          {typeDetails.icon}
        </div>
        <div>
          <div className="flex items-center">
            <h4 className="font-medium text-neutral-900 dark:text-white">{merchantName}</h4>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Info className="w-3.5 h-3.5 ml-1.5 text-neutral-400 cursor-help" />
                </TooltipTrigger>
                <TooltipContent className="max-w-xs">
                  <p>{description || "No additional details available"}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <Badge variant="outline" className="ml-2 text-xs py-0 px-1.5 h-5 bg-neutral-100 dark:bg-neutral-800 border-neutral-200 dark:border-neutral-700">
              {typeDetails.label}
            </Badge>
            {getStatusBadge()}
          </div>
          <div className="flex items-center text-sm text-neutral-500 dark:text-neutral-400">
            <span>{formattedDate}</span>
            {formattedCategory && (
              <>
                <span className="mx-1.5">•</span>
                <span className={getCategoryTextColor()}>{formattedCategory}</span>
              </>
            )}
          </div>
        </div>
      </div>
      <div className="text-right">
        <span className={cn(
          "font-medium text-lg",
          typeDetails.prefix === "+" ? "text-green-600 dark:text-green-400" : "text-neutral-900 dark:text-white"
        )}>
          {typeDetails.prefix}{formattedAmount}
        </span>
        {getFormattedDescription() && (
          <div className="text-xs text-neutral-500 dark:text-neutral-400 mt-1 max-w-[150px] truncate">
            {getFormattedDescription()}
          </div>
        )}
      </div>
    </div>
  );
}
