import { useState } from "react";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";
import { formatCurrency } from "@/lib/utils";

interface SpendingCategory {
  name: string;
  amount: number;
  color: string;
}

interface SpendingChartProps {
  data: SpendingCategory[];
}

const DEFAULT_DATA: SpendingCategory[] = [
  { name: "Groceries", amount: 548.20, color: "#3B82F6" },
  { name: "Utilities", amount: 328.75, color: "#8B5CF6" },
  { name: "Dining Out", amount: 289.32, color: "#22C55E" },
  { name: "Shopping", amount: 184.59, color: "#F59E0B" },
  { name: "Subscriptions", amount: 104.90, color: "#EF4444" }
];

export default function SpendingChart({ data = DEFAULT_DATA }: Partial<SpendingChartProps>) {
  const [selectedPeriod, setSelectedPeriod] = useState("This Month");
  const [activeIndex, setActiveIndex] = useState<number | undefined>(undefined);

  const handleMouseEnter = (_: any, index: number) => {
    setActiveIndex(index);
  };

  const handleMouseLeave = () => {
    setActiveIndex(undefined);
  };

  const total = data.reduce((sum, item) => sum + item.amount, 0);

  const renderTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white dark:bg-neutral-800 p-2 rounded shadow text-sm">
          <p className="font-semibold">{data.name}</p>
          <p className="text-neutral-600 dark:text-neutral-400">{formatCurrency(data.amount)}</p>
          <p className="text-neutral-500 dark:text-neutral-500">
            {Math.round((data.amount / total) * 100)}% of total
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold text-neutral-900 dark:text-white">Spending Analysis</h2>
        <select 
          className="text-sm bg-transparent border-none text-neutral-600 dark:text-neutral-400 focus:ring-0"
          value={selectedPeriod}
          onChange={(e) => setSelectedPeriod(e.target.value)}
        >
          <option>This Month</option>
          <option>Last Month</option>
          <option>Last 3 Months</option>
        </select>
      </div>
      
      <div className="h-48 mb-6">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={40}
              outerRadius={80}
              paddingAngle={2}
              dataKey="amount"
              onMouseEnter={handleMouseEnter}
              onMouseLeave={handleMouseLeave}
            >
              {data.map((entry, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={entry.color} 
                  stroke={activeIndex === index ? '#fff' : 'transparent'}
                  strokeWidth={activeIndex === index ? 2 : 0}
                />
              ))}
            </Pie>
            <Tooltip content={renderTooltip} />
          </PieChart>
        </ResponsiveContainer>
      </div>
      
      <div className="space-y-3">
        {data.map((category, index) => (
          <div key={index} className="flex items-center justify-between">
            <div className="flex items-center">
              <div 
                className="w-3 h-3 rounded-full mr-2" 
                style={{ backgroundColor: category.color }}
              />
              <span className="text-sm text-neutral-700 dark:text-neutral-300">
                {category.name}
              </span>
            </div>
            <span className="text-sm font-medium text-neutral-900 dark:text-white">
              {formatCurrency(category.amount)}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
