import { Card } from "@/components/ui/card";
import { Link } from "wouter";
import { 
  AccountBalance, 
  Savings, 
  CreditCard as CreditCardIcon, 
  Payments, 
  AddCircleOutline, 
  MoreHoriz,
  ArrowForward,
  Lock,
  AttachMoney,
  BarChart
} from "@mui/icons-material";
import { cn, formatCurrency, formatCardNumber } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu, 
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator
} from "@/components/ui/dropdown-menu";


interface AccountCardProps {
  id: number;
  type: "checking" | "savings" | "credit_card";
  name: string;
  accountNumber: string;
  balance: string;
  availableBalance?: string;
}

export default function AccountCard({
  id,
  type,
  name,
  accountNumber,
  balance,
  availableBalance,
}: AccountCardProps) {

  
  // Calculate the percent of balance available for credit cards
  const getCreditUtilization = () => {
    if (type === "credit_card" && availableBalance) {
      const total = parseFloat(balance) + parseFloat(availableBalance);
      const used = parseFloat(balance);
      const percent = Math.round((used / total) * 100);
      return percent;
    }
    return null;
  };
  
  const creditUtilization = getCreditUtilization();

  const getIcon = () => {
    switch (type) {
      case "checking":
        return <AccountBalance className="text-primary w-6 h-6" />;
      case "savings":
        return <Savings className="text-primary w-6 h-6" />;
      case "credit_card":
        return <CreditCardIcon className="text-primary w-6 h-6" />;
      default:
        return <AccountBalance className="text-primary w-6 h-6" />;
    }
  };

  const getDisplayType = () => {
    switch (type) {
      case "checking":
        return "Checking Account";
      case "savings":
        return "Savings Account";
      case "credit_card":
        return "Credit Card";
      default:
        return "Account";
    }
  };

  const getBackgroundClass = () => {
    switch (type) {
      case "checking":
        return "bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/30 dark:to-indigo-900/30";
      case "savings":
        return "bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/30 dark:to-emerald-900/30";
      case "credit_card":
        return "bg-gradient-to-r from-purple-50 to-violet-50 dark:from-purple-900/30 dark:to-violet-900/30";
      default:
        return "bg-gradient-to-r from-neutral-50 to-neutral-100 dark:from-neutral-800/30 dark:to-neutral-700/30";
    }
  };

  const getBalanceLabel = () => {
    if (type === "credit_card") {
      return "Current Balance";
    }
    return "Available Balance";
  };

  const getSecondaryBalanceLabel = () => {
    if (type === "credit_card" && availableBalance) {
      return `Available Credit: ${formatCurrency(availableBalance)}`;
    } else if (type !== "credit_card" && availableBalance && availableBalance !== balance) {
      return `Pending: ${formatCurrency(parseFloat(balance) - parseFloat(availableBalance))}`;
    }
    return null;
  };

  const handleTransferClick = () => {
    // Navigate to the transfers page instead of opening the modal
    window.location.href = '/transfers';
  };

  return (
    <>
      <Card className={`account-card overflow-hidden shadow hover:shadow-md transition-shadow border-0 ${getBackgroundClass()}`}>
        <div className="px-6 pt-6 pb-4">
          <div className="flex justify-between items-start mb-4">
            <div>
              <div className="flex items-center mb-1">
                <span className="text-sm font-medium text-neutral-600 dark:text-neutral-400">
                  {getDisplayType()}
                </span>
                {type === "credit_card" && (
                  <Badge variant="outline" className="ml-2 bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300 border-0">
                    Secured
                  </Badge>
                )}
              </div>
              <h3 className="text-lg font-semibold text-neutral-900 dark:text-white">
                {name}
              </h3>
            </div>
            <div className={`p-2 rounded-full ${
              type === 'checking' ? 'bg-blue-100 dark:bg-blue-800/50' : 
              type === 'savings' ? 'bg-green-100 dark:bg-green-800/50' : 
              'bg-purple-100 dark:bg-purple-800/50'
            }`}>
              {getIcon()}
            </div>
          </div>
          
          <div className="mb-3">
            <div className="flex items-baseline">
              <span className="text-2xl font-bold text-neutral-900 dark:text-white">
                {formatCurrency(balance)}
              </span>
              <span className="ml-2 text-xs px-2 py-0.5 rounded bg-neutral-200 dark:bg-neutral-700 text-neutral-700 dark:text-neutral-300">
                {type === "credit_card" ? "Balance" : "Available"}
              </span>
            </div>
            {getSecondaryBalanceLabel() && (
              <p className="text-sm text-neutral-600 dark:text-neutral-400 mt-1">
                {getSecondaryBalanceLabel()}
              </p>
            )}
          </div>
          
          <div className="flex justify-between items-center">
            <div className="text-sm text-neutral-600 dark:text-neutral-400 flex items-center">
              <Lock className="w-3 h-3 mr-1" />
              <span className="text-xs bg-neutral-200 dark:bg-neutral-700 px-2 py-1 rounded">
                ••••{accountNumber}
              </span>
            </div>
            
            {type === "credit_card" && creditUtilization !== null && (
              <div className="text-xs">
                <span className={`${
                  creditUtilization > 75 ? 'text-red-600 dark:text-red-400' : 
                  creditUtilization > 30 ? 'text-amber-600 dark:text-amber-400' : 
                  'text-green-600 dark:text-green-400'
                }`}>
                  {creditUtilization}% Used
                </span>
              </div>
            )}
          </div>
        </div>
        
        <div className="px-6 py-3 bg-white/50 dark:bg-black/20 flex justify-between items-center">
          <Button variant="ghost" size="sm" asChild>
            <Link href={`/accounts/${id}`}>
              <span className="flex items-center text-sm">
                Transactions
                <ArrowForward className="w-3 h-3 ml-1" />
              </span>
            </Link>
          </Button>
          
          <div className="flex space-x-1">
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-8 w-8 rounded-full"
              onClick={handleTransferClick}
            >
              <Payments className="h-4 w-4" />
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-8 w-8 rounded-full"
                >
                  <MoreHoriz className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => window.location.href = `/accounts/${id}`}>
                  <BarChart className="mr-2 h-4 w-4" />
                  <span>Account Details</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleTransferClick}>
                  <Payments className="mr-2 h-4 w-4" />
                  <span>Transfer Money</span>
                </DropdownMenuItem>
                {type === "credit_card" && (
                  <DropdownMenuItem onClick={() => window.location.href = '/bills'}>
                    <AttachMoney className="mr-2 h-4 w-4" />
                    <span>Make Payment</span>
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <Lock className="mr-2 h-4 w-4" />
                  <span>Security Settings</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </Card>


    </>
  );
}
