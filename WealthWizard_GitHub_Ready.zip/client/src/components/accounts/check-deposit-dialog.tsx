import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription
} from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency } from "@/lib/utils";
import { CloudUpload, PhotoCamera } from "@mui/icons-material";

const checkDepositSchema = z.object({
  accountId: z.string().min(1, { message: "Account is required" }),
  amount: z.string()
    .min(1, { message: "Amount is required" })
    .refine(val => !isNaN(parseFloat(val)) && parseFloat(val) > 0, {
      message: "Amount must be a positive number"
    }),
  frontImage: z.any()
    .refine((file) => file !== null, {
      message: "Front image of check is required",
    }),
  backImage: z.any()
    .refine((file) => file !== null, {
      message: "Back image of check is required",
    }),
  memo: z.string().optional(),
  depositType: z.enum(["standard", "instant"]).default("standard"),
});

interface CheckDepositDialogProps {
  isOpen: boolean;
  onClose: () => void;
  accounts: any[];
}

export default function CheckDepositDialog({ isOpen, onClose, accounts = [] }: CheckDepositDialogProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [frontImagePreview, setFrontImagePreview] = useState<string | null>(null);
  const [backImagePreview, setBackImagePreview] = useState<string | null>(null);
  
  const form = useForm<z.infer<typeof checkDepositSchema>>({
    resolver: zodResolver(checkDepositSchema),
    defaultValues: {
      accountId: "",
      amount: "",
      frontImage: null,
      backImage: null,
      memo: "",
      depositType: "standard",
    }
  });
  
  const depositMutation = useMutation({
    mutationFn: (data: FormData) => {
      return apiRequest("POST", "/api/transactions/check-deposit", data, {
        headers: {
          // Don't set Content-Type as it will be set automatically with boundary for FormData
        }
      });
    },
    onSuccess: () => {
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions/recent"] });
      
      // Reset form and close dialog
      form.reset();
      setFrontImagePreview(null);
      setBackImagePreview(null);
      onClose();
      
      // Show success toast
      toast({
        title: "Check deposit submitted",
        description: "Your check has been submitted for processing.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Deposit failed",
        description: error.message || "There was an error processing your check deposit.",
        variant: "destructive",
      });
    }
  });
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, side: 'front' | 'back') => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      
      // Update form value
      if (side === 'front') {
        form.setValue('frontImage', file);
        // Create preview URL
        const previewUrl = URL.createObjectURL(file);
        setFrontImagePreview(previewUrl);
      } else {
        form.setValue('backImage', file);
        // Create preview URL
        const previewUrl = URL.createObjectURL(file);
        setBackImagePreview(previewUrl);
      }
    }
  };
  
  const onSubmit = (values: z.infer<typeof checkDepositSchema>) => {
    const formData = new FormData();
    formData.append('accountId', values.accountId);
    formData.append('amount', values.amount);
    formData.append('frontImage', values.frontImage);
    formData.append('backImage', values.backImage);
    if (values.memo) formData.append('memo', values.memo);
    formData.append('depositType', values.depositType);
    
    depositMutation.mutate(formData);
  };
  
  const handleClose = () => {
    form.reset();
    setFrontImagePreview(null);
    setBackImagePreview(null);
    onClose();
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[550px]">
        <DialogHeader>
          <DialogTitle className="text-xl">Deposit a Check</DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="accountId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Deposit to Account</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select account" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {accounts.map((account: any) => (
                        <SelectItem key={account.id} value={account.id.toString()}>
                          {account.accountName} (****{account.accountNumber}) - {formatCurrency(account.availableBalance)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Check Amount</FormLabel>
                  <FormControl>
                    <Input 
                      type="text" 
                      placeholder="0.00" 
                      {...field} 
                      prefix="$" 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="frontImage"
                render={({ field: { onChange, value, ...rest } }) => (
                  <FormItem>
                    <FormLabel>Front Image</FormLabel>
                    <FormControl>
                      <div className="flex flex-col items-center">
                        <div 
                          className={`w-full h-32 border-2 border-dashed rounded-md flex flex-col items-center justify-center cursor-pointer ${
                            frontImagePreview ? 'border-primary' : 'border-neutral-300 dark:border-neutral-700'
                          } transition-colors hover:border-primary`}
                          onClick={() => document.getElementById('front-image-input')?.click()}
                        >
                          {frontImagePreview ? (
                            <div className="h-full w-full relative">
                              <img 
                                src={frontImagePreview} 
                                alt="Front of check preview" 
                                className="h-full w-full object-contain"
                              />
                            </div>
                          ) : (
                            <>
                              <CloudUpload className="h-8 w-8 text-neutral-500 dark:text-neutral-400 mb-2" />
                              <p className="text-sm text-neutral-500 dark:text-neutral-400">
                                Upload front of check
                              </p>
                            </>
                          )}
                        </div>
                        <input
                          id="front-image-input"
                          type="file"
                          accept="image/*"
                          capture="environment"
                          onChange={(e) => handleFileChange(e, 'front')}
                          className="hidden"
                          {...rest}
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="backImage"
                render={({ field: { onChange, value, ...rest } }) => (
                  <FormItem>
                    <FormLabel>Back Image</FormLabel>
                    <FormControl>
                      <div className="flex flex-col items-center">
                        <div 
                          className={`w-full h-32 border-2 border-dashed rounded-md flex flex-col items-center justify-center cursor-pointer ${
                            backImagePreview ? 'border-primary' : 'border-neutral-300 dark:border-neutral-700'
                          } transition-colors hover:border-primary`}
                          onClick={() => document.getElementById('back-image-input')?.click()}
                        >
                          {backImagePreview ? (
                            <div className="h-full w-full relative">
                              <img 
                                src={backImagePreview} 
                                alt="Back of check preview" 
                                className="h-full w-full object-contain"
                              />
                            </div>
                          ) : (
                            <>
                              <CloudUpload className="h-8 w-8 text-neutral-500 dark:text-neutral-400 mb-2" />
                              <p className="text-sm text-neutral-500 dark:text-neutral-400">
                                Upload back of check
                              </p>
                            </>
                          )}
                        </div>
                        <input
                          id="back-image-input"
                          type="file"
                          accept="image/*"
                          capture="environment"
                          onChange={(e) => handleFileChange(e, 'back')}
                          className="hidden"
                          {...rest}
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="depositType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Deposit Type</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select deposit type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="standard">Standard (2-3 business days, free)</SelectItem>
                      <SelectItem value="instant">Instant (Available immediately, 1% fee)</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    Select how quickly you want access to your funds
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="memo"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Memo (Optional)</FormLabel>
                  <FormControl>
                    <Input 
                      type="text" 
                      placeholder="What's this check for?" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="flex justify-end space-x-2 pt-4">
              <Button 
                variant="outline" 
                type="button"
                onClick={handleClose}
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                disabled={depositMutation.isPending}
              >
                {depositMutation.isPending ? "Processing..." : "Deposit Check"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}