import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { formatDate, getInitials } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Switch } from "@/components/ui/switch";

interface UserItemProps {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  username: string;
  isActive: boolean;
  isVerified: boolean;
  createdAt: string;
}

export default function UserItem({
  id,
  firstName,
  lastName,
  email,
  username,
  isActive,
  isVerified,
  createdAt
}: UserItemProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const fullName = `${firstName} ${lastName}`;
  
  const toggleActiveMutation = useMutation({
    mutationFn: (data: { isActive: boolean }) => {
      return apiRequest("PATCH", `/api/admin/users/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({
        title: `User ${isActive ? 'deactivated' : 'activated'}`,
        description: `${fullName} has been ${isActive ? 'deactivated' : 'activated'}.`
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error updating user",
        description: error.message || "There was an error updating the user.",
        variant: "destructive"
      });
    }
  });
  
  const handleToggleActive = () => {
    toggleActiveMutation.mutate({ isActive: !isActive });
  };
  
  return (
    <div className="px-6 py-4 flex items-center">
      <Avatar className="w-10 h-10 mr-4">
        <AvatarImage src={`https://ui-avatars.com/api/?name=${firstName}+${lastName}&background=D71E2B&color=fff`} alt={fullName} />
        <AvatarFallback>{getInitials(fullName)}</AvatarFallback>
      </Avatar>
      <div className="flex-1 min-w-0">
        <h4 className="font-medium text-neutral-900 dark:text-white truncate">{fullName}</h4>
        <div className="flex flex-col sm:flex-row sm:items-center">
          <span className="text-sm text-neutral-500 dark:text-neutral-400 mr-2">
            Joined {formatDate(createdAt)}
          </span>
          <div className="flex items-center space-x-2 mt-1 sm:mt-0">
            <span className="text-xs text-neutral-500 dark:text-neutral-500">{email}</span>
            {isVerified && (
              <Badge variant="outline" className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-300 border-none">
                Verified
              </Badge>
            )}
          </div>
        </div>
      </div>
      <div className="flex items-center space-x-2">
        <span className="text-sm text-neutral-600 dark:text-neutral-400">
          {isActive ? 'Active' : 'Inactive'}
        </span>
        <Switch 
          checked={isActive}
          onCheckedChange={handleToggleActive}
          disabled={toggleActiveMutation.isPending}
        />
      </div>
    </div>
  );
}
