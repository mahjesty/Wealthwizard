import { useState, useEffect } from "react";
import { Link } from "wouter";
import { cn } from "@/lib/utils";
import { 
  BarChart, 
  Users, 
  ShieldCheck, 
  FileText, 
  Settings, 
  HelpCircle, 
  Home,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface AdminSidebarProps {
  currentPath: string;
  isOpen?: boolean;
}

export default function AdminSidebar({ currentPath, isOpen = true }: AdminSidebarProps) {
  const [collapsed, setCollapsed] = useState(!isOpen);
  const [mounted, setMounted] = useState(false);
  
  // Navigation items for the admin sidebar
  const navItems = [
    {
      title: "Dashboard",
      href: "/admin/dashboard",
      icon: <BarChart className="h-5 w-5" />,
    },
    {
      title: "Users",
      href: "/admin/users",
      icon: <Users className="h-5 w-5" />,
    },
    {
      title: "KYC Verification",
      href: "/admin/kyc",
      icon: <ShieldCheck className="h-5 w-5" />,
    },
    {
      title: "Transactions",
      href: "/admin/transactions",
      icon: <FileText className="h-5 w-5" />,
    },
    {
      title: "Site Settings",
      href: "/admin/settings",
      icon: <Settings className="h-5 w-5" />,
    },
    {
      title: "Support",
      href: "/admin/support",
      icon: <HelpCircle className="h-5 w-5" />,
    },
  ];
  
  // Set mounted to true after the component mounts
  useEffect(() => {
    setMounted(true);
  }, []);
  
  // If not mounted, return null to avoid hydration mismatch
  if (!mounted) return null;
  
  return (
    <div
      className={cn(
        "h-screen bg-white dark:bg-neutral-900 border-r border-neutral-200 dark:border-neutral-800 transition-all duration-300 overflow-hidden",
        collapsed ? "w-16" : "w-64"
      )}
    >
      <div className="flex flex-col h-full">
        {/* Sidebar Header */}
        <div className="h-16 flex items-center justify-between px-4 border-b border-neutral-200 dark:border-neutral-800">
          {!collapsed && (
            <div className="flex items-center">
              <svg
                className="h-8 w-8 text-primary"
                fill="none"
                height="24"
                stroke="currentColor"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                viewBox="0 0 24 24"
                width="24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path d="M12 2H2v10l9.29 9.29c.94.94 2.48.94 3.42 0l6.58-6.58c.94-.94.94-2.48 0-3.42L12 2Z" />
                <path d="M7 7h.01" />
              </svg>
              <span className="ml-2 text-xl font-bold text-neutral-900 dark:text-white">
                Admin
              </span>
            </div>
          )}
          
          <Button
            variant="ghost"
            size="icon"
            className="ml-auto"
            onClick={() => setCollapsed(!collapsed)}
            aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          >
            {collapsed ? <ChevronRight className="h-5 w-5" /> : <ChevronLeft className="h-5 w-5" />}
          </Button>
        </div>
        
        {/* Navigation Links */}
        <div className="py-4 flex-1 overflow-y-auto">
          <nav className="space-y-1 px-2">
            <Link href="/">
              <a className={cn(
                "flex items-center px-2 py-2 rounded-md text-sm font-medium",
                collapsed ? "justify-center" : "",
                currentPath === "/" 
                  ? "bg-primary-50 text-primary dark:bg-primary-900/10 dark:text-primary-400" 
                  : "text-neutral-700 hover:bg-neutral-100 dark:text-neutral-300 dark:hover:bg-neutral-800"
              )}>
                <Home className={cn("h-5 w-5", currentPath === "/" ? "text-primary" : "text-neutral-500")} />
                {!collapsed && <span className="ml-3">Customer Portal</span>}
              </a>
            </Link>
            
            {navItems.map((item) => (
              <Link key={item.href} href={item.href}>
                <a className={cn(
                  "flex items-center px-2 py-2 rounded-md text-sm font-medium",
                  collapsed ? "justify-center" : "",
                  currentPath === item.href 
                    ? "bg-primary-50 text-primary dark:bg-primary-900/10 dark:text-primary-400" 
                    : "text-neutral-700 hover:bg-neutral-100 dark:text-neutral-300 dark:hover:bg-neutral-800"
                )}>
                  <div className={cn(
                    "h-5 w-5", 
                    currentPath === item.href 
                      ? "text-primary" 
                      : "text-neutral-500 dark:text-neutral-400"
                  )}>
                    {item.icon}
                  </div>
                  {!collapsed && <span className="ml-3">{item.title}</span>}
                </a>
              </Link>
            ))}
          </nav>
        </div>
        
        {/* Sidebar Footer */}
        <div className="border-t border-neutral-200 dark:border-neutral-800 p-4">
          <div className={cn(
            "flex items-center", 
            collapsed ? "justify-center" : "px-2"
          )}>
            <div className="h-8 w-8 rounded-full bg-neutral-200 dark:bg-neutral-700 flex items-center justify-center">
              <Users className="h-4 w-4 text-neutral-600 dark:text-neutral-300" />
            </div>
            {!collapsed && (
              <div className="ml-2">
                <p className="text-sm font-medium text-neutral-900 dark:text-white">Admin User</p>
                <p className="text-xs text-neutral-500 dark:text-neutral-400">System Administrator</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}