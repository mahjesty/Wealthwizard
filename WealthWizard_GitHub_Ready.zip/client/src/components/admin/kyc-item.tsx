import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { MoreVert } from "@mui/icons-material";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { formatDate, getInitials } from "@/lib/utils";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

interface KycItemProps {
  id: number;
  userId: number;
  userName: string;
  submittedDate: string;
  idType: string;
  status: string;
}

export default function KycItem({
  id,
  userId,
  userName,
  submittedDate,
  idType,
  status
}: KycItemProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [notes, setNotes] = useState("");
  const [action, setAction] = useState<"approve" | "reject" | null>(null);

  // Separate mutations for approve and reject actions
  const approveMutation = useMutation({
    mutationFn: () => {
      return apiRequest("PATCH", `/api/admin/kyc-verifications/${id}/approve`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/kyc-verifications"] });
      toast({
        title: "KYC verification approved",
        description: `You have approved the KYC verification for ${userName}.`,
      });
      setIsDialogOpen(false);
      setNotes("");
      setAction(null);
    },
    onError: (error: any) => {
      toast({
        title: "Error approving verification",
        description: error.message || "There was an error approving the KYC verification.",
        variant: "destructive",
      });
    }
  });
  
  const rejectMutation = useMutation({
    mutationFn: (reason: string) => {
      return apiRequest("PATCH", `/api/admin/kyc-verifications/${id}/reject`, { rejectionReason: reason });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/kyc-verifications"] });
      toast({
        title: "KYC verification rejected",
        description: `You have rejected the KYC verification for ${userName}.`,
      });
      setIsDialogOpen(false);
      setNotes("");
      setAction(null);
    },
    onError: (error: any) => {
      toast({
        title: "Error rejecting verification",
        description: error.message || "There was an error rejecting the KYC verification.",
        variant: "destructive",
      });
    }
  });

  const handleApprove = () => {
    setAction("approve");
    setIsDialogOpen(true);
  };

  const handleReject = () => {
    setAction("reject");
    setIsDialogOpen(true);
  };

  const handleConfirm = () => {
    if (action === "approve") {
      approveMutation.mutate();
    } else if (action === "reject") {
      rejectMutation.mutate(notes || "KYC verification rejected by admin.");
    }
  };

  return (
    <>
      <div className="px-6 py-4 flex items-center">
        <Avatar className="w-10 h-10 mr-4">
          <AvatarImage src={`https://ui-avatars.com/api/?name=${userName.replace(" ", "+")}&background=D71E2B&color=fff`} alt={userName} />
          <AvatarFallback>{getInitials(userName)}</AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <h4 className="font-medium text-neutral-900 dark:text-white truncate">{userName}</h4>
          <span className="text-sm text-neutral-500 dark:text-neutral-400">
            Submitted {formatDate(submittedDate)} • {idType.replace("_", " ")}
          </span>
        </div>
        <div className="flex space-x-2">
          <Button 
            size="sm" 
            variant="success" 
            className="px-3 py-1 bg-green-100 dark:bg-green-900 text-green-600 dark:text-green-400 hover:bg-green-200 dark:hover:bg-green-800"
            onClick={handleApprove}
            disabled={status !== "pending" || approveMutation.isPending || rejectMutation.isPending}
          >
            Approve
          </Button>
          <Button 
            size="sm" 
            variant="destructive" 
            className="px-3 py-1 bg-red-100 dark:bg-red-900 text-red-600 dark:text-red-400 hover:bg-red-200 dark:hover:bg-red-800"
            onClick={handleReject}
            disabled={status !== "pending" || approveMutation.isPending || rejectMutation.isPending}
          >
            Reject
          </Button>
          <Button variant="ghost" size="icon" className="p-1 text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white">
            <MoreVert />
          </Button>
        </div>
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{action === "approve" ? "Approve" : "Reject"} KYC Verification</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="notes">Notes (Optional)</Label>
              <Textarea
                id="notes"
                placeholder="Add any notes about this decision..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
            <Button
              variant={action === "approve" ? "success" : "destructive"}
              onClick={handleConfirm}
              disabled={approveMutation.isPending || rejectMutation.isPending}
            >
              {(approveMutation.isPending || rejectMutation.isPending) ? "Processing..." : action === "approve" ? "Approve" : "Reject"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
