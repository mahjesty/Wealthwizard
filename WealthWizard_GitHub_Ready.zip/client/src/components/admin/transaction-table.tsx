import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatCurrency, formatDateTime, getInitials } from "@/lib/utils";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Check, Eye, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useMutation, useQueryClient } from "@tanstack/react-query";

interface TransactionTableUser {
  id: number;
  firstName: string;
  lastName: string;
}

interface TransactionData {
  id: number;
  referenceNumber: string;
  user: TransactionTableUser;
  type: string;
  amount: string;
  date: string;
  status: string;
  description: string;
  category: string;
  merchantName: string;
  accountId: number;
  toAccountId: number | null;
}

interface TransactionTableProps {
  transactions: TransactionData[];
  isLoading?: boolean;
}

export default function TransactionTable({ 
  transactions = [], 
  isLoading = false 
}: TransactionTableProps) {
  const [selectedTransaction, setSelectedTransaction] = useState<TransactionData | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Approve transaction mutation
  const approveMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest("POST", `/api/admin/transactions/${id}/approve`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/transactions"] });
      toast({
        title: "Transaction approved",
        description: "The transaction is now being processed.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Approval failed",
        description: error.message || "There was an error approving the transaction.",
        variant: "destructive",
      });
    }
  });
  
  // Cancel transaction mutation
  const cancelMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest("POST", `/api/admin/transactions/${id}/cancel`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/transactions"] });
      toast({
        title: "Transaction cancelled",
        description: "The transaction has been cancelled.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Cancellation failed",
        description: error.message || "There was an error cancelling the transaction.",
        variant: "destructive",
      });
    }
  });
  
  const handleApproveTransaction = (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    approveMutation.mutate(id);
  };
  
  const handleCancelTransaction = (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    cancelMutation.mutate(id);
  };
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return (
          <Badge className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 hover:bg-green-100 dark:hover:bg-green-900">
            Completed
          </Badge>
        );
      case "pending":
        return (
          <Badge className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 hover:bg-yellow-100 dark:hover:bg-yellow-900">
            Pending
          </Badge>
        );
      case "processing":
        return (
          <Badge className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 hover:bg-blue-100 dark:hover:bg-blue-900">
            Processing
          </Badge>
        );
      case "cancelled":
        return (
          <Badge className="bg-neutral-100 dark:bg-neutral-700 text-neutral-800 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-700">
            Cancelled
          </Badge>
        );
      case "failed":
        return (
          <Badge className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 hover:bg-red-100 dark:hover:bg-red-900">
            Failed
          </Badge>
        );
      default:
        return (
          <Badge variant="outline">
            {status}
          </Badge>
        );
    }
  };
  
  const handleViewTransaction = (transaction: TransactionData) => {
    setSelectedTransaction(transaction);
  };
  
  const closeDialog = () => {
    setSelectedTransaction(null);
  };
  
  if (isLoading) {
    return (
      <div className="w-full p-8 flex justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  return (
    <>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Transaction ID</TableHead>
              <TableHead>User</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {transactions.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8 text-neutral-500">
                  No transactions found
                </TableCell>
              </TableRow>
            ) : (
              transactions.map((transaction) => (
                <TableRow key={transaction.id}>
                  <TableCell className="font-medium">
                    {transaction.referenceNumber}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <Avatar className="h-8 w-8 mr-2">
                        <AvatarImage 
                          src={`https://ui-avatars.com/api/?name=${transaction.user.firstName}+${transaction.user.lastName}&background=D71E2B&color=fff`} 
                          alt={`${transaction.user.firstName} ${transaction.user.lastName}`} 
                        />
                        <AvatarFallback>{getInitials(`${transaction.user.firstName} ${transaction.user.lastName}`)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium">{`${transaction.user.firstName} ${transaction.user.lastName}`}</div>
                        <div className="text-xs text-neutral-500">ID: {transaction.user.id}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="capitalize">{transaction.type}</TableCell>
                  <TableCell className={transaction.type === "deposit" ? "text-green-600 dark:text-green-400" : ""}>
                    {transaction.type === "deposit" ? "+" : ""}{formatCurrency(transaction.amount)}
                  </TableCell>
                  <TableCell>{formatDateTime(transaction.date)}</TableCell>
                  <TableCell>{getStatusBadge(transaction.status)}</TableCell>
                  <TableCell className="text-right space-x-1">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-primary hover:text-primary/80"
                      onClick={() => handleViewTransaction(transaction)}
                    >
                      <Eye className="h-4 w-4 mr-1" />
                      View
                    </Button>
                    
                    {transaction.status === "pending" && (
                      <>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-green-600 hover:text-green-800 hover:bg-green-100"
                          onClick={(e) => handleApproveTransaction(transaction.id, e)}
                          disabled={approveMutation.isPending}
                        >
                          <Check className="h-4 w-4 mr-1" />
                          Approve
                        </Button>
                        
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-red-600 hover:text-red-800 hover:bg-red-100"
                          onClick={(e) => handleCancelTransaction(transaction.id, e)}
                          disabled={cancelMutation.isPending}
                        >
                          <X className="h-4 w-4 mr-1" />
                          Cancel
                        </Button>
                      </>
                    )}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
      
      {selectedTransaction && (
        <Dialog open={!!selectedTransaction} onOpenChange={closeDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Transaction Details</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Reference Number</h4>
                  <p>{selectedTransaction.referenceNumber}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Status</h4>
                  <p>{getStatusBadge(selectedTransaction.status)}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Amount</h4>
                  <p className={selectedTransaction.type === "deposit" ? "text-green-600 dark:text-green-400" : ""}>
                    {selectedTransaction.type === "deposit" ? "+" : ""}{formatCurrency(selectedTransaction.amount)}
                  </p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Date & Time</h4>
                  <p>{formatDateTime(selectedTransaction.date)}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Type</h4>
                  <p className="capitalize">{selectedTransaction.type}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Category</h4>
                  <p className="capitalize">{selectedTransaction.category}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Description</h4>
                  <p>{selectedTransaction.description || "N/A"}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Merchant</h4>
                  <p>{selectedTransaction.merchantName || "N/A"}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-neutral-500 dark:text-neutral-400">User</h4>
                  <p>{`${selectedTransaction.user.firstName} ${selectedTransaction.user.lastName}`}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Account ID</h4>
                  <p>{selectedTransaction.accountId}</p>
                </div>
                {selectedTransaction.toAccountId && (
                  <div>
                    <h4 className="text-sm font-medium text-neutral-500 dark:text-neutral-400">To Account ID</h4>
                    <p>{selectedTransaction.toAccountId}</p>
                  </div>
                )}
              </div>
              
              {selectedTransaction.status === "pending" && (
                <div className="flex justify-end space-x-2 pt-2 border-t">
                  <Button 
                    variant="outline" 
                    className="border-red-300 hover:bg-red-50 text-red-600"
                    onClick={(e) => handleCancelTransaction(selectedTransaction.id, e)}
                    disabled={cancelMutation.isPending}
                  >
                    <X className="h-4 w-4 mr-1" />
                    Cancel Transaction
                  </Button>
                  <Button 
                    className="bg-green-600 hover:bg-green-700 text-white"
                    onClick={(e) => handleApproveTransaction(selectedTransaction.id, e)}
                    disabled={approveMutation.isPending}
                  >
                    <Check className="h-4 w-4 mr-1" />
                    Approve Transaction
                  </Button>
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}
