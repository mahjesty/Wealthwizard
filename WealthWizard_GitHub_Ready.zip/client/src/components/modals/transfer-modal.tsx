import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { formatCurrency } from "@/lib/utils";

interface TransferModalProps {
  isOpen: boolean;
  onClose: () => void;
  fromAccountId?: number;
  fromAccountName?: string;
  fromAccountNumber?: string;
  fromAccountBalance?: string;
}

export default function TransferModal({
  isOpen,
  onClose,
  fromAccountId,
  fromAccountName,
  fromAccountNumber,
  fromAccountBalance
}: TransferModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const today = new Date().toISOString().split('T')[0];

  const [fromAccount, setFromAccount] = useState<string>(fromAccountId?.toString() || "");
  const [toAccount, setToAccount] = useState<string>("");
  const [amount, setAmount] = useState<string>("");
  const [date, setDate] = useState<string>(today);
  const [memo, setMemo] = useState<string>("");

  // Fetch accounts
  const { data: accounts = [] } = useQuery({
    queryKey: ["/api/accounts"],
    enabled: isOpen,
  });

  // Transfer mutation
  const transferMutation = useMutation({
    mutationFn: (data: any) => {
      return apiRequest("POST", "/api/transactions", data);
    },
    onSuccess: () => {
      // Invalidate accounts and transactions queries
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions/recent"] });
      
      // Show success toast
      toast({
        title: "Transfer successful",
        description: `$${amount} has been transferred successfully.`,
        variant: "default",
      });
      
      // Reset form and close modal
      resetForm();
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: "Transfer failed",
        description: error.message || "There was an error processing your transfer.",
        variant: "destructive",
      });
    }
  });

  const resetForm = () => {
    setFromAccount(fromAccountId?.toString() || "");
    setToAccount("");
    setAmount("");
    setDate(today);
    setMemo("");
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    if (!fromAccount || !toAccount || !amount || !date) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }
    
    // Validate amount
    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid amount.",
        variant: "destructive",
      });
      return;
    }
    
    // Ensure from and to accounts are different
    if (fromAccount === toAccount) {
      toast({
        title: "Invalid accounts",
        description: "From and To accounts cannot be the same.",
        variant: "destructive",
      });
      return;
    }
    
    // Process transfer
    transferMutation.mutate({
      accountId: parseInt(fromAccount),
      toAccountId: parseInt(toAccount),
      transactionType: "transfer",
      amount: parsedAmount.toString(),
      description: memo || "Transfer between accounts",
      category: "transfer",
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-neutral-900 dark:text-white">Transfer Money</DialogTitle>
          <DialogDescription className="text-neutral-600 dark:text-neutral-400">
            Move money between your accounts instantly.
          </DialogDescription>
        </DialogHeader>
        
        <form className="space-y-5" onSubmit={handleSubmit}>
          <div>
            <Label htmlFor="from-account">From Account</Label>
            <Select
              value={fromAccount}
              onValueChange={setFromAccount}
              disabled={!!fromAccountId}
            >
              <SelectTrigger id="from-account">
                <SelectValue placeholder="Select account" />
              </SelectTrigger>
              <SelectContent>
                {accounts.map((account: any) => (
                  <SelectItem key={account.id} value={account.id.toString()}>
                    {account.accountName} (****{account.accountNumber}) - {formatCurrency(account.availableBalance)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="to-account">To Account</Label>
            <Select
              value={toAccount}
              onValueChange={setToAccount}
            >
              <SelectTrigger id="to-account">
                <SelectValue placeholder="Select account" />
              </SelectTrigger>
              <SelectContent>
                {accounts
                  .filter((account: any) => account.id.toString() !== fromAccount)
                  .map((account: any) => (
                    <SelectItem key={account.id} value={account.id.toString()}>
                      {account.accountName} (****{account.accountNumber}) - {formatCurrency(account.availableBalance)}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="amount">Amount</Label>
            <Input
              id="amount"
              type="text"
              prefix="$"
              placeholder="0.00"
              pattern="[0-9]*\.?[0-9]+"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
            />
          </div>
          
          <div>
            <Label htmlFor="transfer-date">Date</Label>
            <Input
              id="transfer-date"
              type="date"
              value={date}
              min={today}
              onChange={(e) => setDate(e.target.value)}
              required
            />
          </div>
          
          <div>
            <Label htmlFor="memo">Memo (Optional)</Label>
            <Input
              id="memo"
              type="text"
              placeholder="What's this for?"
              value={memo}
              onChange={(e) => setMemo(e.target.value)}
            />
          </div>
          
          <div className="pt-2">
            <Button
              type="submit"
              className="w-full"
              disabled={transferMutation.isPending}
            >
              {transferMutation.isPending ? "Processing..." : "Transfer"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
