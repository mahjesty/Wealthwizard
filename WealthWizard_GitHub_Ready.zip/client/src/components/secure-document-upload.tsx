import { useState, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { 
  Upload, 
  FileUp, 
  Shield, 
  AlertCircle, 
  CheckCircle2, 
  X, 
  RefreshCcw,
  FileType
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { uploadDocument } from "@/lib/document-utils";

// Document types supported by the bank's document system
const DOCUMENT_TYPES = [
  { value: "id-front", label: "ID Card (Front)" },
  { value: "id-back", label: "ID Card (Back)" },
  { value: "passport", label: "Passport" },
  { value: "drivers-license-front", label: "Driver's License (Front)" },
  { value: "drivers-license-back", label: "Driver's License (Back)" },
  { value: "proof-of-address", label: "Proof of Address" },
  { value: "proof-of-income", label: "Proof of Income" },
  { value: "selfie", label: "Selfie with ID" },
  { value: "utility-bill", label: "Utility Bill" },
  { value: "bank-statement", label: "Bank Statement" },
  { value: "employment-verification", label: "Employment Verification" },
  { value: "tax-return", label: "Tax Return" }
];

interface SecureDocumentUploadProps {
  entityType: "user" | "application" | "account";
  entityId: number;
  acceptedFileTypes?: string;
  maxFileSizeMB?: number;
  allowedDocumentTypes?: string[];
  onUploadSuccess?: (documentId: string, fileName: string) => void;
  onUploadError?: (error: Error) => void;
}

const SecureDocumentUpload = ({
  entityType,
  entityId,
  acceptedFileTypes = ".jpg,.jpeg,.png,.pdf,.heic",
  maxFileSizeMB = 10,
  allowedDocumentTypes,
  onUploadSuccess,
  onUploadError
}: SecureDocumentUploadProps) => {
  const [documentType, setDocumentType] = useState<string>("");
  const [file, setFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  
  // Filter document types if allowedDocumentTypes is provided
  const filteredDocumentTypes = allowedDocumentTypes 
    ? DOCUMENT_TYPES.filter(dt => allowedDocumentTypes.includes(dt.value))
    : DOCUMENT_TYPES;
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUploadError(null);
    setUploadSuccess(false);
    
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;
    
    // Validate file size
    if (selectedFile.size > maxFileSizeMB * 1024 * 1024) {
      setUploadError(`File is too large. Maximum size is ${maxFileSizeMB}MB.`);
      return;
    }
    
    // Validate file type
    const fileExtension = selectedFile.name.split('.').pop()?.toLowerCase();
    if (!fileExtension || !acceptedFileTypes.includes(`.${fileExtension}`)) {
      setUploadError(`Invalid file type. Accepted types: ${acceptedFileTypes}`);
      return;
    }
    
    setFile(selectedFile);
  };
  
  const handleUpload = async () => {
    if (!file || !documentType) {
      setUploadError("Please select a file and document type");
      return;
    }
    
    try {
      setIsUploading(true);
      setUploadProgress(0);
      setUploadError(null);
      
      // Simulate upload progress for a secure banking system
      // In a real app, this would track actual upload progress
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          const newProgress = prev + Math.random() * 15;
          return newProgress >= 95 ? 95 : newProgress;
        });
      }, 300);
      
      // In a banking application, we would:
      // 1. Pre-scan the file client-side
      // 2. Encrypt the file before upload
      // 3. Send via secure channel
      // 4. Validate securely on server
      // 5. Record for compliance/audit
      
      // Upload the document using our secure document utility
      const result = await uploadDocument(
        file,
        documentType,
        entityType,
        entityId,
        {
          originalFileName: file.name,
          fileSize: file.size,
          uploadTimestamp: new Date().toISOString()
        }
      );
      
      clearInterval(progressInterval);
      setUploadProgress(100);
      setUploadSuccess(true);
      
      // Log success for compliance
      console.log(`[COMPLIANCE] Document uploaded successfully: ${documentType} for ${entityType} ID ${entityId}`);
      
      // Notify parent component of success
      if (onUploadSuccess) {
        onUploadSuccess(result.documentId, file.name);
      }
      
      toast({
        title: "Document Uploaded Successfully",
        description: "Your document has been securely uploaded and encrypted",
        variant: "default"
      });
      
      // Reset form after short delay
      setTimeout(() => {
        setFile(null);
        setUploadProgress(0);
        if (fileInputRef.current) {
          fileInputRef.current.value = "";
        }
      }, 2000);
      
    } catch (error) {
      setUploadProgress(0);
      setUploadError(error instanceof Error ? error.message : "Upload failed");
      
      // Notify parent component of error
      if (onUploadError && error instanceof Error) {
        onUploadError(error);
      }
      
      // Log error for security
      console.error(`[SECURITY] Document upload failed: ${error instanceof Error ? error.message : "Unknown error"}`);
    } finally {
      setIsUploading(false);
    }
  };
  
  const resetForm = () => {
    setFile(null);
    setDocumentType("");
    setUploadError(null);
    setUploadSuccess(false);
    setUploadProgress(0);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };
  
  return (
    <Card className="overflow-hidden">
      <CardContent className="p-4">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="document-type">Document Type</Label>
            <Select
              value={documentType}
              onValueChange={setDocumentType}
              disabled={isUploading}
            >
              <SelectTrigger id="document-type">
                <SelectValue placeholder="Select document type" />
              </SelectTrigger>
              <SelectContent>
                {filteredDocumentTypes.map(type => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="document-file">Upload Document</Label>
            <div className="border rounded-md p-4 flex flex-col items-center justify-center bg-muted/50">
              {!file ? (
                <>
                  <div className="mb-4">
                    <Upload className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">
                    Drag and drop your file here, or click to browse
                  </p>
                  <p className="text-xs text-muted-foreground mb-4">
                    Max file size: {maxFileSizeMB}MB • Accepted formats: {acceptedFileTypes.replace(/\./g, '')}
                  </p>
                  <Input
                    id="document-file"
                    type="file"
                    ref={fileInputRef}
                    className="hidden"
                    accept={acceptedFileTypes}
                    onChange={handleFileChange}
                    disabled={isUploading}
                  />
                  <Button
                    variant="outline"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isUploading}
                  >
                    <FileUp className="h-4 w-4 mr-2" />
                    Browse Files
                  </Button>
                </>
              ) : (
                <div className="w-full space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="p-2 bg-primary/10 rounded-md">
                        <FileType className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm font-medium truncate max-w-[200px]">
                          {file.name}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {(file.size / (1024 * 1024)).toFixed(2)}MB
                        </p>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={resetForm}
                      disabled={isUploading}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  {isUploading && (
                    <div className="space-y-2">
                      <div className="flex justify-between text-xs mb-1">
                        <span>Uploading securely...</span>
                        <span>{Math.round(uploadProgress)}%</span>
                      </div>
                      <Progress value={uploadProgress} />
                    </div>
                  )}
                </div>
              )}
            </div>
            
            <div className="flex items-center space-x-1 mt-1">
              <Shield className="h-3 w-3 text-primary" />
              <p className="text-xs text-muted-foreground">
                Your document will be encrypted with bank-grade security
              </p>
            </div>
          </div>
          
          {uploadError && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{uploadError}</AlertDescription>
            </Alert>
          )}
          
          {uploadSuccess && (
            <Alert variant="default" className="bg-green-50 text-green-800 border-green-200">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              <AlertTitle>Success</AlertTitle>
              <AlertDescription>Document uploaded successfully and securely stored.</AlertDescription>
            </Alert>
          )}
          
          <div className="flex justify-end space-x-2">
            <Button
              variant="outline"
              onClick={resetForm}
              disabled={isUploading || (!file && !documentType)}
            >
              <RefreshCcw className="h-4 w-4 mr-2" />
              Reset
            </Button>
            <Button
              onClick={handleUpload}
              disabled={isUploading || !file || !documentType || uploadSuccess}
            >
              {isUploading ? (
                <>
                  <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-t-transparent" />
                  Uploading...
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Document
                </>
              )}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default SecureDocumentUpload;