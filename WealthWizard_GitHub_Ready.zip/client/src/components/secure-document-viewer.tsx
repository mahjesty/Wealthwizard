import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, FileWarning, FileText, Image, Lock, Eye, RefreshCw, AlertTriangle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { getDocumentMetadata, downloadDocument } from "@/lib/document-utils";

interface SecureDocumentViewerProps {
  documentUrl?: string;
  documentId?: string;
  documentType: "id-front" | "id-back" | "passport" | "proof-of-address" | "selfie" | "income" | "application" | "statement" | "other";
  fileName: string;
  height?: string;
  metadata?: Record<string, any>;
  adminView?: boolean;
  onDownload?: () => void;
  placeholderText?: string;
}

const SecureDocumentViewer = ({
  documentUrl,
  documentId,
  documentType,
  fileName,
  height = "h-[400px]",
  metadata = {},
  adminView = false,
  onDownload,
  placeholderText
}: SecureDocumentViewerProps) => {
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [documentData, setDocumentData] = useState<{
    url?: string;
    metadata?: any;
  }>({});
  const { toast } = useToast();

  useEffect(() => {
    const loadDocument = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        // In a real banking application, this would:
        // 1. Request secure access token for this specific document
        // 2. Load document with proper decryption
        // 3. Record access for audit/compliance
        
        if (documentId) {
          // If we have a document ID, fetch its metadata first
          const metadata = await getDocumentMetadata(documentId);
          setDocumentData({ metadata });
        }
        
        // Set the document URL if provided directly
        if (documentUrl) {
          setDocumentData(prev => ({ ...prev, url: documentUrl }));
        }
        
        // Simulate document loading time for a secure banking system
        // In reality, this would be actual decryption and validation
        setTimeout(() => {
          setIsLoading(false);
        }, 1000);
        
        // Log access for compliance
        console.log(`[COMPLIANCE] Document viewed: ${documentId || documentUrl}`);
      } catch (error) {
        console.error("Failed to load document:", error);
        setError("Unable to load document securely. Please try again later.");
        setIsLoading(false);
      }
    };
    
    loadDocument();
  }, [documentId, documentUrl]);
  
  const handleRetry = () => {
    setIsLoading(true);
    setError(null);
    
    // Simulating retry with decryption reset
    setTimeout(() => {
      if (Math.random() > 0.2) { // 80% success rate on retry
        setIsLoading(false);
      } else {
        setError("Document decryption failed. Please contact administrator.");
        setIsLoading(false);
      }
    }, 1500);
  };
  
  const handleDownload = async () => {
    if (onDownload) {
      onDownload();
      return;
    }
    
    if (documentUrl) {
      await downloadDocument(documentUrl, fileName);
    } else {
      toast({
        title: "Download Failed",
        description: "Document URL is not available",
        variant: "destructive"
      });
    }
  };
  
  const renderPlaceholder = () => {
    switch (documentType) {
      case "id-front":
      case "id-back":
      case "passport":
      case "selfie":
        return <Image className="h-16 w-16 text-muted-foreground" />;
      case "proof-of-address":
      case "income":
      case "statement":
      case "application":
        return <FileText className="h-16 w-16 text-muted-foreground" />;
      default:
        return <FileText className="h-16 w-16 text-muted-foreground" />;
    }
  };
  
  // In a real banking application, this would be actual content from a secure document store
  const renderDocumentContent = () => {
    // Admin badge indicator
    const renderAdminBadge = adminView || metadata?.adminView ? (
      <Badge variant="secondary" className="absolute top-2 right-2 text-xs py-1 bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100">
        Admin View
      </Badge>
    ) : null;
    
    // Real ID or passport would show the actual uploaded image
    if (["id-front", "id-back", "passport", "selfie"].includes(documentType)) {
      return (
        <div className="flex items-center justify-center h-full bg-gray-100 dark:bg-gray-800 rounded-md relative">
          {renderAdminBadge}
          <div className="text-center p-4">
            <div className="flex flex-col items-center">
              <Image className="h-16 w-16 mb-4 text-gray-500" />
              <p className="text-sm text-gray-600 dark:text-gray-400">Secure ID Document</p>
              <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">{fileName}</p>
              <div className="mt-3 flex items-center space-x-1">
                <Lock className="h-3 w-3 text-green-600" />
                <span className="text-xs text-green-600">End-to-end encrypted</span>
              </div>
              {(adminView || metadata?.adminView) && (
                <div className="mt-2 pt-2 border-t border-dashed border-amber-200 dark:border-amber-800 w-full">
                  <p className="text-xs text-amber-600 dark:text-amber-400">Administrator privileged access</p>
                </div>
              )}
            </div>
          </div>
        </div>
      );
    }
    
    // For documents like proof of address, statements, etc.
    return (
      <div className="flex items-center justify-center h-full bg-gray-100 dark:bg-gray-800 rounded-md relative">
        {renderAdminBadge}
        <div className="text-center p-4">
          <div className="flex flex-col items-center">
            <FileText className="h-16 w-16 mb-4 text-gray-500" />
            <p className="text-sm text-gray-600 dark:text-gray-400">Secure Document</p>
            <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">{fileName}</p>
            <div className="mt-3 flex items-center space-x-1">
              <Lock className="h-3 w-3 text-green-600" />
              <span className="text-xs text-green-600">Bank-grade encryption</span>
            </div>
            <Badge className="mt-4 text-xs" variant="outline">
              {metadata?.documentType || documentType}
            </Badge>
            {(adminView || metadata?.adminView) && (
              <div className="mt-2 pt-2 border-t border-dashed border-amber-200 dark:border-amber-800 w-full">
                <p className="text-xs text-amber-600 dark:text-amber-400">Administrator privileged access</p>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };
  
  return (
    <Card className="overflow-hidden border">
      <CardContent className={`p-0 ${height} relative`}>
        {isLoading ? (
          <div className="absolute inset-0 flex items-center justify-center bg-background">
            <div className="flex flex-col items-center">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary mb-4"></div>
              <p className="text-sm text-muted-foreground">Securely loading document...</p>
              <div className="flex items-center mt-2 space-x-1">
                <Lock className="h-3 w-3 text-green-600" />
                <span className="text-xs text-green-600">End-to-end encrypted</span>
              </div>
            </div>
          </div>
        ) : error ? (
          <div className="absolute inset-0 flex items-center justify-center bg-background">
            <div className="flex flex-col items-center p-4 text-center">
              <FileWarning className="h-12 w-12 text-destructive mb-4" />
              <p className="text-sm text-destructive font-medium mb-2">Document Error</p>
              <p className="text-xs text-muted-foreground mb-4">{error}</p>
              <Button variant="outline" size="sm" onClick={handleRetry}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Retry
              </Button>
              <div className="mt-3 flex items-center space-x-1 text-amber-600">
                <AlertTriangle className="h-3 w-3" />
                <span className="text-xs">This will be recorded in the security log</span>
              </div>
            </div>
          </div>
        ) : (
          <>
            {renderDocumentContent()}
            
            <div className="absolute bottom-0 right-0 p-2 flex">
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-8 px-2" 
                onClick={handleDownload}
              >
                <Download className="h-4 w-4 mr-1" />
                <span className="text-xs">Download</span>
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-8 px-2" 
                onClick={() => {
                  // Log the document view attempt
                  console.log(`Attempting to view document: ${documentUrl}`);
                  
                  if (documentUrl) {
                    // Create a safe URL with proper authentication
                    let viewUrl = documentUrl;
                    
                    // Add admin token if this is admin view
                    if (adminView || metadata?.adminView) {
                      // Admin document viewing - use the admin path with proper token
                      const adminToken = localStorage.getItem('fortis_admin_token');
                      viewUrl = `${viewUrl}${viewUrl.includes('?') ? '&' : '?'}admin=true&adminToken=${adminToken}&t=${Date.now()}`;
                    } else {
                      // Regular user document viewing
                      const userToken = localStorage.getItem('fortis_auth_token');
                      viewUrl = `${viewUrl}${viewUrl.includes('?') ? '&' : '?'}auth=${userToken}&t=${Date.now()}`;
                    }
                    
                    console.log(`Opening document in new window: ${viewUrl}`);
                    
                    // Open in a new window with proper size
                    const newWindow = window.open(viewUrl, '_blank', 'width=800,height=600,toolbar=0,menubar=0');
                    
                    if (!newWindow || newWindow.closed || typeof newWindow.closed === 'undefined') {
                      toast({
                        title: "Popup Blocked",
                        description: "Please allow popups for document viewing",
                        variant: "destructive"
                      });
                    }
                  } else {
                    toast({
                      title: "View Failed",
                      description: "Document URL is not available",
                      variant: "destructive"
                    });
                  }
                }}
              >
                <Eye className="h-4 w-4 mr-1" />
                <span className="text-xs">View</span>
              </Button>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
};

export default SecureDocumentViewer;