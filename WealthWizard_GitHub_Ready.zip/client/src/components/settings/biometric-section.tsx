import { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/use-auth';
import { Card, CardContent } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Fingerprint, Smartphone, Check } from 'lucide-react';
import { BookOpen as BookOpenIcon } from 'lucide-react';
import { isWebAuthnSupported, isPlatformAuthenticatorAvailable, registerCredential } from '@/lib/webauthn';

interface WebAuthnCredential {
  id: number;
  credentialId: string;
  registeredAt: Date;
  lastUsed?: Date;
}

export function BiometricSection() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isSupported, setIsSupported] = useState<boolean | null>(null);
  const [isPlatformAvailable, setIsPlatformAvailable] = useState<boolean | null>(null);
  const [credentials, setCredentials] = useState<WebAuthnCredential[]>([]);
  const [isRegistering, setIsRegistering] = useState(false);

  // Check if biometrics are supported and get registered credentials
  useEffect(() => {
    const checkSupport = async () => {
      // Check WebAuthn support in browser
      const supported = isWebAuthnSupported();
      setIsSupported(supported);
      
      if (supported) {
        const platformAvailable = await isPlatformAuthenticatorAvailable();
        setIsPlatformAvailable(platformAvailable);
      }
      
      // Only fetch credentials if user is authenticated
      if (user && user.id) {
        // Load registered credentials from API
        fetchCredentials();
      }
    };
    
    checkSupport();
  }, [user]);
  
  const fetchCredentials = async () => {
    try {
      // Get auth token from localStorage if available for header-based auth
      const authToken = localStorage.getItem('fortis_auth_token');
      
      // Build headers with auth token if available
      const headers: Record<string, string> = {};
      
      if (authToken) {
        headers['Authorization'] = `Bearer ${authToken}`;
      }
      
      console.log("Fetching WebAuthn credentials with headers:", headers);
      
      const response = await fetch('/api/webauthn/credentials', {
        credentials: 'include', // Include session cookies
        headers
      });
      
      if (response.ok) {
        const data = await response.json();
        setCredentials(data);
      } else {
        const errorText = await response.text();
        console.error(`Failed to fetch credentials: Status ${response.status}, ${errorText}`);
      }
    } catch (error) {
      console.error('Error fetching credentials:', error);
    }
  };

  const handleRegisterDevice = async () => {
    if (!user || !user.username) {
      toast({
        title: "Registration Error",
        description: "You must be logged in to register a device",
        variant: "destructive"
      });
      return;
    }
    
    setIsRegistering(true);
    
    try {
      await registerCredential(user.username, user.id.toString());
      
      toast({
        title: "Registration Successful",
        description: "Your device has been registered for biometric authentication",
      });
      
      // Refresh credentials list
      await fetchCredentials();
      
    } catch (error) {
      console.error('Registration error:', error);
      
      toast({
        title: "Registration Failed",
        description: error instanceof Error ? error.message : "Failed to register your device. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsRegistering(false);
    }
  };

  const handleRemoveCredential = async (credentialId: string) => {
    try {
      // Get auth token from localStorage if available for header-based auth
      const authToken = localStorage.getItem('fortis_auth_token');
      
      // Build headers with auth token if available
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };
      
      if (authToken) {
        headers['Authorization'] = `Bearer ${authToken}`;
      }
      
      console.log("Sending WebAuthn credential removal request with headers:", headers);
      
      const response = await fetch('/api/webauthn/remove-credential', {
        method: 'POST',
        headers,
        body: JSON.stringify({ credentialId }),
        credentials: 'include', // Include session cookies
      });
      
      if (response.ok) {
        toast({
          title: "Device Removed",
          description: "Biometric login for this device has been disabled",
        });
        
        // Refresh the credentials list
        await fetchCredentials();
      } else {
        const error = await response.text();
        throw new Error(error);
      }
    } catch (error) {
      console.error('Error removing credential:', error);
      
      toast({
        title: "Removal Failed",
        description: error instanceof Error ? error.message : "Failed to remove the device",
        variant: "destructive"
      });
    }
  };

  const formatDate = (date: Date) => {
    if (!date) return 'Unknown';
    return new Date(date).toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (isSupported === null) {
    return <div className="flex justify-center p-6">Checking biometric capability...</div>;
  }

  return (
    <Card>
      <CardContent className="space-y-6 mt-6">
        {!isSupported ? (
          <Alert variant="destructive">
            <AlertTitle>Not Supported</AlertTitle>
            <AlertDescription>
              Your browser does not support WebAuthn for biometric authentication. Please try a modern browser like Chrome, Firefox, Safari, or Edge.
            </AlertDescription>
          </Alert>
        ) : !isPlatformAvailable ? (
          <Alert variant="destructive">
            <AlertTitle>No Hardware Support</AlertTitle>
            <AlertDescription>
              Your device doesn't have biometric sensors (fingerprint, face recognition, etc.) needed for secure biometric authentication.
            </AlertDescription>
          </Alert>
        ) : (
          <>
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-medium">Biometric Authentication</h3>
                <p className="text-sm text-neutral-600 dark:text-neutral-400 mt-1">
                  Register your device to login with fingerprint or face recognition
                </p>
              </div>
              <Button 
                onClick={handleRegisterDevice} 
                disabled={isRegistering}
                className="flex items-center gap-2"
              >
                <Fingerprint className="h-4 w-4" />
                <span>{isRegistering ? 'Registering...' : 'Register Device'}</span>
              </Button>
            </div>

            <Alert className="bg-blue-50 text-blue-800 dark:bg-blue-950 dark:text-blue-200 border-blue-200 dark:border-blue-800">
              <div className="flex items-start gap-3">
                <div className="mt-0.5">
                  <Fingerprint className="h-5 w-5 text-blue-800 dark:text-blue-200" />
                </div>
                <div>
                  <AlertTitle className="text-blue-800 dark:text-blue-200 mb-1">Supported Devices</AlertTitle>
                  <AlertDescription className="text-xs text-blue-700 dark:text-blue-300">
                    <ul className="list-disc list-inside space-y-1">
                      <li>Windows devices with Windows Hello</li>
                      <li>Apple devices with Touch ID or Face ID</li>
                      <li>Android devices with fingerprint or face recognition</li>
                      <li>Mobile phones with biometric authentication enabled</li>
                    </ul>
                  </AlertDescription>
                </div>
              </div>
            </Alert>

            <div className="space-y-4 border p-4 rounded-md border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800/50">
              <h4 className="text-sm font-semibold text-neutral-900 dark:text-white flex items-center gap-2">
                <BookOpenIcon className="h-4 w-4" />
                About Biometric Security
              </h4>
              <ul className="space-y-2 text-xs text-neutral-600 dark:text-neutral-400">
                <li className="flex gap-2">
                  <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                  <span>Your biometric data never leaves your device and is not stored by Fortis Capital</span>
                </li>
                <li className="flex gap-2">
                  <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                  <span>Biometric login is protected by FIDO2 standards, the same technology used by major banks worldwide</span>
                </li>
                <li className="flex gap-2">
                  <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                  <span>You can manage registered devices and revoke access at any time</span>
                </li>
              </ul>
            </div>

            <div className="pt-2">
              <h4 className="text-sm font-medium mb-3 text-neutral-900 dark:text-white">Registered Devices</h4>
              <div className="space-y-3">
                {credentials.length > 0 ? (
                  credentials.map((credential) => (
                    <div key={credential.id} className="flex items-center justify-between p-3 bg-neutral-50 dark:bg-neutral-800 rounded-md border border-neutral-200 dark:border-neutral-700">
                      <div className="flex items-center gap-3">
                        <div className="bg-green-100 dark:bg-green-900 p-2 rounded-full">
                          <Smartphone className="h-4 w-4 text-green-700 dark:text-green-300" />
                        </div>
                        <div>
                          <h4 className="text-sm font-medium text-neutral-900 dark:text-white">Device {credential.id}</h4>
                          <p className="text-xs text-neutral-600 dark:text-neutral-400">
                            Registered: {formatDate(credential.registeredAt)}
                          </p>
                          {credential.lastUsed && (
                            <p className="text-xs text-neutral-500 dark:text-neutral-500">
                              Last used: {formatDate(credential.lastUsed)}
                            </p>
                          )}
                        </div>
                      </div>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="text-red-500 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-950"
                        onClick={() => handleRemoveCredential(credential.credentialId)}
                      >
                        Remove
                      </Button>
                    </div>
                  ))
                ) : (
                  <div className="p-3 bg-neutral-50 dark:bg-neutral-800 rounded-md border border-neutral-200 dark:border-neutral-700 text-center">
                    <p className="text-sm text-neutral-600 dark:text-neutral-400">
                      No devices are currently registered for biometric login.
                    </p>
                    <p className="text-xs text-neutral-500 dark:text-neutral-500 mt-1">
                      Register your device to enable faster, more secure sign-in.
                    </p>
                  </div>
                )}
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}