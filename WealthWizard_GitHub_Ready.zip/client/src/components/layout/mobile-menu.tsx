import { Link } from "wouter";

interface MobileMenuProps {
  isOpen: boolean;
  navItems: { name: string; path: string }[];
  currentPath: string;
}

export default function MobileMenu({ isOpen, navItems, currentPath }: MobileMenuProps) {
  if (!isOpen) return null;

  return (
    <div className="md:hidden pb-3">
      <div className="space-y-1 px-2 pt-2 pb-3">
        {navItems.map((item) => (
          <Link key={item.path} href={item.path}>
            <span
              className={`block px-3 py-2 rounded-md text-base font-medium cursor-pointer ${
                currentPath === item.path
                  ? "text-neutral-900 dark:text-white bg-neutral-100 dark:bg-neutral-700"
                  : "text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-700"
              }`}
            >
              {item.name}
            </span>
          </Link>
        ))}
      </div>
    </div>
  );
}
