import { Link, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Menu, Notifications, DarkMode, LightMode } from "@mui/icons-material";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/lib/theme-provider";
import { queryClient, apiRequest } from "@/lib/queryClient";
import UserDropdown from "./user-dropdown";
import MobileMenu from "./mobile-menu";
import { useState, useEffect } from "react";
import { FortisLogo } from "@/components/ui/fortis-logo";
import { formatDateTime } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Check, Lock, ReceiptText, BellOff } from "lucide-react";

const navItems = [
  { name: "Dashboard", path: "/dashboard" },
  { name: "Accounts", path: "/accounts" },
  { name: "Transfers", path: "/transfers" },
  { name: "Bill Pay", path: "/bills" },
  { name: "Cards", path: "/cards" },
  { name: "Support", path: "/support" },
];

// Type for notification data
interface Notification {
  id: number;
  type: string;
  message: string;
  read: boolean;
  timestamp: string;
  actionUrl: string;
}

// Icon mapping based on notification type
const notificationIcons: Record<string, React.ReactNode> = {
  security: <Lock className="h-4 w-4" />,
  account: <ReceiptText className="h-4 w-4" />,
  transaction: <Check className="h-4 w-4" />,
};

export default function Header() {
  const [location] = useLocation();
  const { theme, setTheme } = useTheme();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  
  // Properly typed user data
  interface User {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
    role: string;
  }
  
  const { data: user } = useQuery<User | null>({
    queryKey: ["/api/auth/me"],
    retry: false,
  });

  // Fetch notifications
  const { data: notifications = [] } = useQuery<Notification[]>({
    queryKey: ["/api/notifications"],
    refetchOnWindowFocus: true,
    enabled: !!user,
  });

  // Count unread notifications
  const unreadCount = notifications.filter(n => !n.read).length;

  // Mark notification as read mutation
  const markAsReadMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("POST", `/api/notifications/${id}/read`);
      if (!response.ok) {
        throw new Error("Failed to mark notification as read");
      }
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
    }
  });

  const handleNotificationClick = (notification: Notification) => {
    if (!notification.read) {
      markAsReadMutation.mutate(notification.id);
    }
    
    // Navigate to the action URL
    window.location.href = notification.actionUrl;
    
    // Close the dropdown
    setShowNotifications(false);
  };

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  const toggleMobileMenu = () => {
    setMobileMenuOpen(prev => !prev);
  };

  if (!user) return null;

  return (
    <header className="bg-white dark:bg-neutral-800 border-b border-neutral-200 dark:border-neutral-700 sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center">
            <Link href="/dashboard" className="flex items-center">
              <FortisLogo width={42} height={42} showText={true} className="text-primary" />
            </Link>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-6">
            {navItems.map((item) => (
              <Link key={item.path} href={item.path}>
                <span className={`cursor-pointer ${
                  location === item.path
                    ? "text-neutral-900 dark:text-white font-medium"
                    : "text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white"
                }`}>
                  {item.name}
                </span>
              </Link>
            ))}
          </nav>
          
          {/* User Actions */}
          <div className="flex items-center space-x-4">
            {/* Notifications Dropdown */}
            <DropdownMenu open={showNotifications} onOpenChange={setShowNotifications}>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="relative">
                  <Notifications className="h-5 w-5 text-neutral-600 dark:text-neutral-400" />
                  {unreadCount > 0 && (
                    <span className="absolute top-1 right-1 w-2 h-2 bg-primary rounded-full"></span>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-80" align="end">
                <DropdownMenuLabel className="font-normal">
                  <div className="flex justify-between items-center">
                    <span className="font-semibold">Notifications</span>
                    {unreadCount > 0 && (
                      <Badge variant="outline" className="text-xs">
                        {unreadCount} new
                      </Badge>
                    )}
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                
                {notifications.length === 0 ? (
                  <div className="p-4 text-center text-neutral-500 dark:text-neutral-400">
                    <BellOff className="mx-auto h-6 w-6 mb-2 opacity-50" />
                    <p className="text-sm">No notifications</p>
                  </div>
                ) : (
                  <DropdownMenuGroup className="max-h-[300px] overflow-y-auto py-1">
                    {notifications.map((notification) => (
                      <DropdownMenuItem 
                        key={notification.id} 
                        className={`cursor-pointer p-3 ${notification.read ? 'opacity-70' : 'bg-neutral-50 dark:bg-neutral-800/50'}`}
                        onClick={() => handleNotificationClick(notification)}
                      >
                        <div className="flex gap-3">
                          <div className={`mt-0.5 rounded-full p-1.5 ${
                            notification.type === 'security' ? 'bg-yellow-100 text-yellow-600 dark:bg-yellow-900 dark:text-yellow-300' :
                            notification.type === 'account' ? 'bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-300' :
                            'bg-green-100 text-green-600 dark:bg-green-900 dark:text-green-300'
                          }`}>
                            {notificationIcons[notification.type] || <Notifications className="h-4 w-4" />}
                          </div>
                          <div className="space-y-1">
                            <p className="text-sm font-medium leading-none">
                              {notification.message}
                            </p>
                            <p className="text-xs text-neutral-500 dark:text-neutral-400">
                              {formatDateTime(new Date(notification.timestamp))}
                            </p>
                          </div>
                        </div>
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuGroup>
                )}
                
                <DropdownMenuSeparator />
                <Link href="/settings">
                  <DropdownMenuItem className="cursor-pointer">
                    <span className="text-sm text-center w-full">Manage Notifications</span>
                  </DropdownMenuItem>
                </Link>
              </DropdownMenuContent>
            </DropdownMenu>
            
            {/* Dark mode toggle */}
            <Button variant="ghost" size="icon" onClick={toggleTheme}>
              {theme === "dark" ? (
                <LightMode className="h-5 w-5 text-neutral-600 dark:text-neutral-400" />
              ) : (
                <DarkMode className="h-5 w-5 text-neutral-600 dark:text-neutral-400" />
              )}
            </Button>
            
            {/* User Profile */}
            <UserDropdown user={user} />
            
            {/* Mobile menu button */}
            <Button variant="ghost" size="icon" className="md:hidden" onClick={toggleMobileMenu}>
              <Menu className="h-6 w-6 text-neutral-600 dark:text-neutral-400" />
            </Button>
          </div>
        </div>
        
        {/* Mobile Navigation Menu */}
        <MobileMenu isOpen={mobileMenuOpen} navItems={navItems} currentPath={location} />
      </div>
    </header>
  );
}
