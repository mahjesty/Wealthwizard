import { Link } from "wouter";
import { AccountBalance, Facebook, Twitter, Language, Phone, Email, LocationOn } from "@mui/icons-material";

export default function Footer() {
  return (
    <footer className="bg-white dark:bg-neutral-800 border-t border-neutral-200 dark:border-neutral-700 py-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center mb-4">
              <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center mr-2">
                <AccountBalance className="text-white text-sm" />
              </div>
              <span className="font-bold text-lg text-neutral-900 dark:text-white">Fortis Capital</span>
            </div>
            <p className="text-sm text-neutral-600 dark:text-neutral-400 mb-4">
              Secure, reliable banking solutions for all your financial needs.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-neutral-600 dark:text-neutral-400 hover:text-primary">
                <Facebook />
              </a>
              <a href="#" className="text-neutral-600 dark:text-neutral-400 hover:text-primary">
                <Twitter />
              </a>
              <a href="#" className="text-neutral-600 dark:text-neutral-400 hover:text-primary">
                <Language />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-bold text-neutral-900 dark:text-white mb-4">Products</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-sm text-neutral-600 dark:text-neutral-400 hover:text-primary">Checking Accounts</a></li>
              <li><a href="#" className="text-sm text-neutral-600 dark:text-neutral-400 hover:text-primary">Savings Accounts</a></li>
              <li><a href="#" className="text-sm text-neutral-600 dark:text-neutral-400 hover:text-primary">Credit Cards</a></li>
              <li><a href="#" className="text-sm text-neutral-600 dark:text-neutral-400 hover:text-primary">Loans</a></li>
              <li><a href="#" className="text-sm text-neutral-600 dark:text-neutral-400 hover:text-primary">Mortgages</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold text-neutral-900 dark:text-white mb-4">Support</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-sm text-neutral-600 dark:text-neutral-400 hover:text-primary">Help Center</a></li>
              <li><Link href="/support" className="text-sm text-neutral-600 dark:text-neutral-400 hover:text-primary">Contact Us</Link></li>
              <li><a href="#" className="text-sm text-neutral-600 dark:text-neutral-400 hover:text-primary">Privacy Policy</a></li>
              <li><a href="#" className="text-sm text-neutral-600 dark:text-neutral-400 hover:text-primary">Terms of Service</a></li>
              <li><a href="#" className="text-sm text-neutral-600 dark:text-neutral-400 hover:text-primary">Security</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold text-neutral-900 dark:text-white mb-4">Contact</h4>
            <ul className="space-y-2">
              <li className="flex items-center text-sm text-neutral-600 dark:text-neutral-400">
                <Phone className="text-sm mr-2" />
                1-800-FORTIS-1 (1-800-367-8471)
              </li>
              <li className="flex items-center text-sm text-neutral-600 dark:text-neutral-400">
                <Email className="text-sm mr-2" />
                support@fortiscapital.com
              </li>
              <li className="flex items-center text-sm text-neutral-600 dark:text-neutral-400">
                <LocationOn className="text-sm mr-2" />
                123 Financial St, San Francisco, CA 94103
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-neutral-200 dark:border-neutral-700 mt-8 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-neutral-600 dark:text-neutral-400">
            &copy; {new Date().getFullYear()} Fortis Capital. All rights reserved.
          </p>
          <div className="mt-4 md:mt-0">
            <ul className="flex space-x-6">
              <li><a href="#" className="text-xs text-neutral-600 dark:text-neutral-400 hover:text-primary">Privacy</a></li>
              <li><a href="#" className="text-xs text-neutral-600 dark:text-neutral-400 hover:text-primary">Terms</a></li>
              <li><a href="#" className="text-xs text-neutral-600 dark:text-neutral-400 hover:text-primary">Cookies</a></li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
  );
}
