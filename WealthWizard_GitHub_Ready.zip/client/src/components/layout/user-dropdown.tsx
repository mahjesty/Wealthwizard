import { useState } from "react";
import { Link } from "wouter";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { getInitials } from "@/lib/utils";
import { ArrowDropDown } from "@mui/icons-material";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";

interface UserDropdownProps {
  user: {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
    role: string;
  };
}

export default function UserDropdown({ user }: UserDropdownProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { logout } = useAuth();
  const { toast } = useToast();

  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };

  const closeDropdown = () => {
    setIsOpen(false);
  };

  const handleLogout = async () => {
    try {
      await logout();
      // Navigation and toasts are now handled in the useAuth hook
    } catch (error) {
      toast({
        title: "Error logging out",
        description: "There was a problem logging out. Please try again.",
        variant: "destructive",
      });
    }
  };

  // When clicked outside
  const handleOutsideClick = (e: MouseEvent) => {
    const target = e.target as HTMLElement;
    if (!target.closest("#user-menu-button") && !target.closest("#user-dropdown")) {
      setIsOpen(false);
    }
  };

  // Add event listener for outside clicks
  useState(() => {
    document.addEventListener("click", handleOutsideClick);
    return () => {
      document.removeEventListener("click", handleOutsideClick);
    };
  });

  const fullName = `${user.firstName} ${user.lastName}`;

  return (
    <div className="relative">
      <button
        id="user-menu-button"
        className="flex items-center space-x-2"
        onClick={toggleDropdown}
      >
        <Avatar>
          <AvatarImage src={`https://ui-avatars.com/api/?name=${user.firstName}+${user.lastName}&background=D71E2B&color=fff`} alt={fullName} />
          <AvatarFallback>{getInitials(fullName)}</AvatarFallback>
        </Avatar>
        <span className="hidden md:block text-neutral-900 dark:text-white font-medium">
          {fullName}
        </span>
        <ArrowDropDown className="text-neutral-600 dark:text-neutral-400" />
      </button>

      {isOpen && (
        <div
          id="user-dropdown"
          className="absolute right-0 mt-2 w-48 bg-white dark:bg-neutral-800 rounded-lg shadow-lg py-1 border border-neutral-200 dark:border-neutral-700 z-10"
        >
          <Link 
            href="/profile" 
            className="block px-4 py-2 text-sm text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700"
            onClick={closeDropdown}
          >
            Your Profile
          </Link>
          <Link 
            href="/settings"
            className="block px-4 py-2 text-sm text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700"
            onClick={closeDropdown}
          >
            Settings
          </Link>
          <Link 
            href="/support"
            className="block px-4 py-2 text-sm text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700"
            onClick={closeDropdown}
          >
            Help Center
          </Link>
          {user.role === "admin" && (
            <Link 
              href="/admin"
              className="block px-4 py-2 text-sm text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700"
              onClick={closeDropdown}
            >
              Admin Panel
            </Link>
          )}
          <div className="border-t border-neutral-200 dark:border-neutral-700"></div>
          <button
            className="block w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-neutral-100 dark:hover:bg-neutral-700"
            onClick={handleLogout}
          >
            Sign out
          </button>
        </div>
      )}
    </div>
  );
}
