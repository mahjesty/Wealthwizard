import { Link } from "wouter";
import { 
  Dashboard, 
  AccountBalance, 
  Payment, 
  CreditCard, 
  AttachMoney, 
  ContactSupport,
  Settings,
  ExitToApp
} from "@mui/icons-material";
import { cn } from "@/lib/utils";
import { useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { FortisLogo } from "@/components/ui/fortis-logo";

interface SidebarProps {
  currentPath: string;
  isAdmin?: boolean;
  isOpen?: boolean;
}

export default function Sidebar({ currentPath, isAdmin = false, isOpen = true }: SidebarProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleLogout = async () => {
    try {
      await apiRequest("POST", "/api/auth/logout", {});
      queryClient.clear();
      toast({
        title: "Logged out successfully",
        description: "You have been logged out of your account.",
      });
      window.location.href = "/login";
    } catch (error) {
      toast({
        title: "Error logging out",
        description: "There was a problem logging out. Please try again.",
        variant: "destructive",
      });
    }
  };

  const userNavItems = [
    { name: "Dashboard", path: "/dashboard", icon: <Dashboard className="w-5 h-5" /> },
    { name: "Accounts", path: "/accounts", icon: <AccountBalance className="w-5 h-5" /> },
    { name: "Transfers", path: "/transfers", icon: <Payment className="w-5 h-5" /> },
    { name: "Bill Pay", path: "/bills", icon: <AttachMoney className="w-5 h-5" /> },
    { name: "Cards", path: "/cards", icon: <CreditCard className="w-5 h-5" /> },
    { name: "Support", path: "/support", icon: <ContactSupport className="w-5 h-5" /> },
  ];

  const adminNavItems = [
    { name: "Dashboard", path: "/admin", icon: <Dashboard className="w-5 h-5" /> },
    { name: "Users", path: "/admin/users", icon: <AccountBalance className="w-5 h-5" /> },
    { name: "KYC Verification", path: "/admin/kyc", icon: <CreditCard className="w-5 h-5" /> },
    { name: "Transactions", path: "/admin/transactions", icon: <Payment className="w-5 h-5" /> },
  ];

  const navItems = isAdmin ? adminNavItems : userNavItems;

  return (
    <aside className={cn(
      "bg-sidebar fixed h-full w-64 border-r border-sidebar-border dark:border-sidebar-border transition-all duration-300 z-40",
      isOpen ? "left-0" : "-left-64"
    )}>
      <div className="flex flex-col h-full">
        <div className="flex items-center px-4 py-5">
          {isAdmin ? (
            <>
              <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                <AccountBalance className="text-white" />
              </div>
              <h1 className="text-xl font-bold text-sidebar-foreground ml-2">
                Admin Panel
              </h1>
            </>
          ) : (
            <Link href="/dashboard">
              <FortisLogo width={38} height={38} showText={true} className="text-primary" />
            </Link>
          )}
        </div>

        <nav className="flex-1 px-2 py-4 space-y-1">
          {navItems.map((item) => (
            <Link key={item.path} href={item.path}>
              <a className={cn(
                "flex items-center px-4 py-3 text-sm rounded-md transition-colors",
                currentPath === item.path 
                  ? "bg-sidebar-accent text-sidebar-primary font-medium" 
                  : "text-sidebar-foreground hover:bg-sidebar-accent"
              )}>
                <span className="mr-3">{item.icon}</span>
                {item.name}
              </a>
            </Link>
          ))}
        </nav>

        <div className="p-4 border-t border-sidebar-border">
          <Link href="/settings">
            <a className="flex items-center px-4 py-3 text-sm rounded-md text-sidebar-foreground hover:bg-sidebar-accent">
              <Settings className="mr-3 w-5 h-5" />
              Settings
            </a>
          </Link>
          <button 
            onClick={handleLogout}
            className="w-full flex items-center px-4 py-3 text-sm rounded-md text-sidebar-foreground hover:bg-sidebar-accent"
          >
            <ExitToApp className="mr-3 w-5 h-5" />
            Logout
          </button>
        </div>
      </div>
    </aside>
  );
}
