import { AlertCircle, ShieldAlert, Info, PhoneCall, Clock, HelpCircle, XCircle, ArrowRightCircle, ShieldOff } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Separator } from "@/components/ui/separator";
import { motion } from "framer-motion";

interface RestrictionAlertProps {
  title: string;
  description: string;
  restrictionType?: "login" | "transfer" | "deposit" | "withdrawal" | "card" | "general";
  contactInfo?: boolean;
  securityInfo?: boolean;
  className?: string;
}

export function RestrictionAlert({
  title,
  description,
  restrictionType = "general",
  contactInfo = true,
  securityInfo = true,
  className = ""
}: RestrictionAlertProps) {
  // Get the appropriate icon and color based on restriction type
  const getRestrictionDetails = () => {
    switch (restrictionType) {
      case "login":
        return {
          icon: <ShieldAlert className="h-6 w-6" />,
          variant: "destructive" as const,
          bgClass: "bg-red-50 border-2 border-red-200",
          iconBg: "bg-red-100 text-red-700",
          textColor: "text-red-800",
          restrictionTypeText: "Account Access Restriction",
          securityMessage: "For your protection, access to your account has been temporarily restricted."
        };
      case "transfer":
        return {
          icon: <ArrowRightCircle className="h-6 w-6" />,
          variant: "destructive" as const,
          bgClass: "bg-orange-50 border-2 border-orange-200",
          iconBg: "bg-orange-100 text-orange-700",
          textColor: "text-orange-800",
          restrictionTypeText: "Transfer Restriction",
          securityMessage: "For your security, money transfer functionality has been temporarily disabled."
        };
      case "deposit":
        return {
          icon: <XCircle className="h-6 w-6" />,
          variant: "destructive" as const,
          bgClass: "bg-amber-50 border-2 border-amber-200",
          iconBg: "bg-amber-100 text-amber-700",
          textColor: "text-amber-800",
          restrictionTypeText: "Deposit Restriction",
          securityMessage: "Deposit functionality has been temporarily disabled pending verification."
        };
      case "withdrawal":
        return {
          icon: <ShieldOff className="h-6 w-6" />,
          variant: "destructive" as const,
          bgClass: "bg-red-50 border-2 border-red-200",
          iconBg: "bg-red-100 text-red-700",
          textColor: "text-red-800",
          restrictionTypeText: "Withdrawal Restriction",
          securityMessage: "For your protection, withdrawals have been temporarily suspended."
        };
      case "card":
        return {
          icon: <AlertCircle className="h-6 w-6" />,
          variant: "destructive" as const,
          bgClass: "bg-purple-50 border-2 border-purple-200",
          iconBg: "bg-purple-100 text-purple-700",
          textColor: "text-purple-800",
          restrictionTypeText: "Card Services Restriction",
          securityMessage: "Your card services have been temporarily limited for security purposes."
        };
      case "general":
      default:
        return {
          icon: <Info className="h-6 w-6" />,
          variant: "default" as const,
          bgClass: "bg-blue-50 border-2 border-blue-200",
          iconBg: "bg-blue-100 text-blue-700",
          textColor: "text-blue-800",
          restrictionTypeText: "Account Restriction",
          securityMessage: "Your account access has been temporarily limited."
        };
    }
  };

  const { 
    icon, 
    variant, 
    bgClass, 
    iconBg, 
    textColor,
    restrictionTypeText,
    securityMessage
  } = getRestrictionDetails();

  return (
    <motion.div 
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className={`space-y-4 ${className}`}
    >
      <Alert variant={variant} className={`${bgClass} p-5 shadow-md`}>
        <div className="flex flex-col space-y-4">
          <div className="flex items-start">
            <div className={`mr-3 p-2 rounded-full ${iconBg}`}>
              {icon}
            </div>
            <div>
              <AlertTitle className={`text-lg font-semibold ${textColor}`}>{title}</AlertTitle>
              <div className="text-xs uppercase tracking-wider font-semibold mt-1 mb-2 opacity-75">
                {restrictionTypeText}
              </div>
              <AlertDescription className="text-sm mt-1 leading-relaxed">
                {description}
              </AlertDescription>
            </div>
          </div>
          
          {securityInfo && (
            <div className="bg-white/50 rounded-md p-3 border border-gray-200 mt-2">
              <div className="flex items-center mb-2">
                <ShieldAlert className="h-4 w-4 mr-2 text-red-600" />
                <span className="font-medium text-sm">Security Notice</span>
              </div>
              <p className="text-sm text-gray-700">
                {securityMessage} Please contact customer service for assistance in resolving this matter.
              </p>
            </div>
          )}
        </div>
      </Alert>
      
      {contactInfo && (
        <div className="bg-white rounded-md p-4 border border-gray-200 shadow-sm">
          <div className="font-medium text-base mb-3 flex items-center">
            <HelpCircle className="h-4 w-4 mr-2 text-primary" />
            Customer Support Information
          </div>
          <Separator className="mb-3" />
          <div className="grid md:grid-cols-2 gap-4 text-sm">
            <div className="flex items-center">
              <div className="bg-primary/10 p-2 rounded-full mr-3">
                <PhoneCall className="h-4 w-4 text-primary" />
              </div>
              <div>
                <div className="font-medium">Contact Center</div>
                <div className="text-primary">1-800-FORTIS-HELP</div>
              </div>
            </div>
            <div className="flex items-center">
              <div className="bg-primary/10 p-2 rounded-full mr-3">
                <Clock className="h-4 w-4 text-primary" />
              </div>
              <div>
                <div className="font-medium">Hours of Operation</div>
                <div>Mon-Fri, 8AM - 8PM ET</div>
              </div>
            </div>
          </div>
          <div className="mt-4 text-center">
            <Link href="/support">
              <Button variant="outline" className="text-xs h-8">
                Submit Support Ticket
                <ArrowRightCircle className="h-3 w-3 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      )}
    </motion.div>
  );
}