import { ShieldAlert, AlertTriangle, XCircle, LockIcon, AlertCircle, PhoneCall, Clock, ArrowRightCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Link } from "wouter";

// Import dialog components from shadcn UI
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
} from "@/components/ui/dialog";

interface RestrictionModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  description: string;
  restrictionType?: "login" | "transfer" | "deposit" | "withdrawal" | "card" | "general";
  showContactInfo?: boolean;
}

export function RestrictionModal({
  isOpen,
  onClose,
  title,
  description,
  restrictionType = "login",
  showContactInfo = true
}: RestrictionModalProps) {

  // Get the appropriate icon and styling based on restriction type
  const getRestrictionDetails = () => {
    switch (restrictionType) {
      case "login":
        return {
          icon: <ShieldAlert className="h-10 w-10" />,
          iconColor: "text-red-600",
          backgroundColor: "bg-red-50",
          borderColor: "border-red-200",
          headerColor: "bg-red-600 text-white",
          title: title || "Account Access Restricted",
          alertIcon: <AlertTriangle className="h-5 w-5 text-red-500" />,
          securityMessage: "For your protection, access to your account has been temporarily restricted."
        };
      case "transfer":
        return {
          icon: <XCircle className="h-10 w-10" />,
          iconColor: "text-orange-600",
          backgroundColor: "bg-orange-50",
          borderColor: "border-orange-200",
          headerColor: "bg-orange-600 text-white",
          title: title || "Transfer Functionality Restricted",
          alertIcon: <AlertTriangle className="h-5 w-5 text-orange-500" />,
          securityMessage: "For your security, money transfer functionality has been temporarily disabled."
        };
      case "deposit":
        return {
          icon: <XCircle className="h-10 w-10" />,
          iconColor: "text-amber-600",
          backgroundColor: "bg-amber-50",
          borderColor: "border-amber-200",
          headerColor: "bg-amber-600 text-white",
          title: title || "Deposit Functionality Restricted",
          alertIcon: <AlertTriangle className="h-5 w-5 text-amber-500" />,
          securityMessage: "Deposit functionality has been temporarily disabled pending verification."
        };
      case "withdrawal":
        return {
          icon: <LockIcon className="h-10 w-10" />,
          iconColor: "text-red-600",
          backgroundColor: "bg-red-50",
          borderColor: "border-red-200",
          headerColor: "bg-red-600 text-white",
          title: title || "Withdrawal Functionality Restricted",
          alertIcon: <AlertTriangle className="h-5 w-5 text-red-500" />,
          securityMessage: "For your protection, withdrawals have been temporarily suspended."
        };
      case "card":
        return {
          icon: <AlertCircle className="h-10 w-10" />,
          iconColor: "text-purple-600",
          backgroundColor: "bg-purple-50",
          borderColor: "border-purple-200",
          headerColor: "bg-purple-600 text-white",
          title: title || "Card Services Restricted",
          alertIcon: <AlertTriangle className="h-5 w-5 text-purple-500" />,
          securityMessage: "Your card services have been temporarily limited for security purposes."
        };
      default:
        return {
          icon: <AlertCircle className="h-10 w-10" />,
          iconColor: "text-blue-600",
          backgroundColor: "bg-blue-50",
          borderColor: "border-blue-200",
          headerColor: "bg-blue-600 text-white",
          title: title || "Account Restriction",
          alertIcon: <AlertTriangle className="h-5 w-5 text-blue-500" />,
          securityMessage: "Your account access has been temporarily limited."
        };
    }
  };

  const { 
    icon, 
    iconColor, 
    backgroundColor, 
    borderColor, 
    headerColor,
    title: modalTitle,
    alertIcon,
    securityMessage
  } = getRestrictionDetails();

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md p-0 overflow-hidden gap-0">
        {/* Custom Header */}
        <div className={`${headerColor} p-4 flex items-center -mt-1.5 -mx-1.5 rounded-t-lg`}>
          <div className="bg-white/20 p-2 rounded-full mr-3">
            {icon}
          </div>
          <div>
            <h2 className="text-xl font-semibold">{modalTitle}</h2>
            <p className="text-sm opacity-90">Security Alert</p>
          </div>
        </div>

        {/* Content */}
        <div className={`${backgroundColor} p-5 -mx-1.5`}>
          <div className="mb-4">
            <div className="flex items-start mb-3">
              {alertIcon}
              <p className="ml-2 text-sm font-semibold text-gray-800">SECURITY NOTIFICATION</p>
            </div>
            <p className="text-base text-gray-800 leading-relaxed">{description}</p>
          </div>
          
          <div className="bg-white/70 rounded-md p-3 border border-gray-200 mt-4">
            <div className="flex items-center mb-2">
              <ShieldAlert className="h-4 w-4 mr-2 text-red-600" />
              <span className="font-medium text-sm">Security Notice</span>
            </div>
            <p className="text-sm text-gray-700">
              {securityMessage} Please contact customer service for assistance in resolving this matter.
            </p>
          </div>
        </div>

        {/* Contact Info */}
        {showContactInfo && (
          <div className="bg-white p-4 -mx-1.5 rounded-b-lg">
            <div className="font-medium text-base mb-3 flex items-center">
              <AlertCircle className="h-4 w-4 mr-2 text-primary" />
              <span>Customer Support Information</span>
            </div>
            <Separator className="mb-3" />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm mb-4">
              <div className="flex items-center">
                <div className="bg-primary/10 p-2 rounded-full mr-3">
                  <PhoneCall className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <div className="font-medium">Contact Center</div>
                  <div className="text-primary">1-800-FORTIS-HELP</div>
                </div>
              </div>
              <div className="flex items-center">
                <div className="bg-primary/10 p-2 rounded-full mr-3">
                  <Clock className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <div className="font-medium">Hours of Operation</div>
                  <div>Mon-Fri, 8AM - 8PM ET</div>
                </div>
              </div>
            </div>

            <DialogFooter className="mt-4 flex justify-between sm:justify-between gap-2">
              <Link href="/support">
                <Button variant="outline" size="sm">
                  Contact Support
                  <ArrowRightCircle className="h-3 w-3 ml-1" />
                </Button>
              </Link>
              <Button onClick={onClose} variant="default">
                Acknowledge & Close
              </Button>
            </DialogFooter>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}