import { useState, useEffect } from 'react';
import { Fingerprint, ShieldAlert, Check, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { isWebAuthnSupported, isPlatformAuthenticatorAvailable } from '@/lib/webauthn';
import { FortisLogo } from '@/components/ui/fortis-logo';

interface BiometricPromptProps {
  onSuccess: () => void;
  onCancel: () => void;
  title?: string;
  description?: string;
  bankName?: string;
}

export function BiometricPrompt({
  onSuccess,
  onCancel,
  title = "Biometric Authentication",
  description = "Verify your identity using your device's biometric sensor",
  bankName = "Fortis Capital"
}: BiometricPromptProps) {
  const [status, setStatus] = useState<'idle' | 'verifying' | 'success' | 'error'>('idle');
  const [error, setError] = useState<string | null>(null);
  const [supportsWebAuthn, setSupportsWebAuthn] = useState<boolean | null>(null);

  useEffect(() => {
    // Check if device supports WebAuthn
    const checkSupport = async () => {
      const isSupported = isWebAuthnSupported();
      const isPlatformAvailable = isSupported ? await isPlatformAuthenticatorAvailable() : false;
      
      setSupportsWebAuthn(isSupported && isPlatformAvailable);
      
      if (!isSupported || !isPlatformAvailable) {
        setError('Your device or browser does not support biometric authentication');
        setStatus('error');
      } else {
        // Immediately start the verification when the component mounts
        setStatus('verifying');
        // The actual verification is handled by the parent component logic
        // that triggers device biometrics via WebAuthn
      }
    };
    
    checkSupport();
  }, []);
  
  useEffect(() => {
    // When verification is triggered, attempt to register biometric credentials
    // using the actual WebAuthn API via the parent component
    if (status === 'success') {
      const timer = setTimeout(() => {
        onSuccess();
      }, 1000);
      
      return () => clearTimeout(timer);
    }
  }, [status, onSuccess]);

  const renderContent = () => {
    switch (status) {
      case 'idle':
        return (
          <div className="flex flex-col items-center">
            <Fingerprint className="h-12 w-12 text-primary animate-pulse mb-2" />
            <div className="text-center">
              <p className="text-sm text-muted-foreground">
                Waiting to verify your identity...
              </p>
            </div>
          </div>
        );
      
      case 'verifying':
        return (
          <div className="flex flex-col items-center">
            <Fingerprint className="h-12 w-12 text-primary animate-pulse mb-2" />
            <div className="text-center">
              <p className="text-sm text-muted-foreground">
                Use your fingerprint or face recognition to verify
              </p>
            </div>
          </div>
        );
      
      case 'success':
        return (
          <div className="flex flex-col items-center">
            <div className="bg-green-100 dark:bg-green-900 rounded-full p-2 mb-2">
              <Check className="h-8 w-8 text-green-600 dark:text-green-400" />
            </div>
            <div className="text-center">
              <p className="font-medium">Identity Verified</p>
              <p className="text-sm text-muted-foreground">
                Authentication successful
              </p>
            </div>
          </div>
        );
      
      case 'error':
        return (
          <div className="flex flex-col items-center">
            <div className="bg-red-100 dark:bg-red-900 rounded-full p-2 mb-2">
              <ShieldAlert className="h-8 w-8 text-red-600 dark:text-red-400" />
            </div>
            <div className="text-center">
              <p className="font-medium">Authentication Failed</p>
              <p className="text-sm text-muted-foreground">
                {error || "Please try again or use another method"}
              </p>
            </div>
          </div>
        );
    }
  };

  // Handle events from parent component
  const updateStatus = (newStatus: 'idle' | 'verifying' | 'success' | 'error', errorMsg?: string) => {
    setStatus(newStatus);
    if (errorMsg) {
      setError(errorMsg);
    }
  };

  // Make the updateStatus function accessible to the parent component through a ref
  // if you need to control this component from the parent
  
  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm flex items-center justify-center z-50">
      <Card className="w-[340px] max-w-[95vw] shadow-lg">
        <CardContent className="p-6">
          <div className="text-center mb-6">
            <div className="bg-primary/10 h-20 w-20 rounded-full mx-auto flex items-center justify-center mb-4">
              <Fingerprint className="h-10 w-10 text-primary" />
            </div>
            <h3 className="text-xl font-bold mb-1">{title}</h3>
            <p className="text-sm text-muted-foreground">
              {description}
            </p>
          </div>
          
          <div className="border border-border rounded-md p-4 mb-6">
            <div className="flex items-center gap-3 mb-2">
              <FortisLogo width={32} height={32} className="text-primary" />
              <div>
                <p className="text-sm font-medium">{bankName}</p>
                <p className="text-xs text-muted-foreground">Authentication Request</p>
              </div>
            </div>
            
            <div className="mt-4">
              {renderContent()}
            </div>
          </div>
          
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={onCancel}>
              <X className="mr-2 h-4 w-4" />
              Cancel
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default BiometricPrompt;