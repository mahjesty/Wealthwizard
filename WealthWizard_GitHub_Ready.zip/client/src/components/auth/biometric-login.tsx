import { useState, useEffect } from 'react';
import { Fingerprint, AlertOctagon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import BiometricPrompt from './biometric-prompt';
import { isWebAuthnSupported, isPlatformAuthenticatorAvailable, authenticateWithBiometrics } from '@/lib/webauthn';

interface BiometricLoginProps {
  onBiometricLogin: (username: string, password: string) => void;
  className?: string;
  showUnavailable?: boolean;
}

export function BiometricLogin({ 
  onBiometricLogin, 
  className = '', 
  showUnavailable = true 
}: BiometricLoginProps) {
  const [isAvailable, setIsAvailable] = useState(false);
  const [isRegistered, setIsRegistered] = useState(false);
  const [showBiometricPrompt, setShowBiometricPrompt] = useState(false);
  const { toast } = useToast();
  
  // Check if biometrics are available and registered
  useEffect(() => {
    const checkBiometricStatus = async () => {
      try {
        // Check WebAuthn support
        const webAuthnSupported = isWebAuthnSupported();
        
        if (webAuthnSupported) {
          // Check platform authenticator
          const platformAuthAvailable = await isPlatformAuthenticatorAvailable();
          setIsAvailable(platformAuthAvailable);
          
          if (platformAuthAvailable) {
            // Check if any credentials are registered
            try {
              // Instead of checking existing credentials (which requires authentication),
              // we'll check if WebAuthn login is possible by making a request for login options
              const loginOptionsResponse = await fetch('/api/webauthn/login-options', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                },
                credentials: 'include'
              });
              
              if (loginOptionsResponse.ok) {
                // If we can get login options, consider biometric login available
                setIsRegistered(true);
              } else {
                setIsRegistered(false);
              }
            } catch (err) {
              console.error('Error checking biometric login availability:', err);
              setIsRegistered(false);
            }
          }
        } else {
          setIsAvailable(false);
        }
      } catch (error) {
        console.error('Error checking biometric availability:', error);
        setIsAvailable(false);
      }
    };
    
    checkBiometricStatus();
  }, []);

  const handleBiometricLogin = async () => {
    // Show the biometric prompt UI
    setShowBiometricPrompt(true);
    
    try {
      // This will trigger the actual device biometric verification
      // and perform the server-side login by setting the session
      const { username } = await authenticateWithBiometrics();
      
      console.log("WebAuthn authentication successful for user:", username);
      
      // Show success message (the actual login will be performed by onBiometricLogin)
      toast({
        title: "Biometric Authentication",
        description: "Successfully authenticated with biometrics!",
      });
      
      // We pass the username with an empty password to signal a biometric login
      // The auth hook will handle this specially by using the session that was already set
      setTimeout(() => {
        onBiometricLogin(username, '');
      }, 500);
      
    } catch (error) {
      console.error('Biometric authentication error:', error);
      toast({
        title: "Authentication Failed",
        description: error instanceof Error ? error.message : "Biometric verification failed. Please try again.",
        variant: "destructive"
      });
    } finally {
      setShowBiometricPrompt(false);
    }
  };
  
  const handleAuthCancel = () => {
    setShowBiometricPrompt(false);
    
    toast({
      title: "Authentication Canceled",
      description: "Biometric authentication was canceled.",
    });
  };

  // If biometrics aren't available or registered, show nothing or unavailable message
  if (!isAvailable || !isRegistered) {
    return showUnavailable ? (
      <div className={`mt-4 p-4 flex items-center justify-center gap-2 bg-neutral-100 dark:bg-neutral-800 rounded-md border border-neutral-200 dark:border-neutral-700 ${className}`}>
        <AlertOctagon className="h-5 w-5 text-amber-500" />
        <span className="text-sm text-neutral-600 dark:text-neutral-400">
          Biometric login not available for this device
        </span>
      </div>
    ) : null;
  }

  return (
    <div className={`mt-4 ${className}`}>
      <Button
        variant="outline"
        className="w-full h-12 flex gap-3 items-center justify-center border-neutral-300 dark:border-neutral-700"
        onClick={handleBiometricLogin}
      >
        <Fingerprint className="h-5 w-5 text-primary" />
        <span>Sign in with biometrics</span>
      </Button>
      
      {showBiometricPrompt && (
        <BiometricPrompt
          onSuccess={() => {}}  // Success is handled in handleBiometricLogin
          onCancel={handleAuthCancel}
        />
      )}
    </div>
  );
}

export default BiometricLogin;