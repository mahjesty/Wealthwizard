import { useState, useEffect, useCallback, useRef } from 'react';
import { Fingerprint, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { authenticateWithBiometrics, isWebAuthnSupported, isPlatformAuthenticatorAvailable } from '@/lib/webauthn';
import BiometricPrompt from './biometric-prompt';

interface BiometricAuthProps {
  onBiometricSuccess: (username: string) => void;
  className?: string;
}

export function BiometricAuth({ onBiometricSuccess, className = '' }: BiometricAuthProps) {
  const [isBiometricSupported, setIsBiometricSupported] = useState<boolean | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showPrompt, setShowPrompt] = useState(false);
  const { toast } = useToast();
  
  // Ref to avoid race conditions in state updates with async operations
  const loadingRef = useRef(false);

  // Check biometric availability on component mount
  useEffect(() => {
    const checkBiometricAvailability = async () => {
      try {
        // Check if the browser supports WebAuthn
        const isSupported = isWebAuthnSupported();
        
        if (isSupported) {
          // Check if platform authenticator is available
          const isPlatformAvailable = await isPlatformAuthenticatorAvailable();
          setIsBiometricSupported(isPlatformAvailable);
        } else {
          setIsBiometricSupported(false);
        }
      } catch (error) {
        console.error('Error checking biometric support:', error);
        setIsBiometricSupported(false);
      }
    };

    checkBiometricAvailability();
  }, []);

  const handleBiometricAuth = useCallback(async () => {
    // Avoid duplicate auth attempts
    if (loadingRef.current) return;
    
    loadingRef.current = true;
    setIsLoading(true);
    
    try {
      // Show the biometric prompt
      setShowPrompt(true);
      
      // The actual WebAuthn verification begins
      // This will trigger the native biometric UI in the browser
      const { username } = await authenticateWithBiometrics();
      
      toast({
        title: "Biometric verification successful",
        description: "Your identity has been verified using your device biometrics.",
      });
      
      // Pass credentials to parent component
      setTimeout(() => {
        onBiometricSuccess(username);
      }, 1000);
      
    } catch (error) {
      console.error('Biometric authentication error:', error);
      toast({
        title: "Authentication failed",
        description: "Biometric authentication failed. Please try again or use your password.",
        variant: "destructive",
      });
      
      setShowPrompt(false);
    } finally {
      // Keep isLoading true while the success animation plays in the BiometricPrompt
      // component before calling onBiometricSuccess
      setTimeout(() => {
        setIsLoading(false);
        loadingRef.current = false;
      }, 500);
    }
  }, [onBiometricSuccess, toast]);

  const handlePromptCancel = () => {
    setShowPrompt(false);
    setIsLoading(false);
    loadingRef.current = false;
    
    toast({
      title: "Authentication Canceled",
      description: "Biometric authentication was canceled.",
    });
  };
  
  const handlePromptSuccess = () => {
    // Will close the prompt after showing success animation
    // The actual auth success is handled in handleBiometricAuth
    setShowPrompt(false);
  };

  // If we haven't determined biometric support yet
  if (isBiometricSupported === null) {
    return null;
  }

  // If biometric authentication is not supported
  if (!isBiometricSupported) {
    return (
      <div className={`flex items-center gap-2 text-sm text-muted-foreground ${className}`}>
        <AlertCircle className="h-4 w-4" />
        <span>Biometric login is not available on this device</span>
      </div>
    );
  }

  return (
    <>
      <Button
        type="button"
        variant="outline"
        onClick={handleBiometricAuth}
        disabled={isLoading}
        className={`gap-2 ${className}`}
      >
        <Fingerprint className={`h-4 w-4 ${isLoading ? 'animate-pulse' : ''}`} />
        {isLoading ? "Verifying..." : "Sign in with Biometrics"}
      </Button>
      
      {showPrompt && (
        <BiometricPrompt 
          onSuccess={handlePromptSuccess}
          onCancel={handlePromptCancel}
        />
      )}
    </>
  );
}

export default BiometricAuth;